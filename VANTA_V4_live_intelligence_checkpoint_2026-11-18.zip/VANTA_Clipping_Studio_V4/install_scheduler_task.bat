@echo off
setlocal
rem Creates an opt-in per-user Task Scheduler entry which starts the local
rem VANTA backend at logon. It does not enable scheduling or upload anything.
cd /d "%~dp0"
call "%~dp0_find_python.bat"
if not defined STUDIO_PYTHON (
  echo Python 3.10+ backend environment not found. Run setup_backend.bat first.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  exit /b 1
)
where schtasks >nul 2>nul || (
  echo Windows Task Scheduler command was not found.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  exit /b 1
)
if not exist "%~dp0start_backend.bat" (
  echo start_backend.bat is missing.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  exit /b 1
)
schtasks /Create /TN "VANTA Clipping Studio Backend" /SC ONLOGON /RL LIMITED /F /TR "cmd.exe /c \"\"%~dp0start_backend.bat\"\""
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" (
  echo Installed the per-user backend startup task.
  echo The VANTA scheduler itself remains disabled until enabled in Settings.
) else (
  echo Could not create the Task Scheduler entry. Run this batch as the intended Windows user.
)
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%
