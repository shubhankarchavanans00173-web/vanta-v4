@echo off
rem Sets STUDIO_PYTHON to the one Python interpreter used by every VANTA script.
rem Priority: VANTA_PYTHON, python_env.txt, C:\ai-video-env, then this folder's .venv.
set "STUDIO_PYTHON="
if defined VANTA_PYTHON if exist "%VANTA_PYTHON%" set "STUDIO_PYTHON=%VANTA_PYTHON%"
if not defined STUDIO_PYTHON if exist "%~dp0python_env.txt" (
  for /f "usebackq delims=" %%P in ("%~dp0python_env.txt") do if not defined STUDIO_PYTHON if exist "%%P" set "STUDIO_PYTHON=%%P"
)
if not defined STUDIO_PYTHON if exist "C:\ai-video-env\Scripts\python.exe" set "STUDIO_PYTHON=C:\ai-video-env\Scripts\python.exe"
if not defined STUDIO_PYTHON if exist "%~dp0.venv\Scripts\python.exe" set "STUDIO_PYTHON=%~dp0.venv\Scripts\python.exe"
if not defined STUDIO_PYTHON exit /b 1
"%STUDIO_PYTHON%" -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 (
  set "STUDIO_PYTHON="
  exit /b 1
)
exit /b 0
