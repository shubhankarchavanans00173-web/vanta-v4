@echo off
setlocal
cd /d "%~dp0frontend"
where node >nul 2>nul || ( echo Node.js 20+ is required. Install it from https://nodejs.org and reopen this window. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
where npm >nul 2>nul || ( echo npm was not found with Node.js. Reinstall Node.js 20+. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
node --version
npm install --no-audit --no-fund
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Frontend dependency installation failed.
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%
