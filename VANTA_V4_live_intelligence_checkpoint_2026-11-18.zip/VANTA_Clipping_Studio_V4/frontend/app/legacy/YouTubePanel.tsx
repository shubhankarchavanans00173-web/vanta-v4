"use client";

import type {StudioState} from "./useStudioState";

/** YouTube section of the legacy studio (extracted verbatim from the single page). */
export function YouTubePanel({s}:{s:StudioState}) {
  const {content, busy, uploading, voice, yt, ytPrivacy, setYtPrivacy, ytKids, setYtKids, ytAi, setYtAi, ytSchedule, setYtSchedule, ytThumb, setYtThumb, current, ytConnect, ytDisconnect, ytUpload} = s;
  return (<>  {current&&current.status==="completed"&&current.output_path&&current.settings?.input_type!=="video_clips"&&<section className="panel youtube-panel"><h2>Publish to YouTube</h2>
   {!yt||!yt.libraries?<p className="muted small">YouTube libraries are missing. Re-run setup_backend.bat.</p>:!yt.client_secret_found?<p className="muted small">One-time setup needed: save your Google OAuth client file as <code>{yt.client_secret_path}</code>. Follow docs/YOUTUBE_SETUP.md (about 5 minutes).</p>:!yt.connected?<div className="actions"><button disabled={yt.connect_state==="waiting"} onClick={ytConnect}>{yt.connect_state==="waiting"?"Waiting for browser sign-in…":"Connect YouTube"}</button>{yt.connect_error&&<span className="muted small">{yt.connect_error}</span>}</div>:<>
   <p className="muted small">Connected as <b>{yt.channel}</b> · <a href="#" onClick={e=>{e.preventDefault();ytDisconnect()}}>disconnect</a></p>
   <div className="row"><div className="field"><label>VISIBILITY</label><select value={ytPrivacy} disabled={!!ytSchedule} onChange={event=>setYtPrivacy(event.target.value)}><option value="private">Private (safe default)</option><option value="unlisted">Unlisted</option><option value="public">Public</option></select></div><div className="field"><label>SCHEDULE (OPTIONAL, YOUR LOCAL TIME)</label><input type="datetime-local" value={ytSchedule} onChange={event=>setYtSchedule(event.target.value)}/></div></div>
   <div className="checks"><label><input type="checkbox" checked={ytAi} onChange={event=>setYtAi(event.target.checked)}/> Disclose altered / synthetic content (recommended for AI voice or generated visuals)</label><label><input type="checkbox" checked={ytKids} onChange={event=>setYtKids(event.target.checked)}/> Made for kids</label><label><input type="checkbox" checked={ytThumb} onChange={event=>setYtThumb(event.target.checked)}/> Upload generated thumbnail</label></div>
   <div className="actions"><button disabled={busy||current.settings?.youtube?.state==="uploading"||current.settings?.youtube?.state==="queued"} onClick={()=>ytUpload(current.id)}>{current.settings?.youtube?.state==="uploading"?`Uploading… ${current.settings.youtube.progress||0}%`:"Upload to YouTube"}</button></div></>}
   {current.settings?.youtube?.state==="done"&&<div className="notice"><b>Uploaded.</b> <a href={current.settings.youtube.url} target="_blank" rel="noreferrer">{current.settings.youtube.url}</a> · <a href={current.settings.youtube.studio_url} target="_blank" rel="noreferrer">Open in YouTube Studio</a>{(current.settings.youtube.notes||[]).map((n:string,i:number)=><p className="muted small" key={i}>{n}</p>)}</div>}
   {current.settings?.youtube?.state==="error"&&<div className="notice error" role="alert">{current.settings.youtube.error}</div>}
  </section>}</>);
}
