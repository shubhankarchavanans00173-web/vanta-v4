export type Scene={id?:number;title:string;narration:string;caption?:string;start_seconds?:number;end_seconds?:number};
export type Job={id:string;topic:string;script:string;status:string;progress:number;settings:any;output_path?:string;error?:string;created_at:string};
export type GenerationMode="motion_graphics"|"local_ai"|"online_ai"|"hybrid";
