export const API=process.env.NEXT_PUBLIC_API_URL||"http://127.0.0.1:8000";

export async function readResponse(response:Response){
 const data=await response.json().catch(()=>({}));
 if(!response.ok) throw Error(data.detail||data.message||"Request failed");
 return data;
}
