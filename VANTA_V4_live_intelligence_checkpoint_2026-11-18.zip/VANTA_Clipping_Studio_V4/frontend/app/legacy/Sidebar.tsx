"use client";

import type {StudioState} from "./useStudioState";

/** Sidebar section of the legacy studio (extracted verbatim from the single page). */
export function Sidebar({s}:{s:StudioState}) {
  const {diagnostic, activeNav, navigateTo, create} = s;
  return (<>  <aside className="sidebar" aria-label="Studio navigation">
   <button className="workspace-mark" onClick={()=>navigateTo("create")} aria-label="Go to video creation"><span className="mark-icon">V</span><span><b>VANTA</b><small>AI VIDEO STUDIO</small></span></button>
   <div className="nav-label">WORKSPACE</div>
   <nav className="side-nav">
    <button className={activeNav==="create"?"active":""} onClick={()=>navigateTo("create")}><span className="nav-icon">✳</span>Create Video</button>
    <button className={activeNav==="script"?"active":""} onClick={()=>navigateTo("script")}><span className="nav-icon">≡</span>Script to Video</button>
    <button className={activeNav==="clips"?"active":""} onClick={()=>navigateTo("clips")}><span className="nav-icon">▤</span>Video to Clips</button>
    <button className={activeNav==="history"?"active":""} onClick={()=>navigateTo("history")}><span className="nav-icon">◷</span>Projects & History</button>
   </nav>
   <div className="nav-label nav-label-spaced">SYSTEM</div>
   <nav className="side-nav">
    <button className={activeNav==="providers"?"active":""} onClick={()=>navigateTo("providers")}><span className="nav-icon">◈</span>Models & Providers</button>
    <button className={activeNav==="settings"?"active":""} onClick={()=>navigateTo("settings")}><span className="nav-icon">⚙</span>Settings</button>
   </nav>
   <div className="sidebar-spacer"/>
   <div className="sidebar-provider"><span className={"provider-dot "+(diagnostic?.providers?.local?.available?"ready":"")}/><div><b>{diagnostic?.providers?.local?.available?"Local model ready":diagnostic?"Local model unavailable":"Checking providers…"}</b><small>{diagnostic?.providers?.local?.model||"Provider status not verified"}</small></div></div>
   <div className="sidebar-footer"><span className="avatar">L</span><span><b>Local workspace</b><small>Private · on this device</small></span></div>
  </aside></>);
}
