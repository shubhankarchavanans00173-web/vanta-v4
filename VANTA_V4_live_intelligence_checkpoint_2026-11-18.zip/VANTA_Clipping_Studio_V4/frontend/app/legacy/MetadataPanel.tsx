"use client";

import type {StudioState} from "./useStudioState";

/** Metadata section of the legacy studio (extracted verbatim from the single page). */
export function MetadataPanel({s}:{s:StudioState}) {
  const {metadataEdit, setMetadataEdit, busy, current, canEdit, saveMetadata, changeMetadataList} = s;
  return (<>  {current&&<section className="panel metadata"><h2>03 / Metadata</h2><p className="muted small">Edit title suggestions, description and hashtags before export or any future publishing integration.</p><div className="field"><label>TITLE SUGGESTIONS</label>{metadataEdit.titles.map((title,index)=><input key={index} disabled={!canEdit||busy} value={title} onChange={event=>changeMetadataList("titles",index,event.target.value)} placeholder={`Title ${index+1}`}/>)}</div><div className="field"><label>DESCRIPTION</label><textarea disabled={!canEdit||busy} value={metadataEdit.description} onChange={event=>setMetadataEdit(current=>({...current,description:event.target.value}))}/></div><div className="field"><label>HASHTAGS</label>{metadataEdit.hashtags.map((tag,index)=><input key={index} disabled={!canEdit||busy} value={tag} onChange={event=>changeMetadataList("hashtags",index,event.target.value)} placeholder="#shorts"/>)}<button className="secondary small-button" disabled={!canEdit||busy||metadataEdit.hashtags.length>=20} onClick={()=>setMetadataEdit(current=>({...current,hashtags:[...current.hashtags,""]}))}>Add hashtag</button></div><div className="actions"><button disabled={!canEdit||busy} onClick={saveMetadata}>Save metadata</button></div></section>}</>);
}
