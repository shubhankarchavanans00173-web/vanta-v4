"use client";

import {useCallback,useEffect,useMemo,useState} from "react";
import {API,readResponse} from "./api";
import type {GenerationMode,Job,Scene} from "./types";

/** Every piece of studio state and every handler, in one hook.
 *  Extracted verbatim from the original single page so behaviour is unchanged;
 *  the panels below receive this object and use the same names as before. */
export function useStudioState(){
 const [inputType,setInputType]=useState("topic"),[topic,setTopic]=useState(""),[content,setContent]=useState(""),[youtubeUrl,setYoutubeUrl]=useState("");
 const [sourceId,setSourceId]=useState(""),[sourceName,setSourceName]=useState(""),[sourceUrl,setSourceUrl]=useState(""),[sourceAuthorized,setSourceAuthorized]=useState(false),[clipCount,setClipCount]=useState("5"),[clipDuration,setClipDuration]=useState("15"),[clipTitle,setClipTitle]=useState(""),[clipTitleOverlay,setClipTitleOverlay]=useState(true),[subtitleId,setSubtitleId]=useState(""),[subtitleName,setSubtitleName]=useState(""),[musicId,setMusicId]=useState(""),[musicName,setMusicName]=useState(""),[soundEffectsId,setSoundEffectsId]=useState(""),[soundEffectsName,setSoundEffectsName]=useState(""),[referenceId,setReferenceId]=useState(""),[referenceName,setReferenceName]=useState("");
 const [duration,setDuration]=useState("45"),[ratio,setRatio]=useState("9:16"),[resolution,setResolution]=useState("quality"),[frameRate,setFrameRate]=useState("30");
 const [style,setStyle]=useState("cinematic"),[generationMode,setGenerationMode]=useState<GenerationMode>("motion_graphics"),[hybridOnlineEnabled,setHybridOnlineEnabled]=useState(false),[characterDescription,setCharacterDescription]=useState(""),[environmentDescription,setEnvironmentDescription]=useState(""),[language,setLanguage]=useState("English"),[mode,setMode]=useState("manual"),[narration,setNarration]=useState(true),[speed,setSpeed]=useState("1"),[captions,setCaptions]=useState(true);
 const [jobs,setJobs]=useState<Job[]>([]),[selected,setSelected]=useState<Job|null>(null),[scriptEdit,setScriptEdit]=useState(""),[sceneEdit,setSceneEdit]=useState<Scene[]>([]),[metadataEdit,setMetadataEdit]=useState({titles:[""],description:"",hashtags:[""]});
 const [busy,setBusy]=useState(false),[uploading,setUploading]=useState(false),[message,setMessage]=useState(""),[diagnostic,setDiagnostic]=useState<any>(null);
 const [activeNav,setActiveNav]=useState("create"),[historySearch,setHistorySearch]=useState("");
 // Studio Pro options
 const [visualSource,setVisualSource]=useState("auto"),[narrationEngine,setNarrationEngine]=useState("edge"),[voice,setVoice]=useState("en-US-AndrewNeural"),[voices,setVoices]=useState<{id:string;label:string}[]>([]),[captionStyle,setCaptionStyle]=useState("karaoke"),[musicVolume,setMusicVolume]=useState("0.12"),[transitions,setTransitions]=useState(true),[progressBar,setProgressBar]=useState(true),[watermark,setWatermark]=useState(""),[channelName,setChannelName]=useState(""),[accentColor,setAccentColor]=useState("");
 // YouTube publishing
 const [yt,setYt]=useState<any>(null),[ytPrivacy,setYtPrivacy]=useState("private"),[ytKids,setYtKids]=useState(false),[ytAi,setYtAi]=useState(true),[ytSchedule,setYtSchedule]=useState(""),[ytThumb,setYtThumb]=useState(true);

 const refresh=useCallback(async()=>{
  try{const list:Job[]=await readResponse(await fetch(API+"/api/jobs"));setJobs(previous=>{
   const unchanged=previous.length===list.length&&previous.every((job,index)=>{const next=list[index];return job.id===next?.id&&job.status===next?.status&&job.progress===next?.progress&&job.output_path===next?.output_path&&job.error===next?.error&&job.script===next?.script&&job.settings?.status_message===next?.settings?.status_message&&JSON.stringify([job.settings?.scenes,job.settings?.metadata,job.settings?.validation,job.settings?.generated_clips,job.settings?.render_notice])===JSON.stringify([next?.settings?.scenes,next?.settings?.metadata,next?.settings?.validation,next?.settings?.generated_clips,next?.settings?.render_notice])});
   return unchanged?previous:list;
  })}
  catch(error){const detail=error instanceof Error?error.message:String(error);setMessage(`Backend unavailable at ${API}. Start start_backend.bat and check that port 8000 is listening. ${detail}`)}
 },[]);
 const getDiagnostics=useCallback(async()=>{try{setDiagnostic(await readResponse(await fetch(API+"/api/diagnostics")))}catch{setDiagnostic(null)}},[]);
 useEffect(()=>{refresh();getDiagnostics();const timer=setInterval(refresh,3000);return()=>clearInterval(timer)},[refresh,getDiagnostics]);
 const outputSize=useMemo(()=>{
  const sizes:any={draft:{"9:16":"360 × 640","16:9":"640 × 360","1:1":"480 × 480"},balanced:{"9:16":"720 × 1280","16:9":"1280 × 720","1:1":"900 × 900"},quality:{"9:16":"1080 × 1920","16:9":"1920 × 1080","1:1":"1080 × 1080"}};
  return sizes[resolution]?.[ratio]||"";
 },[resolution,ratio]);
 const current=selected?(jobs.find(job=>job.id===selected.id)||selected):null;
 const canEdit=!!current&&["draft","failed","cancelled","completed"].includes(current.status);
 const usesOnlineVideo=generationMode==="online_ai"||(generationMode==="hybrid"&&hybridOnlineEnabled);
 const filteredJobs=useMemo(()=>jobs.filter(job=>`${job.topic} ${job.id} ${job.status} ${job.settings?.generation_mode||""}`.toLowerCase().includes(historySearch.toLowerCase())),[jobs,historySearch]);
 function navigateTo(section:string){
  setActiveNav(section);
  if(section==="create")setInputType("topic");
  if(section==="script")setInputType("script");
  if(section==="clips")setInputType("video_clips");
  window.setTimeout(()=>{const target=document.getElementById(section==="providers"?"studio-providers":section==="settings"?"studio-settings":section==="history"?"studio-history":"studio-create");if(target instanceof HTMLDetailsElement&&section==="settings")target.open=true;target?.scrollIntoView({behavior:"smooth",block:"start"})},0);
 }

 async function upload(file:File|undefined,kind:"video"|"audio"|"image"|"subtitle",audioRole:"music"|"sound_effects"="music"){
  if(!file)return;setUploading(true);setMessage("");
  try{const body=new FormData();body.append("file",file);const data=await readResponse(await fetch(API+"/api/uploads?kind="+kind,{method:"POST",body}));
   if(kind==="video"){setSourceId(data.upload_id);setSourceName(data.name);setSourceUrl("")}else if(kind==="audio"){if(audioRole==="sound_effects"){setSoundEffectsId(data.upload_id);setSoundEffectsName(data.name)}else{setMusicId(data.upload_id);setMusicName(data.name)}}else if(kind==="subtitle"){setSubtitleId(data.upload_id);setSubtitleName(data.name)}else{setReferenceId(data.upload_id);setReferenceName(data.name)}
   setMessage(data.name+" stored locally for this project.");
  }catch(error:any){setMessage(error.message)}finally{setUploading(false)}
 }
 async function loadTextFile(file:File|undefined){
  if(!file)return;
  try{const text=await file.text();if(text.length>30000){setMessage("Text files are limited to 30,000 characters.");return}setContent(text);setMessage(`Loaded ${file.name} into the local script editor.`)}
  catch(error){setMessage(error instanceof Error?error.message:String(error))}
 }
 async function create(){
  const isClips=inputType==="video_clips";
  if(isClips&&(!sourceId&&!sourceUrl.trim())){setMessage("Upload a source video or provide a direct HTTPS media URL.");return}
  if(isClips&&!sourceAuthorized){setMessage("Confirm that you have permission to create clips from this source.");return}
  if(inputType==="source_video"&&!sourceId){setMessage("Upload an authorized source video first.");return}
  const text=content.trim();if(!isClips&&inputType!=="source_video"&&!topic.trim()&&!text){setMessage("Enter a topic, script, story, or transcript.");return}
  setBusy(true);setMessage("");const isScript=inputType==="script",isText=["story","transcript","youtube_remake"].includes(inputType);
  const payload={topic:topic.trim()||(inputType==="source_video"?sourceName:isClips?(sourceName||"Source video clips"):""),script:isScript?text:null,source_text:isText?text:null,input_type:inputType,source_upload_id:inputType==="source_video"||isClips&&sourceId?sourceId:null,source_video_url:isClips&&!sourceId?sourceUrl.trim():null,source_authorized:isClips?sourceAuthorized:false,clip_count:Number(clipCount),clip_duration_seconds:Number(clipDuration),clip_title:clipTitle,clip_title_overlay:clipTitleOverlay,subtitle_upload_id:subtitleId||null,music_upload_id:musicId||null,sound_effects_upload_id:soundEffectsId||null,duration_seconds:Number(duration),aspect_ratio:ratio,resolution_preset:resolution,frame_rate:Number(frameRate),visual_style:style,generation_mode:inputType==="source_video"||isClips?"motion_graphics":generationMode,hybrid_online_enabled:inputType!=="source_video"&&!isClips&&generationMode==="hybrid"&&hybridOnlineEnabled,character_description:characterDescription,environment_description:environmentDescription,workflow_mode:mode,language,narration,narration_speed:Number(speed),captions,visual_source:visualSource,narration_engine:narrationEngine,voice,caption_style:captionStyle,music_volume:Number(musicVolume),transitions,progress_bar:progressBar,watermark:watermark.trim(),channel_name:channelName.trim(),accent_color:/^#[0-9a-fA-F]{6}$/.test(accentColor)?accentColor:"",reference_upload_ids:referenceId&&generationMode==="motion_graphics"?[referenceId]:(usesOnlineVideo&&referenceId?[referenceId]:[])};
  try{const job=await readResponse(await fetch(API+"/api/jobs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)}));selectJob(job);setTopic("");setContent("");setMessage(job.status==="queued"?"Job queued for the selected renderer.":job.settings?.status_message||"Job created. Review its storyboard, then produce it.");await refresh()}
  catch(error:any){setMessage(error.message)}finally{setBusy(false)}
 }
 async function action(id:string,verb:string){
  const target=jobs.find(job=>job.id===id)||selected;
  const paid=target?.settings?.generation_mode==="online_ai"||(target?.settings?.generation_mode==="hybrid"&&target?.settings?.hybrid_online_enabled);
  let options:RequestInit={method:"POST"};
  if(paid&&verb!=="cancel"){
   if(!diagnostic?.providers?.online?.configured){setMessage(diagnostic?.providers?.online?.detail||"Replicate is not configured in the backend.");return}
   const estimate=diagnostic.providers.online.estimated_cost_usd;
   const cost=typeof estimate==="number"?`Estimated cost: $${estimate.toFixed(2)}.`:"No fixed per-video estimate is available; provider charges may apply at current Replicate rates.";
   if(!window.confirm(`This will send your prompt${referenceId?" and reference image":""} to ${diagnostic.providers.online.provider} for generation. ${cost} Review the model pricing and account spending controls before continuing. Approve this paid request?`))return;
   options={method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({approve_online:true})};
  }
  try{const data=await readResponse(await fetch(API+"/api/jobs/"+id+"/"+verb,options));setMessage(data.message||"Request accepted.");await refresh()}catch(error:any){setMessage(error.message)}
 }
 async function regenerateScene(id:string,sceneId:number){
  const target=jobs.find(job=>job.id===id)||selected;
  const paid=target?.settings?.generation_mode==="online_ai"||(target?.settings?.generation_mode==="hybrid"&&target?.settings?.hybrid_online_enabled);
  let options:RequestInit={method:"POST"};
  if(paid){
   if(!diagnostic?.providers?.online?.configured){setMessage(diagnostic?.providers?.online?.detail||"Replicate is not configured in the backend.");return}
   if(!window.confirm(`Regenerating scene ${sceneId} will make a new paid Replicate video request. No fixed per-video estimate is available; provider charges may apply. Review pricing and approve this request?`))return;
   options={method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({approve_online:true})};
  }
  try{const data=await readResponse(await fetch(`${API}/api/jobs/${id}/scenes/${sceneId}/regenerate`,options));setMessage(data.message||`Scene ${sceneId} regeneration queued.`);await refresh()}catch(error:any){setMessage(error.message)}
 }
 async function saveScript(){
  if(!current)return;setBusy(true);
  try{const job=await readResponse(await fetch(API+"/api/jobs/"+current.id+"/script",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({script:scriptEdit})}));selectJob(job);setMessage("Script saved and storyboard rebuilt.");await refresh()}catch(error:any){setMessage(error.message)}finally{setBusy(false)}
 }
 async function saveScenes(){
  if(!current)return;setBusy(true);
  try{const job=await readResponse(await fetch(API+"/api/jobs/"+current.id+"/storyboard",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({scenes:sceneEdit})}));selectJob(job);setMessage("Storyboard saved.");await refresh()}catch(error:any){setMessage(error.message)}finally{setBusy(false)}
 }
 async function saveMetadata(){
  if(!current)return;setBusy(true);
  try{const payload={titles:metadataEdit.titles.filter(value=>value.trim()),description:metadataEdit.description,hashtags:metadataEdit.hashtags.filter(value=>value.trim())};const job=await readResponse(await fetch(API+"/api/jobs/"+current.id+"/metadata",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)}));selectJob(job);setMessage("Metadata saved.");await refresh()}catch(error:any){setMessage(error.message)}finally{setBusy(false)}
 }
 async function analyzeYoutube(){
  if(!youtubeUrl.trim()){setMessage("Paste a YouTube URL first.");return}
  try{const result=await readResponse(await fetch(API+"/api/youtube/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:youtubeUrl,mode:"remake"})}));setMessage(result.message)}catch(error:any){setMessage(error.message)}
 }

 const ytRefresh=useCallback(async()=>{try{setYt(await readResponse(await fetch(API+"/api/youtube/status")))}catch{setYt(null)}},[]);
 useEffect(()=>{ytRefresh();fetch(API+"/api/voices").then(r=>r.json()).then(d=>d.voices&&setVoices(d.voices)).catch(()=>{})},[ytRefresh]);
 useEffect(()=>{if(yt?.connect_state==="waiting"){const t=setInterval(ytRefresh,2500);return()=>clearInterval(t)}},[yt?.connect_state,ytRefresh]);
 async function ytConnect(){try{await readResponse(await fetch(API+"/api/youtube/connect",{method:"POST"}));setMessage("A browser window is opening - sign in and allow access, then return here.");setYt((v:any)=>({...v,connect_state:"waiting"}))}catch(error:any){setMessage(error.message)}}
 async function ytDisconnect(){await fetch(API+"/api/youtube/disconnect",{method:"POST"});ytRefresh()}
 async function ytUpload(id:string){
  const meta=current?.settings?.metadata||{};
  const body:any={title:(metadataEdit.titles[0]||meta.titles?.[0]||"").trim(),privacy:ytPrivacy,made_for_kids:ytKids,ai_disclosure:ytAi,set_thumbnail:ytThumb};
  if(ytSchedule){body.publish_at=new Date(ytSchedule).toISOString().replace(/\.\d+Z$/,"Z");body.privacy="private"}
  if(ytPrivacy==="public"&&!ytSchedule&&!window.confirm("Publish this video publicly right now?"))return;
  try{await readResponse(await fetch(API+"/api/jobs/"+id+"/youtube/upload",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}));setMessage("Upload started - progress shows in the YouTube panel.");await refresh()}catch(error:any){setMessage(error.message)}
 }
 async function deleteJob(id:string){if(!window.confirm("Delete this project and its files?"))return;try{await readResponse(await fetch(API+"/api/jobs/"+id,{method:"DELETE"}));if(selected?.id===id)setSelected(null);await refresh()}catch(error:any){setMessage(error.message)}}
 function selectJob(job:Job){setSelected(job);setScriptEdit(job.script||"");setSceneEdit(job.settings?.scenes||[]);const metadata=job.settings?.metadata||{};setMetadataEdit({titles:metadata.titles?.length?metadata.titles:[""],description:metadata.description||"",hashtags:metadata.hashtags?.length?metadata.hashtags:[""]})}
 function changeScene(index:number,key:"title"|"narration"|"caption",value:string){setSceneEdit(items=>items.map((scene,itemIndex)=>itemIndex===index?{...scene,[key]:value}:scene))}
 function changeMetadataList(key:"titles"|"hashtags",index:number,value:string){setMetadataEdit(current=>({...current,[key]:current[key].map((item,itemIndex)=>itemIndex===index?value:item)}))}

 return {inputType, setInputType, topic, setTopic, content, setContent, youtubeUrl, setYoutubeUrl, sourceId, setSourceId, sourceName, setSourceName, sourceUrl, setSourceUrl, sourceAuthorized, setSourceAuthorized, clipCount, setClipCount, clipDuration, setClipDuration, clipTitle, setClipTitle, clipTitleOverlay, setClipTitleOverlay, subtitleId, setSubtitleId, subtitleName, setSubtitleName, musicId, setMusicId, musicName, setMusicName, soundEffectsId, setSoundEffectsId, soundEffectsName, setSoundEffectsName, referenceId, setReferenceId, referenceName, setReferenceName, duration, setDuration, ratio, setRatio, resolution, setResolution, frameRate, setFrameRate, style, setStyle, generationMode, setGenerationMode, hybridOnlineEnabled, setHybridOnlineEnabled, characterDescription, setCharacterDescription, environmentDescription, setEnvironmentDescription, language, setLanguage, mode, setMode, narration, setNarration, speed, setSpeed, captions, setCaptions, jobs, setJobs, selected, setSelected, scriptEdit, setScriptEdit, sceneEdit, setSceneEdit, metadataEdit, setMetadataEdit, busy, setBusy, uploading, setUploading, message, setMessage, diagnostic, setDiagnostic, activeNav, setActiveNav, historySearch, setHistorySearch, visualSource, setVisualSource, narrationEngine, setNarrationEngine, voice, setVoice, voices, setVoices, captionStyle, setCaptionStyle, musicVolume, setMusicVolume, transitions, setTransitions, progressBar, setProgressBar, watermark, setWatermark, channelName, setChannelName, accentColor, setAccentColor, yt, setYt, ytPrivacy, setYtPrivacy, ytKids, setYtKids, ytAi, setYtAi, ytSchedule, setYtSchedule, ytThumb, setYtThumb, refresh, getDiagnostics, outputSize, current, canEdit, usesOnlineVideo, filteredJobs, ytRefresh, navigateTo, upload, loadTextFile, create, action, regenerateScene, saveScript, saveScenes, saveMetadata, analyzeYoutube, ytConnect, ytDisconnect, ytUpload, deleteJob, selectJob, changeScene, changeMetadataList};
}

export type StudioState=ReturnType<typeof useStudioState>;
