"use client";

import type {StudioState} from "./useStudioState";

/** StudioHeader section of the legacy studio (extracted verbatim from the single page). */
export function StudioHeader({s}:{s:StudioState}) {
  const {message, diagnostic, getDiagnostics} = s;
  return (<>   <header className="topbar"><div className="topbar-title"><span className="eyebrow">CREATIVE WORKSPACE</span><h1>Make something moving.</h1><p>Turn an idea, a script, or your footage into a finished video.</p></div><div className="head-actions"><span className="connection-pill"><i className={diagnostic?"online-dot":"offline-dot"}/>{diagnostic?"Backend connected":message.startsWith("Backend unavailable")?"Backend unavailable":"Checking backend…"}</span><button className="icon-button" onClick={getDiagnostics} aria-label="Refresh backend and provider status" title="Refresh status">↻</button></div></header>
   {message&&<div className={"notice "+(message.toLowerCase().includes("unavailable")||message.toLowerCase().includes("failed")?"error":"")} role="status">{message}</div>}</>);
}
