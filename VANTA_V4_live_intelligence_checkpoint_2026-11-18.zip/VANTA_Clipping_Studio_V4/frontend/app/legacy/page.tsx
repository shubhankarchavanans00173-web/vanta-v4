"use client";

import {CreatePanel} from "./CreatePanel";
import {HistoryPanel} from "./HistoryPanel";
import {MetadataPanel} from "./MetadataPanel";
import {PreviewPanel} from "./PreviewPanel";
import {ProviderPanel} from "./ProviderPanel";
import {Sidebar} from "./Sidebar";
import {StoryboardPanel} from "./StoryboardPanel";
import {StudioHeader} from "./StudioHeader";
import {YouTubePanel} from "./YouTubePanel";
import {useStudioState} from "./useStudioState";

/** The original legacy text-to-video studio. Same workflow, same API calls, same markup:
 *  the state lives in useStudioState and each visual section is its own module. */
export default function Home(){
 const s=useStudioState();
 return <div className="app-shell">
  <Sidebar s={s}/>
  <main className="shell">
   <StudioHeader s={s}/>
   <div className="grid create-grid">
    <CreatePanel s={s}/>
    <PreviewPanel s={s}/>
   </div>
   <MetadataPanel s={s}/>
   <YouTubePanel s={s}/>
   <StoryboardPanel s={s}/>
   <div className="grid lower" id="studio-history">
    <HistoryPanel s={s}/>
    <ProviderPanel s={s}/>
   </div>
  </main>
 </div>
}
