"use client";

import type {StudioState} from "./useStudioState";

/** Storyboard section of the legacy studio (extracted verbatim from the single page). */
export function StoryboardPanel({s}:{s:StudioState}) {
  const {narration, scriptEdit, setScriptEdit, sceneEdit, busy, current, canEdit, saveScript, saveScenes, changeScene} = s;
  return (<>  {current&&<section className="panel storyboard"><h2>04 / Storyboard</h2><p className="muted small">{current.settings?.planner_notice||"Edit the script or individual scenes before producing."}</p><div className="field"><label>EDITABLE SCRIPT</label><textarea disabled={!canEdit||busy} value={scriptEdit} onChange={event=>setScriptEdit(event.target.value)}/></div><div className="actions"><button disabled={!canEdit||busy} onClick={saveScript}>Rebuild scenes from script</button></div><div className="scene-list">{sceneEdit.map((scene,index)=><article className="scene" key={index}><div className="scene-head"><span>SCENE {index+1}</span><span>{scene.start_seconds?.toFixed?.(1)??"—"}–{scene.end_seconds?.toFixed?.(1)??"—"}s</span></div><input disabled={!canEdit||busy} value={scene.title} onChange={event=>changeScene(index,"title",event.target.value)}/><textarea disabled={!canEdit||busy} value={scene.narration} onChange={event=>changeScene(index,"narration",event.target.value)}/><input disabled={!canEdit||busy} value={scene.caption||""} onChange={event=>changeScene(index,"caption",event.target.value)} placeholder="Sentence caption"/></article>)}</div><div className="actions"><button disabled={!canEdit||busy||sceneEdit.length===0} onClick={saveScenes}>Save storyboard edits</button></div></section>}</>);
}
