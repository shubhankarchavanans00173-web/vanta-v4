"use client";
import {useEffect, useMemo, useState} from "react";
import {ApiError, call} from "./api";
import type {Ctx} from "./ctx";

type FieldInfo = {
  key: string; label: string; group: string; kind: "bool" | "int" | "float" | "choice" | "text" | "url"; help: string; default: string;
  secret: boolean; apply: string; min: number | null; max: number | null; choices: string[];
  saved?: string | null; running?: string | null; saved_set?: boolean; running_set?: boolean; pending_restart: boolean;
};
type Described = {env_file: string; exists: boolean; restart_required: boolean; fields: FieldInfo[]};

const TRUE = new Set(["1", "true", "yes", "on"]);
const isOn = (v: string | null | undefined) => TRUE.has(String(v ?? "").trim().toLowerCase());
const show = (f: FieldInfo, v: string | null | undefined) => {
  if (v === null || v === undefined || v === "") return f.kind === "choice" && f.choices.includes("") ? "(off)" : "(not set)";
  return f.kind === "bool" ? (isOn(v) ? "on" : "off") : v;
};
/** The value a field has in the saved .env file, or its default when the file has no line for it. */
const savedValue = (f: FieldInfo) => (f.saved ?? f.default) as string;

export function SettingsFields({ctx}: {ctx: Ctx}) {
  const [data, setData] = useState<Described | null>(null);
  const [draft, setDraft] = useState<Record<string, string>>({});       // non-secret edits, as strings ("1"/"0" for bool)
  const [secretDraft, setSecretDraft] = useState<Record<string, string>>({}); // write-only; never pre-filled
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [lastMessage, setLastMessage] = useState<string | null>(null);

  const load = async () => {
    try { setData(await call<Described>("/settings/fields")); }
    catch (e: any) { ctx.notify(e.message, "bad"); }
  };
  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const groups = useMemo(() => {
    const order: string[] = [], by: Record<string, FieldInfo[]> = {};
    for (const f of data?.fields ?? []) { if (!by[f.group]) { by[f.group] = []; order.push(f.group); } by[f.group].push(f); }
    return order.map(g => ({name: g, fields: by[g]}));
  }, [data]);

  const dirtyKeys = (data?.fields ?? []).filter(f => f.secret ? !!secretDraft[f.key] : (f.key in draft && draft[f.key] !== String(savedValue(f)))).map(f => f.key);

  const send = async (values: Record<string, string | null>, clear: string[] = []) => {
    setBusy(true); setErrors({});
    try {
      const r = await call<Described & {saved?: boolean; message?: string}>("/settings/fields", {method: "PUT", headers: {"Content-Type": "application/json"}, body: JSON.stringify({values, clear})});
      setData(r);
      setDraft(d => { const n = {...d}; for (const k of [...Object.keys(values), ...clear]) delete n[k]; return n; });
      setSecretDraft(d => { const n = {...d}; for (const k of [...Object.keys(values), ...clear]) delete n[k]; return n; });
      setLastMessage(r.saved ? (r.message || "Saved.") : null);
      ctx.notify(r.saved ? "Saved. Restart the backend for it to take effect." : "Nothing to save.", "ok");
    } catch (e: any) {
      if (e instanceof ApiError && e.errors) { setErrors(e.errors); ctx.notify("Some settings are not valid; nothing was saved.", "bad"); }
      else ctx.notify(e.message, "bad");
    } finally { setBusy(false); }
  };

  const saveAll = () => {
    const values: Record<string, string> = {};
    for (const f of data?.fields ?? []) {
      if (f.secret) { if (secretDraft[f.key]) values[f.key] = secretDraft[f.key].trim(); }
      else if (f.key in draft && draft[f.key] !== String(savedValue(f))) values[f.key] = draft[f.key];
    }
    if (!Object.keys(values).length) { ctx.notify("Nothing changed.", "ok"); return; }
    send(values);
  };

  const input = (f: FieldInfo) => {
    const err = errors[f.key];
    const cur = f.key in draft ? draft[f.key] : String(savedValue(f));
    const set = (v: string) => { setDraft(d => ({...d, [f.key]: v})); setErrors(e => { const n = {...e}; delete n[f.key]; return n; }); };
    const common = {"aria-invalid": !!err, "aria-describedby": err ? "err-" + f.key : undefined, disabled: busy, id: "f-" + f.key} as const;
    if (f.secret) {
      return <input {...common} className="v-input" type="password" autoComplete="new-password" spellCheck={false} style={{width: 260}}
        placeholder={f.saved_set ? "A key is set — type to replace it" : "Not set"} value={secretDraft[f.key] ?? ""}
        onChange={e => { setSecretDraft(d => ({...d, [f.key]: e.target.value})); setErrors(x => { const n = {...x}; delete n[f.key]; return n; }); }} />;
    }
    if (f.kind === "bool") return <input {...common} type="checkbox" checked={isOn(cur)} onChange={e => set(e.target.checked ? "1" : "0")} />;
    if (f.kind === "choice") return <select {...common} className="v-input sm" value={cur} onChange={e => set(e.target.value)}>{f.choices.map(c => <option key={c} value={c}>{c || "(off)"}</option>)}</select>;
    if (f.kind === "int" || f.kind === "float") return <input {...common} className="v-input sm" style={{width: 130}} type="number" min={f.min ?? undefined} max={f.max ?? undefined} step={f.kind === "int" ? 1 : "any"} value={cur} onChange={e => set(e.target.value)} />;
    return <input {...common} className="v-input" style={{width: 300}} type="text" value={cur} onChange={e => set(e.target.value)} />;
  };

  if (!data) return <div className="v-card" style={{marginTop: 16}}><h3>Editable settings</h3><p className="v-muted">Loading…</p></div>;

  return (
    <div className="v-card" style={{marginTop: 16}} data-testid="settings-fields">
      <div className="v-row" style={{justifyContent: "space-between"}}>
        <h3 style={{margin: 0}}>Editable settings</h3>
        <span className="v-small v-muted" style={{wordBreak: "break-all"}}>{data.exists ? data.env_file : "No .env file yet — one is created when you save"}</span>
      </div>
      <p className="v-small v-muted">These are written to <code>.env</code> (a <code>.env.bak</code> backup is kept). The backend reads them only at start-up, so every change needs a restart. Secrets are write-only and are never shown again.</p>
      {data.restart_required && <div className="v-banner warn" role="status" data-testid="restart-banner" style={{margin: "8px 0", padding: "8px 12px", border: "1px solid #b7791f", borderRadius: 6}}>
        <strong>Restart required.</strong> Some saved values differ from what the running backend is using. Run <code>stop_all.bat</code>, then <code>start_all.bat</code>.</div>}
      {lastMessage && <p className="v-small" role="status">{lastMessage}</p>}
      {groups.map(g => <fieldset key={g.name} style={{border: "1px solid rgba(128,128,128,.35)", borderRadius: 6, margin: "12px 0", padding: "8px 12px"}}>
        <legend className="v-small" style={{padding: "0 6px"}}>{g.name}</legend>
        {g.fields.map(f => {
          const overridden = f.secret ? !!f.saved_set : f.saved !== null && f.saved !== undefined;
          return <div key={f.key} data-field={f.key} style={{padding: "8px 0", borderBottom: "1px solid rgba(128,128,128,.15)"}}>
            <div className="v-row" style={{alignItems: "center", gap: 10, flexWrap: "wrap"}}>
              <label htmlFor={"f-" + f.key} style={{minWidth: 260, fontWeight: 600}}>{f.label}</label>
              {input(f)}
              {f.pending_restart && <span className="v-badge warn" data-badge="restart">restart required</span>}
              {overridden && !f.secret && <button type="button" className="v-btn sm" disabled={busy} onClick={() => send({[f.key]: null})} title="Delete this line from .env so the default applies again">Remove my override</button>}
              {f.secret && f.saved_set && <button type="button" className="v-btn sm bad" disabled={busy} onClick={() => send({}, [f.key])}>Clear</button>}
            </div>
            {f.help && <div className="v-small v-muted">{f.help}</div>}
            {f.secret
              ? <div className="v-small v-muted">Saved: <strong>{f.saved_set ? "is set" : "not set"}</strong> · Running: <strong>{f.running_set ? "is set" : "not set"}</strong></div>
              : <div className="v-small v-muted">Saved: <strong>{overridden ? show(f, f.saved) : "default: " + show(f, f.default)}</strong> · Running: <strong>{show(f, f.running ?? f.default)}</strong>{f.running == null ? " (default)" : ""}</div>}
            {errors[f.key] && <div id={"err-" + f.key} role="alert" className="v-small" style={{color: "#c53030"}} data-error={f.key}>{errors[f.key]}</div>}
          </div>;
        })}
      </fieldset>)}
      <div className="v-row">
        <button type="button" className="v-btn pri" disabled={busy || !dirtyKeys.length} onClick={saveAll} data-testid="save-settings">{busy ? "Saving…" : dirtyKeys.length ? `Save ${dirtyKeys.length} change${dirtyKeys.length === 1 ? "" : "s"}` : "Save"}</button>
        <button type="button" className="v-btn" disabled={busy || (!dirtyKeys.length && !Object.keys(errors).length)} onClick={() => { setDraft({}); setSecretDraft({}); setErrors({}); }}>Discard edits</button>
      </div>
    </div>
  );
}
