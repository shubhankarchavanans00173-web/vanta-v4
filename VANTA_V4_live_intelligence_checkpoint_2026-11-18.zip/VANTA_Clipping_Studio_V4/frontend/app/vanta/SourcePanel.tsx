"use client";

import type {ReactNode, RefObject} from "react";
import {V, clock, type Candidate, type Project} from "./api";

/** Source video with the approximate caption overlay, plus the transcript the ranking used. */
export function SourcePanel({project, pid, videoRef, onTime, caption, sel, capPrev, transcript, busy, onSeek, whisper}: {
  project: Project; pid: string | undefined; videoRef: RefObject<HTMLVideoElement>; onTime: () => void; caption: ReactNode;
  sel: Candidate | null; capPrev: any; transcript: any; busy: boolean; onSeek: (start: number) => void; whisper: any;
}) {
  return (
    <div className="v-stack">
      <div className="v-card">
        <h3>Source preview</h3>
        {project.has_source ? (
          <div className="v-player"><video ref={videoRef} controls preload="metadata" src={`${V}/projects/${pid}/source`} onTimeUpdate={onTime} />{caption && <div className="v-cap">{caption}</div>}</div>
        ) : <div className="v-empty">{busy ? "Downloading… progress is shown above." : "The linked video is not on disk yet. Use Download video / Retry download, or upload the file instead."}</div>}
        {sel && <p className="v-small v-muted" style={{margin: "8px 0 0"}}>Previewing clip {clock(sel.start)}–{clock(sel.end)}. Caption overlay is an approximation of your caption style; the export is burned in by FFmpeg.{capPrev?.granularity === "sentence" ? " This transcript has sentence-level timing only, so words are not highlighted individually." : ""}</p>}
        {project.probe && <p className="v-small v-dim" style={{margin: "6px 0 0"}}>{project.probe.width}×{project.probe.height} · {project.probe.fps} fps · {clock(project.probe.duration)} · {project.probe.has_audio ? "audio" : "no audio"}</p>}
      </div>
      <div className="v-card">
        <h3>Transcript {transcript?.available && <span className="v-badge">{transcript.source}{transcript.word_level ? " · word timings" : " · sentence timings"}</span>}</h3>
        {transcript?.available ? (
          <div className="v-tr">{transcript.segments.map((s: any, i: number) => (
            <button key={i} className={sel && s.end > sel.start && s.start < sel.end ? "in" : ""} onClick={() => onSeek(s.start)}><time>{clock(s.start)}</time><span>{s.text}</span></button>))}</div>
        ) : <div className="v-empty">No transcript. Attach an .srt/.vtt/.json file{whisper?.available ? " or enable local transcription and re-analyze" : ", or install faster-whisper for free local transcription"}.</div>}
      </div>
    </div>
  );
}
