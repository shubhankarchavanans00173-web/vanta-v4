"use client";

import {upload, type Project} from "./api";
import type {RS} from "./clipSettings";
import type {Ctx} from "./ctx";

/** Format / reframing / captions / audio + the single Render action (approval is required first). */
export function ClipSettingsPanel({rs, set, setRs, templates, pickTemplate, project, approvedCount, busy, onRender, ctx}: {
  rs: RS; set: <K extends keyof RS>(k: K, v: RS[K]) => void; setRs: React.Dispatch<React.SetStateAction<RS>>;
  templates: any[]; pickTemplate: (id: string) => void; project: Project; approvedCount: number; busy: boolean;
  onRender: () => void; ctx: Ctx;
}) {
  async function uploadMusic(f?: File | null) {
    if (!f) return; const form = new FormData(); form.append("file", f);
    try { const r = await upload("/music", form); setRs(p => ({...p, music_id: r.music_id, music_name: r.name})); ctx.notify("Music added.", "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
  }
  return (
    <div className="v-card">
      <h3>Clip settings</h3>
      <div className="v-row">
        <div><span className="v-label">Format</span><div className="v-chips">{["9:16", "1:1", "16:9"].map(a => <button key={a} className={`v-chip ${rs.aspect === a ? "on" : ""}`} onClick={() => set("aspect", a)}>{a}</button>)}</div></div>
        <div><span className="v-label">Reframing</span><div className="v-chips">
          <button className={`v-chip ${rs.reframe === "blur" ? "on" : ""}`} onClick={() => set("reframe", "blur")}>Blurred background</button>
          <button className={`v-chip ${rs.reframe === "center" ? "on" : ""}`} onClick={() => set("reframe", "center")}>Centre crop</button>
          <button className="v-chip" disabled title="No subject detector is bundled in this build">Subject tracking (unavailable)</button></div></div>
      </div>
      <label className="v-check" title={project.has_transcript ? "" : "Attach an .srt/.vtt/.json transcript or run local transcription first"}><input type="checkbox" checked={rs.captions && project.has_transcript} disabled={!project.has_transcript} onChange={e => set("captions", e.target.checked)} /> Burn in captions {!project.has_transcript && <span className="v-dim v-small">(unavailable: no transcript attached — captions are never skipped silently, so attach one to enable them)</span>}</label>
      {rs.captions && project.has_transcript && (
        <div className="v-row" style={{alignItems: "flex-end"}}>
          <div><span className="v-label">Template</span><select className="v-select" value={rs.template_id} onChange={e => pickTemplate(e.target.value)}>{templates.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select></div>
          <div><span className="v-label">Style</span><select className="v-select" value={rs.mode} onChange={e => set("mode", e.target.value)}><option value="word_highlight">Word highlight</option><option value="clean">Clean</option></select></div>
          <div><span className="v-label">Position</span><select className="v-select" value={rs.position} onChange={e => set("position", e.target.value)}><option value="bottom">Bottom</option><option value="middle">Middle</option><option value="top">Top</option></select></div>
          <div><span className="v-label">Size %</span><input className="v-input sm" type="number" step="0.2" min={2} max={10} value={rs.font_size_pct} onChange={e => set("font_size_pct", Number(e.target.value))} /></div>
          <div><span className="v-label">Words/line</span><input className="v-input sm" type="number" min={1} max={10} value={rs.max_words_per_line} onChange={e => set("max_words_per_line", Number(e.target.value))} /></div>
          <div><span className="v-label">Text</span><input type="color" value={rs.color} onChange={e => set("color", e.target.value)} /></div>
          <div><span className="v-label">Highlight</span><input type="color" value={rs.highlight_color} onChange={e => set("highlight_color", e.target.value)} /></div>
          <label className="v-check"><input type="checkbox" checked={rs.uppercase} onChange={e => set("uppercase", e.target.checked)} /> UPPERCASE</label>
          <label className="v-check"><input type="checkbox" checked={rs.background} onChange={e => set("background", e.target.checked)} /> Box</label>
        </div>
      )}
      <details className="v-det" open><summary>Audio</summary>
        <label className="v-check"><input type="checkbox" checked={rs.keep_original_audio} onChange={e => set("keep_original_audio", e.target.checked)} /> Keep original audio</label>
        <div className="v-row"><label className="v-small v-muted">Volume <input className="v-input sm" type="number" step="0.1" min={0} max={3} value={rs.volume} onChange={e => set("volume", Number(e.target.value))} /></label>
          <label className="v-check" style={{margin: 0}}><input type="checkbox" checked={rs.remove_silence} onChange={e => set("remove_silence", e.target.checked)} /> Remove silences ≥</label>
          <input className="v-input sm" type="number" step="0.1" min={0.3} max={5} value={rs.silence_min_seconds} disabled={!rs.remove_silence} onChange={e => set("silence_min_seconds", Number(e.target.value))} /><span className="v-dim v-small">s</span></div>
        <div className="v-row" style={{marginTop: 8}}>
          <label className="v-btn sm">{rs.music_id ? `Music: ${rs.music_name}` : "Add background music"}<input type="file" hidden accept="audio/*" onChange={e => { uploadMusic(e.target.files?.[0]); e.target.value = ""; }} /></label>
          {rs.music_id && <button className="v-btn sm" onClick={() => setRs(p => ({...p, music_id: "", music_name: ""}))}>Remove</button>}
          {rs.music_id && <><label className="v-small v-muted">Music vol <input className="v-input sm" type="number" step="0.05" min={0} max={1} value={rs.music_volume} onChange={e => set("music_volume", Number(e.target.value))} /></label>
            <label className="v-check" style={{margin: 0}}><input type="checkbox" checked={rs.ducking} onChange={e => set("ducking", e.target.checked)} /> Duck under speech</label></>}
        </div>
      </details>
      <div className="v-row" style={{marginTop: 14, justifyContent: "space-between"}}>
        <span className="v-muted">{approvedCount} approved clip(s) · {rs.aspect === "9:16" ? "1080×1920" : rs.aspect === "16:9" ? "1920×1080" : "1080×1080"} · 30 fps · H.264/AAC</span>
        <button className="v-btn pri" disabled={busy || approvedCount === 0 || !project.has_source} title={busy ? "A job is running for this project" : !project.has_source ? "The source video is not on disk yet (download or upload it first)" : approvedCount === 0 ? "Approve at least one suggestion first: nothing is exported without your approval" : "Render the approved clips"} onClick={onRender}>Render {approvedCount || ""} approved clip(s)</button>
      </div>
    </div>
  );
}
