"use client";
import {useState} from "react";
import {post} from "./api";
import type {Ctx} from "./ctx";
import {TranscriptionCard} from "./TranscriptionCard";

export function ModelsView({ctx}: {ctx: Ctx}) {
  const h = ctx.health, cloud = h?.cloud_ai;
  const [est, setEst] = useState<any>(null), [ok, setOk] = useState(false), [busy, setBusy] = useState(false);
  async function estimate() {
    if (!ctx.project) return; setBusy(true); setEst(null); setOk(false);
    try { setEst(await post(`/projects/${ctx.project.id}/ai/estimate`)); } catch (e: any) { ctx.notify(e.message, "bad"); } finally { setBusy(false); }
  }
  async function send() {
    if (!ctx.project || !est) return; setBusy(true);
    try { const r = await post(`/projects/${ctx.project.id}/ai/rank`, {estimate_id: est.estimate_id, confirm: true}); setEst(null); setOk(false); await ctx.refresh();
      ctx.notify(`Rated ${r.applied} suggestion(s). Reported usage: ${r.usage.input_tokens ?? "?"} in / ${r.usage.output_tokens ?? "?"} out tokens.`, "ok"); }
    catch (e: any) { ctx.notify(e.message, "bad"); setEst(null); } finally { setBusy(false); }
  }
  return (
    <>
      <h1 className="v-h1">AI Models</h1>
      <p className="v-sub">Everything needed for clipping runs locally and free. Cloud AI is optional, off by default, and asks before every single request.</p>
      <div className="v-grid2">
        <div className="v-stack">
          <div className="v-card"><h3>Clip ranking</h3>
            <p style={{margin: 0}}><span className="v-badge ok">active</span> <strong>Rule-based multi-signal engine</strong> <span className="v-dim v-small">{ctx.health?.clip_engine?.version ? `v${ctx.health.clip_engine.version}` : ""}</span></p>
            <p className="v-muted v-small">Builds clip candidates from sentence boundaries, then scores hook, payoff, standalone clarity, completeness, opening/ending quality, context dependency, repetition, caption readability and duration fit, plus audio loudness and scene cuts when measured. Missing signals are left out, never invented. Scores are relative rankings, not view predictions. Free, no network. The original simple heuristic stays selectable.</p>
            <p style={{margin: "8px 0 0"}}><span className={`v-badge ${ctx.health?.clip_engine?.local_llm?.available ? "ok" : ""}`}>{ctx.health?.clip_engine?.local_llm?.available ? "local AI ready" : "local AI off"}</span> <strong>Optional local language model</strong></p>
            <p className="v-muted v-small">{ctx.health?.clip_engine?.local_llm?.available ? `Model ${ctx.health.clip_engine.local_llm.model} (Ollama) will re-rate the top suggestions; its ratings are validated and can only shift a score by ±15.` : (ctx.health?.clip_engine?.local_llm?.reason || "Backend not reachable.")}</p></div>
          <TranscriptionCard ctx={ctx} />
          <div className="v-card"><h3>Subject-aware reframing</h3><p style={{margin: 0}}><span className="v-badge">unavailable</span> No detector is bundled. Blurred-background and centre-crop reframing are used instead.</p></div>
        </div>
        <div className="v-card"><h3>Optional cloud AI rating (paid)</h3>
          {cloud && <p style={{margin: "0 0 8px"}}><span className={`v-badge ${cloud.configured ? "ok" : "warn"}`}>{cloud.configured ? "configured" : "off"}</span> <strong>{cloud.provider}</strong> {cloud.model ? <span className="v-muted">· {cloud.model}</span> : null}</p>}
          <p className="v-small v-muted">{cloud?.detail}</p>
          <p className="v-small v-muted">Sends only the transcript excerpts of the current suggestions to the provider to get a second-opinion rating. The API key stays on the backend. You see the provider, model and an estimated cost first; each request needs your confirmation and is never retried automatically.</p>
          <button className="v-btn" disabled={!cloud?.configured || !ctx.project || busy} title={!cloud?.configured ? "Cloud AI is off (set VANTA_CLOUD_AI_ENABLED=1 and an API key in .env)" : !ctx.project ? "Select a project in Create Shorts first" : "Estimate the cost; nothing is sent yet"} onClick={estimate}>Get cost estimate for “{ctx.project?.name || "no project selected"}”</button>
          {est && (
            <div className="v-card" style={{marginTop: 12, borderColor: "#ffc65c66"}}>
              <dl className="v-kv"><dt>Provider / model</dt><dd>{est.provider} / {est.model}</dd><dt>Estimated input</dt><dd>~{est.est_input_tokens} tokens</dd><dt>Max output</dt><dd>{est.est_output_tokens_max} tokens</dd>
                <dt>Estimated cost</dt><dd>{est.est_cost_usd != null ? `up to $${est.est_cost_usd}` : "unknown — no prices configured"}</dd></dl>
              <p className="v-small v-muted">{est.note}</p>
              <label className="v-check"><input type="checkbox" checked={ok} onChange={e => setOk(e.target.checked)} /> I understand this makes a paid request to {est.provider}.</label>
              <button className="v-btn pri" disabled={!ok || busy} onClick={send}>Confirm and send</button>
            </div>)}
        </div>
      </div>
    </>
  );
}
