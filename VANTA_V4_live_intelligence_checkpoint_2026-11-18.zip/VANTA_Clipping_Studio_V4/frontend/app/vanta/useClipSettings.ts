"use client";

import {useEffect, useState} from "react";
import {DEFAULT_RS, loadRS, saveRS, type RS} from "./clipSettings";

/** The persisted Create Shorts clip settings, with the same set helper the page used before.
 *  The saved values are loaded after mount (localStorage does not exist during server rendering). */
export function useClipSettings() {
  const [rs, setRs] = useState<RS>(DEFAULT_RS);
  useEffect(() => { setRs(loadRS()); }, []);
  useEffect(() => { saveRS(rs); }, [rs]);
  const set = <K extends keyof RS>(k: K, v: RS[K]) => setRs(p => ({...p, [k]: v}));
  return {rs, setRs, set};
}
