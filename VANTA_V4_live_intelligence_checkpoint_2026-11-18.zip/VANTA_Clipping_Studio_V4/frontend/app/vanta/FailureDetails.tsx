"use client";
import type {Job} from "./api";

/** Per-clip render failures of a job: what went wrong and where the diagnostic files (ffmpeg command/stderr, caption file) were saved. */
export function FailureDetails({job}: {job: Job}) {
  const failed: any[] = job.result?.failed || [];
  if (failed.length === 0) return null;
  return (
    <ul className="v-small" style={{margin: "6px 0 0", paddingLeft: 18}}>
      {failed.map((f, i) => (
        <li key={i} className="v-err">{f.error}{f.diagnostics ? <span className="v-muted"> — diagnostics saved in <code style={{wordBreak: "break-all"}}>{f.diagnostics}</code> inside the VANTA data folder</span> : null}</li>))}
    </ul>
  );
}
