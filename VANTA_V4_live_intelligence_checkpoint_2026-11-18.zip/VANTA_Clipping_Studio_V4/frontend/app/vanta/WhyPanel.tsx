"use client";
import {useState} from "react";
import {Analysis, Candidate, FEATURE_LABEL, FEEDBACK_LABELS, call, clock} from "./api";

/** Evidence-based explanation for one suggestion. Everything shown comes from the backend's measured features and real transcript text. */
export function WhyPanel({c, notify, onChanged}: {c: Candidate; notify: (m: string, k?: "ok" | "bad") => void; onChanged: () => void}) {
  const a: Analysis | null | undefined = c.analysis;
  const [more, setMore] = useState(false);
  const rate = async (label: string) => {
    try {
      if (c.feedback === label) await call(`/candidates/${c.id}/feedback`, {method: "DELETE"});
      else await call(`/candidates/${c.id}/feedback`, {method: "PUT", headers: {"Content-Type": "application/json"}, body: JSON.stringify({label})});
      onChanged();
    } catch (x: any) { notify(x.message, "bad"); }
  };
  const feats = Object.entries(a?.features || {}).filter(([, f]) => f.value != null);
  return (
    <div className="v-why-box">
      {a ? (
        <>
          <p className="v-small" style={{margin: "0 0 6px"}}>{a.summary || c.reasons[0]}</p>
          {a.hook ? <p className="v-small" style={{margin: "0 0 4px"}}><strong>Hook:</strong> <span className="v-muted">“{a.hook}”</span></p> : null}
          {a.payoff ? <p className="v-small" style={{margin: "0 0 4px"}}><strong>Payoff:</strong> <span className="v-muted">“{a.payoff}”</span></p> : null}
          {a.event?.category && a.event.category !== "conversation" ? <p className="v-small" style={{margin: "0 0 4px"}}><strong>Detected event:</strong> <span className="v-muted">{a.event.category} ({Math.round(a.event.confidence * 100)}%)</span></p> : null}
          {a.caveats?.length ? <ul className="v-why" style={{color: "var(--warn)"}}>{a.caveats.map((x, i) => <li key={i}>{x}</li>)}</ul> : null}
          {a.needs_setup && a.suggested_setup ? <p className="v-small v-muted" style={{margin: "4px 0"}}>May need setup: the sentence before the clip (at {clock(a.suggested_setup.start)}) is “{a.suggested_setup.setup}”. Adjust the start time if you want it.</p> : null}
          <div className="v-row v-small" style={{margin: "6px 0"}}>
            <span className={`v-badge ${a.confidence?.level === "high" ? "ok" : a.confidence?.level === "low" ? "bad" : "warn"}`} title={a.confidence?.definition}>confidence: {a.confidence?.level || "n/a"}</span>
            {a.llm?.status === "evaluated" ? <span className="v-badge pur" title="A local language model rated this clip and nudged the score within ±15 points.">Local AI evaluated · {a.llm.model} ({(a.llm.adjustment ?? 0) > 0 ? "+" : ""}{a.llm.adjustment})</span>
              : a.llm?.status === "failed" ? <span className="v-badge warn" title={a.llm.error}>local AI failed — rule-based score kept</span>
              : <span className="v-badge" title="No language model was used for this suggestion.">rule-based only</span>}
          </div>
          <div className="v-small v-dim" title={a.score_meaning}>Signals used: {a.signals_used.length ? a.signals_used.join(", ") : "none"}. Not analysed: {(a.signals_not_available || []).join(", ") || "—"}.</div>
          {a.confidence?.uncertain?.length ? <div className="v-small v-warn">{a.confidence.uncertain.join("; ")}</div> : null}
          {feats.length ? <button className="v-btn sm" style={{marginTop: 6}} onClick={() => setMore(!more)}>{more ? "Hide evidence" : "Show evidence"}</button> : null}
          {more && <ul className="v-why">{feats.map(([k, f]) => <li key={k}><strong>{FEATURE_LABEL[k] || k}</strong> {Math.round((f.value as number) * 100)}% — {f.evidence}</li>)}</ul>}
          {a.alternates?.length ? <div className="v-small v-muted" style={{marginTop: 6}}>Alternative cut points for this moment: {a.alternates.map((x, i) => <span key={i}>{i ? " · " : ""}{clock(x.start)}–{clock(x.end)} ({x.note})</span>)}</div> : null}
        </>
      ) : <ul className="v-why">{c.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul>}
      <div className="v-row" style={{marginTop: 8, flexWrap: "wrap"}}>
        <span className="v-small v-dim">Your rating:</span>
        {FEEDBACK_LABELS.map(([k, label]) => <button key={k} className={`v-btn sm ${c.feedback === k ? "pri" : ""}`} onClick={() => rate(k)} title="Ratings are stored locally and used only to measure ranking quality. Click again to clear.">{label}</button>)}
      </div>
    </div>
  );
}
