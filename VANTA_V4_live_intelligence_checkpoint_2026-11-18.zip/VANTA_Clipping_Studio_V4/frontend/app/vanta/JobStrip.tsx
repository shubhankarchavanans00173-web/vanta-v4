"use client";

import {ACTIVE, KIND_LABEL, STATUS_LABEL, post, type Job} from "./api";
import type {Ctx} from "./ctx";
import {FailureDetails} from "./FailureDetails";
import {LinkErrorBox} from "./LinkErrorBox";

/** The job banner above the source preview. Shows the real backend state, never a guessed percentage. */
export function JobStrip({job, ctx}: {job?: Job; ctx: Ctx}) {
  if (!job) return null;
  const active = ACTIVE.has(job.status);
  if (!active && job.status !== "failed") return null;
  return (
    <div className="v-card" style={{borderColor: job.status === "failed" ? "#ff7d9466" : undefined}}>
      <div className="v-row" style={{justifyContent: "space-between"}}>
        <div><span className={`v-badge ${job.status === "failed" ? "bad" : "pur"}`}>{STATUS_LABEL[job.status]}</span> <span className="v-muted">{KIND_LABEL[job.kind] || job.kind}</span></div>
        {active && <button className="v-btn sm" onClick={async () => { try { await post(`/jobs/${job.id}/cancel`); } catch (e: any) { ctx.notify(e.message, "bad"); } finally { ctx.refresh(); } }}>Cancel</button>}
      </div>
      {job.status === "failed" ? (job.result?.error ? <LinkErrorBox err={job.result.error} /> : <><p className="v-err">{job.error}</p><FailureDetails job={job} /></>) : (
        <>
          <p className="v-muted v-small" style={{margin: "8px 0 6px"}}>{job.message}{job.progress != null ? ` · ${Math.round(job.progress * 100)}%` : ""}</p>
          <div className={`v-bar ${job.progress == null ? "ind" : ""}`}><i style={job.progress != null ? {width: `${Math.round(job.progress * 100)}%`} : undefined} /></div>
          {job.progress == null && <p className="v-dim v-small" style={{margin: "6px 0 0"}}>This step does not report a percentage, so none is shown.</p>}
        </>
      )}
    </div>
  );
}
