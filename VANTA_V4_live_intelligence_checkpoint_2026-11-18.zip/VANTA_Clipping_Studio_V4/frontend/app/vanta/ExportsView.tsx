"use client";
import {useCallback, useEffect, useState} from "react";
import {call, type Export} from "./api";
import type {Ctx} from "./ctx";
import {ExportCard} from "./ExportCard";

export function ExportsView({ctx}: {ctx: Ctx}) {
  const [items, setItems] = useState<Export[] | null>(null);
  const done = ctx.jobs.filter(j => j.status === "completed").length;
  const load = useCallback(() => { call("/exports").then(setItems).catch(e => ctx.notify(e.message, "bad")); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { load(); }, [load, done]);
  return (
    <>
      <h1 className="v-h1">Exports</h1>
      <p className="v-sub">Finished MP4 files. Each one was re-inspected with ffprobe after rendering; a file only appears here if that check passed.</p>
      {items === null ? <div className="v-empty">Loading…</div> : items.length === 0 ? <div className="v-empty">No exports yet. Approve clips and render them from Create Shorts.</div> :
        <div className="v-grid3">{items.map(e => <ExportCard key={e.id} e={e} onChange={() => { load(); ctx.refresh(); }} notify={ctx.notify} />)}</div>}
    </>
  );
}
