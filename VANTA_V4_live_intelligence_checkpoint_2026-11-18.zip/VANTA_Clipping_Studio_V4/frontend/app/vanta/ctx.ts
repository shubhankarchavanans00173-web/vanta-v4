import type {Job, Project} from "./api";
export type Ctx = {
  health: any; projects: Project[]; jobs: Job[]; project: Project | null;
  selectProject: (id: string | null) => void; refresh: () => Promise<void>;
  notify: (message: string, kind?: "ok" | "bad") => void; go: (section: string) => void;
};
