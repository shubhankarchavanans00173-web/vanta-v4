"use client";
import {STATUS_LABEL, del} from "./api";
import type {Ctx} from "./ctx";

export function ProjectsView({ctx}: {ctx: Ctx}) {
  async function remove(id: string, exports: number) {
    if (!window.confirm("Delete this project and its uploaded/downloaded source copy?")) return;
    let q = "";
    if (exports > 0) { if (!window.confirm(`It has ${exports} exported video(s). Delete those files too?`)) return; q = "?delete_exports=true"; }
    try { await del(`/projects/${id}${q}`); if (ctx.project?.id === id) ctx.selectProject(null); await ctx.refresh(); ctx.notify("Project deleted.", "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
  }
  return (
    <>
      <h1 className="v-h1">My Projects</h1>
      <p className="v-sub">Every video you have added, with its suggestions and exports.</p>
      <div className="v-card">
        {ctx.projects.length === 0 ? <div className="v-empty">No projects yet. Start from Create Shorts.</div> : (
          <table className="v-table"><thead><tr><th>Name</th><th>Source</th><th>Status</th><th>Clips</th><th>Exports</th><th>Created</th><th></th></tr></thead><tbody>
            {ctx.projects.map(p => <tr key={p.id}>
              <td><strong>{p.name}</strong>{p.probe?.duration ? <div className="v-dim v-small">{Math.round(p.probe.duration)}s · {p.probe.width}×{p.probe.height}</div> : null}</td>
              <td>{p.source_type}</td><td><span className={`v-badge ${p.status === "failed" ? "bad" : p.status === "awaiting_approval" ? "warn" : ""}`}>{STATUS_LABEL[p.status] || p.status}</span></td>
              <td className="v-small v-muted">{Object.entries(p.counts || {}).map(([k, v]) => `${v} ${k}`).join(", ") || "–"}</td><td>{p.exports ?? 0}</td>
              <td className="v-small v-muted">{new Date(p.created_at).toLocaleString()}</td>
              <td className="v-row"><button className="v-btn sm" onClick={() => { ctx.selectProject(p.id); ctx.go("create"); }}>Open</button><button className="v-btn sm bad" onClick={() => remove(p.id, Number(p.exports) || 0)}>Delete</button></td></tr>)}
          </tbody></table>)}
      </div>
    </>
  );
}
