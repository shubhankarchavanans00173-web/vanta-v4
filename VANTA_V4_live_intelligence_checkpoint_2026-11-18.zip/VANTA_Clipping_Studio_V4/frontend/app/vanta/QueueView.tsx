"use client";
import {useEffect, useRef, useState} from "react";
import {ACTIVE, KIND_LABEL, STATUS_LABEL, post, type Job} from "./api";
import type {Ctx} from "./ctx";
import {FailureDetails} from "./FailureDetails";

const short = (id?: string) => (id ? id.slice(0, 8) : "–");

/** What the backend recorded about a restart: the old job points at its continuation, the new job at its origin. */
function Recovery({job, onFocus}: {job: Job; onFocus: (id: string) => void}) {
  const continuedAs: string | undefined = job.result?.resumed_as;
  const from: string | undefined = job.payload?.resume_of;
  if (!continuedAs && !from) return null;
  return (
    <div className="v-small" style={{marginTop: 4}}>
      {continuedAs ? (
        <span className="v-badge pur" title="A backend restart interrupted this job. Its remaining work was queued again automatically; finished clips were kept.">
          Continued automatically{" "}
          <button className="v-linkbtn" onClick={() => onFocus(continuedAs)}>as job {short(continuedAs)} ↓</button>
        </span>
      ) : null}
      {from ? (
        <span className="v-badge" title="This job continues an interrupted job. Finished clips from the first attempt were kept.">
          Continued from{" "}
          <button className="v-linkbtn" onClick={() => onFocus(from)}>job {short(from)} ↑</button>
          {job.payload?.resume_count ? ` · resume ${job.payload.resume_count}` : ""}
        </span>
      ) : null}
    </div>
  );
}

export function QueueView({ctx}: {ctx: Ctx}) {
  const [cancelling, setCancelling] = useState<Record<string, boolean>>({});   // a second click while the first is in flight is ignored
  const [focus, setFocus] = useState<string | null>(null);
  const rows = useRef<Record<string, HTMLTableRowElement | null>>({});
  useEffect(() => {
    if (!focus) return;
    const el = rows.current[focus];
    el?.scrollIntoView?.({block: "center"});
    const timer = setTimeout(() => setFocus(null), 3000);
    return () => clearTimeout(timer);
  }, [focus]);
  async function cancel(id: string) {
    if (cancelling[id]) return;
    setCancelling(c => ({...c, [id]: true}));
    try { await post(`/jobs/${id}/cancel`); } catch (e: any) { ctx.notify(e.message, "bad"); } finally { await ctx.refresh(); setCancelling(c => ({...c, [id]: false})); }
  }
  const running = ctx.jobs.some(j => ACTIVE.has(j.status) && j.status !== "queued");
  return (
    <>
      <h1 className="v-h1">Processing Queue</h1>
      <p className="v-sub">Live job states from the backend. Jobs run one at a time so files are never written concurrently. Percentages appear only when the underlying step reports them. If the backend restarts, interrupted render and download jobs continue automatically as a new job and the pair is linked here.</p>
      <div className="v-card">
        {ctx.jobs.length === 0 ? <div className="v-empty">No jobs yet.</div> : (
          <table className="v-table"><thead><tr><th>Project</th><th>Job</th><th>State</th><th>Progress</th><th>Detail</th><th>Started</th><th></th></tr></thead><tbody>
            {ctx.jobs.map(j => <tr key={j.id} id={`job-${j.id}`} ref={el => { rows.current[j.id] = el; }}
                style={focus === j.id ? {outline: "2px solid var(--purple)", outlineOffset: -2} : undefined}>
              <td>{j.project_name || j.project_id}</td><td>{KIND_LABEL[j.kind] || j.kind}</td>
              <td><span className={`v-badge ${j.status === "failed" ? "bad" : j.status === "completed" ? "ok" : ACTIVE.has(j.status) ? "pur" : "warn"}`}>{STATUS_LABEL[j.status] || j.status}</span></td>
              <td className="v-small">{j.progress != null ? `${Math.round(j.progress * 100)}%` : ACTIVE.has(j.status) ? "working…" : "–"}</td>
              <td className="v-small v-muted" style={{maxWidth: 380}}>
                {j.error ? <span className="v-err">{j.error}</span> : j.status === "queued" && running ? "Waiting for the running job to finish (jobs run one at a time)" : j.message}
                {j.status === "failed" && !j.result?.resumed_as && j.kind !== "analyze" ? (
                  <div className="v-small v-dim" style={{marginTop: 4}}>Not continued automatically (the resume limit was reached, the job is not resumable, or automatic resume is switched off). Start it again from the project to retry.</div>
                ) : null}
                <Recovery job={j} onFocus={setFocus} />
                <FailureDetails job={j} />
              </td>
              <td className="v-small v-muted">{new Date(j.created_at).toLocaleTimeString()}</td>
              <td>{ACTIVE.has(j.status) && <button className="v-btn sm" disabled={!!cancelling[j.id]} onClick={() => cancel(j.id)}>{cancelling[j.id] ? "Cancelling…" : "Cancel"}</button>}</td></tr>)}
          </tbody></table>)}
      </div>
    </>
  );
}
