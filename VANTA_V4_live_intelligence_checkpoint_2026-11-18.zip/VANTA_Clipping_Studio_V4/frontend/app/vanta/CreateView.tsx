"use client";
import {useCallback, useEffect, useMemo, useRef, useState} from "react";
import {ACTIVE, STATUS_LABEL, call, post, upload, type Candidate} from "./api";
import {CandidateCard} from "./CandidateCard";
import {ClipSettingsPanel} from "./ClipSettingsPanel";
import {ExportCard} from "./ExportCard";
import {LinkErrorBox} from "./LinkErrorBox";
import {SourcePanel} from "./SourcePanel";
import {DEFAULT_RS, renderSettingsPayload} from "./clipSettings";
import type {Ctx} from "./ctx";
import {JobStrip} from "./JobStrip";
import {useClipSettings} from "./useClipSettings";

// Kept as a named export for existing imports: the implementation now lives in its own module.
export {JobStrip};

/** Create Shorts: upload/link -> analyze -> review & approve -> render. Nothing is exported or published without approval. */
export function CreateView({ctx}: {ctx: Ctx}) {
  const {project, health} = ctx;
  const videoRef = useRef<HTMLVideoElement>(null), rangeRef = useRef<{start: number; end: number} | null>(null);
  const [t, setT] = useState(0), [selId, setSelId] = useState<string | null>(null), [capPrev, setCapPrev] = useState<any>(null);
  const [transcript, setTranscript] = useState<any>(null);
  const [upPct, setUpPct] = useState<number | null>(null), [target, setTarget] = useState(30), [count, setCount] = useState(5), [doTranscribe, setDoTranscribe] = useState(true), [engineMode, setEngineMode] = useState<"auto" | "baseline">("auto"), [localRerank, setLocalRerank] = useState(true);
  const {rs, setRs, set} = useClipSettings();
  const [templates, setTemplates] = useState<any[]>([]);
  const [customStart, setCustomStart] = useState(""), [customEnd, setCustomEnd] = useState("");
  useEffect(() => { call("/templates").then(setTemplates).catch(() => {}); }, []);

  const pid = project?.id;
  const cands = project?.candidates || [];
  const jobs = project?.jobs || [];
  const busy = jobs.some(j => ACTIVE.has(j.status));
  const approved = cands.filter(c => c.status === "approved" || c.status === "failed");
  const sel = cands.find(c => c.id === selId) || null;
  const exportsHere = project?.exports || [];
  const needsDownload = !!project && project.source_type === "link" && !project.has_source;
  async function retryDownload() {
    if (!pid) return;
    try { const r = await post(`/projects/${pid}/download`); ctx.refresh(); ctx.notify(r.already_downloaded ? r.message : "Download started.", "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
  }

  const tKey = pid ? `${pid}:${project?.transcript_meta?.source}:${project?.transcript_meta?.segments}` : "";
  useEffect(() => {
    setTranscript(null);
    if (pid && project?.has_transcript) call(`/projects/${pid}/transcript`).then(setTranscript).catch(() => {});
  }, [tKey]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setSelId(null); setCapPrev(null); rangeRef.current = null; }, [pid]);
  useEffect(() => { if (sel) call(`/candidates/${sel.id}/captions-preview?max_words=${rs.max_words_per_line}`).then(setCapPrev).catch(() => setCapPrev(null)); else setCapPrev(null); }, [selId, sel?.start, sel?.end, project?.has_transcript, rs.max_words_per_line]); // eslint-disable-line react-hooks/exhaustive-deps

  const play = (c: Candidate) => {
    setSelId(c.id); const v = videoRef.current; if (!v) return;
    rangeRef.current = {start: c.start, end: c.end}; v.currentTime = c.start; v.play().catch(() => {});
  };
  const onTime = () => {
    const v = videoRef.current; if (!v) return; setT(v.currentTime);
    const r = rangeRef.current; if (r && v.currentTime >= r.end) { v.pause(); rangeRef.current = null; }
  };
  const getPlayhead = useCallback(() => Math.round((videoRef.current?.currentTime || 0) * 10) / 10, []);
  const seek = (start: number) => { const v = videoRef.current; if (v) { rangeRef.current = null; v.currentTime = start; } };

  const caption = useMemo(() => {
    if (!sel || !capPrev?.events?.length || !rs.captions) return null;
    const ct = t - sel.start; if (ct < 0 || ct > sel.end - sel.start) return null;
    const ev = capPrev.events.find((e: any) => ct >= e.start && ct <= e.end + 0.05); if (!ev) return null;
    const up = (s: string) => rs.uppercase ? s.toUpperCase() : s;
    if (ev.words && rs.mode === "word_highlight") return <>{ev.words.map((w: any, i: number) => { const on = ct >= w.start && ct < (ev.words[i + 1]?.start ?? ev.end + 0.1); return on ? <b key={i}>{up(w.text)} </b> : <span key={i}>{up(w.text)} </span>; })}</>;
    return <>{up(ev.text)}</>;
  }, [sel, capPrev, t, rs.captions, rs.uppercase, rs.mode]);

  async function onUpload(video?: File | null) {
    if (!video) return;
    const form = new FormData(); form.append("file", video);
    setUpPct(0);
    try { const p = await upload("/projects/upload", form, f => setUpPct(f)); await ctx.refresh(); ctx.selectProject(p.id); ctx.notify(`“${p.name}” uploaded and checked with ffprobe. Press Analyze to find clips.`, "ok"); }
    catch (e: any) { ctx.notify(e.message, "bad"); } finally { setUpPct(null); }
  }
  async function attachTranscript(f?: File | null) {
    if (!f || !pid) return; const form = new FormData(); form.append("file", f);
    try { const r = await upload(`/projects/${pid}/transcript`, form); ctx.notify(r.message, "ok"); ctx.refresh(); } catch (e: any) { ctx.notify(e.message, "bad"); }
  }
  const inflight = useRef(false);   // blocks a second click while the first request is still on its way (double-click protection)
  async function once(fn: () => Promise<void>) {
    if (inflight.current) return;
    inflight.current = true;
    try { await fn(); } finally { inflight.current = false; }
  }
  async function analyze(autoRender = false) {
    if (!pid) return;
    await once(async () => {
    try {
      await post(`/projects/${pid}/analyze`, {target_duration: target, count, transcribe: doTranscribe, engine_mode: engineMode, local_llm: localRerank, auto_render: autoRender, render_settings: autoRender ? renderSettingsPayload(rs, !!project?.has_transcript) : {}});
      ctx.refresh();
      if (autoRender) ctx.notify("Auto Clip started: VANTA will rank moments and render the top suggestions automatically.", "ok");
    } catch (e: any) { ctx.notify(e.message, "bad"); }
    });
  }
  async function addCustom() {
    if (!pid) return;
    await once(async () => {
      try { await post(`/projects/${pid}/candidates`, {start: customStart, end: customEnd}); setCustomStart(""); setCustomEnd(""); ctx.refresh(); ctx.notify("Custom clip added and approved.", "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
    });
  }
  async function render() {
    if (!pid) return;
    const settings = renderSettingsPayload(rs, !!project?.has_transcript);
    await once(async () => {
      try { await post(`/projects/${pid}/render`, {candidate_ids: approved.map(c => c.id), settings}); ctx.refresh(); ctx.notify(`Rendering ${approved.length} approved clip(s).`, "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
    });
  }
  function pickTemplate(id: string) {
    const tpl = templates.find(x => x.id === id); set("template_id", id);
    if (tpl) setRs(p => ({...p, template_id: id, ...Object.fromEntries(Object.entries(tpl.style).filter(([k]) => k in DEFAULT_RS))} as typeof p));
  }

  const whisper = health?.transcription_engines?.find((e: any) => e.id === "faster-whisper");
  return (
    <>
      <h1 className="v-h1">Create Shorts</h1>
      <p className="v-sub">Auto Clip ranks the strongest available moments and renders the top suggestions into captioned vertical MP4s. It uses local heuristics and transcript/audio/scene signals—not a guarantee of virality. Nothing is published to YouTube automatically.</p>

      <div className="v-card" style={{marginBottom: 16}}>
        <div className="v-row" style={{justifyContent: "space-between"}}>
          <div className="v-row">
            <label className="v-btn pri">Upload video<input type="file" hidden accept="video/*,.mkv,.mov,.avi,.ts,.mpg,.mpeg" onChange={e => { onUpload(e.target.files?.[0]); e.target.value = ""; }} /></label>
            <label className={`v-btn ${pid ? "" : "disabled"}`} style={pid ? undefined : {opacity: .45, cursor: "not-allowed"}} title={pid ? "Attach or replace the transcript of the selected project, then re-analyze" : "Select or upload a project first"}>{project?.has_transcript ? "Replace transcript" : "Attach transcript"} (.srt .vtt .json)<input type="file" hidden disabled={!pid || busy} accept=".srt,.vtt,.json" onChange={e => { attachTranscript(e.target.files?.[0]); e.target.value = ""; }} /></label>
            <button className="v-btn" onClick={() => ctx.go("links")}>Use a video link…</button>
            {upPct != null && <span className="v-muted">Uploading {Math.round(upPct * 100)}%</span>}
          </div>
          <select className="v-select" value={pid || ""} onChange={e => ctx.selectProject(e.target.value || null)} aria-label="Project">
            <option value="">— choose a project —</option>
            {ctx.projects.map(p => <option key={p.id} value={p.id}>{p.name} ({STATUS_LABEL[p.status] || p.status})</option>)}
          </select>
        </div>
        {project && (
          <div className="v-row" style={{marginTop: 14}}>
            <div className="v-chips">{[15, 30, 45, 60].map(d => <button key={d} className={`v-chip ${target === d ? "on" : ""}`} onClick={() => setTarget(d)}>{d}s</button>)}</div>
            <label className="v-small v-muted">Suggestions <input className="v-input sm" style={{width: 56}} type="number" min={1} max={20} value={count} onChange={e => setCount(Math.max(1, Math.min(20, Number(e.target.value) || 1)))} /></label>
            <label className="v-check" style={{margin: 0}} title={whisper?.available ? "Free local transcription" : whisper?.detail}>
              <input type="checkbox" checked={doTranscribe} onChange={e => setDoTranscribe(e.target.checked)} /> Transcribe locally {whisper && !whisper.available ? <span className="v-badge warn">{whisper.installed === false ? "not installed" : "model needed — see AI Models"}</span> : <span className="v-badge ok">available</span>}
            </label>
            <label className="v-small v-muted" title="Multi-signal creates safe candidates. If Ollama is configured, the local model re-ranks them for meaning and context; otherwise the rule-based score is clearly retained.">Ranking <select className="v-input sm" value={engineMode} onChange={e => setEngineMode(e.target.value as "auto" | "baseline")}><option value="auto">Local-AI re-rank when ready</option><option value="baseline">Simple heuristic</option></select></label>
            <label className="v-check" style={{margin: 0}} title={health?.clip_engine?.local_llm?.available ? "Use the configured local Ollama model to re-rank suggestions" : (health?.clip_engine?.local_llm?.reason || "Configure Ollama in .env to enable model re-ranking.")}><input type="checkbox" checked={localRerank} disabled={engineMode === "baseline"} onChange={e => setLocalRerank(e.target.checked)} /> Local AI re-rank {health?.clip_engine?.local_llm?.available ? <span className="v-badge ok">ready</span> : <span className="v-badge">fallback</span>}</label>
            <button className="v-btn" disabled={busy || !project} onClick={() => analyze(false)}>{cands.length ? "Re-analyze" : "Analyze"}</button>
            <button className="v-btn pri" disabled={busy || !project} onClick={() => analyze(true)}>Auto Clip · Find & Render</button>
            {!project.has_transcript && <span className="v-small v-muted">No transcript yet — ranking will use audio/visual signals only (labelled).</span>}
          </div>
        )}
        {project?.error && !busy && (project.download_error ? <LinkErrorBox err={project.download_error} onRetry={retryDownload} /> : <p className="v-err">{project.error}</p>)}
        {needsDownload && !busy && !project?.download_error && <div className="v-row" style={{marginTop: 10}}><button className="v-btn pri" onClick={retryDownload}>Download video</button><span className="v-small v-muted">Linked video not on disk yet. A valid local copy is never downloaded twice.</span></div>}
      </div>

      <div className="v-stack" style={{marginBottom: 16}}><JobStrip job={jobs[0]} ctx={ctx} /></div>

      {!project ? <div className="v-empty">Upload a video or add a link to begin.</div> : (
        <div className="v-grid2">
          <SourcePanel project={project} pid={pid} videoRef={videoRef} onTime={onTime} caption={caption} sel={sel} capPrev={capPrev}
                       transcript={transcript} busy={busy} onSeek={seek} whisper={whisper} />

          <div className="v-stack">
            <div className="v-card">
              <h3>Suggested clips · ranked</h3>
              {cands.length === 0 ? <div className="v-empty">{busy ? "Working…" : "No suggestions yet. Press Analyze or Auto Clip."}</div> : (
                <div className="v-stack">{cands.map(c => <CandidateCard key={c.id} c={c} sel={c.id === selId} busy={busy} onSelect={() => play(c)} onChanged={ctx.refresh} getPlayhead={getPlayhead} ctx={ctx} />)}</div>)}
              <p className="v-small v-dim" style={{margin: "10px 0 0"}}>Scores are relative rankings within this video, not predictions of views. Open “Why selected” to see the evidence and rate a clip. Tick a clip to approve it for export.</p>
              <details className="v-det"><summary>Add a custom clip</summary>
                <div className="v-row" style={{marginTop: 8}}>
                  <input className="v-input sm" placeholder="start 1:05" value={customStart} onChange={e => setCustomStart(e.target.value)} />
                  <input className="v-input sm" placeholder="end 1:40" value={customEnd} onChange={e => setCustomEnd(e.target.value)} />
                  <button className="v-btn sm" disabled={busy || !customStart || !customEnd} title={busy ? "A job is running for this project" : "Enter a start and an end time (for example 1:05 and 1:40)"} onClick={addCustom}>Add</button>
                </div>
              </details>
            </div>

            <ClipSettingsPanel rs={rs} set={set} setRs={setRs} templates={templates} pickTemplate={pickTemplate} project={project}
                              approvedCount={approved.length} busy={busy} onRender={render} ctx={ctx} />
          </div>
        </div>
      )}

      {exportsHere.length > 0 && (
        <div style={{marginTop: 22}}>
          <h3 className="v-sub" style={{textTransform: "uppercase", letterSpacing: ".08em", fontSize: 13}}>Exports for this project</h3>
          <div className="v-grid3">{exportsHere.map((e: any) => <ExportCard key={e.id} e={{...e, project_name: undefined, file_exists: true}} onChange={ctx.refresh} notify={ctx.notify} />)}</div>
        </div>
      )}
    </>
  );
}
