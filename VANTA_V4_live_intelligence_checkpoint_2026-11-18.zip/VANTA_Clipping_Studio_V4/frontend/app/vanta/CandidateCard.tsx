"use client";

import {useEffect, useState} from "react";
import {METHOD_LABEL, V, clock, del, patch, post, type Candidate} from "./api";
import type {Ctx} from "./ctx";
import {WhyPanel} from "./WhyPanel";

/** One ranked suggestion: real timestamps, approval, trimming, reasons and rating. */
export function CandidateCard({c, sel, busy, onSelect, onChanged, getPlayhead, ctx}: {c: Candidate; sel: boolean; busy: boolean; onSelect: () => void; onChanged: () => void; getPlayhead: () => number; ctx: Ctx}) {
  const [s, setS] = useState(clock(c.start)), [e, setE] = useState(clock(c.end)), [open, setOpen] = useState(false);
  useEffect(() => { setS(clock(c.start)); setE(clock(c.end)); }, [c.start, c.end]);
  const [opt, setOpt] = useState<string | null>(null);   // optimistic status until the server confirms
  useEffect(() => { setOpt(null); }, [c.status]);
  const shown = opt ?? c.status;
  const approved = shown === "approved" || shown === "failed" || shown === "rendered" || shown === "queued" || shown === "rendering";
  const save = async (start: string | number, end: string | number) => {
    try { await patch(`/candidates/${c.id}`, {start, end}); onChanged(); } catch (x: any) { ctx.notify(x.message, "bad"); setS(clock(c.start)); setE(clock(c.end)); }
  };
  const setStatus = async (status: string) => { setOpt(status); try { await patch(`/candidates/${c.id}`, {status}); onChanged(); } catch (x: any) { setOpt(null); ctx.notify(x.message, "bad"); } };
  const schedule = async () => { try { await post("/scheduler/tasks", {candidate_id: c.id, settings: {}}); ctx.notify("Approved clip added to the disabled-by-default scheduler queue.", "ok"); } catch (x: any) { ctx.notify(x.message, "bad"); } };
  return (
    <div className={`v-cand ${sel ? "sel" : ""} ${c.status === "rejected" ? "rej" : ""}`}>
      <div className="v-row" style={{justifyContent: "space-between"}}>
        <label className="v-check" style={{margin: 0}}>
          <input type="checkbox" checked={approved} disabled={busy || ["queued", "rendering"].includes(c.status)} onChange={ev => setStatus(ev.target.checked ? "approved" : "suggested")} />
          <span>{c.origin === "custom" ? "Custom clip" : `#${c.rank}`} {c.title ? `· ${c.title}` : ""}</span>
        </label>
        <div style={{textAlign: "right"}}>
          {c.score != null ? <div className="v-score" title={c.analysis?.score_meaning || "Heuristic ranking score. Not a prediction of views or virality."}>{c.score.toFixed(0)}<span className="v-dim v-small"> /100 relative rank</span></div> : <span className="v-dim v-small">no score</span>}
        </div>
      </div>
      <div className="v-row v-small" style={{margin: "6px 0"}}>
        <span className="v-badge pur">{METHOD_LABEL[c.method] || c.method}</span>
        <span className={`v-badge ${c.status === "rendered" ? "ok" : c.status === "failed" ? "bad" : c.status === "rejected" ? "" : "warn"}`}>{c.status}</span>
        {c.edited ? <span className="v-badge">edited</span> : null}
        <span className="v-dim">{(c.end - c.start).toFixed(1)}s</span>
      </div>
      {c.excerpt ? <div className="v-excerpt">“{c.excerpt.length > 220 ? c.excerpt.slice(0, 220) + "…" : c.excerpt}”</div> : null}
      {c.error ? <div className="v-err v-small">{c.error}</div> : null}
      <div className="v-row">
        <input className="v-input sm" value={s} onChange={x => setS(x.target.value)} onBlur={() => save(s, e)} onKeyDown={x => x.key === "Enter" && (x.target as HTMLInputElement).blur()} aria-label="Start time" disabled={busy} />
        <span className="v-dim">→</span>
        <input className="v-input sm" value={e} onChange={x => setE(x.target.value)} onBlur={() => save(s, e)} onKeyDown={x => x.key === "Enter" && (x.target as HTMLInputElement).blur()} aria-label="End time" disabled={busy} />
        <button className="v-btn sm" disabled={busy} title="Use the current video position as the start" onClick={() => save(getPlayhead(), c.end)}>start = playhead</button>
        <button className="v-btn sm" disabled={busy} title="Use the current video position as the end" onClick={() => save(c.start, getPlayhead())}>end = playhead</button>
      </div>
      <div className="v-row" style={{marginTop: 8}}>
        <button className="v-btn sm pri" onClick={onSelect}>▶ Preview</button>
        <button className="v-btn sm" onClick={() => setOpen(!open)}>{open ? "Hide" : "Why selected"}</button>
        {ctx.project?.has_transcript ? <a className="v-btn sm" href={`${V}/candidates/${c.id}/srt`} title="Download the transcript lines of this clip as an .srt, re-timed to start at 0:00">SRT</a>
          : <button className="v-btn sm" disabled title="No transcript is attached, so there is nothing to export">SRT</button>}
        {shown === "approved" ? <button className="v-btn sm" disabled={busy} title="Queue this approved clip for an opt-in local scheduler run. It will never upload to YouTube." onClick={schedule}>Schedule</button> : null}
        <button className="v-btn sm" disabled={busy || ["queued", "rendering"].includes(c.status)} onClick={() => setStatus(c.status === "rejected" ? "suggested" : "rejected")}>{c.status === "rejected" ? "Restore" : "Reject"}</button>
        <button className="v-btn sm bad" disabled={busy || ["queued", "rendering"].includes(c.status)} onClick={async () => { try { await del(`/candidates/${c.id}`); onChanged(); } catch (x: any) { ctx.notify(x.message, "bad"); } }}>Remove</button>
      </div>
      {open && <WhyPanel c={c} notify={ctx.notify} onChanged={onChanged} />}
    </div>
  );
}
