"use client";

import {useEffect, useState} from "react";
import {call, clock, post, V, type ApiError} from "./api";
import type {Ctx} from "./ctx";

type Ingest = {running: boolean; pid?: number | null; segments_published: number; error?: string | null; separate_audio?: boolean};
type ChatSource = {source: string; running: boolean; reason?: string; messages?: number; last_error?: string | null};
type LiveSession = {id: string; platform: string; stream_ref: string; state: string; post_event_seconds: number; buffer: {segments: number; buffered_seconds: number; retention_seconds: number}; chat: {messages_per_second: number; active_chatters: number}; ingest?: Ingest | null; chat_source?: ChatSource | null; chat_problem?: string; clips?: {id: string; status: string}[]; events: {event_time: number; detected_at: number; kind: string; confidence: number; evidence: string[]}[]};
type LiveClip = {id: string; session_id: string; status: string; event?: {kind?: string; event_time?: number; confidence?: number}; duration: number | null; segments: number; error?: string | null; requested_at?: number; project_id?: string | null; candidate_id?: string | null; file_ready: boolean; review_only: boolean; published: boolean};

/** Clips the live pipeline assembled, whether this app or the CLI produced them. Playback and promotion stay local. */
function LiveClipsPanel({ctx}: {ctx: Ctx}) {
  const [clips, setClips] = useState<LiveClip[]>([]), [files, setFiles] = useState<Record<string, File | null>>({}), [busy, setBusy] = useState<string | null>(null);
  const refresh = () => call<{clips: LiveClip[]}>("/live/clips").then(r => setClips(r.clips)).catch(() => {});
  useEffect(() => { refresh(); const timer = setInterval(refresh, 3000); return () => clearInterval(timer); }, []);
  const promote = async (clip: LiveClip) => {
    setBusy(clip.id);
    try {
      const form = new FormData();
      if (files[clip.id]) form.append("transcript", files[clip.id] as File);
      const result = await call<{project_id: string; candidate_id: string}>(
        `/live/clips/${clip.id}/promote`, {method: "POST", body: form});
      ctx.notify(`Promoted to project ${result.project_id}. Nothing was published.`, "ok");
      await ctx.refresh();
      refresh();
    } catch (e: any) { ctx.notify(e.hint ? `${e.message} ${e.hint}` : e.message, "bad"); }
    finally { setBusy(null); }
  };
  return <div className="v-card"><h3>Review live clips</h3><p className="v-small v-dim" style={{marginTop: 0}}>
    Clips assembled from your live sessions. Each one is review-only: play it, then promote it into a normal project to edit and render it. Nothing here publishes or uploads.
  </p>
    <div className="v-stack">{clips.length ? clips.map(clip => {
      const kind = clip.event?.kind || "event";
      const projectId = clip.project_id || null;
      return <div key={clip.id} style={{border: "1px solid var(--line)", borderRadius: 12, padding: 12}}>
        <div className="v-row" style={{justifyContent: "space-between"}}>
          <div><strong>{kind.toUpperCase()}</strong> <span className="v-small v-dim">· {clip.status.replace(/_/g, " ")} · {clock(clip.duration)} · {clip.segments} segment(s){clip.event?.event_time != null ? ` · event at ${clip.event.event_time.toFixed(1)}s` : ""}</span>
            {clip.error ? <div className="v-small" style={{color: "var(--bad)"}}>{clip.error}</div> : null}</div>
          {projectId ? <span className="v-small">Project <code>{projectId}</code></span> : null}
        </div>
        {clip.file_ready ? <video controls preload="metadata" src={`${V}/live/clips/${clip.id}/file`} style={{width: "100%", maxWidth: 420, marginTop: 10, borderRadius: 10}} /> : null}
        <div className="v-row" style={{marginTop: 10}}>
          {projectId
            ? <button className="v-btn sm" onClick={() => { ctx.selectProject(projectId); ctx.go("create"); }}>Open in Create Shorts</button>
            : <>
              <input className="v-input sm" style={{width: 210, padding: "4px 8px"}} type="file" accept=".srt,.vtt,.json"
                     title="Optional transcript: needed only when no local speech model is installed"
                     onChange={e => setFiles(f => ({...f, [clip.id]: e.target.files?.[0] || null}))} />
              <button className="v-btn pri sm" disabled={busy === clip.id || clip.status !== "ready_for_review"}
                      onClick={() => promote(clip)}>{busy === clip.id ? "Promoting…" : "Promote reviewed clip"}</button>
              <span className="v-small v-dim">Transcript is optional when local transcription is ready.</span>
            </>}
        </div>
      </div>;
    }) : <div className="v-empty">No live clips yet. Run the live pipeline (or the CLI), then review its clips here.</div>}</div>
    <p className="v-small v-dim" style={{marginBottom: 0}}>Promotion needs no credentials and creates one project and one candidate; publishing remains a separate, manual step.</p>
  </div>;
}

/** Dashboard for bounded, authorised live-monitoring sessions. It does not expose credentials. */
export function LiveView({ctx}: {ctx: Ctx}) {
  const [sessions, setSessions] = useState<LiveSession[]>([]), [platform, setPlatform] = useState("youtube"), [ref, setRef] = useState(""), [source, setSource] = useState(""), [busy, setBusy] = useState(false);
  const refresh = () => call<LiveSession[]>("/live/sessions").then(setSessions).catch(() => {});
  useEffect(() => { refresh(); const timer = setInterval(refresh, 2000); return () => clearInterval(timer); }, []);
  const create = async () => {
    if (!source.trim()) return;
    setBusy(true);
    try {
      const started = await post<{note?: string}>("/live/sessions", {platform, stream_ref: ref, source, authorized: true});
      setRef(""); setSource(""); refresh();
      ctx.notify(started.note || "Live session started: FFmpeg is reading your source.", "ok");
    }
    catch (e: any) { ctx.notify(e.hint ? `${e.message} ${e.hint}` : e.message, "bad"); } finally { setBusy(false); }
  };
  const stop = async (id: string) => { try { await post(`/live/sessions/${id}/stop`); refresh(); } catch (e: any) { ctx.notify(e.message, "bad"); } };
  return <>
    <header className="v-head"><div><h1>Live Intelligence</h1><p>Monitor authorised YouTube or Twitch sources with a bounded local buffer. Detected moments always remain review-only.</p></div></header>
    <div className="v-card"><h3>Start authorised monitoring</h3><div className="v-row"><select className="v-select" value={platform} onChange={e => setPlatform(e.target.value)}><option value="youtube">YouTube Live</option><option value="twitch">Twitch</option><option value="manual">Manual adapter test</option></select><input className="v-input" style={{minWidth: 180}} value={ref} onChange={e => setRef(e.target.value)} placeholder={platform === "twitch" ? "Channel (optional with a link)" : platform === "youtube" ? "Video id (optional with a link)" : "Session label"} /><button className="v-btn pri" disabled={busy || !source.trim()} onClick={create}>{busy ? "Starting…" : "Start monitoring"}</button></div>
      <div className="v-row" style={{marginTop: 8}}><input className="v-input" style={{flex: 1, minWidth: 320}} value={source} onChange={e => setSource(e.target.value)} placeholder="https://www.youtube.com/live/…, a Twitch channel link, a direct HLS/RTMP URL, or a local capture file" /><span className="v-small v-dim">Links are resolved locally with yt-dlp.</span></div>
      <p className="v-small v-dim" style={{marginBottom: 0}}>A YouTube/Twitch live link is resolved with the local yt-dlp (Platform links must be enabled) and its video + audio playlists are read by one FFmpeg ingest into a bounded buffer. Direct HLS/RTSP/RTMP URLs and local capture files work too. Chat is read only: YouTube needs its OAuth token, Twitch reads public chat anonymously. If chat cannot start, the stream still ingests and the reason is shown on the session. Nothing is published.</p></div>
    <LiveClipsPanel ctx={ctx} />
    <div className="v-stack">{sessions.length ? sessions.map(session => <div className="v-card" key={session.id}><div className="v-row" style={{justifyContent: "space-between"}}><div><h3 style={{margin: 0}}>{session.platform} · {session.state}</h3><div className="v-small v-dim">{session.stream_ref}</div></div><button className="v-btn sm" disabled={session.state !== "monitoring"} onClick={() => stop(session.id)}>Stop</button></div><div className="v-row v-small" style={{marginTop: 10, gap: 14}}><span>Buffer: {session.buffer.buffered_seconds.toFixed(0)}s / {session.buffer.retention_seconds}s</span><span>Segments: {session.buffer.segments}</span><span>Chat: {session.chat.messages_per_second.toFixed(1)} msg/s</span><span>Active chatters: {session.chat.active_chatters}</span><span>Candidates: {session.events.length}</span></div><div className="v-row v-small" style={{marginTop: 6, gap: 14}}><span>Ingest: {session.ingest?.running ? `running${session.ingest.pid ? ` (pid ${session.ingest.pid})` : ""}` : "not running"} · {session.ingest?.segments_published ?? 0} segment(s) written</span><span>Chat adapter: {session.chat_source?.running ? session.chat_source.source : "not running"}</span></div>{session.ingest?.error ? <div className="v-small" style={{color: "var(--bad)"}}>{session.ingest.error}</div> : null}{session.chat_problem || session.chat_source?.reason ? <div className="v-small v-dim">{session.chat_problem || session.chat_source?.reason}</div> : null}<div style={{marginTop: 10}}>{session.events.length ? session.events.slice().reverse().map((event, i) => <div className="v-small" key={i}><strong>{event.kind.toUpperCase()}</strong> · {Math.round(event.confidence)}% · event at {event.event_time.toFixed(1)}s <span className="v-dim">{event.evidence[0]}</span></div>) : <span className="v-small v-dim">Waiting for synchronised chat and media evidence.</span>}</div></div>) : <div className="v-empty">No live sessions. Start one when its authorised adapter is configured.</div>}</div>
  </>;
}
