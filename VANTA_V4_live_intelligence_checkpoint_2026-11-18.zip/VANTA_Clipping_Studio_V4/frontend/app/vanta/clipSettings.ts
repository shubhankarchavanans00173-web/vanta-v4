/** Clip render settings shared by Create Shorts: defaults, persistence, hook and the render payload. */

export const DEFAULT_RS = {aspect: "9:16", reframe: "blur", captions: true, template_id: "builtin-highlight", mode: "word_highlight", font_size_pct: 4.6, position: "bottom", margin_pct: 16,
  color: "#FFFFFF", highlight_color: "#FFC83C", max_words_per_line: 3, uppercase: true, background: false, keep_original_audio: true, volume: 1, music_id: "", music_name: "",
  music_volume: 0.15, ducking: true, remove_silence: false, silence_min_seconds: 0.7};
export type RS = typeof DEFAULT_RS;

/** Restore the last used settings. An uploaded music file is never restored (its id is per upload). */
export function loadRS(): RS {
  try { const raw = localStorage.getItem("vanta.rs"); if (raw) return {...DEFAULT_RS, ...JSON.parse(raw), music_id: "", music_name: ""}; } catch {}
  return DEFAULT_RS;
}

export function saveRS(rs: RS): void {
  try { localStorage.setItem("vanta.rs", JSON.stringify(rs)); } catch {}
}

/** The exact object POST /render expects. Captions are only requested when a transcript exists. */
export function renderSettingsPayload(rs: RS, hasTranscript: boolean) {
  const style = {mode: rs.mode, font_size_pct: rs.font_size_pct, position: rs.position, margin_pct: rs.margin_pct, color: rs.color, highlight_color: rs.highlight_color, max_words_per_line: rs.max_words_per_line, uppercase: rs.uppercase, background: rs.background};
  return {aspect: rs.aspect, reframe: rs.reframe, captions: rs.captions && hasTranscript, caption_style: style, keep_original_audio: rs.keep_original_audio, volume: rs.volume,
    music_id: rs.music_id || undefined, music_volume: rs.music_volume, ducking: rs.ducking, remove_silence: rs.remove_silence, silence_min_seconds: rs.silence_min_seconds};
}
