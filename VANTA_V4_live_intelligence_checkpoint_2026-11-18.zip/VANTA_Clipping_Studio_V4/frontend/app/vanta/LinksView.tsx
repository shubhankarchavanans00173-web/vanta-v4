"use client";
import {useState} from "react";
import {ACTIVE, ApiError, STATUS_LABEL, post, type LinkErr} from "./api";
import type {Ctx} from "./ctx";
import {DiagnosticsPanel} from "./DiagnosticsPanel";
import {LinkErrorBox} from "./LinkErrorBox";

export function LinksView({ctx}: {ctx: Ctx}) {
  const [url, setUrl] = useState(""), [rights, setRights] = useState(false), [busy, setBusy] = useState(false), [updating, setUpdating] = useState(false);
  const [addErr, setAddErr] = useState<LinkErr | null>(null), [retrying, setRetrying] = useState<string | null>(null), [upd, setUpd] = useState<any>(null), [showDiag, setShowDiag] = useState(false);
  const links = ctx.health?.links;
  const linked = ctx.projects.filter(p => p.source_type === "link");
  const activeFor = (pid: string) => ctx.jobs.find(j => j.project_id === pid && ACTIVE.has(j.status));
  async function add() {
    setBusy(true); setAddErr(null);
    try {
      const p = await post("/projects/link", {url, rights_confirmed: rights});
      setUrl(""); await ctx.refresh(); ctx.selectProject(p.id);
      ctx.notify(p.duplicate ? "That video was already added. Opened the existing project (no second download)." : p.job ? "Link accepted. Downloading now — progress is shown in Create Shorts and the Processing Queue." : "Link accepted.", "ok");
      ctx.go("create");
    } catch (e: any) {
      if (e instanceof ApiError && e.code) setAddErr({code: e.code, message: e.message, retryable: !!e.retryable, hint: e.hint, details: e.details});
      else setAddErr({code: "request_failed", message: e.message, retryable: false});
    } finally { setBusy(false); }
  }
  async function retry(pid: string) {
    setRetrying(pid);
    try {
      const r = await post(`/projects/${pid}/download`);
      await ctx.refresh();
      ctx.notify(r.already_downloaded ? r.message : "Retrying the download…", "ok");
    } catch (e: any) { ctx.notify(e.message, "bad"); } finally { setRetrying(null); }
  }
  async function updateYtdlp() {
    setUpdating(true); setUpd(null);
    try {
      const r = await post("/links/update-ytdlp");
      setUpd({ok: true, ...r}); await ctx.refresh(); ctx.notify(r.message, "ok");
    } catch (e: any) { setUpd({ok: false, message: e.message}); ctx.notify(e.message, "bad"); }
    finally { setUpdating(false); }
  }
  return (
    <>
      <h1 className="v-h1">Video Links</h1>
      <p className="v-sub">Paste a link to a video you have the right to use. VANTA checks the link, downloads it into its own folder, validates the file, and only then lets you analyze it. If a link cannot be fetched, upload the video file instead.</p>
      <div className="v-grid2">
        <div className="v-card">
          <h3>Add a link</h3>
          <input className="v-input" style={{width: "100%"}} placeholder="https://www.youtube.com/watch?v=…  ·  youtu.be/…  ·  /shorts/…  ·  https://…/video.mp4" value={url} onChange={e => setUrl(e.target.value)} onKeyDown={e => e.key === "Enter" && url.trim() && rights && !busy && add()} />
          <label className="v-check" style={{marginTop: 12}}><input type="checkbox" checked={rights} onChange={e => setRights(e.target.checked)} /> I own this video or have permission to make clips from it.</label>
          <div className="v-row" style={{marginTop: 10}}><button className="v-btn pri" disabled={!url.trim() || !rights || busy} title={!url.trim() ? "Paste a video link first" : !rights ? "Confirm that you own the video or have permission to use it" : busy ? "Working…" : "Check the link and download the video"} onClick={add}>{busy ? "Checking…" : "Check link & download"}</button>
            <span className="v-dim v-small">Can’t use a link? Upload the file from Create Shorts — that always works.</span></div>
          {addErr && <LinkErrorBox err={addErr} onDiagnostics={() => { setShowDiag(true); setTimeout(() => document.getElementById("v-diagnostics")?.scrollIntoView({behavior: "smooth"}), 50); }} />}
        </div>
        <div className="v-card">
          <h3>What is supported here</h3>
          {!links ? <p className="v-muted">Backend not reachable.</p> : (
            <dl className="v-kv">
              <dt>Direct file links</dt><dd><span className="v-badge ok">available</span> <span className="v-small v-muted">{links.direct_media.detail}</span></dd>
              <dt>Platform pages</dt><dd><span className={`v-badge ${links.platforms.available ? "ok" : "warn"}`}>{links.platforms.available ? "enabled" : "off"}</span> <span className="v-small v-muted">{links.platforms.detail}</span></dd>
              <dt>yt-dlp version</dt><dd className="v-small">{links.platforms.yt_dlp_version || (links.platforms.yt_dlp_installed ? "Installed; version unavailable" : "Not installed")}</dd>
              <dt>YouTube forms</dt><dd className="v-small">{(links.platforms.youtube_forms || []).join(" · ")}</dd>
              <dt>Never supported</dt><dd className="v-small v-muted">{links.never_supported.join("; ")}</dd>
            </dl>
          )}
          {links ? <div className="v-row" style={{marginTop: 12}}>
            <button className="v-btn" disabled={updating || ctx.jobs.some(j => ACTIVE.has(j.status) && j.kind !== "render")} onClick={updateYtdlp}>{updating ? "Updating yt-dlp…" : "Update yt-dlp"}</button>
            <button className="v-btn" onClick={() => setShowDiag(true)}>Diagnostics</button>
            <span className="v-small v-muted">Updates only the Python environment this backend runs in.</span>
          </div> : null}
          {upd && (upd.ok
            ? <p className="v-small" style={{margin: "10px 0 0"}}><span className="v-badge ok">{upd.changed ? "updated" : "already current"}</span> {upd.message}{upd.other_packages_changed?.length ? ` Other packages changed: ${upd.other_packages_changed.join(", ")}.` : ""}</p>
            : <p className="v-err v-small" style={{margin: "10px 0 0"}}>{upd.message}</p>)}
        </div>
      </div>
      {showDiag && <div style={{marginTop: 16}}><DiagnosticsPanel ctx={ctx} autoRun /></div>}
      <div className="v-card" style={{marginTop: 16}}>
        <h3>Linked projects</h3>
        {linked.length === 0 ? <div className="v-empty">No linked videos yet.</div> : (
          <table className="v-table"><thead><tr><th>Link</th><th>Status</th><th></th></tr></thead><tbody>
            {linked.map(p => {
              const job = activeFor(p.id);
              return <tr key={p.id}><td style={{wordBreak: "break-all"}}>{p.source_ref}{p.has_source ? <div className="v-dim v-small">✓ downloaded and validated{p.probe?.duration ? ` · ${Math.round(p.probe.duration)}s · ${p.probe.width}×${p.probe.height}` : ""}</div> : null}</td>
                <td><span className={`v-badge ${p.status === "failed" ? "bad" : job ? "pur" : ""}`}>{STATUS_LABEL[p.status] || p.status}</span>
                  {job ? <div className="v-small v-muted">{job.message}{job.progress != null ? ` · ${Math.round(job.progress * 100)}%` : ""}</div> : null}
                  {!job && p.download_error ? <LinkErrorBox err={p.download_error} onRetry={() => retry(p.id)} retrying={retrying === p.id} onDiagnostics={() => setShowDiag(true)} /> : (!job && p.error ? <div className="v-err v-small">{p.error}</div> : null)}</td>
                <td className="v-row"><button className="v-btn sm" onClick={() => { ctx.selectProject(p.id); ctx.go("create"); }}>Open</button>
                  {!p.has_source && !job && !p.download_error ? <button className="v-btn sm" disabled={retrying === p.id} onClick={() => retry(p.id)}>Download</button> : null}</td></tr>;
            })}
          </tbody></table>)}
      </div>
    </>
  );
}
