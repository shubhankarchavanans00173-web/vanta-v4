@echo off
setlocal
rem VANTA one-command verification. Writes verify_report.txt (send that file back).
rem   verify_all.bat                         everything (tests can take 10-25 minutes)
rem   verify_all.bat --skip-tests           environment + live checks only
rem   verify_all.bat --skip-network         no live YouTube download
rem   verify_all.bat --video "D:\talk.mp4"  also transcribe 60 s with the real Whisper model (must already be downloaded)
rem   verify_all.bat --url https://www.youtube.com/watch?v=...   use another PUBLIC video you may use
rem Never registers the scheduled task, never uploads, never downloads a Whisper model.
rem Exit code: 0 = nothing FAILED (skips possible), 1 = a check failed, 2 = cannot run.
set "ROOT=%~dp0"
cd /d "%ROOT%"
call "%ROOT%_find_python.bat"
if not defined STUDIO_PYTHON goto :nopython
echo Using Python: %STUDIO_PYTHON%
set "ORIG_PAUSE=%VANTA_NO_PAUSE%"
set "VANTA_NO_PAUSE=1"
set "PYTHONIOENCODING=utf-8"
"%STUDIO_PYTHON%" "%ROOT%backend\verify_all.py" %*
set "RC=%ERRORLEVEL%"
goto :done

:nopython
echo [!!] Backend Python environment not found. Run setup_backend.bat first, or set VANTA_PYTHON.
set "RC=2"
goto :done

:done
echo.
if "%RC%"=="0" echo Finished: nothing failed. Check the report for SKIPPED lines - those are NOT verified.
if "%RC%"=="1" echo Finished: at least one check FAILED. Send verify_report.txt back.
if "%RC%"=="2" echo Could not run.
if not "%ORIG_PAUSE%"=="1" pause
endlocal & exit /b %RC%
