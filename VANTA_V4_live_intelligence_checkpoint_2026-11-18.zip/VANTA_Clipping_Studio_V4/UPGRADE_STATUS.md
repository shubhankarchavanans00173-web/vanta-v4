# VANTA Clipping Studio - Upgrade Status

## Session 13 - local review panel for live clips (2026-11-17)

Real Windows 11, real FFmpeg; verified in a running browser, not only in tests.

The CLI runs in its own process, so the app can only see live clips through a shared record: `live/clip_store.py`
writes one atomically-replaced JSON sidecar per job (`<data>/live/clips/<job id>.job.json`) from `LiveReviewPipeline`,
and the review routes read it. Three local endpoints were added in `routes/live.py`: list (ids and metadata, **never a
media path**), play (`GET .../file`, resolved server-side and refused outside the clips folder), and promote
(`POST .../promote`, optional transcript upload + title). Promotion calls `clip_store.promote(..., reviewed=True)`,
which delegates to the same handoff used by `LiveReviewPipeline.promote(reviewed=True)`, and records
`project_id`/`candidate_id` on the sidecar so a second promotion is refused across processes too.

Frontend: **Live Intelligence → Review live clips** (`LiveView.tsx`) lists clips, plays them inline, offers
**Promote reviewed clip** with an optional `.srt/.vtt/.json` box, and after promotion shows the project id plus
**Open in Create Shorts**, which calls `selectProject`/`go("create")` so the promoted clip lands in the normal
workflow. There is deliberately **no publish button, no upload button and no media-path input** anywhere in the panel.

Verified live (demo data in a throwaway `VANTA_DATA_DIR`): panel listed `CHAT_SPIKE · ready for review · 0:04.0` with a
working `<video>`; promotion via the API returned project `ddae6819fd11`; the card refreshed to `Project ddae6819fd11`
with **Open in Create Shorts**; clicking it opened Create Shorts with the project selected, transcript loaded and the
`live-review` candidate approved for rendering. Backend: 9 new API tests, 6/6 mutations (`work/mutation_live_panel.py`),
full suite 589 OK. Frontend: `tsc --noEmit` and `next build` clean.

Reported and fixed in session 13 follow-up: **a live session in the app never took a stream**. `POST /live/sessions`
recorded an in-memory row and returned "ready for its authorised backend adapter", so buffer, segments and chat stayed
at zero and no clip could appear; only the CLI ingested media. The endpoint now starts the same `LiveSessionRunner` the
CLI uses: `source` is validated (`source_required`, `not_a_media_stream` for a platform watch page, `bad_source`), a
real FFmpeg segment ingest fills the rolling buffer, chat is built through the new `live/chat_factory.py` (YouTube
token, Twitch anonymous public chat, or a `NullChatSource` that reports why), and `stop`/app shutdown end chat then
FFmpeg. Chat builders moved out of `cli.py` into that shared module so both entry points use one implementation.
Covered by `backend/tests/test_live_session_api.py` (3 tests, real FFmpeg: segments published, buffer > 0 s, clean
stop; watch page and missing source refused). Review panel stays as delivered.

Then the owner pasted a YouTube live link and it was refused as a watch page. Follow-up: `live/stream_source.py`
resolves a public platform link with the local yt-dlp (only when `VANTA_ENABLE_YTDLP=1`; a refusal carries the tool's own
reason), `SegmentIngest` accepts a **separate audio playlist** (live YouTube publishes video-only + audio-only HLS, so
one input would be silent), the session derives its chat reference from the link when no id is given, and the signed
media URLs never leave the server - the payload keeps the page link. Verified with the owner's link on this machine:
15 segments / 60 s buffered, sampled segment `h264` + `aac`; YouTube chat stayed off because no OAuth token is connected.

Hardening found in review: the promote endpoint used to derive its temp transcript filename from the raw path id
before validating it, so a decoded Windows id such as `..\..\evil` could aim a write outside the temp folder. The id is
now validated (and the clip must exist) **before** any upload is read, and the temp name is a random token instead of
request input. Covered by `test_promote_with_a_windows_traversal_id_and_transcript_upload_writes_nothing`, which asserts
`_save_upload` is never called for a bad id, plus the matching mutation.

Not done on purpose: no HTTP endpoint accepts a media path; no live pipeline instance is started by the app (the CLI
remains the producer); chat integrations stay **PARTIAL** (still no real credentials in this workspace).

## Session 12 - reviewed live clip becomes a real project (2026-11-17)

Real Windows 11, Python 3.14.5, FFmpeg 9.0.1. No new dependency: the handoff reuses the existing DB, transcript storage, caption builder and render queue.

`live/handoff.py` is the one-way bridge the live pipeline was missing: the review-only MP4 is copied into the normal upload folder, transcribed locally (or taken from a transcript file the reviewer attaches), stored as the project's transcript JSON plus a standalone `.srt`, and given one candidate covering the whole clip. After that the existing analyze / approve / render / export / publish-metadata routes operate on it unchanged - no live-specific rendering path exists or is needed.

Safety rules, all tested: the clip must be a playable video **inside VANTA's data folder** (a path from a browser cannot import arbitrary media); a transcript is mandatory (local engine or attached file) because a project without captions is not publishable; `LiveReviewPipeline.promote(job_id, reviewed=True)` requires the explicit human-review flag and only accepts `ready_for_review` jobs, and refuses to promote the same job twice; every failure rolls back the project row, source copy, transcript JSON and SRT. `published`/`review_only` stay in the payload so a promoted project cannot be mistaken for a published clip.

Operator surface: `python -m app.clipstudio.live.cli --promote <clip.mp4> [--transcript clip.srt] [--title "..."] [--json]` (local, no credentials, nothing uploaded). There is deliberately **no HTTP endpoint that takes a media path**: an HTTP promotion route must wait for the persisted clip registry, because otherwise it would accept arbitrary filesystem paths.

Evidence: `backend/tests/test_live_clip_handoff.py` (9 tests: project/transcript/SRT/candidate, suggestion mode, unavailable-engine refusal, outside-data refusal, non-video/missing refusal, rollback after a post-creation failure, review gate + double-promotion, and a whole-app run that promotes -> analyzes -> renders through the API and ffprobes the exported 1080x1920 h264 file); `work/mutation_handoff.py` 6/6 caught. Transcription is stubbed in tests: this machine has no faster-whisper model, so **real ASR of a live clip is NOT VERIFIED** - attach an `.srt` or install a model.

## Session 11 - Phase 5 step 2: real YouTube/Twitch chat wired to review-only clips (2026-11-17)

Real Windows 11, Python 3.14.5. No new dependency: Twitch IRC uses `socket` + `ssl`; YouTube reuses the existing Google libraries and the app's saved OAuth login.

| Step | Status |
|---|---|
| YouTube Live Chat adapter | DONE, fake-transport verified (**PARTIAL** for real credentials). `find_live_chat_id` resolves `activeLiveChatId` with actionable errors for a missing video, a non-live video and no active chat. The adapter stamps messages with stream time, records the API's `pollingIntervalMillis` (clamped 250 ms–10 s; `liveChatMessages.list` costs 5 quota units per call) and threads the page token. |
| Twitch IRC adapter | DONE, fake-socket verified (**PARTIAL** for real credentials). Read-only IRC over TLS (6697) with the standard library only: anonymous `justinfan` nick for public chat, optional `TWITCH_OAUTH_TOKEN` (`chat:read`), PING→PONG, split-line reassembly, and explicit errors for RECONNECT, auth failure and a closed socket. It never sends PRIVMSG (a test asserts it). |
| Chat sources | DONE. `chat_sources.py` owns polling/reading, retry with backoff and reconnect budgets; every message is re-stamped with `StreamClock` (the rolling buffer's media timestamp), so a spike is placed at footage that exists instead of wall-clock zero. |
| Session runner + CLI | DONE. `session_runner.py` wires session → ingest → chat source → `LiveReviewPipeline` and stops in the safe order (chat, ingest, session). `python -m app.clipstudio.live.cli` is the operator entry point; `--check` validates credentials and chat without media or clips, `--json`/`--seconds`/`--buffer`/`--before`/`--after`/`--segment`/`--output` for a real run. No credential is ever printed; diagnostics report only paths and booleans. |
| End to end | VERIFIED (Windows): scripted source (the interface the real sources use) + real FFmpeg stream + manager + pipeline → exactly one `ready_for_review` clip, `review_only: true`, `published: false`, duration matching a 5 s window. 4/4 mutations caught: stamping removed, runner not wiring `on_event`, Twitch token never sent, discovery returning the video id. |
| Race found by the wiring test | FIXED: `review_pipeline.submit` registered a job before starting its thread, so a concurrent `drain()` could join an unstarted thread (`RuntimeError`). The thread is now started inside the pipeline lock and `_join_started` never raises; two new tests cover the started-before-visible invariant and concurrent submit/drain. |
| Regression | Full suite on Windows: **571 tests, OK (skipped=3), 272 s** (547 before, 24 new); `compileall` and pyflakes clean on the new modules and tests. |

**Still PARTIAL:** no real YouTube/Twitch credential, quota error, moderation/ban event, slow-mode, reconnect or live URL has been exercised. Moving the label needs one `--check` against the operator's own account and one real spike producing one clip. Required inputs are listed in `docs/LIVE_INGEST.md`: YouTube `data/secrets/client_secret.json` (or `YOUTUBE_CLIENT_SECRET_FILE`) plus the Connect-YouTube token (`YOUTUBE_TOKEN_FILE` override) and a live video id; Twitch `TWITCH_CHANNEL`, optionally `TWITCH_OAUTH_TOKEN` (`chat:read`) and `TWITCH_NICK`. There is still no live UI, and nothing is uploaded or published.

## Session 10 - Phase 5 step 1: local segment ingest and review-only live clips (2026-11-17)

Real Windows 11, Python 3.14.5, FFmpeg 9.0.1. No new dependency, no paid API, no credential used or stored.

| Step | Status |
|---|---|
| Local FFmpeg segment ingest for an authorised source | DONE, Windows-verified. `live/segment_ingest.py` runs one FFmpeg that writes MPEG-TS segments into the session folder. `resolve_source` accepts only an existing local file or an explicitly named `http(s)`/`rtsp`/`rtmp(s)` URL and rejects `file://`, `concat:`, `pipe:`, `md5:` (tested). Commands are argument lists, never shell strings. `-force_key_frames` on every boundary: without it a 2 s request produced ~8 s segments and the post-event window arrived late or never (found by a real test, then fixed). |
| Buffer feeding: atomic, bounded, self-cleaning | DONE, Windows-verified. A segment is published only when the FFmpeg segment-list CSV lists it with a positive duration **and** its file is non-empty; a listed-but-still-empty file is not published (mutation-checked). The ingest owns a publication poller thread, so the buffer keeps moving without an external tick. Retention and `max_segments` come from `RollingBuffer`; `max_bytes` (512 MiB default) evicts and deletes the oldest via new `RollingBuffer.evict_oldest()`. Deletion is refused unless the path resolves inside the session's `segments/` folder; list names are reduced to their basename; refusals are reported. The source file is never touched. |
| Review fix: pruning could race a running assembly | DONE, Windows-verified. Segment deletion (retention **and** the disk cap) could previously remove a file `LiveClipWorker` was concatenating. `RollingBuffer.lease_window()` now selects and pins a window under the buffer lock, `assemble()` holds that lease for the whole FFmpeg run and releases it in `finally`, and the ingest performs the pin check and the unlink under the same lock; a pinned file's deletion is deferred (`status()["deferred_deletions"]`, `"deleted_after_release"`) and retried after every poll. While a clip assembles the cap can be exceeded by that clip's window only. |
| `LiveClipWorker.assemble()` wired to detected events | DONE, Windows-verified. New `live/review_pipeline.py`: subscribes to the manager's `on_event`, waits in a worker thread until the buffer holds `event_time + post_event_seconds`, then assembles one clip per event and records a job (`ready_for_review` / `pending_post_event_footage` / `failed`). Every job says `review_only: true`, `published: false`, `publishing: "manual approval only"`. |
| Real local stream test | DONE. A generated video read with `ffmpeg -re` (a paced local stream) feeds a real buffer; segments arrive progressively and do not overlap; the assembled MP4 is verified with ffprobe at the requested 6 s window (±1.5 s). A fake YouTube transport + real stream + real assembly produces exactly one review-only clip. |
| Regression | Full suite on Windows: **547 tests, OK (skipped=3), 266 s**; `compileall` clean; pyflakes clean on the new modules and test. |
| Mutation checks | 9/9 caught over two rounds. Round 1: empty partial segment published, deletion outside the session folder allowed, disk cap disabled, forced keyframes removed, background poller disabled, review clip reported as published (one initially **missed** because no test covered a *listed but empty* segment; the test was added rather than the mutation ignored). Round 2 (lease fix): pinned segments deletable again, deferred deletions never retried, assembly releasing its lease before encoding. All restored and re-verified green. |

**Not claimed (see `docs/LIVE_INGEST.md`):** chat integrations are **PARTIAL** - YouTube Live Chat and Twitch IRC run only against fake transports (a fake Google client, hand-written IRC lines); no real credential, quota, reconnect or moderation event was tried. No real YouTube/Twitch URL was ingested, so the network path, platform throttling and reconnect behaviour are untested. There is no UI surface for live clips, and live moments are still not ranked by the selection engine.

## Session 9 - Phase 3 steps 1-2: Unicode tokenisation and Hindi/Hinglish cues (2026-11-17)

Real Windows 11, Python 3.14.5. No model, no paid API, no new dependency.

| Step | Status |
|---|---|
| Phase 3 step 1: Unicode-aware tokenisation in `selection/lexicon.py` | DONE, Windows-verified. Written test-first: the new tests failed against the old code (7 failures, `words("हिन्दी में लिखा है।")` returned `[]`), then passed. Letters, combining marks (matras, virama, nukta) and digits now stay inside a token; danda `।`/`॥` ends a sentence; input is NFC-normalised. Pure-ASCII text still takes the original `[A-Za-z0-9']+` regex path, so English tokens, content words and trigrams are provably identical (equality test against the old pattern, plus the bundled English fixture script). |
| Phase 3 step 2: Hindi/Hinglish cue module | DONE, unit- and engine-verified, **not scored**. `selection/languages/` (registry) + `hindi.py` (eight cue categories, Devanagari and romanised forms, literal evidence). `candidate.analysis.language_cues` carries the result; no weight reads it, and a test proves a bogus cue payload cannot move a score. Plain English returns no Hindi cues. Not shown in the UI yet. |
| Regression | Full suite on Windows: **519 tests, OK (skipped=3), 254 s** (488 before this session, 31 new); `compileall` clean; pyflakes clean on the new modules (only the pre-existing unused `re` in `engine.py`). |
| Mutation checks | 5/5 caught: tokeniser reverted to ASCII-only, combining marks dropped from the word categories, danda removed from `TERMINAL`, the Hindi adapter claiming every text, and the banter cue list emptied. Each restored and re-verified green. |

**Not claimed:** semantic understanding of Hindi, translation, transliteration (romanised and Devanagari are handled as separate surface forms), speaker diarisation, audio tone, or that a matched cue makes a moment funny. Other scripts tokenise but have no cue lists. The cues are not a ranking input yet.

## Session 8 - Phase 2c steps 4-5, Phase 2d, real Windows verification (2026-11-17)

Windows 11, Python 3.14.5, Node 24.16.0, FFmpeg 9.0.1, yt-dlp 2026.10.26. This session ran on the target OS rather than a Linux sandbox.

| Step | Status |
|---|---|
| Phase 2c step 4: `frontend/app/vanta/CreateView.tsx` split (29.7 KB → 17 KB orchestrator) | DONE, Windows-verified. New modules: `CandidateCard.tsx`, `SourcePanel.tsx`, `ClipSettingsPanel.tsx`, `JobStrip.tsx`, `clipSettings.ts` (defaults/persistence/render payload), `useClipSettings.ts`. `JobStrip` is still exported from `CreateView.tsx` for old imports. `tsc`, `build`, 7 new static guard tests and a real browser click-through pass. |
| Phase 2c step 5: `frontend/app/legacy/page.tsx` split (53 KB → 1.2 KB composition) | DONE, Windows-verified. 124 state values and 25 handlers moved verbatim into `useStudioState.ts`; nine panels (`Sidebar`, `StudioHeader`, `CreatePanel`, `PreviewPanel`, `MetadataPanel`, `YouTubePanel`, `StoryboardPanel`, `HistoryPanel`, `ProviderPanel`) plus `api.ts` and `types.ts`. Every JSX block was copied by line range (no retyping); the guard test proves each panel's bindings still exist in the hook. Browser: workflow switch, prompt editing, `<details>` toggles, anchors, 0 console errors. |
| Phase 2d: queue "continued automatically" indicator and navigation | DONE, Windows-verified in a real browser: `Continued automatically as job <id>` on the interrupted job, `Continued from job <id> · resume N` on the resumed job, click scrolls to and highlights the other row, failed jobs that were not resumed say why. New backend test proves `GET /jobs` exposes both links. |
| Reliability validation incl. captions rendering | DONE: **488 tests OK (skipped=3), 248 s**, `tsc --noEmit` 0, `npm run build` 0, `compileall -q backend` clean, pyflakes clean on the new module (only pre-existing unused imports elsewhere). |
| Fresh baseline repaired | A first Windows run gave 481 tests / 6 failures / 13 errors, all environmental or stale (missing optional `yt-dlp`, POSIX-only path assertions, symlink privilege, `PosixPath` snapshots, a retired label, fontconfig simulation). Fixed at the cause - see `docs/FINAL_TEST_REPORT.md`. |
| Windows temp-folder lock | Fixed: the scheduler kept `diagnostics/scheduler.log` open, breaking temp-folder cleanup with `WinError 32`; the handler now opens per record. |
| Mutation checks | 4 caught (panel un-mounted, hook binding removed, `/jobs` result dropped, log handler reverted), each restored and re-verified. |
| Still open from Phase 2 | None. `verify_all.bat`/launcher execution on Windows is still the user's to run (not touched this session). |

**Not claimed this session:** live YouTube/Twitch monitoring against a real stream, multimodal/audio-event detection, Hindi tokenisation, Ollama reranking against a real model, NVENC, OAuth upload. Those are Phase 3+ items and need the user's approval before starting.

## V3 conversational intelligence — Phase 1 (2026-11-17)

**Implemented and unit-tested in this workspace:** `clipstudio/intelligence/` supplies deterministic setup/payoff, humour, banter, sarcasm-wording, direct-audience-address and conversational-turn signals. The multi-signal engine (version 3.0) now treats them as explainable ranking features, generates candidates around a contextual punchline and its setup, and preserves the simple heuristic fallback. The review UI now exposes the requested editor labels and keeps older feedback labels readable.

**Intentionally not claimed:** a transcript has no speaker diarisation, so VANTA does not claim who said a line; audio loudness is not laughter detection; no live platform source, chat authentication, rolling-buffer capture, or live dashboard has been implemented or verified by this Phase 1 change. Those require their own authorized-integration and end-to-end stream testing phases.

## Session 6 progress (2026-11-03)

| Step | Status |
|---|---|
| Phase 1 `verify_all.bat` | Done, Linux-verified; the `.bat` itself NOT run on Windows. User still owes `verify_report.txt`. |
| Phase 2a resumable render/download jobs | Done, Linux-verified; real Windows restart NOT verified. |
| Phase 2b settings API | Done, Linux-verified. |
| Phase 2b-UI settings form (`SettingsFields.tsx`) | Done: tsc, build, 32-check headless-browser click-through, 3 UI mutations caught. Windows restart check NOT verified. |
| Phase 2c step 1: `router.py` split into `clipstudio/routes/*.py` | Done, Linux-verified (see below). |
| Phase 2c step 2: `ytdlp.py` split into 5 leaf modules + facade | Done, Linux-verified (see below). |
| Phase 2c step 3: legacy `renderer.py` split into 6 leaf modules + facade | Done, Linux-verified (see below). |
| NEXT | 2c remaining splits, one file per step: `CreateView.tsx`, `legacy/page.tsx`; then 2d queue "continued automatically" link; then Phase 3. |

## Final2 current status (2026-10-30)

| Mission item | Status |
|---|---|
| TODO 7 local scheduler | Implemented and focused-test verified. Disabled by default; persistent queue, timezone, per-run limit, retry, pause/resume, restart reconciliation, lock and log are present. |
| TODO 8 VANTA YouTube upload | Implemented with mocks. Official backend-only OAuth, review panel, fresh confirmation, Private default, resumable API helper, error handling and success-only ID recording are present. Live OAuth/upload is unverified. |
| TODO 9 Windows setup | Launcher and static Windows audit complete; scripts detect prerequisites and propagate failure. Task registration is supplied but not executed. |
| TODO 10 evaluation | Export-pool and human dataset evaluator are present and documented. No human-labelled results are bundled; no quality improvement is claimed. |
| TODO 11 documentation | Updated for Final2, including configuration and feature status. |
| TODO 12 end-to-end | Automated synthetic-media coverage exercises the local flow. Real authorised media/browser/Windows checks remain manual. |
| TODO 13 release | Final ZIP is built only after suite, build, manifest and clean-extraction verification. |

See docs/FINAL_TEST_REPORT.md for the verified/partial/unverified boundary.

_Last updated: 2026-10-23 (session in progress)_

## 1. Audit of the existing project (Phase A)
Source archive: `Universal_AI_Shorts_Studio_V3.zip` (root folder inside is named `Universal_AI_Shorts_Studio_V2`).
The original archive/folder is untouched; all work happens in a copy (`VANTA_Clipping_Studio/`).

| Item | Finding |
|---|---|
| Backend | FastAPI (`backend/app/main.py`, run via `backend/run.py`, port 8000), SQLite `data/jobs.db` via `store.py` |
| Frontend | Next.js 14 / React 18 single page (`frontend/app/page.tsx`, ~210 dense lines + `globals.css`) |
| What it was | A **text-to-video generator** (topic/script -> stock footage + TTS + captions) with a thin "Video-to-Clips" mode |
| Existing FFmpeg | Used throughout `renderer.py` / `pro_render.py` (subprocess arg lists, good) |
| Existing clipping | `_render_video_clips`: picks evenly-spaced windows via scene-change score; **no transcript, no ranking explanation, no user trimming, no approval step** |
| Existing URL fetch | `_download_authorized_video`: direct HTTPS media only, SSRF checks, no redirects |
| Transcription | None for source video (roadmap item 3) |
| AI integrations | Ollama / Anthropic script writer (`llm.py`), Replicate (paid) provider, YouTube OAuth upload - all optional |
| Tests | 44 unittest tests in `backend/tests` |
| Baseline result | `python -m unittest discover -s backend/tests` -> **44 tests OK** (this sandbox, Python 3.13) |
| Env | `.env.example`, Windows `.bat` launchers |

### Known issues in the original (not all fixed)
- Clip mode has no review/approval step and cannot trim.
- `/api/youtube/analyze` only validates the host; downloads nothing (honest, kept).
- Legacy page mixes ten workflows in one screen.

## 2. Plan / architecture
New package `backend/app/clipstudio/` mounted in the existing FastAPI app under `/api/vanta/*`; the legacy
text-to-video studio is preserved (frontend moved to `/legacy`). Reuses `captions.py` (ASS writer),
`config.py`, `store.py` DB file, existing FFmpeg conventions.

Modules: `media` (ffprobe), `timeutil`, `transcript` (SRT/VTT/JSON parse + pluggable engines), `analysis`
(candidate ranking), `captions` (trim-aware caption build), `render` (FFmpeg + ffprobe validation),
`links` (URL validation/SSRF + optional adapters), `cost` (paid AI gate), `db` (projects/jobs/candidates/exports),
`pipeline` (job state machine), `router`.

## 3. Progress
See sections below, updated as work lands.


## 3. Final state (this session)

### Completed
- [x] Backend clipping engine `backend/app/clipstudio/` mounted under `/api/vanta` (see CHANGELOG_UPGRADE.md).
- [x] New 8-section UI; legacy studio preserved at `/legacy`.
- [x] Docs: README, `.env.example`, CHANGELOG_UPGRADE, CONTINUATION_PROMPT.

### Verified (exact commands and results, Linux sandbox, Python 3.13, Node 22, FFmpeg 6.1.1)
| Check | Command | Result |
|---|---|---|
| Baseline before changes | `PYTHONPATH=backend python -m unittest discover -s backend/tests` | PASS - 44 tests |
| VANTA unit tests | `python -m unittest tests.test_vanta_unit` (from `backend/`, `-W error::ResourceWarning`) | PASS - 58 tests |
| VANTA end-to-end (HTTP API, synthetic video) | `python -m unittest tests.test_vanta_e2e` | PASS - 12 tests |
| Full suite after changes | `PYTHONPATH=backend python -m unittest discover -s backend/tests` | PASS - 114 tests |
| Frontend typecheck + build | `npx tsc --noEmit`; `npm run build` | PASS (routes `/`, `/legacy`) |
| Browser flow (Playwright/Chromium against real servers) | upload -> attach transcript -> analyze -> preview -> approve -> render -> export card; visited all 8 sections | PASS, 0 console errors |
| Rendered frames inspected by eye | 9:16 blur background, word highlight, caption box | PASS |

Covered by automated tests: timestamp parsing/validation, clip duration limits, overlap handling, media inspection, invalid uploads, missing transcripts, caption timing after trim and after silence removal, render failure handling, output existence + ffprobe validation, job state transitions, paid API disabled by default, cost confirmation requirements, SSRF/URL validation, path traversal helper.

### NOT verified / skipped (be aware)
- **In-browser video playback**: headless Chromium here has no H.264 decoder, so the preview/export `<video>` panes were blank in screenshots. Files themselves were verified with ffprobe and extracted frames.
- **faster-whisper** transcription: adapter written, not installed or run (needs model download).
- **yt-dlp platform downloads**: tested only with a stub executable; never against a real site.
- **Cloud AI adapter**: tested only with a mock transport; never called the live API (no paid calls were made).
- **Windows batch launchers**: unchanged from the original, not run here (Linux sandbox).
- Subject tracking: not implemented (no detector).

## Remaining work / ideas
- [ ] Try faster-whisper on a real machine and confirm word-synced captions on real speech.
- [ ] Verify yt-dlp path against a real public video on the user's machine.
- [ ] Thumbnails and AI-written titles/descriptions/hashtags (optional features, not started).
- [ ] Batch export presets; scheduling; YouTube upload from VANTA (legacy studio already has OAuth upload code).
- [ ] Subject-aware reframing (face/person detector) as an optional adapter.
- [ ] Resume interrupted jobs instead of marking them failed.

## Known bugs / caveats
- None open from testing. Silence removal is limited to 60 cuts per clip (clear error otherwise).


## V2 YouTube link enablement update (2026-10-25)

### Changes made
- Added Windows helper `enable_youtube_links.bat` to install `yt-dlp` into the same Python environment used by VANTA and set `VANTA_ENABLE_YTDLP=1` in `.env`. Existing `.env` settings are preserved.
- Added classification for `youtube-nocookie.com` and `www.youtube-nocookie.com` embed URLs.
- Updated README with setup and use steps.
- Added unit cases for YouTube Shorts and no-cookie embed URL classification.

### Verification status
- Source ZIP was extracted into a separate working copy; original V1 archive was not modified.
- No paid API calls were made.
- Live public YouTube download is not claimed as verified; this environment may not have platform network access and a real download was not attempted. Run `enable_youtube_links.bat`, restart VANTA, and test a video you own or are authorized to repurpose.

### Checks run for this packaged update
- `PYTHONPATH=backend python -m unittest tests.test_vanta_unit -v` (run from `backend/` with `PYTHONPATH=.`): **PASS — 58 tests**.
- `python -m compileall -q backend`: **PASS**.
- Full `python -m unittest discover -s backend/tests`: **TIMED OUT in this execution environment** after partial output; do not treat as a pass.
- Frontend production build: **SKIPPED** because `frontend/node_modules` is not present; no dependency installation was attempted.
- Real public YouTube download: **NOT RUN**; requires network access and a specific authorized public video. Existing yt-dlp adapter was covered by its local stub test only.

## V2.1 Auto Clip update (2026-10-25)
- Implemented an Auto Clip UI action that runs analysis and then queues rendering of the ranked candidates automatically.
- Backend analyze request now accepts `auto_render` and `render_settings`; automatic candidates are marked approved and submitted to the render worker after analysis completes.
- Existing manual review/render flow remains unchanged.
- Focused unit tests: 58 passed in 2.765 seconds before this update; Python compileall passed after this update.
- Full test discovery was attempted again but timed out in this environment; it is not reported as passing.
- Frontend production build remains unverified because `frontend/node_modules` is not installed. Live YouTube download and full Auto Clip render still need testing on Windows with an authorized video.


## V2.2 — YouTube-link diagnostics and updater (item 1, 2026-10-25)

### Changes made
- `links.py` now finds `yt-dlp` through PATH, the active interpreter's Scripts directory, or `python -m yt_dlp`; platform downloads use the active Python module when no executable is on PATH. This addresses the Windows case where `yt-dlp` is installed but VANTA reports it missing.
- `yt-dlp` failures now return clearer machine-readable categories and actionable user messages for bot checks, login/age gates, region blocks, outdated `yt-dlp`, network/DNS/TLS failures, and existing unsupported/unavailable/rate-limit cases. Restrictions are not bypassed.
- Added `POST /api/vanta/links/update-ytdlp` to upgrade the package in the currently running backend's Python environment, with timeout/error handling and post-update version verification.
- `GET /api/vanta/health` reports `yt_dlp.installed` and `yt_dlp.version`; Video Links displays the version and an **Update yt-dlp** button.
- Added unit tests for error categories and a mocked updater endpoint. No paid AI calls added.

### Verification
- Before changes: `cd backend && PYTHONPATH=. python -m unittest discover -s tests` **PASS — 114 tests in 50.066s**.
- After changes: `PYTHONPATH=. python -m unittest tests.test_vanta_unit` **PASS — 59 tests**; `PYTHONPATH=. python -m unittest tests.test_core tests.test_pro tests.test_video_providers` **PASS — 44 tests**; `PYTHONPATH=. python -m unittest tests.test_vanta_e2e` **PASS — 12 tests**. These split groups total 115 tests; full discovery was attempted after changes but timed out, so it is not claimed as a pass.
- Python `py_compile` on the changed backend files **PASS**.
- Frontend `npm install --no-audit --no-fund` timed out in the build environment. `npx tsc --noEmit` failed because the interrupted/partial install lacked `@types/node`, React and related type definitions. `npm run build` **NOT RUN**. Frontend/browser behavior remains unverified.
- Real YouTube download: **NOT RUN**. Live package update: **NOT RUN**. The update endpoint is tested with a stubbed subprocess only. Windows `.bat` launchers were not run in this Linux build environment.

### Remaining in the requested sequence
- [ ] Item 2: automatic analyze → render end-to-end test and explicit UI error when render cannot start.
- [ ] Item 3: robust faster-whisper model configuration/download progress and transcribe-only action.
- [ ] Item 4: frontend typecheck/build and Playwright click-through of all sections.
- [ ] Item 5: editable per-clip metadata and ZIP metadata file.
- [ ] Item 6: resumable renders and durable job-state recovery.
- Later ideas remain unstarted and require asking before implementation.


## V3.0 — Reliable video-link downloads (2026-10-27)

### Root cause of the original UI error (conclusively reproduced)
`links.classify_ytdlp_error` matched regexes against the **entire** yt-dlp stderr, warnings included. On Python 3.10 yt-dlp prints
`Deprecated Feature: Support for Python version 3.10 has been deprecated. Please update to Python 3.11 or above`; the pattern `please update`
matched that, so *any* failure (e.g. `Video unavailable`, `live stream recording is not available`) was reported as "yt-dlp may be outdated".
Reproduced before the fix (`unavailable + py3.10 warning -> yt_dlp_outdated`); a regression test now pins the correct result. The Python 3.10 warning is
therefore not the cause of failed downloads — it was the cause of the *misleading label*. Whether *your* specific videos are unavailable or
failing in extraction (missing Node/JS runtime, old yt-dlp) can now be read from the precise code + Diagnostics. Contributing issues also fixed: PATH-vs-`sys.executable`
mismatch, no JS runtime passed to yt-dlp, `.env` parsing (inline comments / UTF-16), download only inside Analyze (no retry), non-atomic job submission.

### Verified (Linux sandbox: Python 3.12.3, Node 22.22.2, FFmpeg 6.1.1, yt-dlp 2026.10.21)
| Check | Command | Result |
|---|---|---|
| Baseline before changes | `unittest discover -s tests` | 115 passed |
| Full backend suite after changes | `cd backend && PYTHONPATH=. python -m unittest discover -s tests -t .` | **182 tests, OK, 0 failed, 0 skipped, 0 errors** (130 s) |
| New adapter tests | `tests/test_ytdlp.py` | 51 passed (URL parsing, classification incl. regression, command building, real subprocess runner: progress/timeout/cancel/retry/bounds/cleanup/no-file/oversize, validation, updater, `.env`) |
| New route integration tests | `tests/test_links_api.py` | 18 passed (download→source record, canonical URL, failure→actionable error, retry clears stale error, no re-download, duplicates, double-click atomicity, cancel+cleanup, analyze, **render→real 1080×1920 H.264 MP4→download**, analysis-failure labelling, orphan reuse, invalid links, restart cleanup, diagnostics, updater errors) |
| Frontend type-check | `cd frontend && npx tsc --noEmit` | passed |
| Frontend production build | `npm run build` | **passed** |
| Real servers | backend (`run.py`) + `next start`; `/health`, `/` | both HTTP 200 |
| Live HTTP workflow | upload → attach SRT → analyze → edit/approve (invalid range rejected 400) → custom clip → render 9:16, 1:1, 16:9 with captions → download → Auto Clip | all passed; ffprobe: h264+aac at 1080×1920, 1080×1080, 1920×1080; download bytes == file, `ftyp` header |
| Real yt-dlp via real backend | link `youtu.be/jNQXAC9IVRw` | job `failed` with `network_error` (DNS: sandbox cannot resolve youtube.com), retryable, scrubbed details — **not** "outdated" |

### NOT verified (be aware)
* **Real YouTube download: NOT verified.** The sandbox has no DNS/route to youtube.com, so no media was fetched. Manual check: `diagnose_youtube.bat https://www.youtube.com/watch?v=jNQXAC9IVRw` (exit 0 = real download validated).
* **Live `pip` upgrade of yt-dlp**: only tested with a stubbed pip (arguments, dry-run-first, failure handling, version verification). Manual check: Video Links → Update yt-dlp.
* **Browser click-through of the UI**: no browser binary available. The UI compiles, builds and every route it uses was exercised over HTTP.
* **Windows**: `.bat` scripts, `taskkill` process-tree kill, `C:\ai-video-env`, GTX 1650 — not executable here. Process-tree kill is tested on POSIX (`killpg`).
* `faster-whisper` transcription and GPU/CPU fallback were not exercised (not installed); the code path falls back to attached transcripts / audio-visual signals as before.
* Python 3.11 not run; 3.12 passes. Python 3.10 not run in V3 (only simulated through the exact deprecation text).

### Dependency / Python compatibility finding
All backend requirements support Python 3.11 and 3.12 and the suite passes on 3.12. Migration is optional (not needed to fix the error). `migrate_python_env.bat` builds `C:\ai-video-env-py312` side by side, runs the tests, switches nothing; switch with `python_env.txt`.

### Controls audited (backend route + UI wiring)
Create Shorts, Upload video, Attach transcript, Use a video link, Video Links, Update yt-dlp, Retry download (new), Diagnostics (new), Analyze, Auto Clip, suggested-clip approve/reject/edit (timestamp validation), custom clip, duration/count, aspect ratios, captions, Processing Queue (incl. cancel), My Projects, Exports/download, Settings (+diagnostics). Route behaviour verified over HTTP/tests; visual state transitions not browser-verified.

### Remaining / ideas
Item list in `CONTINUATION_PROMPT.md`. Notably: real-browser verification, faster-whisper path, resumable renders.


## V4 session (clip selection engine) - results
Environment: Linux sandbox, Python 3.12, Node 22, FFmpeg 6.1.1, yt-dlp 2026.10.26 (installed for tests).
| Check | Result |
|---|---|
| Baseline before changes | 170 passed, 12 failed because yt-dlp was not installed in the sandbox; with yt-dlp installed the link tests pass |
| Per-module runs after changes (each run separately; a single full-suite run exceeded the sandbox's 5-minute limit and a background run was killed, so no single combined run is recorded) | core 17, pro 18, providers 9, ytdlp 51, links_api 18, vanta_unit 57, vanta_e2e 12, selection 45 = **227 passed, 0 failed, 0 skipped** |
| `tsc --noEmit`, `npm run build` | pass |
| `python backend/evaluate_ranking.py` | see docs/EVALUATION.md: engine beat baseline on the synthetic fixtures (tuned on those fixtures, so optimistic) |
**Not verified:** quality against human ratings (none exist yet); local LLM against a real model; browser click-through of the new panel; Windows launchers; faster-whisper; live YouTube download.
**Not implemented from the repair/automation prompt:** daily scheduler, Windows startup/background service, YouTube upload (OAuth), title/description/thumbnail generation, editable settings UI, resumable jobs. Existing behaviour of these items was not changed.

## Session 2 status
Done: TODO 1, TODO 2 (Linux-verified only). Not started: TODO 3-13. See CONTINUATION_PROMPT.md.

## Session 3
* TODO 3 (YouTube ingestion): audited; trailing-dot host bug fixed; `tests/test_ingestion_audit.py` added (74 ingestion tests pass on Linux). Real download unverified (no network in sandbox). See `docs/YOUTUBE_INGESTION.md`.
* TODO 2b still needs the user's `scripts\check_captions.bat` output. TODO 4-13 not started.


## STATE AFTER SESSION 4
DONE (Linux-verified with a stub model; real model run NOT verified): TODO 4 local transcription - see `docs/LOCAL_TRANSCRIPTION.md`.
New: `whisper_local.py`, `_auto_transcribe` in pipeline, `/transcription/*` endpoints, AI Models transcription card, `check_transcription.py` + `scripts\check_transcription.bat`,
`enable_local_transcription.bat`, `tests/test_transcription.py` (43 tests). Default model changed base -> small.
STILL OPEN: TODO 2b (needs user's Windows output), 5-13.

## STATE AFTER SESSION 5 (PARTIAL)
DONE, Linux-verified: TODO 5 (job-state audit: stale-progress guard, cancel resting status, failed-render result + diagnostics path shown in Queue, stale-refresh guard, double-click guards, reasons on disabled controls; `tests/test_job_states.py` 12 tests, mutations caught; scripted browser click-through of all 8 sections, no console errors).
DONE, Linux-verified: TODO 6 (real-frame thumbnails from the export, selectable/custom time/download; transcript-only title/description/hashtags with provenance + validation; clip SRT; Exports UI panel; `tests/test_metadata.py` 11 tests). Fixed a Hindi word/hashtag splitting bug found by the tests. New UI panel (PublishPanel) typechecks but was NOT clicked through in a browser.
NOT STARTED: TODO 7 scheduler, 8 YouTube upload, 9 launchers audit, 10 evaluation doc, 11 docs, 12 end-to-end, 13 FINAL2 zip. Full suite NOT re-run after sessions 5 changes.

## STATE AFTER SESSION 6 - PHASE 1 (verification tooling)
DONE, Linux-verified: `verify_all.bat` -> `backend/verify_all.py` -> one scrubbed `verify_report.txt` with PASS / FAIL / SKIPPED per check (system, live YouTube, transcription status, captions, each backend test module run separately with its own timeout). Unit tests: `backend/tests/test_verify_all.py` (26 tests; two deliberate mutations - skip-counted-as-pass and redaction disabled - were caught). Ran end to end in Python mode on the Linux sandbox for a subset (captions check PASS; test_core 17, test_selection 45, test_verify_all 26 OK; system check FAILED there only because that sandbox had no `.env`/links disabled - an honest report line).
NOT VERIFIED: `verify_all.bat` itself and the Windows `cmd /d /s /c` command-line builder have never been executed on Windows (only string-tested). The full backend suite was not run in one go this session. Live YouTube, real Whisper model, browser playback: still the user's to run.
Also: the four CONTINUATION_PROMPT*.md files were merged into one `CONTINUATION_PROMPT.md`, which now carries the Phase 2-5 plan.
NEXT: user runs `verify_all.bat` and returns `verify_report.txt`; then Phase 2 (resumable renders, editable settings, file splits).

## STATE AFTER SESSION 6 - PHASE 2a (resumable jobs)
DONE, Linux-verified: `db.recover_interrupted()` + `pipeline.startup()` continue interrupted render/download jobs as a NEW queued job (old job stays visible as Failed with "continued automatically as job X"). Renders redo only clips without an intact export (file present, size equals the validated size); all-clips-done becomes Completed; crash loops are capped (`VANTA_MAX_RESUMES`, default 2); analyze/transcribe jobs and scheduler-owned jobs are failed as before; no upload job kind exists. `VANTA_RESUME_JOBS=0` restores the old behaviour. `db.fail_interrupted()` is unchanged.
Tests: `tests/test_resume.py` (14 tests incl. one real FFmpeg render resumed through `pipeline.startup()`); mutations caught: intact-exports-ignored (2 tests failed), cap removed (1), scheduler ownership ignored (1). Regression modules re-run OK: test_job_states 12, test_vanta_unit 57, test_scheduler_upload 7, test_links_api 18.
NOT VERIFIED: a real restart of the uvicorn process on Windows; the Queue UI wording for the old/new job pair was not clicked through in a browser; full suite not re-run in one go.

## STATE AFTER SESSION 6 - PHASE 2b (editable settings: backend only)
DONE, Linux-verified: `clipstudio/envsettings.py` + `GET/PUT /api/vanta/settings/fields`. Whitelist of 17 normal keys + 3 write-only secrets (ANTHROPIC_API_KEY, PEXELS_API_KEY, REPLICATE_API_TOKEN); per-field validation (bool/int range/choice/local-only Ollama URL/text); all-or-nothing writes; atomic `.env` rewrite that keeps comments, other lines, CRLF/LF, UTF-8(BOM)/UTF-16/ANSI encoding, drops duplicate active lines (the loader lets the last duplicate win), keeps one `.env.bak`; secrets are never returned (only "is set"); every field is labelled restart-required and compared against the value the running process actually uses. Paths, data folders, Python and yt-dlp runtime settings are deliberately NOT editable.
Tests: `tests/test_envsettings.py` (24 tests); mutations caught: secret leak (2 failures), duplicate lines kept (1), save despite errors (1), any Ollama host allowed (1). test_vanta_e2e 12 OK (the read-only `GET /settings` is unchanged).
NOT DONE: the Settings form in the UI (frontend/app/vanta SettingsView). NOT VERIFIED: writing a real Windows `.env` locked by an editor; a real restart picking the values up.


## STATE AFTER SESSION 7 - PHASE 2c step 1 (router.py split)
DONE, Linux-verified: the 42 KB `clipstudio/router.py` is now a thin assembler (about 35 lines) plus ten route modules in `clipstudio/routes/` (`system`, `scheduling`, `projects`, `transcription`, `candidates`, `render_jobs`, `exports`, `publishing`, `templates`, `cloud_ai`) and `routes/common.py` (shared helpers, `VERSION`). Handler code was moved by line range, not retyped; the only edit inside a handler is one relative import (`from .captions` -> `from ..captions` in `candidate_srt`). `router.py` still exports every name the old module had (including private helpers), so `from app.clipstudio import router`, `router.upload_export_to_youtube` and `mock.patch("app.clipstudio.router.youtube_upload.status")` keep working. `app/main.py` is unchanged.
Evidence: the OpenAPI document of the whole app was captured before and after: all 94 operations (64 under `/api/vanta`) identical in method, path, operationId and tags; the only difference is a cosmetic schema component name (`YouTubeUploadRequest` is now qualified with its new module name; nothing in the frontend reads it). New `tests/test_router_split.py` (6 tests) + `tests/data/vanta_routes_snapshot.json` (taken from the ORIGINAL file) guard route set, tags/prefix, duplicate routes, mounted modules, old names and the patch path. Mutations caught: module dropped from the mount loop (2 failures), a route path renamed (1), a re-export removed (1).
Regression: test_vanta_unit 57, test_scheduler_upload 7, test_envsettings 24, test_resume 14, test_job_states 12, test_core 17, test_metadata 11, test_selection 45, test_links_api 18, test_vanta_e2e 12 (real HTTP + FFmpeg), test_pro 18, test_video_providers 9, test_transcription 43, test_verify_all 26, test_remaining_repair 40, test_ingestion_audit 5, ytdlp 51 - all OK, each module run separately. `compileall -q backend` OK; pyflakes clean on the new modules.
NOT RE-RUN: the frontend (no frontend file changed, so tsc/build were not repeated); the full suite in one go; Windows.
Found and fixed (pre-existing, NOT caused by the split): `tests/test_final2_e2e_light.py` was already failing on the original code (confirmed against the untouched backup). It sent `target_duration: 9` although the analyze API requires >= 10, then asserted `GET /projects/{id}` `exports == 1` although that endpoint returns the list (only the project LIST endpoint returns a count; the frontend uses them that way). Both assertions in the test were corrected (10, `len(...) == 1`); the test now passes (real upload -> analyze -> approve -> render -> export, ffprobe 1080x1920 h264, upload state `not_started`). Also run OK: `test_check_captions` 16. NOT run this session: `test_captions_render` (slowest module).

## STATE AFTER SESSION 7 - PHASE 2c step 2 (ytdlp.py split)
DONE, Linux-verified: the 37.7 KB `clipstudio/ytdlp.py` (670 lines) is now a 281-line facade plus `ytdlp_const.py`, `ytdlp_urls.py`, `ytdlp_errors.py`, `ytdlp_probe.py`, `ytdlp_proc.py` (all copied by line range, not retyped). Design decision: everything the tests patch (`installed`, `version`, `base_command`, `diagnostics`, `download`, `update`, `check_disk`, plus the `subprocess`, `shutil`, `time` module references) stays in `ytdlp.py`, because a patch on `ytdlp.X` only reaches callers that look `X` up in that module. Only pure/leaf code moved; every old name, including private ones (`_CACHE`, `_RULES`, `_collect`, `_UPDATE_LOCK`), is still importable from `ytdlp`.
Evidence: `tests/data/ytdlp_surface_snapshot.json` was taken from the ORIGINAL file (75 names: kind and normalised signature) and is identical after the split. `tests/test_ytdlp_split.py` (9 tests) guards it; 5 mutations caught (re-export dropped, diagnostics bypassing the facade's `ffmpeg_info`, `base_command` bypassing `installed`, a `--cookies` flag added, a function copied instead of re-exported). pyflakes found 2 real missing imports during the work (`Path` in ytdlp_errors, `LinkError` in ytdlp_urls); both fixed before the first test run.
Regression (each module run separately, after the split): core 17, envsettings 24, final2_e2e_light 1, ingestion_audit 5, job_states 12, links_api 18, metadata 11, pro 18, remaining_repair 40, resume 14, router_split 6, scheduler_upload 7, selection 45, transcription 43, vanta_e2e 12, vanta_unit 57, verify_all 26, video_providers 9, ytdlp 51 (same as before the split), ytdlp_split 9, check_captions 16 - all OK; `python -m compileall -q backend` clean.
NOT RE-RUN: `test_captions_render` (slowest module); the frontend (untouched); Windows; live YouTube (the split touches no network code, but a real download was not run).

## STATE AFTER SESSION 7 - PHASE 2c step 3 (legacy renderer.py split)
DONE, Linux-verified: the 51.6 KB / 1002-line `app/renderer.py` is now a 347-line facade (19.7 KB) plus `renderer_common.py`, `renderer_scenes.py`, `renderer_audio.py`, `renderer_validate.py`, `renderer_download.py`, `renderer_clips.py` (copied by line range; a script confirmed no non-blank original line was left uncovered). The facade keeps `render_video`, `_render_ai_video`, `_temporal_motion_score`, `_existing_ai_clip_motion_score` (the helper `tests/test_core.py` patches as `app.renderer._temporal_motion_score`, so its caller must look it up in the facade) and the `subprocess`/`httpx`/`socket`/`shutil`/`Image` references, and re-exports every old name incl. private ones used by `pro_render.py` and the tests. `pro_render.py` untouched.
Evidence: `tests/data/renderer_surface_snapshot.json` (58 names, taken from the ORIGINAL) identical after the split; `tests/test_renderer_split.py` (8 tests: surface, re-export identity, facade-resident functions, patch reaches caller, pinned behaviour of dims/wrap/_timestamp/_parse_srt_time/_palette taken from the original code, size limits, `main`/`pro_render` imports). 5 mutations caught (re-export line dropped, function copied, `dims` behaviour changed, `subprocess` import removed from facade, motion-score patch bypassed). pyflakes: only intentional re-export "unused" lines.
Regression (each module separately): all 22 backend modules OK incl. core 17, pro 18, vanta_e2e 12, final2_e2e_light 1, job_states 12, ytdlp 51, renderer_split 8, check_captions 16; `compileall -q backend` clean.
NOT RE-RUN: `test_captions_render`; the frontend (untouched); Windows; a real legacy text-to-video render with an AI video provider (only the FFmpeg-based pro and source-clip paths exercised by tests).
