"""Phase 2b: editable settings. Validation, secrets stay write-only, .env keeps its comments/encoding/line endings, writes are atomic."""
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import envsettings as es
from app.envload import parse_env, read_env_text
from tests.vanta_fixtures import isolate

SECRET = "sk-ant-api03-SUPERSECRETVALUE1234567890"


def check(key, value):
    apply, errors = es.validate({key: value})
    return apply.get(key), errors.get(key)


class Validation(unittest.TestCase):
    def test_bool_int_choice_accept_and_normalise(self):
        self.assertEqual(check("VANTA_ENABLE_YTDLP", True)[0], "1")
        self.assertEqual(check("VANTA_ENABLE_YTDLP", "off")[0], "0")
        self.assertEqual(check("VANTA_YTDLP_ATTEMPTS", "3")[0], "3")
        self.assertEqual(check("VANTA_WHISPER_DEVICE", "cpu")[0], "cpu")
        self.assertEqual(check("VANTA_LOCAL_LLM", "")[0], "")

    def test_bad_values_are_rejected_with_a_reason(self):
        for key, bad in (("VANTA_ENABLE_YTDLP", "maybe"), ("VANTA_YTDLP_ATTEMPTS", "9"), ("VANTA_YTDLP_ATTEMPTS", "1.5"),
                         ("VANTA_YTDLP_ATTEMPTS", "abc"), ("VANTA_WHISPER_DEVICE", "tpu"), ("VANTA_WHISPER_MODEL", "huge-xl"),
                         ("VANTA_LOCAL_LLM_MODEL", 'a"b'), ("VANTA_LOCAL_LLM_MODEL", "x#y"), ("VANTA_MAX_UPLOAD_BYTES", "5"),
                         ("VANTA_YTDLP_TIMEOUT", "line1\nline2")):
            value, err = check(key, bad)
            self.assertIsNone(value, (key, bad))
            self.assertTrue(err, (key, bad))

    def test_ollama_address_must_be_local(self):
        self.assertEqual(check("VANTA_OLLAMA_URL", "http://127.0.0.1:11434")[0], "http://127.0.0.1:11434")
        self.assertEqual(check("VANTA_OLLAMA_URL", "http://localhost:8080")[0], "http://localhost:8080")
        for bad in ("http://evil.example.com:11434", "ftp://127.0.0.1", "127.0.0.1:11434", "http://127.0.0.1.evil.com"):
            self.assertIsNotNone(check("VANTA_OLLAMA_URL", bad)[1], bad)

    def test_unknown_and_dangerous_keys_cannot_be_edited(self):
        for key in ("PATH", "VANTA_DATA_DIR", "STUDIO_DATA_DIR", "VANTA_ENV_FILE", "YOUTUBE_CLIENT_SECRET_FILE", "VANTA_PYTHON"):
            self.assertIn("cannot be edited", check(key, "x")[1], key)

    def test_secret_rules(self):
        self.assertEqual(check("ANTHROPIC_API_KEY", SECRET)[0], SECRET)
        for bad in ("short", "has space in it 12345", 'quote"d-key-123456', "line\nbreak123456", ""):
            self.assertIsNotNone(check("ANTHROPIC_API_KEY", bad)[1], repr(bad))
        _, errors = es.validate({}, clear=["VANTA_MAX_RESUMES"])
        self.assertTrue(errors)                                   # only secrets can be cleared
        apply, errors = es.validate({}, clear=["PEXELS_API_KEY"])
        self.assertEqual((apply, errors), ({"PEXELS_API_KEY": None}, {}))

    def test_null_means_remove_override(self):
        self.assertEqual(es.validate({"VANTA_MAX_RESUMES": None})[0], {"VANTA_MAX_RESUMES": None})

    def test_whitelist_contains_no_path_or_command_settings(self):
        keys = {f.key for f in es.fields()}
        for forbidden in ("VANTA_DATA_DIR", "STUDIO_DATA_DIR", "VANTA_PYTHON", "VANTA_WHISPER_CACHE", "VANTA_YTDLP_JS_RUNTIME", "PATH"):
            self.assertNotIn(forbidden, keys)


SAMPLE = "# VANTA settings (my notes)\r\n\r\nPEXELS_API_KEY=oldkey12345\r\n# VANTA_MAX_RESUMES=2\r\nVANTA_ENABLE_YTDLP=1\r\nVANTA_ENABLE_YTDLP=0\r\n# end of file\r\n"


class TextEditing(unittest.TestCase):
    def test_other_lines_are_untouched_and_duplicates_cannot_undo_the_edit(self):
        out = es.apply_to_text(SAMPLE.replace("\r\n", "\n"), {"VANTA_ENABLE_YTDLP": "1", "VANTA_MAX_RESUMES": "3"}, "\n")
        parsed = parse_env(out)
        self.assertEqual(parsed["VANTA_ENABLE_YTDLP"], "1")          # the later duplicate "=0" would have won if it were kept
        self.assertEqual(parsed["VANTA_MAX_RESUMES"], "3")
        self.assertEqual(parsed["PEXELS_API_KEY"], "oldkey12345")
        self.assertIn("# VANTA settings (my notes)", out)
        self.assertIn("# end of file", out)
        self.assertEqual(out.count("VANTA_ENABLE_YTDLP"), 1)

    def test_commented_example_is_uncommented_in_place(self):
        out = es.apply_to_text("a=1\n# VANTA_MAX_RESUMES=2\nb=2\n", {"VANTA_MAX_RESUMES": "5"})
        self.assertEqual(out, "a=1\nVANTA_MAX_RESUMES=5\nb=2\n")

    def test_removing_an_override_keeps_documentation_comments(self):
        out = es.apply_to_text("# VANTA_MAX_RESUMES=2\nVANTA_MAX_RESUMES=7\n", {"VANTA_MAX_RESUMES": None})
        self.assertEqual(out, "# VANTA_MAX_RESUMES=2\n")
        self.assertNotIn("VANTA_MAX_RESUMES", parse_env(out))

    def test_new_keys_are_appended_under_a_marker(self):
        out = es.apply_to_text("a=1\n", {"VANTA_LLM_TOP_N": "5"})
        self.assertTrue(out.endswith("# --- Added by VANTA Settings ---\nVANTA_LLM_TOP_N=5\n"))

    def test_values_with_spaces_are_quoted_and_round_trip(self):
        out = es.apply_to_text("", {"VANTA_LOCAL_LLM_MODEL": "my model name"})
        self.assertEqual(parse_env(out)["VANTA_LOCAL_LLM_MODEL"], "my model name")


class Saving(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = Path(self.dir.name) / ".env"

    def tearDown(self):
        self.dir.cleanup()

    def test_crlf_utf8_bom_and_non_ascii_comments_are_preserved(self):
        self.path.write_bytes(b"\xef\xbb\xbf" + "# n\u00fctzlich \u0939\u093f\u0928\u094d\u0926\u0940\r\nVANTA_MAX_RESUMES=2\r\n".encode("utf-8"))
        es.save({"VANTA_MAX_RESUMES": "4"}, self.path)
        raw = self.path.read_bytes()
        self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
        self.assertIn(b"\r\n", raw)
        self.assertNotIn(b"\n", raw.replace(b"\r\n", b""))
        text = read_env_text(self.path)
        self.assertIn("\u0939\u093f\u0928\u094d\u0926\u0940", text)
        self.assertEqual(parse_env(text)["VANTA_MAX_RESUMES"], "4")

    def test_utf16_files_stay_utf16(self):
        self.path.write_bytes("VANTA_MAX_RESUMES=2\r\n".encode("utf-16"))
        es.save({"VANTA_LLM_TOP_N": "6"}, self.path)
        self.assertTrue(self.path.read_bytes().startswith((b"\xff\xfe", b"\xfe\xff")))
        self.assertEqual(parse_env(read_env_text(self.path)), {"VANTA_MAX_RESUMES": "2", "VANTA_LLM_TOP_N": "6"})

    def test_backup_and_no_temp_files_left(self):
        self.path.write_text("VANTA_MAX_RESUMES=2\n")
        info = es.save({"VANTA_MAX_RESUMES": "3"}, self.path)
        self.assertEqual(Path(info["backup"]).read_text(), "VANTA_MAX_RESUMES=2\n")
        self.assertEqual(sorted(p.name for p in Path(self.dir.name).iterdir()), [".env", ".env.bak"])

    def test_missing_file_is_created(self):
        es.save({"VANTA_MAX_RESUMES": "3"}, self.path)
        self.assertEqual(parse_env(read_env_text(self.path)), {"VANTA_MAX_RESUMES": "3"})

    def test_a_failed_write_leaves_the_original_intact(self):
        self.path.write_text("VANTA_MAX_RESUMES=2\n")
        with mock.patch("os.replace", side_effect=OSError("locked")):
            with self.assertRaises(OSError):
                es.save({"VANTA_MAX_RESUMES": "3"}, self.path)
        self.assertEqual(self.path.read_text(), "VANTA_MAX_RESUMES=2\n")
        self.assertFalse([p for p in Path(self.dir.name).iterdir() if p.suffix == ".tmp"])


class Describe(unittest.TestCase):
    def test_secrets_are_never_returned_and_pending_restart_is_honest(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / ".env"
            p.write_text(f"ANTHROPIC_API_KEY={SECRET}\nVANTA_MAX_RESUMES=5\n")
            info = es.describe(p, environ={"VANTA_MAX_RESUMES": "2"})
        self.assertNotIn(SECRET, json.dumps(info))
        self.assertNotIn("SUPERSECRET", json.dumps(info))
        f = {x["key"]: x for x in info["fields"]}
        self.assertEqual((f["ANTHROPIC_API_KEY"]["saved_set"], f["ANTHROPIC_API_KEY"]["running_set"], f["ANTHROPIC_API_KEY"]["pending_restart"]), (True, False, True))
        self.assertEqual((f["VANTA_MAX_RESUMES"]["saved"], f["VANTA_MAX_RESUMES"]["running"], f["VANTA_MAX_RESUMES"]["pending_restart"]), ("5", "2", True))
        self.assertFalse(f["VANTA_LLM_TOP_N"]["pending_restart"])
        self.assertTrue(info["restart_required"])

    def test_no_pending_restart_when_saved_equals_default_or_running(self):
        with tempfile.TemporaryDirectory() as d:
            info = es.describe(Path(d) / ".env", environ={})
        self.assertFalse(info["restart_required"])
        self.assertFalse(info["exists"])


class Api(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = isolate()
        cls.dir = tempfile.TemporaryDirectory()
        cls.env_file = Path(cls.dir.name) / ".env"
        cls._env = mock.patch.dict(os.environ, {"VANTA_ENV_FILE": str(cls.env_file)}); cls._env.start()
        from app.main import app
        cls.client = TestClient(app).__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None); cls._env.stop(); cls.dir.cleanup(); cls.tmp.cleanup()

    def test_01_get_lists_fields_and_marks_everything_restart_required(self):
        r = self.client.get("/api/vanta/settings/fields").json()
        self.assertTrue(r["fields"])
        self.assertTrue(all(f["apply"] == "restart" for f in r["fields"]))
        self.assertIn("fields_endpoint", self.client.get("/api/vanta/settings").json())

    def test_02_invalid_input_writes_nothing_and_names_each_bad_field(self):
        self.env_file.write_text("VANTA_MAX_RESUMES=2\n")
        r = self.client.put("/api/vanta/settings/fields", json={"values": {"VANTA_MAX_RESUMES": "99", "VANTA_ENABLE_YTDLP": "1", "PATH": "x"}})
        self.assertEqual(r.status_code, 422)
        errors = r.json()["detail"]["errors"]
        self.assertEqual(set(errors), {"VANTA_MAX_RESUMES", "PATH"})
        self.assertEqual(self.env_file.read_text(), "VANTA_MAX_RESUMES=2\n")         # the valid field was NOT written either

    def test_03_valid_save_then_secret_is_written_but_never_echoed(self):
        r = self.client.put("/api/vanta/settings/fields", json={"values": {"VANTA_MAX_RESUMES": 4, "ANTHROPIC_API_KEY": SECRET}})
        self.assertEqual(r.status_code, 200, r.text)
        body = r.json()
        self.assertTrue(body["saved"] and body["restart_required"])
        self.assertNotIn("SUPERSECRET", r.text)
        self.assertNotIn("SUPERSECRET", self.client.get("/api/vanta/settings/fields").text)
        parsed = parse_env(read_env_text(self.env_file))
        self.assertEqual((parsed["VANTA_MAX_RESUMES"], parsed["ANTHROPIC_API_KEY"]), ("4", SECRET))
        self.assertEqual(os.environ.get("VANTA_MAX_RESUMES"), None)                  # the running process is not changed

    def test_04_clear_secret_and_remove_override(self):
        r = self.client.put("/api/vanta/settings/fields", json={"values": {"VANTA_MAX_RESUMES": None}, "clear": ["ANTHROPIC_API_KEY"]})
        self.assertEqual(r.status_code, 200)
        self.assertNotIn("ANTHROPIC_API_KEY", parse_env(read_env_text(self.env_file)))
        self.assertNotIn("VANTA_MAX_RESUMES", parse_env(read_env_text(self.env_file)))

    def test_05_empty_request_is_a_noop(self):
        before = self.env_file.read_bytes() if self.env_file.exists() else b""
        r = self.client.put("/api/vanta/settings/fields", json={})
        self.assertEqual((r.status_code, r.json()["saved"]), (200, False))
        self.assertEqual(self.env_file.read_bytes() if self.env_file.exists() else b"", before)


if __name__ == "__main__":
    unittest.main()
