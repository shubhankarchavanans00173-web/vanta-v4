"""Guard for the legacy renderer.py split (Phase 2c step 3). The snapshot was taken from the ORIGINAL single-file renderer.py."""
from __future__ import annotations

import inspect
import json
import re
import subprocess
import unittest
from pathlib import Path
from unittest import mock

from app import renderer, renderer_audio, renderer_clips, renderer_common, renderer_download, renderer_scenes, renderer_validate

SNAP = Path(__file__).parent / "data" / "renderer_surface_snapshot.json"


def surface() -> dict:
    out = {}
    for name, value in sorted(vars(renderer).items()):
        if name.startswith("__"):
            continue
        if inspect.ismodule(value):
            out[name] = "module:" + value.__name__
        elif inspect.isclass(value):
            out[name] = "class"
        elif inspect.isfunction(value):
            # A lambda default prints its memory address (uppercase hex on Windows): normalise it.
            out[name] = "function" + re.sub(r"0x[0-9a-fA-F]+", "0x0", str(inspect.signature(value)))
        else:
            # PosixPath vs WindowsPath is the only path-type difference between platforms.
            out[name] = "value:" + ("Path" if isinstance(value, Path) else type(value).__name__)
    return out


class SplitGuard(unittest.TestCase):
    def test_every_old_name_is_importable_with_same_kind_and_signature(self):
        old = {k: ("value:Path" if v in ("value:PosixPath", "value:WindowsPath") else v)
               for k, v in json.loads(SNAP.read_text(encoding="utf-8")).items()}
        new = surface()
        self.assertEqual(sorted(set(old) - set(new)), [])
        self.assertEqual({k: new[k] for k in old if new[k] != old[k]}, {})

    def test_reexports_are_the_same_objects(self):
        for module, names in [(renderer_common, ["dims", "getfont", "wrap", "_safe_upload", "_run", "_timestamp", "_fraction", "_sample_image"]),
                              (renderer_scenes, ["_normalise_scenes", "_write_srt", "_scene_image", "_palette", "_style_prompt"]),
                              (renderer_audio, ["_add_audio_tracks", "_voice", "_audio_upload", "_normalise_audio_track"]),
                              (renderer_validate, ["validate_output", "_render_source_video"]),
                              (renderer_download, ["_download_authorized_video"]),
                              (renderer_clips, ["_render_video_clips", "_select_clip_windows", "_slice_srt", "_parse_srt_time", "_title_overlay"])]:
            for name in names:
                self.assertIs(getattr(renderer, name), getattr(module, name), f"{name} copied instead of re-exported")

    def test_orchestrators_and_patched_helpers_stay_in_the_facade(self):
        for name in ("render_video", "_render_ai_video", "_temporal_motion_score", "_existing_ai_clip_motion_score"):
            self.assertEqual(getattr(renderer, name).__module__, "app.renderer", name)

    def test_patch_on_facade_motion_score_reaches_its_caller(self):
        probe = subprocess.CompletedProcess([], 0, stdout=json.dumps({"streams": [{"codec_type": "video"}], "format": {"duration": "1.0"}}), stderr="")
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            clip = Path(d) / "generated_clip_001.mp4"
            clip.write_bytes(b"x" * 6000)
            with mock.patch("app.renderer.subprocess.run", return_value=probe), mock.patch("app.renderer._temporal_motion_score", return_value=0.5) as m:
                self.assertEqual(renderer._existing_ai_clip_motion_score("ffmpeg", "ffprobe", clip, 1.0), 0.5)
        m.assert_called_once()

    def test_subprocess_patch_target_still_exists_on_the_facade(self):
        import subprocess as sp
        self.assertIs(renderer.subprocess, sp)
        for name in ("httpx", "socket", "shutil", "Image"):
            self.assertTrue(hasattr(renderer, name), name)

    def test_behaviour_pinned_from_the_original_code(self):
        self.assertEqual(renderer.dims("9:16", "balanced"), (720, 1280))
        self.assertEqual(renderer.dims("16:9", "draft"), (640, 360))
        self.assertEqual(renderer.dims("1:1", "quality"), (1080, 1080))
        self.assertEqual(renderer.wrap("the quick brown fox jumps over the lazy dog again and again", 18),
                         ["the quick brown", "fox jumps over the", "lazy dog again and", "again"])
        self.assertEqual(renderer._timestamp(3661.5), "01:01:01,500")
        self.assertEqual(renderer._parse_srt_time("00:01:02,500"), 62.5)
        self.assertEqual(renderer._palette("cinematic"), ((23, 22, 34), (123, 80, 178), (245, 157, 86)))

    def test_no_module_is_oversized(self):
        base = Path(renderer.__file__).parent
        for name in ("renderer", "renderer_common", "renderer_scenes", "renderer_audio", "renderer_validate", "renderer_download", "renderer_clips"):
            self.assertLess((base / f"{name}.py").stat().st_size, 22_000, name)

    def test_legacy_entry_point_and_pro_render_imports_resolve(self):
        from app import main, pro_render  # noqa: F401
        self.assertIs(main.render_video, renderer.render_video)
        for name in ("DEFAULT_FPS", "_audio_upload", "_normalise_scenes", "_palette", "_run", "_safe_upload", "validate_output"):
            self.assertIs(getattr(pro_render, name), getattr(renderer, name))


if __name__ == "__main__":
    unittest.main()
