"""Shared helpers for the VANTA tests: isolated data dir + tiny synthetic media made with the local FFmpeg."""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

from app.clipstudio import db, settings

HAVE_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))

# (start, end, text): speech windows are 0-10, 12-22, 24-34, 36-46, 48-58, 60-70 s (tone on), silences between
SCRIPT = [
    (0.3, 4.0, "Here is the one mistake that ruins most first videos."),
    (4.2, 9.5, "Most people never check their audio before they hit record, and that is why viewers leave."),
    (12.3, 17.0, "So what should you do instead? Start with a clear hook in the first three seconds."),
    (17.2, 21.8, "Because the reason is simple: attention drops fast, which means every second counts."),
    (24.3, 30.0, "I remember my first upload years ago. Nobody watched it, and honestly it was painful."),
    (30.2, 33.8, "Then one day I changed a single thing, and everything turned around!"),
    (36.3, 43.0, "The trick is to explain one idea at a time. First, state the problem. Second, show the fix."),
    (43.3, 46.0, "That is basically the whole lesson."),
    (48.3, 54.0, "And then, um, we kind of went on about other stuff that does not matter."),
    (60.3, 65.0, "Thanks for watching and see you next time."),
]


def _ts(t: float) -> str:
    ms = round(t * 1000)
    h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def script_srt() -> str:
    return "\n".join(f"{i}\n{_ts(a)} --> {_ts(b)}\n{t}\n" for i, (a, b, t) in enumerate(SCRIPT, 1))


def make_video(path: Path, duration: int = 70, audio: bool = True, size: str = "640x360") -> Path:
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"testsrc2=size={size}:rate=30:duration={duration}"]
    if audio:
        cmd += ["-f", "lavfi", "-i", f"sine=f=440:duration={duration}:sample_rate=48000", "-af", "volume='if(lt(mod(t,12),10),1,0)':eval=frame", "-c:a", "aac"]
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "32", "-pix_fmt", "yuv420p", str(path)]
    subprocess.run(cmd, check=True, timeout=180)
    return path


def make_music(path: Path, duration: int = 5) -> Path:
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", f"sine=f=220:duration={duration}", "-c:a", "libmp3lame", str(path)], check=True, timeout=60)
    return path


def isolate() -> tempfile.TemporaryDirectory:
    """Point all VANTA state at a fresh temp dir and create the schema. Keep the returned object alive; call .cleanup()."""
    tmp = tempfile.TemporaryDirectory(prefix="vanta-test-")
    settings.configure(Path(tmp.name))
    db.init()
    return tmp
