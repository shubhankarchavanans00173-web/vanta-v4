"""Unicode-aware tokenisation for the clip ranker's lexicon.

Written before the fix and failing on the old ``[A-Za-z0-9']+`` pattern, which returned **no tokens at
all** for Devanagari text (``words("हिन्दी में लिखा है।") == []``), so Hindi could not reach any feature.

The English guarantee is tested two ways: an exact equality check against the old regex over an ASCII
corpus (word/content/trigram output must stay byte-identical), and a check on the bundled English
fixture script that the numbers the features consume do not move at all.
"""
from __future__ import annotations

import re
import unittest
import unicodedata

from app.clipstudio.selection import engine
from app.clipstudio.selection import lexicon as L
from app.clipstudio.transcript import Segment, Transcript
from tests.vanta_fixtures import SCRIPT

# The pattern that shipped before this change. ASCII text must still produce exactly these tokens.
OLD_WORD = re.compile(r"[A-Za-z0-9']+")

ENGLISH_CORPUS = [
    "I'm actually a professional player.",
    "Then why are you losing? COPIUM",
    "don't stop, rock'n'roll and 1990s U.S.A. e-mail",
    "'quoted' things and 3.5x growth, 50% off!",
    "C++ and __init__ and a1b2 are not words here",
    "LOL LMAO BRO no way!!!",
    "The trick is to explain one idea at a time. First, state the problem.",
]


class DevanagariTests(unittest.TestCase):
    def test_devanagari_words_are_tokenised_with_their_marks(self):
        text = "मैं तो बहुत अच्छा खिलाड़ी हूँ"
        self.assertEqual(L.words(text), ["मैं", "तो", "बहुत", "अच्छा", "खिलाड़ी", "हूँ"])

    def test_matra_and_virama_stay_inside_one_token(self):
        # हिन्दी is ह + ि + न + ् + द + ी: a tokeniser that only keeps letters would yield ह, न, द.
        self.assertEqual(L.words("हिन्दी"), ["हिन्दी"])
        self.assertEqual(L.words("अच्छा"), ["अच्छा"])
        self.assertEqual(len(L.words("क्षत्रिय")), 1)

    def test_decomposed_input_gives_the_same_tokens(self):
        # ऩ (U+0929) is ऩ as one code point, or न + nukta (U+093C) when a source emits decomposed text.
        composed, decomposed = "\u0929", "\u0928\u093c"
        self.assertNotEqual(composed, decomposed)          # the fixture really is decomposed
        self.assertEqual(L.words(decomposed), L.words(composed))
        self.assertEqual(L.words(decomposed), [composed])
        self.assertEqual(L.words(unicodedata.normalize("NFD", "ज़रूर बकवास")), ["ज़रूर", "बकवास"])

    def test_content_words_survive_for_hindi(self):
        content = L.content_words("मैं तो बहुत अच्छा खिलाड़ी हूँ")
        self.assertIn("खिलाड़ी", content)
        self.assertIn("अच्छा", content)
        self.assertTrue(content, "Hindi text produced no content words")


class MixedScriptTests(unittest.TestCase):
    def test_hinglish_and_romanised_hindi_are_unchanged(self):
        self.assertEqual(L.words("yaar ye kya bakwaas hai bhai"), ["yaar", "ye", "kya", "bakwaas", "hai", "bhai"])

    def test_mixed_script_line_keeps_both_scripts(self):
        words = L.words("BRO ye toh OP tha 😂 हिन्दी")
        self.assertEqual(words, ["BRO", "ye", "toh", "OP", "tha", "हिन्दी"])

    def test_unicode_punctuation_and_emojis_are_separators(self):
        self.assertEqual(L.words("“bakwaas” hai…"), ["bakwaas", "hai"])
        self.assertEqual(L.words("sach\tmein\nbhai"), ["sach", "mein", "bhai"])
        self.assertEqual(L.words("family👨‍👩‍👧‍👦time"), ["family", "time"])   # zero-width joiner inside an emoji
        self.assertEqual(L.words("\u200bzero\u200bwidth"), ["zero", "width"])

    def test_typographic_apostrophe_joins_a_word(self):
        self.assertEqual(L.words("don’t stop"), ["don’t", "stop"])     # widened on purpose; ASCII stays as it was


class TerminalPunctuationTests(unittest.TestCase):
    def test_danda_ends_a_sentence(self):
        self.assertTrue(L.ends_terminal("हिन्दी में लिखा है।"))
        self.assertTrue(L.ends_terminal("हाँ॥"))

    def test_english_terminal_behaviour_is_unchanged(self):
        for text, expected in (("He said that.", True), ("Why?", True), ("Wait!", True), ("so…", True),
                               ("no punctuation", False), ("ends with comma,", False)):
            self.assertEqual(L.ends_terminal(text), expected, text)


class EnglishInvarianceTests(unittest.TestCase):
    def test_word_and_content_output_is_identical_to_the_old_pattern(self):
        for text in ENGLISH_CORPUS:
            self.assertEqual(L.words(text), OLD_WORD.findall(text), text)
            self.assertEqual(L.content_words(text),
                             [w.lower() for w in OLD_WORD.findall(text) if w.lower() not in L.STOPWORDS and len(w) > 2], text)

    def test_trigrams_are_identical_to_the_old_pattern(self):
        for text in ENGLISH_CORPUS:
            old = [w.lower() for w in OLD_WORD.findall(text)]
            self.assertEqual(L.trigrams(text), [tuple(old[i:i + 3]) for i in range(len(old) - 2)], text)

    def test_the_english_fixture_script_feeds_the_features_unchanged(self):
        for _, _, text in SCRIPT:
            self.assertEqual(L.words(text), OLD_WORD.findall(text), text)
            self.assertEqual(len(L.trigrams(text)), max(0, len(OLD_WORD.findall(text)) - 2), text)

    def test_ascii_fast_path_is_really_the_old_behaviour(self):
        self.assertEqual(L.words(""), [])
        self.assertEqual(L.words("   \n\t "), [])
        self.assertEqual(L.words("123 456"), ["123", "456"])


class HindiSelectionTests(unittest.TestCase):
    """The tokeniser is only useful if a Hindi transcript actually reaches the ranker's features."""

    PAIRS = [(0.0, 4.0, "मैं तो बहुत अच्छा खिलाड़ी हूँ।"),
             (4.2, 9.0, "फिर तुम क्यों हार रहे हो? ये क्या बकवास है।"),
             (9.2, 13.0, "मैं उन्हें जीतने दे रहा हूँ।"),
             (13.2, 18.0, "बिल्कुल झूठ। हाहाहा।")]

    def transcript(self):
        return Transcript([Segment(a, b, t) for a, b, t in self.PAIRS], "subtitle-file")

    def test_a_hindi_transcript_produces_ranked_candidates_with_text_evidence(self):
        pool_before = len(engine.rank(20, Transcript(), [], [], 15, 2)[1])
        cands, pool = engine.rank(20, self.transcript(), [], [], 15, 2)
        self.assertTrue(pool, "Hindi transcript produced no candidate windows")
        self.assertTrue(cands, "Hindi transcript produced no selected candidate")
        top = cands[0]
        self.assertTrue(top.excerpt, "the selected candidate has no excerpt")
        self.assertIn("खिलाड़ी", L.words(top.excerpt) + L.words(" ".join(t for _, _, t in self.PAIRS)), top.excerpt)
        analysis = top.features["analysis"]
        self.assertTrue(analysis["signals_used"][0].startswith("transcript"), analysis["signals_used"])
        assessed = {k: f["value"] for k, f in analysis["features"].items() if k in ("hook", "payoff", "story_completeness", "standalone_clarity", "caption_readability")}
        self.assertTrue(all(v is not None for v in assessed.values()), assessed)   # text features were measurable
        self.assertGreater(max(assessed.values()), 0.0, assessed)                   # and a Hindi signal registered
        self.assertEqual(pool_before, len(engine.rank(20, Transcript(), [], [], 15, 2)[1]))

    def test_hindi_windows_have_a_topic_signature_so_dedupe_can_work(self):
        _, pool = engine.rank(20, self.transcript(), [], [], 15, 2)
        topics = [set(L.content_words(w.window.text)) for w in pool]
        self.assertTrue(any(topics), "no window has Hindi content words")
        self.assertTrue(any(len(t) >= 2 for t in topics), topics)


if __name__ == "__main__":
    unittest.main()
