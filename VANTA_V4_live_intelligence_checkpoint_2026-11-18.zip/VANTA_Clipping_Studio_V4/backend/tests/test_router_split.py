"""Guards the split of clipstudio/router.py into clipstudio/routes/*.py: same API surface, same names, same patch targets."""
from __future__ import annotations

import json
import unittest
from pathlib import Path
from unittest import mock

from fastapi import FastAPI

from app.clipstudio import router as router_module
from app.clipstudio.routes import candidates, cloud_ai, exports, live, projects, publishing, render_jobs, scheduling, system, templates, transcription

SNAPSHOT = json.loads((Path(__file__).parent / "data" / "vanta_routes_snapshot.json").read_text(encoding="utf-8"))
MODULES = (system, live, scheduling, projects, transcription, candidates, render_jobs, exports, publishing, templates, cloud_ai)


def _operations() -> list[list]:
    app = FastAPI()
    app.include_router(router_module.router)
    schema = app.openapi()
    return sorted([m.upper(), p, v["operationId"], list(v.get("tags", []))] for p, item in schema["paths"].items() for m, v in item.items())


class RouterSplitTests(unittest.TestCase):
    def test_existing_api_surface_is_preserved(self):
        expected = sorted(SNAPSHOT["operations"])
        actual = _operations()
        self.assertEqual([o for o in expected if o not in actual], [], "routes lost in the split")

    def test_no_duplicate_method_path_pairs(self):
        seen = [(o[0], o[1]) for o in _operations()]
        self.assertEqual(len(seen), len(set(seen)))

    def test_every_route_module_is_mounted_and_non_empty(self):
        mounted = {id(m.router) for m in MODULES}
        for m in MODULES:
            self.assertGreater(len(m.router.routes), 0, m.__name__)
        # the assembled API exposes exactly the routes of all modules (one operation per method+path)
        self.assertEqual(len(_operations()), sum(len(r.methods) for m in MODULES for r in m.router.routes))
        self.assertEqual(len(mounted), len(MODULES))

    def test_old_module_names_are_still_importable(self):
        missing = [n for n in SNAPSHOT["names"] if not hasattr(router_module, n)]
        self.assertEqual(missing, [])

    def test_patching_through_the_old_path_reaches_the_route_code(self):
        from app.clipstudio import youtube_upload
        with mock.patch("app.clipstudio.router.youtube_upload.status", return_value={"connected": False}):
            self.assertIs(publishing.youtube_upload, router_module.youtube_upload)
            self.assertEqual(publishing.youtube_upload.status(), {"connected": False})
        self.assertIsNot(youtube_upload.status(), None)

    def test_prefix_and_tag(self):
        for _, path, _, tags in _operations():
            self.assertTrue(path.startswith("/api/vanta/"), path)
            self.assertEqual(tags, ["vanta"], path)


if __name__ == "__main__":
    unittest.main()
