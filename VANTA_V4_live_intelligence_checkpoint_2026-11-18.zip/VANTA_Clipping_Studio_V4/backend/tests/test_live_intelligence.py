"""Unit tests for local, credential-free live intelligence primitives."""
from __future__ import annotations

import unittest
from pathlib import Path

from app.clipstudio.live.chat_spike_detector import ChatMessage, ChatSpikeDetector
from app.clipstudio.live.event_correlator import EvidenceEvent, correlate
from app.clipstudio.live.live_clip_worker import LiveClipWorker
from app.clipstudio.live.review_pipeline import LiveReviewPipeline
from app.clipstudio.live.rolling_buffer import BufferedSegment, RollingBuffer
from app.clipstudio.live.stream_manager import LiveStreamManager


class RollingBufferTests(unittest.TestCase):
    def test_retains_only_configured_recent_segments_and_reports_post_capture_readiness(self):
        buffer = RollingBuffer(60, max_segments=10)
        retired = []
        for second in range(0, 100, 10):
            retired.extend(buffer.add(BufferedSegment(second, second + 10, Path(f"segment-{second}.ts"))))
        self.assertTrue(retired)
        self.assertGreaterEqual(buffer.status()["start"], 30)
        parts, coverage = buffer.window(80, before_seconds=30, after_seconds=8)
        self.assertEqual(parts[0].start, 50)
        self.assertTrue(coverage["ready"])
        _, pending = buffer.window(98, before_seconds=30, after_seconds=8)
        self.assertFalse(pending["ready"])
        self.assertGreater(pending["missing_after_seconds"], 0)


class ChatSpikeTests(unittest.TestCase):
    def test_filters_bots_and_copy_spam_but_detects_independent_reaction_burst(self):
        detector = ChatSpikeDetector(window_seconds=5, history_seconds=60, minimum_messages=5, spike_multiplier=2)
        self.assertIsNone(detector.ingest(ChatMessage(0, "nightbot", "follow the channel")))
        # Establish a normal baseline.
        for i in range(8):
            detector.ingest(ChatMessage(float(i), f"normal-{i}", f"regular message {i}"))
        # A raid-like wall of copy-paste text must not become a moment.
        copy_result = None
        for i in range(8):
            copy_result = detector.ingest(ChatMessage(20 + i * 0.05, f"copy-{i}", "BUY FOLLOWERS NOW"))
        self.assertIsNone(copy_result)
        # Independent chatters reacting with distinct messages should.
        result = None
        reactions = ["WHAT", "NO WAY", "CLUTCH", "he did it", "insane play", "OMG", "that was wild", "lets go"] * 2
        for i, text in enumerate(reactions):
            result = detector.ingest(ChatMessage(40 + i * 0.05, f"viewer-{i}", text))
        self.assertIsNotNone(result)
        assert result is not None
        self.assertGreaterEqual(result.unique_chatters, 5)
        self.assertLess(result.copy_ratio, 0.72)


class CorrelationAndManagerTests(unittest.TestCase):
    def test_chat_reaction_is_aligned_to_prior_evidence_not_its_arrival_time(self):
        detector = ChatSpikeDetector(window_seconds=5, minimum_messages=5, spike_multiplier=1)
        spike = None
        for i in range(5):
            spike = detector.ingest(ChatMessage(30 + i * 0.1, f"u{i}", f"no way {i}"))
        assert spike is not None
        event = correlate(spike, [EvidenceEvent(21, 23, "humour", 0.9, "setup/payoff")])
        self.assertAlmostEqual(event.event_time, 22.0)
        self.assertNotEqual(event.event_time, spike.timestamp)
        self.assertEqual(event.kind, "humour")

    def test_chat_only_event_is_rejected_instead_of_becoming_a_clip(self):
        manager = LiveStreamManager()
        worker = LiveClipWorker(Path("unused-clips"))
        pipeline = LiveReviewPipeline(manager, worker)
        session = manager.start("youtube", "video-chat-only")
        event = correlate(
            type("Spike", (), {"timestamp": 40.0, "score": 90.0, "reasons": ("chat burst",)})(),
            [],
        )
        self.assertEqual(event.kind, "chat activity")
        self.assertIsNone(pipeline.submit(session, event))
        self.assertEqual(pipeline.jobs(session.id), [])
        status = pipeline.status()
        self.assertEqual(status["rejected_chat_only"], 1)
        self.assertEqual(status["last_rejection"]["reason"], "chat_only_event")

    def test_manager_ignores_chat_before_first_media_segment(self):
        manager = LiveStreamManager()
        session = manager.start("youtube", "video-1", buffer_seconds=60, post_event_seconds=8)
        # A chat adapter can connect faster than FFmpeg can publish its first segment.
        for i, text in enumerate(["WHAT", "NO WAY", "CLUTCH", "OMG", "INSANE", "LETS GO", "WTF", "LOL"]):
            manager.add_chat(session.id, ChatMessage(0.0, f"viewer-{i}", text, "youtube"))
        self.assertEqual(session.events, [])
        self.assertEqual(session.detector.status()["tracked_messages"], 0)
        manager.add_segment(session.id, 0, 4, Path("segment-0.ts"))
        self.assertIsNone(manager.add_chat(session.id, ChatMessage(4.0, "viewer-after", "real message", "youtube")))

    def test_manager_deduplicates_continuing_spikes_and_exposes_review_plan(self):
        manager = LiveStreamManager()
        session = manager.start("manual", "authorised-test", buffer_seconds=60, post_event_seconds=8)
        for second in range(0, 50, 10):
            manager.add_segment(session.id, second, second + 10, Path(f"seg-{second}.ts"))
        manager.add_evidence(session.id, EvidenceEvent(30, 32, "gameplay event", 0.9, "visual/timing cue"))
        for i in range(8):
            manager.add_chat(session.id, ChatMessage(38 + i * 0.05, f"chat-{i}", f"clutch {i}"))
        snap = manager.snapshot(session.id)
        self.assertTrue(snap["events"])
        worker = LiveClipWorker(Path("."))
        # No real media is required to verify the bounded capture plan.
        self.assertIn("coverage", worker.plan(session.buffer, session.events[-1]))


if __name__ == "__main__":
    unittest.main()
