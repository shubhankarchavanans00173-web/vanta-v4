"""End-to-end pipeline test through the real HTTP API with a locally generated synthetic video (no network, no paid APIs)."""
import json
import os
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import db, settings
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_music, make_video, script_srt


def ffprobe(path) -> dict:
    out = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)], capture_output=True, text=True, check=True).stdout
    return json.loads(out)


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class VantaEndToEnd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._env = mock.patch.dict(os.environ, {}, clear=False); cls._env.start()
        for k in ("VANTA_CLOUD_AI_ENABLED", "VANTA_ENABLE_YTDLP", "ANTHROPIC_API_KEY"):
            os.environ.pop(k, None)
        cls.tmp = isolate()
        cls.media_dir = tempfile.TemporaryDirectory()
        cls.video = make_video(Path(cls.media_dir.name) / "talk.mp4", duration=70)
        cls.silent_video = make_video(Path(cls.media_dir.name) / "quiet.mp4", duration=40, audio=False)
        cls.music = make_music(Path(cls.media_dir.name) / "m.mp3")
        cls.srt = Path(cls.media_dir.name) / "talk.srt"; cls.srt.write_text(script_srt())
        from app.main import app
        cls.client = TestClient(app).__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None)
        cls.media_dir.cleanup(); cls.tmp.cleanup(); cls._env.stop()

    # ---- helpers
    def upload(self, video=None, transcript=True, name="Test talk"):
        files = {"file": ("talk.mp4", (video or self.video).read_bytes(), "video/mp4")}
        if transcript:
            files["transcript"] = ("talk.srt", self.srt.read_bytes(), "text/plain")
        r = self.client.post("/api/vanta/projects/upload", files=files, data={"name": name})
        self.assertEqual(r.status_code, 200, r.text)
        return r.json()

    def wait(self, job_id, until, timeout=240):
        end = time.time() + timeout
        while time.time() < end:
            j = self.client.get(f"/api/vanta/jobs/{job_id}").json()
            if j["status"] in until:
                return j
            self.assertNotIn(j["status"], {"failed", "cancelled"} - set(until), j)
            time.sleep(0.4)
        self.fail(f"job {job_id} did not reach {until}; last={j}")

    def analyze(self, pid, **opts):
        r = self.client.post(f"/api/vanta/projects/{pid}/analyze", json={"target_duration": 15, "count": 4, "transcribe": False, **opts})
        self.assertEqual(r.status_code, 200, r.text)
        return self.wait(r.json()["id"], {"awaiting_approval"})

    # ---- tests
    def test_01_health_reports_real_capabilities(self):
        h = self.client.get("/api/vanta/health").json()
        self.assertEqual(h["status"], "ok"); self.assertIn("ffmpeg", h["ffmpeg"].lower())
        self.assertFalse(h["cloud_ai"]["enabled"]); self.assertFalse(h["links"]["platforms"]["available"])
        self.assertFalse(h["subject_tracking"]["available"])
        # the legacy studio API still works alongside
        self.assertIn(self.client.get("/api/health").json()["status"], {"ok", "degraded"})

    def test_02_full_pipeline_with_transcript(self):
        p = self.upload()
        self.assertTrue(p["has_transcript"]); self.assertEqual(p["probe"]["width"], 640)
        job = self.analyze(p["id"])
        self.assertEqual(job["result"]["method"], "multi-signal"); self.assertEqual(job["result"]["engine"], "multi-signal-rules")
        self.assertIn("transcript (sentence timings)", job["result"]["signals_used"]); self.assertIn("does not predict", job["result"]["score_note"])
        self.assertFalse(job["result"]["llm"]["requested"])   # no local model is configured in tests, so nothing may claim AI analysis
        proj = self.client.get(f"/api/vanta/projects/{p['id']}").json()
        cands = proj["candidates"]
        self.assertGreaterEqual(len(cands), 2)
        for c in cands:
            self.assertEqual(c["status"], "suggested"); self.assertTrue(c["reasons"]); self.assertTrue(c["excerpt"])
            self.assertTrue(0 <= c["score"] <= 100); self.assertGreaterEqual(c["end"] - c["start"], 9)
        self.assertEqual(proj["status"], "awaiting_approval")

        # approval is required before export
        r = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={})
        self.assertEqual(r.status_code, 409)
        r = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"candidate_ids": [cands[0]["id"]]})
        self.assertEqual(r.status_code, 409); self.assertIn("approved", r.json()["detail"])

        # edit: invalid ranges rejected, valid range accepted
        cid = cands[0]["id"]
        for body in ({"start": "0:30", "end": "0:20"}, {"start": 0, "end": 1}, {"start": 0, "end": 999}, {"start": "abc"}, {"status": "published"}):
            self.assertEqual(self.client.patch(f"/api/vanta/candidates/{cid}", json=body).status_code, 400, body)
        ok = self.client.patch(f"/api/vanta/candidates/{cid}", json={"start": "0:00.3", "end": "0:14.0", "status": "approved"}).json()
        self.assertEqual((ok["start"], ok["end"], ok["edited"], ok["status"]), (0.3, 14.0, 1, "approved"))
        self.assertIn("mistake", ok["excerpt"])
        other = self.client.patch(f"/api/vanta/candidates/{cands[1]['id']}", json={"status": "rejected"}).json()
        self.assertEqual(other["status"], "rejected")
        r = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"candidate_ids": [other["id"]]})
        self.assertEqual(r.status_code, 409)

        # caption preview before export
        prev = self.client.get(f"/api/vanta/candidates/{cid}/captions-preview").json()
        self.assertEqual(prev["granularity"], "sentence"); self.assertTrue(prev["events"]); self.assertLess(prev["events"][0]["start"], 1.0)

        # render
        r = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"settings": {"aspect": "9:16", "remove_silence": True, "caption_style": {"mode": "clean"}}, "template_id": "builtin-clean"})
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(self.client.post(f"/api/vanta/projects/{p['id']}/render", json={}).status_code, 409)      # busy -> no concurrent job on the project
        done = self.wait(r.json()["id"], {"completed"})
        self.assertEqual(len(done["result"]["exported"]), 1); self.assertEqual(done["progress"], 1.0)

        exp = self.client.get("/api/vanta/exports").json()[0]
        self.assertTrue(exp["file_exists"]); self.assertTrue(exp["validation"]["valid"]); self.assertEqual(exp["aspect"], "9:16")
        self.assertEqual(exp["meta"]["captions_granularity"], "sentence"); self.assertFalse(exp["meta"]["subject_tracking"])
        info = ffprobe(settings.EXPORT_DIR / p["id"] / exp["filename"])
        v = next(s for s in info["streams"] if s["codec_type"] == "video"); a = next(s for s in info["streams"] if s["codec_type"] == "audio")
        self.assertEqual((v["codec_name"], v["width"], v["height"], v["pix_fmt"]), ("h264", 1080, 1920, "yuv420p"))
        self.assertEqual(a["codec_name"], "aac"); self.assertEqual(v["avg_frame_rate"], "30/1")
        self.assertAlmostEqual(float(info["format"]["duration"]), exp["duration"], delta=0.2)
        self.assertLess(exp["duration"], 13.7)                  # silences inside 0.3-14.0 were removed
        dl = self.client.get(f"/api/vanta/exports/{exp['id']}/download")
        self.assertEqual(dl.status_code, 200); self.assertEqual(dl.content[4:8], b"ftyp"); self.assertIn("attachment", dl.headers["content-disposition"])
        self.assertEqual(self.client.get(f"/api/vanta/exports/{exp['id']}/preview").status_code, 200)
        srt = self.client.get(f"/api/vanta/exports/{exp['id']}/captions")
        self.assertEqual(srt.status_code, 200); self.assertRegex(srt.text, r"00:00:00,\d{3} -->")
        self.assertEqual(self.client.get(f"/api/vanta/candidates/{cid}").status_code, 405)   # (no GET route; just checking routing is sane)
        # the original upload is untouched
        self.assertEqual(Path(db.get_project(p["id"])["source_path"]).read_bytes(), self.video.read_bytes())
        # the source video can be streamed with Range requests for the preview player
        rng = self.client.get(f"/api/vanta/projects/{p['id']}/source", headers={"Range": "bytes=0-99"})
        self.assertIn(rng.status_code, (200, 206))
        # candidate shows as rendered; deleting the export returns it to approved
        self.assertEqual(db.get_candidate(cid)["status"], "rendered")
        self.assertEqual(self.client.delete(f"/api/vanta/exports/{exp['id']}").status_code, 200)
        self.assertFalse((settings.EXPORT_DIR / p["id"] / exp["filename"]).exists()); self.assertEqual(db.get_candidate(cid)["status"], "approved")

        # project with exports requires explicit confirmation to delete
        self.assertEqual(self.client.delete(f"/api/vanta/projects/{p['id']}").status_code, 200)   # exports were removed above

    def test_03_no_transcript_uses_labelled_fallback_and_silent_source_renders_without_audio(self):
        p = self.upload(self.silent_video, transcript=False, name="Quiet")
        job = self.analyze(p["id"])
        self.assertEqual(job["result"]["method"], "signal-segmentation")
        self.assertTrue(any("transcript" in n.lower() for n in job["result"]["notes"]))
        cands = self.client.get(f"/api/vanta/projects/{p['id']}").json()["candidates"]
        self.assertTrue(cands); self.assertIn("No transcript", cands[0]["reasons"][0]); self.assertEqual(cands[0]["excerpt"], "")
        self.client.patch(f"/api/vanta/candidates/{cands[0]['id']}", json={"status": "approved"})
        # Captions requested but there is no transcript: the render must FAIL loudly, never export an uncaptioned MP4.
        r = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"settings": {"aspect": "1:1", "captions": True}})
        failed = self.wait(r.json()["id"], {"failed"})
        self.assertIn("no usable transcript", failed["error"] if failed.get("error") else failed["message"])
        self.assertEqual([e for e in self.client.get("/api/vanta/exports").json() if e["project_id"] == p["id"]], [])
        # The same approved clip renders normally once captions are switched off.
        r = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"settings": {"aspect": "1:1", "captions": False}})
        self.assertEqual(r.status_code, 200, r.text)
        self.wait(r.json()["id"], {"completed"})
        exp = next(e for e in self.client.get("/api/vanta/exports").json() if e["project_id"] == p["id"])
        self.assertEqual(exp["meta"]["captions_granularity"], "none")
        info = ffprobe(settings.EXPORT_DIR / p["id"] / exp["filename"])
        self.assertEqual([s["codec_type"] for s in info["streams"]], ["video"])
        self.assertEqual((info["streams"][0]["width"], info["streams"][0]["height"]), (1080, 1080))

    def test_04_custom_range_music_and_16x9(self):
        p = self.upload(name="Music")
        mus = self.client.post("/api/vanta/music", files={"file": ("m.mp3", self.music.read_bytes(), "audio/mpeg")}).json()
        bad = self.client.post("/api/vanta/music", files={"file": ("m.mp3", b"not audio", "audio/mpeg")})
        self.assertEqual(bad.status_code, 400)
        c = self.client.post(f"/api/vanta/projects/{p['id']}/candidates", json={"start": "0:12", "end": "0:24", "title": "mine"})
        self.assertEqual(c.status_code, 200); self.assertEqual(c.json()["status"], "approved"); self.assertEqual(c.json()["origin"], "custom")
        self.assertEqual(self.client.post(f"/api/vanta/projects/{p['id']}/candidates", json={"start": "0:60", "end": "1:20"}).status_code, 400)
        r = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"settings": {"aspect": "16:9", "music_id": mus["music_id"], "music_volume": 0.3, "reframe": "center"}})
        self.wait(r.json()["id"], {"completed"})
        exp = next(e for e in self.client.get("/api/vanta/exports").json() if e["project_id"] == p["id"])
        info = ffprobe(settings.EXPORT_DIR / p["id"] / exp["filename"])
        self.assertEqual((info["streams"][0]["width"], info["streams"][0]["height"]), (1920, 1080)); self.assertTrue(exp["validation"]["valid"])
        self.assertEqual(self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"settings": {"music_id": "deadbeef0000"}}).status_code, 409)  # nothing approved now
        c2 = self.client.post(f"/api/vanta/projects/{p['id']}/candidates", json={"start": 1, "end": 12}).json()
        self.assertEqual(self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"settings": {"music_id": "deadbeef0000"}}).status_code, 400)   # unknown music

    def test_05_render_failure_is_reported_and_leaves_no_export(self):
        p = self.upload(name="Broken")
        c = self.client.post(f"/api/vanta/projects/{p['id']}/candidates", json={"start": 2, "end": 14}).json()
        before = len(self.client.get("/api/vanta/exports").json())
        Path(db.get_project(p["id"])["source_path"]).write_bytes(b"corrupted, not a video" * 50)     # source breaks after approval
        r = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={})
        j = self.wait(r.json()["id"], {"failed"})
        self.assertTrue(j["error"]); self.assertEqual(len(self.client.get("/api/vanta/exports").json()), before)
        cand = db.get_candidate(c["id"])
        self.assertEqual(cand["status"], "failed"); self.assertTrue(cand["error"])           # failure is visible on the clip itself
        again = self.client.post(f"/api/vanta/projects/{p['id']}/render", json={"candidate_ids": [c["id"]]})
        self.assertEqual(again.status_code, 200)                                              # ...and can be retried without re-approving
        self.wait(again.json()["id"], {"failed"})
        self.assertFalse(list((settings.EXPORT_DIR / p["id"]).glob("*.mp4")) if (settings.EXPORT_DIR / p["id"]).exists() else [])
        self.assertEqual(db.get_project(p["id"])["status"], "awaiting_approval")

    def test_06_invalid_uploads(self):
        post = lambda name, data, **kw: self.client.post("/api/vanta/projects/upload", files={"file": (name, data, "application/octet-stream")}, **kw)
        r = post("notes.txt", b"hello"); self.assertEqual(r.status_code, 400); self.assertIn("Unsupported", r.json()["detail"])
        r = post("fake.mp4", b"not really a video" * 200); self.assertEqual(r.status_code, 400); self.assertIn("not readable media", r.json()["detail"])
        r = post("empty.mp4", b""); self.assertEqual(r.status_code, 400)
        r = post("../../evil.sh", b"x"); self.assertEqual(r.status_code, 400)
        with mock.patch.object(settings, "MAX_UPLOAD_BYTES", 1000):
            r = post("big.mp4", self.video.read_bytes()); self.assertEqual(r.status_code, 413)
        with mock.patch.object(settings, "MAX_DURATION_SECONDS", 10):
            r = post("long.mp4", self.video.read_bytes()); self.assertEqual(r.status_code, 400); self.assertIn("limit", r.json()["detail"])
        self.assertEqual([p for p in settings.UPLOAD_DIR.iterdir() if p.name.endswith(("notes.txt", "fake.mp4", "empty.mp4", "big.mp4", "long.mp4"))], [])   # nothing left behind
        bad_tr = self.client.post(f"/api/vanta/projects/{self.upload(transcript=False)['id']}/transcript", files={"file": ("x.srt", b"garbage", "text/plain")})
        self.assertEqual(bad_tr.status_code, 400)

    def test_07_links_are_validated_and_never_faked(self):
        post = lambda url, rights=True: self.client.post("/api/vanta/projects/link", json={"url": url, "rights_confirmed": rights})
        self.assertEqual(post("https://cdn.example.com/a.mp4", rights=False).status_code, 428)
        for bad in ("file:///etc/passwd", "ftp://x.com/a.mp4", "http://127.0.0.1/a.mp4", "http://localhost:8000/a.mp4", "http://169.254.169.254/latest/meta-data", "https://user:pw@example.com/a.mp4"):
            r = post(bad); self.assertEqual(r.status_code, 400, bad); self.assertIn("code", r.json()["detail"])
        r = post("https://www.youtube.com/watch?v=dQw4w9WgXcQ"); self.assertEqual(r.status_code, 400); self.assertEqual(r.json()["detail"]["code"], "adapter_disabled")
        self.assertIn("upload", r.json()["detail"]["message"].lower())
        r = post("https://www.netflix.com/title/1"); self.assertEqual(r.json()["detail"]["code"], "unsupported_platform")

    def test_08_link_project_failure_is_surfaced_through_the_job(self):
        from app.clipstudio import links
        with mock.patch.object(links, "assert_public_host", lambda *a, **k: None):
            r = self.client.post("/api/vanta/projects/link", json={"url": "https://cdn.example.com/gone.mp4", "rights_confirmed": True, "start_download": False})
        self.assertEqual(r.status_code, 200); pid = r.json()["id"]
        self.assertFalse(r.json()["has_source"])
        with mock.patch.object(links, "fetch", side_effect=links.LinkError("unavailable", "The video was not found at that link (HTTP 404).")):
            j = self.client.post(f"/api/vanta/projects/{pid}/analyze", json={}).json()
            j = self.wait(j["id"], {"failed"})
        self.assertIn("not found", j["error"]); self.assertEqual(db.get_project(pid)["status"], "failed"); self.assertFalse(db.get_project(pid)["source_path"])

    def test_09_link_download_success_path_feeds_the_pipeline(self):
        from app.clipstudio import links
        real = self.video

        def fake_fetch(url, dest, progress=lambda p: None, cancelled=lambda: False, resolver=None):
            dest.mkdir(parents=True, exist_ok=True); out = dest / "source.mp4"; out.write_bytes(real.read_bytes())
            return links.Fetched(out, None, "Fetched title", "direct_media", "http")
        with mock.patch.object(links, "assert_public_host", lambda *a, **k: None):
            pid = self.client.post("/api/vanta/projects/link", json={"url": "https://cdn.example.com/v.mp4", "rights_confirmed": True, "start_download": False}).json()["id"]
        with mock.patch.object(links, "fetch", fake_fetch):
            j = self.analyze(pid)
        proj = db.get_project(pid)
        self.assertTrue(Path(proj["source_path"]).is_file()); self.assertEqual(proj["probe"]["duration"], 70.0); self.assertEqual(j["result"]["method"], "signal-segmentation")

    def test_10_paid_ai_is_off_and_requires_confirmation(self):
        p = self.upload(name="AI gate"); self.analyze(p["id"])
        r = self.client.post(f"/api/vanta/projects/{p['id']}/ai/estimate"); self.assertEqual(r.status_code, 403)
        r = self.client.post(f"/api/vanta/projects/{p['id']}/ai/rank", json={"confirm": True, "estimate_id": "x"}); self.assertEqual(r.status_code, 403)
        self.assertFalse(self.client.get("/api/vanta/ai/providers").json()["cloud"]["enabled"])
        # enabled but not confirmed -> 428; no provider request is ever made
        with mock.patch.dict(os.environ, {"VANTA_CLOUD_AI_ENABLED": "1", "VANTA_CLOUD_AI_MODEL": "m", "ANTHROPIC_API_KEY": "k"}):
            with mock.patch("app.clipstudio.cost.httpx.Client", side_effect=AssertionError("network must not be touched")):
                est = self.client.post(f"/api/vanta/projects/{p['id']}/ai/estimate"); self.assertEqual(est.status_code, 200)
                self.assertEqual(self.client.post(f"/api/vanta/projects/{p['id']}/ai/rank", json={"estimate_id": est.json()["estimate_id"]}).status_code, 428)
                self.assertEqual(self.client.post(f"/api/vanta/projects/{p['id']}/ai/rank", json={"estimate_id": "bogus", "confirm": True}).status_code, 409)

    def test_11_templates_jobs_settings_and_project_deletion(self):
        tpls = self.client.get("/api/vanta/templates").json()
        self.assertGreaterEqual(sum(1 for t in tpls if t["builtin"]), 3)
        new = self.client.post("/api/vanta/templates", json={"name": "Mine", "style": {"font_size_pct": 5, "color": "#00FF00"}}).json()
        self.assertEqual(new["style"]["font_size_pct"], 5.0)
        self.assertEqual(self.client.delete(f"/api/vanta/templates/builtin-clean").status_code, 404)
        self.assertEqual(self.client.delete(f"/api/vanta/templates/{new['id']}").status_code, 200)
        self.assertTrue(self.client.get("/api/vanta/jobs").json()); self.assertFalse(self.client.get("/api/vanta/settings").json()["editable"])
        p = self.upload(transcript=False, name="Temp"); path = Path(db.get_project(p["id"])["source_path"]); self.assertTrue(path.exists())
        self.assertEqual(self.client.delete(f"/api/vanta/projects/{p['id']}").status_code, 200)
        self.assertFalse(path.exists()); self.assertEqual(self.client.get(f"/api/vanta/projects/{p['id']}").status_code, 404)
        self.assertEqual(self.client.get("/api/vanta/projects/nope/source").status_code, 404)
        self.assertEqual(self.client.get("/api/vanta/exports/nope/download").status_code, 404)

    def test_12_no_scratch_left_behind(self):
        leftovers = [d for d in settings.TMP_DIR.iterdir()] if settings.TMP_DIR.exists() else []
        self.assertEqual(leftovers, [])


if __name__ == "__main__":
    unittest.main()
