"""Hindi / Hinglish surface-cue module.

These tests pin what the module is allowed to claim: it matches *literal, inspected* words and phrases
that a speaker used, and it returns that evidence. It does not translate, does not infer meaning, and
must not fire on ordinary English.
"""
from __future__ import annotations

import unittest
from unittest import mock

from app.clipstudio.selection import engine
from app.clipstudio.selection.languages import analyze_cues, script_of
from app.clipstudio.selection.languages import hindi
from app.clipstudio.transcript import Segment, Transcript


class ScriptDetectionTests(unittest.TestCase):
    def test_scripts(self):
        self.assertEqual(script_of("मैं तो बहुत अच्छा खिलाड़ी हूँ"), "devanagari")
        self.assertEqual(script_of("I'm actually a professional player."), "latin")
        self.assertEqual(script_of("BRO ye toh OP tha हिन्दी"), "mixed")
        self.assertEqual(script_of("123 !!! ??"), "none")


class HindiCueTests(unittest.TestCase):
    def test_banter_and_teasing_are_detected_with_evidence(self):
        result = analyze_cues("yaar tu toh pagal hai, bakwaas mat kar")
        self.assertEqual(result["language"], "hindi")
        self.assertIn("banter", result["cues"])
        self.assertIn("bakwaas", result["cues"]["banter"])
        self.assertIn("pagal", result["cues"]["banter"])

    def test_devanagari_cues_are_detected(self):
        result = analyze_cues("अरे यार ये क्या बकवास है")
        self.assertIn("banter", result["cues"])
        self.assertTrue(any("बकवास" in hit for hit in result["cues"]["banter"]))

    def test_dev_anagari_laughter_and_disbelief(self):
        laughs = analyze_cues("हाहाहा सच में? क्या बात है")
        self.assertIn("laughter", laughs["cues"])
        self.assertIn("surprise", laughs["cues"])

    def test_romanised_hindi_laughter_and_frustration(self):
        result = analyze_cues("hahaha bhai bas kar, kya kar raha hai")
        self.assertIn("laughter", result["cues"])
        self.assertIn("frustration", result["cues"])

    def test_plain_english_never_produces_hindi_cues(self):
        for text in ("I'm actually a professional player.", "Then why are you losing? COPIUM",
                     "The trick is to explain one idea at a time.", "hello everybody welcome back"):
            result = analyze_cues(text)
            self.assertEqual(result["language"], None, text)
            self.assertEqual(result["cues"], {}, text)

    def test_a_single_word_is_not_a_confident_semantic_claim(self):
        one = analyze_cues("yaar")
        many = analyze_cues("yaar tu toh pagal hai, bakwaas mat kar, hahaha")
        self.assertLess(one["confidence"], 0.5)
        self.assertGreater(many["confidence"], one["confidence"])

    def test_result_states_its_own_limits(self):
        result = analyze_cues("yaar ye kya bakwaas hai")
        self.assertIn("surface", result["limits"].lower())
        self.assertIn("no semantic", result["limits"].lower())
        self.assertIs(result["semantic_understanding"], False)

    def test_matching_is_deterministic_and_deduplicated(self):
        first, second = analyze_cues("yaar yaar yaar bakwaas bakwaas"), analyze_cues("yaar yaar yaar bakwaas bakwaas")
        self.assertEqual(first, second)
        self.assertEqual(first["cues"]["banter"].count("yaar"), 1)

    def test_english_word_inside_a_longer_word_is_not_a_hit(self):
        # "bhai" must not match inside "bhaijaan" without a boundary rule... it is a Hindi word, so it does;
        # but an English false friend like "hai" inside "Haiti" must not fire.
        self.assertNotIn("banter", analyze_cues("Haiti is a country").get("cues", {}))

    def test_only_known_categories_are_reported(self):
        allowed = {"laughter", "humour", "banter", "sarcasm", "surprise", "frustration", "agreement", "disagreement"}
        self.assertLessEqual(set(hindi.cues("yaar hahaha pagal").keys()), allowed)

    def test_empty_and_symbol_only_text(self):
        for text in ("", "   ", "😂😂😂", "।।"):
            result = analyze_cues(text)
            self.assertEqual(result["cues"], {}, repr(text))


class EngineWiringTests(unittest.TestCase):
    """The cues are attached to the candidate analysis, and they do not move any score."""

    HINDI = [(0.0, 4.0, "मैं तो बहुत अच्छा खिलाड़ी हूँ।"), (4.2, 9.0, "ये क्या बकवास है यार।"),
             (9.2, 13.0, "बिल्कुल झूठ। हाहाहा।")]
    ENGLISH = [(0.0, 4.0, "I'm actually a professional player."), (4.2, 9.0, "Then why are you losing? COPIUM"),
               (9.2, 13.0, "The trick is to explain one idea at a time.")]

    def rank(self, pairs):
        return engine.rank(18, Transcript([Segment(a, b, t) for a, b, t in pairs], "subtitle-file"), [], [], 12, 2)

    def test_hindi_candidate_carries_cue_evidence(self):
        cands, _ = self.rank(self.HINDI)
        cues = cands[0].features["analysis"]["language_cues"]
        self.assertEqual(cues["language"], "hindi")
        self.assertTrue(cues["cues"], cues)
        self.assertIn("Matched Hindi/Hinglish surface cues", cues["evidence"])
        self.assertIs(cues["semantic_understanding"], False)

    def test_english_candidate_reports_no_language_layer_hit(self):
        cands, _ = self.rank(self.ENGLISH)
        cues = cands[0].features["analysis"]["language_cues"]
        self.assertIsNone(cues["language"])
        self.assertEqual(cues["cues"], {})

    def test_cue_evidence_cannot_change_a_score(self):
        normal = [c.score for c in self.rank(self.HINDI)[0]]
        bogus = {"language": "hindi", "script": "devanagari", "cues": {"banter": ["x"] * 50}, "hits": 50,
                 "confidence": 0.95, "evidence": "bogus", "semantic_understanding": False, "limits": "bogus"}
        with mock.patch.object(engine.languages, "analyze_cues", return_value=bogus):
            patched = [c.score for c in self.rank(self.HINDI)[0]]
        self.assertEqual(normal, patched)
        self.assertNotIn("language", " ".join(str(k) for k in self.rank(self.HINDI)[0][0].features["analysis"]["weights_used"]))


if __name__ == "__main__":
    unittest.main()
