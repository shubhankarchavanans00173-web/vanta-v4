"""The app's live sessions must actually take a stream.

A session used to be a bookkeeping row: nothing read the operator's source, so the buffer stayed at zero seconds and
no clip could ever appear. These tests start a real session through the API against a paced local file (real FFmpeg
when available), and cover the two refusals that keep a missing source or a platform watch page from pretending to
work.
"""
from __future__ import annotations

import json
import os
import time
import unittest
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import settings
from app.clipstudio.routes import live as live_routes
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class LiveSessionApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.env = mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "0",
                                                "YOUTUBE_TOKEN_FILE": str(settings.BASE / "no-token.json")}, clear=False)
        self.env.start()
        from app.main import app
        self.client = TestClient(app)
        self.client.__enter__()

    def tearDown(self):
        try:
            live_routes.stop_all()                    # never leave an FFmpeg ingest behind, even after a failure
        finally:
            self.client.__exit__(None, None, None)
            self.env.stop()
            self.tmp.cleanup()

    def test_a_session_without_a_source_is_refused(self):
        r = self.client.post("/api/vanta/live/sessions",
                             json={"platform": "manual", "stream_ref": "test", "authorized": True})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(r.json()["detail"]["code"], "source_required")
        self.assertIn("HLS", r.json()["detail"]["hint"])

    def test_a_live_link_is_resolved_and_its_signed_url_is_not_returned(self):
        resolved = make_video(settings.BASE / "resolved.mp4", duration=8, size="160x90")
        url = "https://www.youtube.com/live/63p6dc99He8"
        with mock.patch.object(live_routes.stream_source, "resolve", return_value=(str(resolved), None)) as resolve:
            r = self.client.post("/api/vanta/live/sessions",
                                 json={"platform": "youtube", "source": url, "authorized": True})
        self.assertEqual(r.status_code, 200, r.text)
        resolve.assert_called_once()
        body = r.json()
        self.assertEqual(body["stream_ref"], "63p6dc99He8")        # chat reference taken from the link
        self.assertEqual(body["ingest"]["source"], url)            # the page link, never the signed media URL
        self.assertNotIn("m3u8", json.dumps(body))
        self.assertEqual(self.client.post(f"/api/vanta/live/sessions/{body['id']}/stop").status_code, 200)

    def test_a_link_that_cannot_be_resolved_is_refused_with_the_reason(self):
        error = live_routes.stream_source.ResolveError("That link could not be resolved.", code="resolve_failed",
                                                       hint="Private video.")
        with mock.patch.object(live_routes.stream_source, "resolve", side_effect=error):
            r = self.client.post("/api/vanta/live/sessions",
                                 json={"platform": "youtube", "source": "https://www.youtube.com/live/abc",
                                       "authorized": True})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(r.json()["detail"]["code"], "resolve_failed")
        self.assertEqual(r.json()["detail"]["hint"], "Private video.")

    def test_starting_a_session_ingests_the_stream_and_stop_stops_it(self):
        source = make_video(settings.BASE / "capture.mp4", duration=8, size="160x90")
        r = self.client.post("/api/vanta/live/sessions",
                             json={"platform": "youtube", "stream_ref": "live-video", "source": str(source),
                                   "authorized": True, "buffer_seconds": 30, "post_event_seconds": 4})
        self.assertEqual(r.status_code, 200, r.text)
        created = r.json()
        self.assertEqual(created["state"], "monitoring")
        self.assertTrue(created["ingest"]["running"])
        self.assertTrue(created["chat_problem"])      # no YouTube token here: the media must still ingest

        deadline, seen = time.monotonic() + 40, created
        while time.monotonic() < deadline:
            seen = next(s for s in self.client.get("/api/vanta/live/sessions").json() if s["id"] == created["id"])
            if seen["ingest"]["segments_published"] >= 1 and seen["buffer"]["buffered_seconds"] > 0:
                break
            time.sleep(0.5)
        self.assertGreaterEqual(seen["ingest"]["segments_published"], 1)
        self.assertGreater(seen["buffer"]["buffered_seconds"], 0)
        self.assertIsNone(seen["ingest"]["error"])

        stopped = self.client.post(f"/api/vanta/live/sessions/{created['id']}/stop")
        self.assertEqual(stopped.status_code, 200, stopped.text)
        self.assertEqual(stopped.json()["state"], "stopped")
        self.assertFalse(stopped.json()["ingest"]["running"])


if __name__ == "__main__":
    unittest.main()
