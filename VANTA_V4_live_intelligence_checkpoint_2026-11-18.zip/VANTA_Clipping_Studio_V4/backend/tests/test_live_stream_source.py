"""Resolving a platform link into media URLs, and the ingest command that reads two of them.

No network here: yt-dlp is faked, so these tests pin the contract (two URLs become video + audio, one URL still works,
a refused link carries the tool's reason) and the FFmpeg mapping that makes a live YouTube stream have sound.
"""
from __future__ import annotations

import os
import subprocess
import unittest
from pathlib import Path
from unittest import mock

from app.clipstudio.live import stream_source
from app.clipstudio.live.segment_ingest import IngestConfig, build_command

VIDEO = "https://manifest.googlevideo.com/api/manifest/hls_variant/id/video/index.m3u8?sig=abc"
AUDIO = "https://manifest.googlevideo.com/api/manifest/hls_playlist/id/audio/index.m3u8?sig=def"


def _done(stdout: str = "", stderr: str = "", code: int = 0) -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(args=["yt-dlp"], returncode=code, stdout=stdout, stderr=stderr)


class StreamSourceTests(unittest.TestCase):
    def test_links_cannot_be_resolved_when_the_operator_left_them_off(self):
        with mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "0"}), \
                mock.patch.object(stream_source.ytdlp, "base_command", return_value=["python", "-m", "yt_dlp"]), \
                mock.patch.object(stream_source.subprocess, "run") as run:
            with self.assertRaises(stream_source.ResolveError) as ctx:
                stream_source.resolve("https://www.youtube.com/live/abc")
        self.assertEqual(ctx.exception.code, "platform_links_disabled")
        self.assertIn("VANTA_ENABLE_YTDLP=1", ctx.exception.hint)
        run.assert_not_called()

    def test_a_live_stream_returns_video_and_audio(self):
        with mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "1"}), \
                mock.patch.object(stream_source.ytdlp, "base_command", return_value=["python", "-m", "yt_dlp"]), \
                mock.patch.object(stream_source.subprocess, "run", return_value=_done(f"{VIDEO}\n{AUDIO}\n")):
            self.assertEqual(stream_source.resolve("https://www.youtube.com/live/abc"), (VIDEO, AUDIO))

    def test_a_single_stream_is_still_a_valid_source(self):
        with mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "1"}), \
                mock.patch.object(stream_source.ytdlp, "base_command", return_value=["python", "-m", "yt_dlp"]), \
                mock.patch.object(stream_source.subprocess, "run", return_value=_done(f"{VIDEO}\n")):
            self.assertEqual(stream_source.resolve("https://www.twitch.tv/someone"), (VIDEO, None))

    def test_a_refused_link_reports_the_tool_reason_without_the_signed_url(self):
        stderr = ("ERROR: [youtube] abc: Private video. Sign in if you've been granted access to this video. "
                  f"Requested url {VIDEO}")
        with mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "1"}), \
                mock.patch.object(stream_source.ytdlp, "base_command", return_value=["python", "-m", "yt_dlp"]), \
                mock.patch.object(stream_source.subprocess, "run", return_value=_done(stderr=stderr, code=1)):
            with self.assertRaises(stream_source.ResolveError) as ctx:
                stream_source.resolve("https://www.youtube.com/live/abc")
        self.assertEqual(ctx.exception.code, "resolve_failed")
        self.assertIn("Private video", ctx.exception.hint)
        self.assertNotIn("sig=abc", ctx.exception.hint)

    def test_a_non_media_url_from_the_tool_is_never_accepted(self):
        with mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "1"}), \
                mock.patch.object(stream_source.ytdlp, "base_command", return_value=["python", "-m", "yt_dlp"]), \
                mock.patch.object(stream_source.subprocess, "run", return_value=_done("file:///C:/windows/evil.m3u8\n")):
            with self.assertRaises(stream_source.ResolveError) as ctx:
                stream_source.resolve("https://www.youtube.com/live/abc")
        self.assertEqual(ctx.exception.code, "resolve_failed")


class TwoInputIngestTests(unittest.TestCase):
    def test_a_separate_audio_playlist_is_mapped_into_the_segments(self):
        config = IngestConfig(source=VIDEO, audio_source=AUDIO)
        command = build_command("ffmpeg", VIDEO, local_file=False, config=config,
                                segments_dir=Path("segments"), list_path=Path("segments.csv"), audio_source=AUDIO)
        self.assertEqual(command.count("-i"), 2)
        self.assertEqual(command[command.index("-i") + 1], VIDEO)
        self.assertEqual(command[command.index("1:a:0") - 1], "-map")
        self.assertIn("0:v:0", command)
        self.assertTrue(command[-1].endswith("seg_%05d.ts"))                  # the segment pattern is the output

    def test_a_single_input_is_not_remapped(self):
        command = build_command("ffmpeg", "C:/captures/a.mp4", local_file=True,
                                config=IngestConfig(source="C:/captures/a.mp4"),
                                segments_dir=Path("segments"), list_path=Path("segments.csv"))
        self.assertEqual(command.count("-i"), 1)
        self.assertNotIn("-map", command)


if __name__ == "__main__":
    unittest.main()
