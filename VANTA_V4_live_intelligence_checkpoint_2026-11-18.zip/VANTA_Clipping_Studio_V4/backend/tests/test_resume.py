"""Phase 2: interrupted render/download jobs continue after a restart instead of being marked Failed.
Covers: intact exports are kept, missing/short files are redone, a crash loop is capped, analyze/scheduler jobs are never resumed,
the old fail-everything behaviour is still available, nothing can upload, and one real render is resumed end to end."""
import json
import tempfile
import time
import unittest
from pathlib import Path

from app.clipstudio import db, media, pipeline, settings
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.p = db.create_project("p", "upload")
        self.files = Path(self.tmp.name) / "files"
        self.files.mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def cand(self, start=1, status="queued"):
        return db.add_candidate(self.p["id"], start, start + 20, 50, "x", [], "", rank=1, status=status)["id"]

    def render_job(self, cids, status="rendering", extra=None):
        j = db.create_job(self.p["id"], "render", {"candidate_ids": cids, "settings": {}} | (extra or {}))
        if status != "queued":
            db.transition(j["id"], "rendering")
        return j["id"]

    def export(self, jid, cid, size=100, write=True, record_size=None):
        path = self.files / f"{cid}.mp4"
        if write:
            path.write_bytes(b"x" * size)
        e = db.add_export(self.p["id"], cid, jid, str(path), path.name, "9:16", 10.0, record_size if record_size is not None else size, {}, {}, None)
        return e["id"]


class Recovery(Base):
    def test_finished_clips_are_kept_and_only_the_rest_is_requeued(self):
        a, b, c = self.cand(1), self.cand(30), self.cand(60)
        jid = self.render_job([a, b, c])
        ea = self.export(jid, a)                                # intact
        self.export(jid, b, write=False, record_size=100)        # row exists but the file is gone
        out = db.recover_interrupted()
        self.assertEqual(len(out["resumed"]), 1)
        new = out["resumed"][0]
        self.assertEqual(new["status"], "queued")
        self.assertEqual(new["payload"]["candidate_ids"], [b, c])
        self.assertEqual((new["payload"]["resume_of"], new["payload"]["resume_count"]), (jid, 1))
        old = db.get_job(jid)
        self.assertEqual(old["status"], "failed")
        self.assertEqual(old["result"], {"resumed_as": new["id"]})
        self.assertIn("continued automatically", old["error"])
        self.assertEqual(db.get_candidate(a)["status"], "rendered")
        self.assertEqual({db.get_candidate(b)["status"], db.get_candidate(c)["status"]}, {"queued"})
        self.assertEqual(db.get_project(self.p["id"])["status"], "queued")
        self.assertIsNotNone(db.get_export(ea))                  # the finished export is untouched

    def test_a_truncated_file_does_not_count_as_a_finished_clip(self):
        a = self.cand()
        jid = self.render_job([a])
        self.export(jid, a, size=40, record_size=100)            # size differs from what was validated
        out = db.recover_interrupted()
        self.assertEqual(out["resumed"][0]["payload"]["candidate_ids"], [a])

    def test_when_every_clip_was_already_exported_the_job_is_completed_not_rerun(self):
        a, b = self.cand(1), self.cand(30)
        jid = self.render_job([a, b])
        self.export(jid, a); self.export(jid, b)
        out = db.recover_interrupted()
        self.assertEqual((out["resumed"], out["completed"]), ([], [jid]))
        j = db.get_job(jid)
        self.assertEqual(j["status"], "completed")
        self.assertEqual(len(j["result"]["exported"]), 2)
        self.assertEqual(db.get_project(self.p["id"])["status"], "awaiting_approval")
        self.assertEqual(db.get_candidate(a)["status"], "rendered")

    def test_a_crash_loop_is_capped(self):
        a = self.cand()
        jid = self.render_job([a])
        for expected_count in (1, 2):
            out = db.recover_interrupted(max_resumes=2)
            self.assertEqual(out["resumed"][0]["payload"]["resume_count"], expected_count)
        out = db.recover_interrupted(max_resumes=2)          # third restart in a row
        self.assertEqual(out["resumed"], [])
        failed = db.get_job(out["failed"][0])
        self.assertEqual(failed["status"], "failed")
        self.assertIn("not resumed again", failed["error"])
        self.assertFalse([j for j in db.list_jobs(50) if j["status"] in db.ACTIVE])
        self.assertEqual(db.get_candidate(a)["status"], "approved")
        del jid

    def test_download_job_is_resumed_with_its_payload(self):
        q = db.create_project("l", "link", "https://example.com/v")
        j = db.create_job(q["id"], "download", {})
        db.transition(j["id"], "downloading")
        out = db.recover_interrupted()
        self.assertEqual(len(out["resumed"]), 1)
        self.assertEqual((out["resumed"][0]["kind"], out["resumed"][0]["project_id"]), ("download", q["id"]))
        self.assertEqual(db.get_job(j["id"])["status"], "failed")

    def test_analysis_jobs_are_failed_not_resumed(self):
        j = db.create_job(self.p["id"], "analyze", {})
        db.transition(j["id"], "validating"); db.transition(j["id"], "transcribing")
        out = db.recover_interrupted()
        self.assertEqual((out["resumed"], out["failed"]), ([], [j["id"]]))
        self.assertIn("restarted", db.get_job(j["id"])["error"])
        self.assertEqual(db.get_project(self.p["id"])["status"], "failed")

    def test_resume_can_be_switched_off_and_then_everything_fails_like_before(self):
        a = self.cand()
        jid = self.render_job([a])
        out = db.recover_interrupted(resume=False)
        self.assertEqual((out["resumed"], out["failed"]), ([], [jid]))
        self.assertEqual(db.get_job(jid)["error"], db.INTERRUPTED_MSG)

    def test_a_job_owned_by_a_scheduler_task_is_left_to_the_scheduler_retry_path(self):
        a = self.cand(status="approved")
        jid = self.render_job([a])
        with db.connect() as c:
            c.execute("INSERT INTO scheduler_tasks(id,project_id,candidate_id,status,job_id,created_at,updated_at) VALUES('t1',?,?,'running',?,'2026-01-01','2026-01-01')",
                      (self.p["id"], a, jid))
        out = db.recover_interrupted()
        self.assertEqual((out["resumed"], out["failed"]), ([], [jid]))

    def test_settled_jobs_and_awaiting_approval_are_never_touched(self):
        j1 = db.create_job(self.p["id"], "analyze", {}); db.transition(j1["id"], "failed", error="old")
        j2 = db.create_job(self.p["id"], "render", {"candidate_ids": []}); db.transition(j2["id"], "rendering"); db.transition(j2["id"], "completed")
        out = db.recover_interrupted()
        self.assertEqual(out, {"failed": [], "resumed": [], "completed": [], "interrupted_ids": []})
        self.assertEqual(db.get_job(j1["id"])["error"], "old")

    def test_no_upload_or_publish_job_kind_can_be_resumed(self):
        self.assertEqual(set(db.RESUMABLE_KINDS), {"render", "download"})

    def test_corrupt_payload_does_not_crash_recovery(self):
        j = db.create_job(self.p["id"], "render", {})
        with db.connect() as c:
            c.execute("UPDATE jobs SET payload='{not json', status='rendering' WHERE id=?", (j["id"],))
        out = db.recover_interrupted()
        self.assertEqual(len(out["completed"]) + len(out["failed"]) + len(out["resumed"]), 1)

    def test_old_fail_interrupted_still_behaves_as_before(self):
        a = self.cand()
        self.render_job([a])
        self.assertEqual(db.fail_interrupted(), 1)


class Settings(unittest.TestCase):
    def test_defaults(self):
        self.assertTrue(settings.RESUME_INTERRUPTED_JOBS)
        self.assertEqual(settings.MAX_JOB_RESUMES, 2)


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class RealRender(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.media = tempfile.TemporaryDirectory(prefix="vanta-resume-")

    def tearDown(self):
        time.sleep(0.2)
        self.media.cleanup(); self.tmp.cleanup()

    def test_pipeline_startup_resumes_a_render_and_produces_a_valid_export(self):
        video = make_video(Path(self.media.name) / "v.mp4", duration=20, size="160x90")
        info = media.probe(video)
        p = db.create_project("p", "upload", source_path=str(video), probe=info)
        cid = db.add_candidate(p["id"], 2, 14, 50, "x", [], "", rank=1, status="rendering")["id"]
        j = db.create_job(p["id"], "render", {"candidate_ids": [cid], "settings": {"captions": False}})
        db.transition(j["id"], "rendering")                  # the process "died" here
        outcome = pipeline.startup()
        self.assertEqual(len(outcome["resumed"]), 1)
        new_id = outcome["resumed"][0]["id"]
        for _ in range(240):
            st = db.get_job(new_id)["status"]
            if st in {"completed", "failed"}:
                break
            time.sleep(0.5)
        job = db.get_job(new_id)
        self.assertEqual(job["status"], "completed", job)
        self.assertEqual(db.get_candidate(cid)["status"], "rendered")
        exports = db.list_exports(p["id"]) if hasattr(db, "list_exports") else []
        self.assertTrue(exports)
        self.assertTrue(Path(exports[0]["path"]).is_file())
        self.assertEqual(db.get_job(j["id"])["status"], "failed")        # the dead job stays visible and honest


class QueueVisibility(unittest.TestCase):
    """The Queue UI can only link the old and new job if GET /jobs really returns both sides of the pair."""

    def setUp(self):
        self.tmp = isolate()
        self.p = db.create_project("p", "upload")

    def tearDown(self):
        self.tmp.cleanup()

    def test_jobs_endpoint_exposes_the_resume_pair(self):
        from fastapi.testclient import TestClient
        from app.main import app
        cid = db.add_candidate(self.p["id"], 1, 21, 50, "x", [], "", rank=1, status="queued")["id"]
        jid = db.create_job(self.p["id"], "render", {"candidate_ids": [cid], "settings": {}})["id"]
        db.transition(jid, "rendering")                       # the backend "dies" here
        new_id = db.recover_interrupted()["resumed"][0]["id"]
        jobs = {j["id"]: j for j in TestClient(app).get("/api/vanta/jobs").json()}
        self.assertEqual(jobs[jid]["result"]["resumed_as"], new_id)     # old job -> link to the continuation
        self.assertIn("continued automatically", jobs[jid]["error"])
        self.assertEqual(jobs[new_id]["payload"]["resume_of"], jid)      # new job -> link back
        self.assertEqual(jobs[new_id]["payload"]["resume_count"], 1)


if __name__ == "__main__":
    unittest.main()
