"""Structural guard for the Phase 2c UI splits (``CreateView.tsx`` and ``legacy/page.tsx``).

The project has no JavaScript unit-test runner, so these are static checks with real bite: every
section must still exist as its own module *and* be mounted by the page, every binding a panel takes
from the shared state must still be provided by the hook, and the entry files must not grow back into
single-file dumps. Behaviour (the rendered result) is covered by the browser click-through documented
in docs/FINAL_TEST_REPORT.md.
"""
from __future__ import annotations

import re
import unittest
from pathlib import Path

APP = Path(__file__).resolve().parents[2] / "frontend" / "app"
VANTA = APP / "vanta"
LEGACY = APP / "legacy"


class CreateViewSplit(unittest.TestCase):
    def test_entry_file_stays_small_and_keeps_the_old_export(self):
        text = (VANTA / "CreateView.tsx").read_text(encoding="utf-8")
        self.assertLess(len(text), 20_000, "CreateView.tsx grew back into a single-file view")
        self.assertIn("export function CreateView", text)
        self.assertIn("export {JobStrip}", text)              # old `import {JobStrip} from "./CreateView"` keeps working
        self.assertNotIn("export function CandidateCard", text)

    def test_each_section_is_its_own_module_and_is_mounted(self):
        page = (VANTA / "CreateView.tsx").read_text(encoding="utf-8")
        for module, component in (("CandidateCard", "CandidateCard"), ("SourcePanel", "SourcePanel"),
                                  ("ClipSettingsPanel", "ClipSettingsPanel"), ("JobStrip", "JobStrip")):
            body = (VANTA / f"{module}.tsx").read_text(encoding="utf-8")
            self.assertIn(f"export function {component}", body, module)
            self.assertIn(f'from "./{module}"', page, f"{module} is not imported by the view")
            self.assertIn(f"<{component}", page, f"{module} is not rendered by the view")

    def test_shared_clip_settings_live_outside_the_view(self):
        settings = (VANTA / "clipSettings.ts").read_text(encoding="utf-8")
        self.assertIn("export const DEFAULT_RS", settings)
        self.assertIn("export function renderSettingsPayload", settings)
        self.assertIn("export function loadRS", settings)
        self.assertIn("export function useClipSettings", (VANTA / "useClipSettings.ts").read_text(encoding="utf-8"))
        page = (VANTA / "CreateView.tsx").read_text(encoding="utf-8")
        self.assertIn('from "./clipSettings"', page)
        self.assertIn('from "./useClipSettings"', page)


class LegacySplit(unittest.TestCase):
    PANELS = ("Sidebar", "StudioHeader", "CreatePanel", "PreviewPanel", "MetadataPanel", "YouTubePanel",
              "StoryboardPanel", "HistoryPanel", "ProviderPanel")

    def test_page_is_only_a_composition(self):
        text = (LEGACY / "page.tsx").read_text(encoding="utf-8")
        self.assertLess(len(text), 3_000, "legacy page.tsx grew back into a single-file view")
        self.assertIn('from "./useStudioState"', text)
        self.assertIn("const s=useStudioState();", text)
        for panel in self.PANELS:
            self.assertIn(f'from "./{panel}"', text, f"{panel} is not imported")
            self.assertIn(f"<{panel} s={{s}}/>", text, f"{panel} is not rendered")

    def test_state_and_handlers_live_in_the_hook(self):
        hook = (LEGACY / "useStudioState.ts").read_text(encoding="utf-8")
        self.assertIn("export function useStudioState()", hook)
        for name in ("const refresh=useCallback", "const getDiagnostics=useCallback", "async function create()",
                     "async function saveMetadata()", "function selectJob(", "async function ytUpload("):
            self.assertIn(name, hook, f"{name} left the shared hook")
        self.assertNotIn("return <div className", hook)

    def test_every_binding_a_panel_uses_is_provided_by_the_hook(self):
        hook = (LEGACY / "useStudioState.ts").read_text(encoding="utf-8")
        returned = re.search(r"\n return \{([^}]*)\};", hook)
        self.assertIsNotNone(returned, "useStudioState no longer returns an explicit object")
        provided = {n.strip() for n in returned.group(1).split(",") if n.strip()}
        for panel in self.PANELS:
            text = (LEGACY / f"{panel}.tsx").read_text(encoding="utf-8")
            used = re.search(r"const \{([^}]*)\} = s;", text)
            self.assertIsNotNone(used, f"{panel} does not read the shared state")
            wanted = {n.strip() for n in used.group(1).split(",") if n.strip()}
            self.assertEqual(sorted(wanted - provided), [], f"{panel} uses bindings the hook does not provide")

    def test_api_helpers_are_shared(self):
        api = (LEGACY / "api.ts").read_text(encoding="utf-8")
        self.assertIn("export const API", api)
        self.assertIn("export async function readResponse", api)
        self.assertIn("export type Job", (LEGACY / "types.ts").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
