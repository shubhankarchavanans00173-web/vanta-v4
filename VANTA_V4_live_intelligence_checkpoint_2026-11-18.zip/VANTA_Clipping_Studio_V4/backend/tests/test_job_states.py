"""TODO 5: job-state audit. Illegal transitions, stale late updates, double submission, cancelling queued jobs, restart recovery,
and that a failed render surfaces its error + diagnostics location in the job result (no fake 100%)."""
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import db, pipeline, settings
from app.clipstudio.render import RenderError
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video, script_srt


class Machine(unittest.TestCase):
    def test_graph_properties(self):
        self.assertEqual(set(db.ALLOWED), set(db.JOB_STATES))
        for s in ("completed", "failed", "cancelled"):
            self.assertEqual(db.ALLOWED[s], set())
        # every non-terminal state can reach a terminal one (nothing can get stuck by construction)
        terminal = {"completed", "failed", "cancelled"}
        for start in db.JOB_STATES:
            seen, todo = set(), [start]
            while todo:
                x = todo.pop()
                if x in seen:
                    continue
                seen.add(x); todo += list(db.ALLOWED[x])
            self.assertTrue(seen & terminal, start)
        # every active state may be failed or cancelled
        for s in db.ACTIVE:
            self.assertLessEqual({"failed", "cancelled"}, db.ALLOWED[s], s)

    def test_all_ten_states_are_named_as_specified(self):
        self.assertEqual(set(db.JOB_STATES), {"queued", "validating", "downloading", "transcribing", "analyzing", "awaiting_approval", "rendering", "completed", "failed", "cancelled"})


class Db(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.p = db.create_project("p", "upload")

    def tearDown(self):
        self.tmp.cleanup()

    def job(self, status_path=("validating",)):
        j = db.create_job(self.p["id"], "analyze", {})
        for s in status_path:
            db.transition(j["id"], s)
        return j["id"]

    def test_illegal_transitions_raise_and_leave_the_job_unchanged(self):
        jid = self.job()
        for bad in ("rendering", "completed", "awaiting_approval", "queued", "nonsense"):
            with self.assertRaises(db.StateError):
                db.transition(jid, bad)
        self.assertEqual(db.get_job(jid)["status"], "validating")
        db.transition(jid, "cancelled")
        for any_state in db.JOB_STATES:
            with self.assertRaises(db.StateError):
                db.transition(jid, any_state)

    def test_late_progress_cannot_overwrite_a_settled_job(self):
        for end in ("cancelled", "failed"):
            jid = self.job()
            db.set_progress(jid, 0.4, "working")
            self.assertEqual(db.get_job(jid)["progress"], 0.4)
            db.transition(jid, end, error="x" if end == "failed" else None)
            before = db.get_job(jid)
            db.set_progress(jid, 0.99, "Rendering clip 3 of 3")     # a worker thread still unwinding
            after = db.get_job(jid)
            self.assertEqual((after["progress"], after["message"], after["status"]), (before["progress"], before["message"], end))
        jid = self.job(("validating", "analyzing", "awaiting_approval"))
        db.set_progress(jid, 0.5, "stale")
        self.assertNotEqual(db.get_job(jid)["message"], "stale")

    def test_failure_never_reports_progress(self):
        jid = self.job()
        db.set_progress(jid, 1.0, "almost")
        db.transition(jid, "failed", error="boom")
        self.assertIsNone(db.get_job(jid)["progress"])

    def test_restart_recovery_leaves_no_job_in_an_active_state(self):
        ids = [self.job(path) for path in (("validating",), ("validating", "transcribing"), ("validating", "analyzing"), ())]
        db.transition(self.job(), "failed", error="old")
        c = db.add_candidate(self.p["id"], 1, 20, 50, "x", [], "", rank=1, status="rendering")
        self.assertEqual(db.fail_interrupted(), 4)
        for i in ids:
            j = db.get_job(i)
            self.assertEqual(j["status"], "failed"); self.assertIn("restarted", j["error"]); self.assertIsNone(j["progress"])
        self.assertEqual(db.get_candidate(c["id"])["status"], "approved")
        self.assertEqual(db.get_project(self.p["id"])["status"], "failed")
        self.assertFalse([j for j in db.list_jobs(50) if j["status"] in db.ACTIVE])


class Submission(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.gate = threading.Event()

        def blocker(job_id):
            j = db.get_job(job_id)
            if j["status"] != "queued":
                return
            db.transition(job_id, "validating")
            self.gate.wait(20)
            db.transition(job_id, "failed", error="test finished")
        self.patch = mock.patch.object(pipeline, "_run_analyze", blocker); self.patch.start()

    def tearDown(self):
        self.gate.set(); time.sleep(0.2); self.patch.stop(); self.tmp.cleanup()

    def test_concurrent_double_click_creates_exactly_one_job(self):
        p = db.create_project("p", "upload")
        results, barrier = [], threading.Barrier(8)
        real_busy = pipeline.project_busy

        def slow_busy(pid):            # widen the check-then-create window so a missing lock cannot go unnoticed
            r = real_busy(pid); time.sleep(0.03); return r
        patcher = mock.patch.object(pipeline, "project_busy", slow_busy); patcher.start(); self.addCleanup(patcher.stop)

        def click():
            barrier.wait()
            try:
                results.append(pipeline.submit_analyze(p["id"], {}))
            except pipeline.Busy:
                results.append("busy")
        ts = [threading.Thread(target=click) for _ in range(8)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(sum(1 for r in results if r != "busy"), 1)
        self.assertEqual(len(db.list_jobs(50, p["id"])), 1)

    def test_cancelling_a_queued_job_sticks_even_when_the_worker_reaches_it(self):
        a, b = db.create_project("a", "upload"), db.create_project("b", "upload")
        ja = pipeline.submit_analyze(a["id"], {})          # occupies the single worker
        for _ in range(100):
            if db.get_job(ja["id"])["status"] == "validating":
                break
            time.sleep(0.05)
        jb = pipeline.submit_analyze(b["id"], {})          # waits behind it
        self.assertEqual(db.get_job(jb["id"])["status"], "queued")
        self.assertEqual(pipeline.cancel_job(jb["id"])["status"], "cancelled")
        self.assertEqual(db.get_project(b["id"])["status"], "new")
        self.gate.set(); time.sleep(0.8)
        self.assertEqual(db.get_job(jb["id"])["status"], "cancelled")      # the worker skipped it

    def test_cancel_of_a_queued_reanalysis_returns_the_project_to_review_not_new(self):
        a, b = db.create_project("a", "upload"), db.create_project("b", "upload")
        db.add_candidate(b["id"], 1, 20, 50, "x", [], "", rank=1)
        ja = pipeline.submit_analyze(a["id"], {})
        for _ in range(100):
            if db.get_job(ja["id"])["status"] == "validating":
                break
            time.sleep(0.05)
        jb = pipeline.submit_analyze(b["id"], {})
        pipeline.cancel_job(jb["id"])
        self.assertEqual(db.get_project(b["id"])["status"], "awaiting_approval")

    def test_cancel_of_a_running_reanalysis_settles_back_to_review(self):
        p = db.create_project("p", "upload")
        db.add_candidate(p["id"], 1, 20, 50, "x", [], "", rank=1)
        j = db.create_job(p["id"], "analyze", {}); db.transition(j["id"], "validating")
        pipeline._settle_cancelled(j["id"], p["id"])
        self.assertEqual(db.get_job(j["id"])["status"], "cancelled"); self.assertEqual(db.get_project(p["id"])["status"], "awaiting_approval")
        q = db.create_project("q", "upload"); k = db.create_job(q["id"], "analyze", {}); db.transition(k["id"], "validating")
        pipeline._settle_cancelled(k["id"], q["id"]); self.assertEqual(db.get_project(q["id"])["status"], "new")

    def test_cancelling_a_settled_job_is_refused(self):
        p = db.create_project("p", "upload")
        j = db.create_job(p["id"], "analyze", {}); db.transition(j["id"], "cancelled")
        with self.assertRaises(db.StateError):
            pipeline.cancel_job(j["id"])


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class RenderFailure(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.media = tempfile.TemporaryDirectory(); cls.video = make_video(Path(cls.media.name) / "t.mp4", duration=40)

    @classmethod
    def tearDownClass(cls):
        cls.media.cleanup()

    def setUp(self):
        self.tmp = isolate()
        from app.main import app
        self.client = TestClient(app).__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None); self.tmp.cleanup()

    def wait(self, jid, until=("completed", "failed", "cancelled", "awaiting_approval"), timeout=90):
        end = time.time() + timeout
        while time.time() < end:
            j = self.client.get(f"/api/vanta/jobs/{jid}").json()
            if j["status"] in until:
                return j
            time.sleep(0.1)
        self.fail(j)

    def test_failed_render_reports_error_and_diagnostics_and_is_retryable(self):
        r = self.client.post("/api/vanta/projects/upload", files={"file": ("t.mp4", self.video.read_bytes(), "video/mp4"), "transcript": ("t.srt", script_srt().encode(), "text/plain")}, data={"name": "t"})
        pid = r.json()["id"]
        jid = self.client.post(f"/api/vanta/projects/{pid}/analyze", json={"transcribe": False, "target_duration": 15, "count": 2}).json()["id"]
        self.wait(jid)
        cands = self.client.get(f"/api/vanta/projects/{pid}").json()["candidates"]
        cid = cands[0]["id"]
        self.client.patch(f"/api/vanta/candidates/{cid}", json={"status": "approved"})

        def boom(source, out, tmp, *a, **k):
            Path(tmp).mkdir(parents=True, exist_ok=True); (Path(tmp) / "ffmpeg.stderr.txt").write_text("fake ffmpeg failure details")
            raise RenderError("FFmpeg exploded")
        with mock.patch.object(pipeline, "render_clip", boom):
            rid = self.client.post(f"/api/vanta/projects/{pid}/render", json={"candidate_ids": [cid]}).json()["id"]
            j = self.wait(rid)
        self.assertEqual(j["status"], "failed"); self.assertIsNone(j["progress"]); self.assertIn("FFmpeg exploded", j["error"])
        failed = j["result"]["failed"][0]
        self.assertEqual(failed["candidate_id"], cid); self.assertTrue(failed["diagnostics"])
        self.assertTrue((settings.BASE / failed["diagnostics"] / "ffmpeg.stderr.txt").is_file())
        proj = self.client.get(f"/api/vanta/projects/{pid}").json()
        self.assertEqual(proj["status"], "awaiting_approval")
        self.assertEqual(next(c for c in proj["candidates"] if c["id"] == cid)["status"], "failed")
        # double click on Render while one is queued/running -> 409, never two jobs
        gate = threading.Event()

        def slow(*a, **k):
            gate.wait(20); raise RenderError("late")
        with mock.patch.object(pipeline, "render_clip", slow):
            first = self.client.post(f"/api/vanta/projects/{pid}/render", json={})
            self.assertEqual(first.status_code, 200, first.text)
            self.assertEqual(self.client.post(f"/api/vanta/projects/{pid}/render", json={}).status_code, 409)
            self.assertEqual(self.client.delete(f"/api/vanta/projects/{pid}").status_code, 409)       # cannot delete under a running job
            gate.set(); self.wait(first.json()["id"])


if __name__ == "__main__":
    unittest.main()
