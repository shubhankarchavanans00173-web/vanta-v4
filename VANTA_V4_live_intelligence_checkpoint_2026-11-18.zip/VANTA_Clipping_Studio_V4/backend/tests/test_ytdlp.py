"""Tests for the yt-dlp adapter: URL parsing, error classification, diagnostics, command building, the real subprocess runner
(against stub downloaders), staged-download validation/cleanup, and the updater. No network, no paid APIs."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import textwrap
import time
import unittest
from pathlib import Path
from unittest import mock

from app import envload
from app.clipstudio import links, settings, ytdlp
from app.clipstudio.linkerrors import LinkError
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video

VID = "dQw4w9WgXcQ"
PY310_WARNING = "Deprecated Feature: Support for Python version 3.10 has been deprecated. Please update to Python 3.11 or above"


# ------------------------------------------------------------------------------------------------ URL parsing
class YouTubeUrlTests(unittest.TestCase):
    def test_all_supported_forms_collapse_to_one_canonical_url(self):
        canonical = f"https://www.youtube.com/watch?v={VID}"
        forms = [
            f"https://www.youtube.com/watch?v={VID}", f"https://youtube.com/watch?v={VID}&feature=share", f"https://m.youtube.com/watch?v={VID}&t=42s",
            f"https://music.youtube.com/watch?v={VID}", f"https://youtu.be/{VID}", f"https://youtu.be/{VID}?si=abc&t=5", f"https://www.youtube.com/shorts/{VID}",
            f"https://www.youtube.com/shorts/{VID}?feature=share", f"https://www.youtube.com/embed/{VID}", f"https://www.youtube-nocookie.com/embed/{VID}?rel=0",
            f"https://www.youtube.com/live/{VID}", f"https://www.youtube.com/watch?v={VID}&list=PLabc&index=3",
        ]
        for url in forms:
            with self.subTest(url=url):
                ref = ytdlp.parse_youtube_url(url)
                self.assertEqual((ref.video_id, ref.canonical), (VID, canonical))
                self.assertEqual(links.canonical_ref(url), (canonical, VID))

    def test_kinds(self):
        self.assertEqual(ytdlp.parse_youtube_url(f"https://youtu.be/{VID}").kind, "short_link")
        self.assertEqual(ytdlp.parse_youtube_url(f"https://www.youtube.com/shorts/{VID}").kind, "shorts")
        self.assertEqual(ytdlp.parse_youtube_url(f"https://www.youtube.com/embed/{VID}").kind, "embed")

    def test_invalid_and_unsupported_youtube_urls(self):
        cases = {
            "https://www.youtube.com/watch?v=abc": "invalid_url", "https://www.youtube.com/watch": "invalid_url", "https://www.youtube.com/": "invalid_url",
            "https://www.youtube.com/watch?v=" + "x" * 40: "invalid_url", "https://www.youtube.com/watch?v=--no-check-cert": "invalid_url",
            "https://www.youtube.com/playlist?list=PLabc": "unsupported_platform", "https://www.youtube.com/@somechannel": "unsupported_platform",
            "https://www.youtube.com/channel/UCabc": "unsupported_platform", "https://www.youtube.com/results?search_query=x": "unsupported_platform",
            "https://www.youtube.com/embed/videoseries?list=PLabc": "unsupported_platform", "https://example.com/watch?v=" + VID: "unsupported_platform",
        }
        for url, code in cases.items():
            with self.subTest(url=url):
                with self.assertRaises(LinkError) as ctx:
                    ytdlp.parse_youtube_url(url)
                self.assertEqual(ctx.exception.code, code)

    def test_non_http_and_credentialed_urls_are_rejected_before_any_download(self):
        for bad in ("file:///etc/passwd", "javascript:alert(1)", "ftp://youtube.com/watch?v=" + VID, f"https://user:pw@www.youtube.com/watch?v={VID}"):
            with self.subTest(bad=bad), self.assertRaises(LinkError):
                links.normalise_url(bad)


# ------------------------------------------------------------------------------------------------ classification
class ClassificationTests(unittest.TestCase):
    def code(self, stderr: str, stdout: str = "") -> str:
        return ytdlp.classify_error(stderr, stdout, 1).code

    def test_REGRESSION_python310_warning_never_turns_a_real_error_into_outdated(self):
        """The original bug: 'Please update to Python 3.11' in a warning line matched the 'please update' pattern."""
        self.assertEqual(self.code(f"{PY310_WARNING}\nERROR: [youtube] {VID}: Video unavailable. This video is unavailable"), "unavailable")
        self.assertEqual(self.code(f"{PY310_WARNING}\nERROR: [youtube] {VID}: This live stream recording is not available."), "live_unavailable")
        self.assertEqual(self.code(f"{PY310_WARNING}\nERROR: [youtube] {VID}: Private video. Sign in if you've been granted access"), "login_required")

    def test_warning_only_output_is_unknown_not_outdated(self):
        err = ytdlp.classify_error(PY310_WARNING + "\nWARNING: something harmless", "", 1)
        self.assertEqual(err.code, "unknown_error")
        self.assertNotIn("outdated", str(err).lower())
        self.assertTrue(err.details)

    def test_categories(self):
        cases = [
            ("ERROR: [youtube] x: This video is unavailable", "unavailable"), ("ERROR: [youtube] x: Video unavailable. This video has been removed by the uploader", "unavailable"),
            ("ERROR: [youtube] x: Private video. Sign in if you've been granted access to this video", "login_required"),
            ("ERROR: [youtube] x: Sign in to confirm your age. This video may be inappropriate for some users.", "login_required"),
            ("ERROR: [youtube] x: Join this channel to get access to members-only content like this video", "login_required"),
            ("ERROR: [youtube] x: Sign in to confirm you\u2019re not a bot. Use --cookies-from-browser or --cookies for the authentication.", "bot_check"),
            ("ERROR: [youtube] x: This live stream recording is not available.", "live_unavailable"), ("ERROR: [youtube] x: This live event will begin in 3 hours.", "live_unavailable"),
            ("ERROR: [youtube] x: The uploader has not made this video available in your country", "geo_blocked"),
            ("ERROR: [youtube] x: HTTP Error 429: Too Many Requests", "rate_limited"), ("ERROR: unable to download video data: HTTP Error 503: Service Unavailable", "server_error"),
            ("ERROR: unable to download video data: HTTP Error 403: Forbidden", "access_denied"),
            ("ERROR: [youtube] x: Unable to download API page: HTTPSConnection(host='www.youtube.com') Failed to resolve 'www.youtube.com' (Name or service not known)", "network_error"),
            ("ERROR: [youtube] x: Unable to download webpage: <urlopen error timed out>", "timeout"),
            ("ERROR: Postprocessing: ffmpeg not found. Please install or provide the path using --ffmpeg-location", "ffmpeg_missing"),
            ("ERROR: You have requested merging of multiple formats but ffmpeg is not installed", "ffmpeg_missing"),
            ("ERROR: unable to open for writing: [Errno 28] No space left on device", "disk_full"), ("ERROR: unable to open for writing: [Errno 13] Permission denied: 'x'", "permission_denied"),
            ("ERROR: [youtube] x: Requested format is not available. Use --list-formats for a list of available formats", "format_unavailable"),
            ("ERROR: [youtube] x: Unable to extract initial player response; please report this issue on https://github.com/yt-dlp/yt-dlp/issues", "extraction_failed"),
            ("ERROR: [generic] Unsupported URL: https://example.com/x", "unsupported_platform"), ("ERROR: This video is DRM protected", "drm"),
            ("ERROR: something nobody has seen before", "unknown_error"),
        ]
        for text, code in cases:
            with self.subTest(text=text[:70]):
                self.assertEqual(self.code(text), code)

    def test_word_fragments_do_not_trigger_categories(self):
        """'generated' contains 'rate'; 'cookies' appears in many hints - neither may decide the category."""
        self.assertEqual(self.code("ERROR: the report was generated automatically"), "unknown_error")
        self.assertEqual(self.code("ERROR: Use --cookies for the authentication of something odd"), "unknown_error")

    def test_js_challenge_context_upgrades_format_error_to_extraction_failure(self):
        err = ytdlp.classify_error("WARNING: [youtube] x: n challenge solving failed: Some formats may be missing. No supported JavaScript runtime could be found\n"
                                   "ERROR: [youtube] x: Requested format is not available.", "", 1)
        self.assertEqual(err.code, "extraction_failed"); self.assertIn("JavaScript", str(err)); self.assertTrue(err.retryable)

    def test_error_objects_are_actionable_and_scrubbed(self):
        err = ytdlp.classify_error("ERROR: [youtube] x: HTTP Error 403: Forbidden https://rr1.googlevideo.com/videoplayback?sig=SECRETSIG&token=abc123&id=1", "", 1)
        blob = json.dumps(err.to_dict())
        self.assertNotIn("SECRETSIG", blob); self.assertNotIn("abc123", blob)
        self.assertTrue(err.hint); self.assertTrue(err.retryable); self.assertEqual(set(err.to_dict()), {"code", "message", "retryable", "hint", "details"})

    def test_only_transient_errors_are_retryable_automatically(self):
        self.assertEqual(ytdlp.AUTO_RETRY_CODES, {"network_error", "timeout", "server_error"})
        for text in ("ERROR: Video unavailable", "ERROR: Private video", "ERROR: HTTP Error 429: Too Many Requests"):
            self.assertNotIn(self.code(text), ytdlp.AUTO_RETRY_CODES)


# ------------------------------------------------------------------------------------------------ command building
class CommandTests(unittest.TestCase):
    def build(self, **kw):
        return ytdlp.build_command(["py", "-m", "yt_dlp"], f"https://www.youtube.com/watch?v={VID}", Path("/data/sources/p1/.dl-x"), max_filesize=1000, **kw)

    def test_core_flags_and_url_is_last_after_double_dash(self):
        cmd = self.build()
        self.assertEqual(cmd[-2:], ["--", f"https://www.youtube.com/watch?v={VID}"])
        for flag in ("--ignore-config", "--no-playlist", "--merge-output-format", "--max-filesize"):
            self.assertIn(flag, cmd)
        self.assertEqual(cmd[cmd.index("--max-filesize") + 1], "1000")
        self.assertTrue(cmd[cmd.index("-o") + 1].replace("\\", "/").endswith("/.dl-x/source.%(ext)s"))

    def test_never_uses_cookies_or_access_bypass_flags(self):
        joined = " ".join(self.build(js_runtime_arg="node:/usr/bin/node", ffmpeg_dir="/usr/bin", remote_components="ejs:github", auto_subs=True))
        for banned in ("--cookies", "--cookies-from-browser", "--username", "--password", "--geo-bypass", "--proxy", "--no-check-certificate", "--video-password"):
            self.assertNotIn(banned, joined)

    def test_optional_pieces_only_when_given(self):
        plain = self.build()
        for flag in ("--js-runtimes", "--ffmpeg-location", "--remote-components", "--write-auto-subs"):
            self.assertNotIn(flag, plain)
        full = self.build(js_runtime_arg="node:/usr/bin/node", ffmpeg_dir="/usr/bin", remote_components="ejs:github", auto_subs=True)
        self.assertEqual(full[full.index("--js-runtimes") + 1], "node:/usr/bin/node"); self.assertEqual(full[full.index("--ffmpeg-location") + 1], "/usr/bin")
        self.assertIn("--write-auto-subs", full)

    def test_uses_the_backend_interpreter_never_a_path_lookup(self):
        if ytdlp.installed():
            self.assertEqual(ytdlp.base_command(), [sys.executable, "-m", "yt_dlp"])
        with mock.patch.object(ytdlp, "installed", return_value=False):
            self.assertIsNone(ytdlp.base_command())
        self.assertIn(sys.executable, ytdlp.install_command()); self.assertIn("yt-dlp[default]", ytdlp.install_command())

    def test_child_environment_hides_secrets(self):
        with mock.patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-secret", "REPLICATE_API_TOKEN": "tok", "SOME_PASSWORD": "pw", "HARMLESS": "ok"}):
            env = ytdlp._child_env()
        self.assertNotIn("ANTHROPIC_API_KEY", env); self.assertNotIn("REPLICATE_API_TOKEN", env); self.assertNotIn("SOME_PASSWORD", env)
        self.assertEqual(env["HARMLESS"], "ok"); self.assertEqual(env["PYTHONUTF8"], "1")


# ------------------------------------------------------------------------------------------------ diagnostics
class DiagnosticsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = isolate()

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def setUp(self):
        ytdlp.reset_caches()

    def test_report_contents_and_no_secret_leak(self):
        with mock.patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-ant-SUPERSECRET", "VANTA_ENABLE_YTDLP": "1"}):
            d = ytdlp.diagnostics()
        self.assertEqual(d["python"]["executable"], sys.executable)
        self.assertEqual(d["yt_dlp"]["version"], ytdlp.version()); self.assertIn("install_command", d["yt_dlp"])
        for key in ("ffmpeg", "js_runtime", "folders", "env_file", "problems", "warnings", "ready"):
            self.assertIn(key, d)
        self.assertNotIn("SUPERSECRET", json.dumps(d))

    def test_problems_name_the_missing_piece(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("VANTA_ENABLE_YTDLP", None)
            self.assertTrue(any("VANTA_ENABLE_YTDLP=1" in p for p in ytdlp.diagnostics()["problems"]))
        with mock.patch.object(ytdlp, "installed", return_value=False), mock.patch.object(ytdlp, "version", return_value=None):
            d = ytdlp.diagnostics()
            self.assertFalse(d["ready"]); self.assertTrue(any(sys.executable in p for p in d["problems"]))
        with mock.patch.object(ytdlp, "ffmpeg_info", return_value={"ffmpeg": None, "ffprobe": None, "version": None, "available": False, "dir": None}):
            self.assertTrue(any("FFmpeg" in p for p in ytdlp.diagnostics()["problems"]))

    def test_python310_is_a_warning_not_a_problem(self):
        with mock.patch.object(sys, "version_info", (3, 10, 11, "final", 0)):
            d = ytdlp.diagnostics()
        self.assertTrue(any("NOT the cause" in w for w in d["warnings"]))
        self.assertFalse(any("3.10" in p for p in d["problems"]))

    def test_version_age(self):
        self.assertIsNone(ytdlp.version_age_days(None)); self.assertIsNone(ytdlp.version_age_days("garbage"))
        self.assertGreater(ytdlp.version_age_days("2020.01.01"), 1000)
        self.assertIsNotNone(ytdlp.version_age_days("2026.03.17.232812"))

    def _fake_tool(self, d: Path, name: str, version: str) -> Path:
        exe = d / (name + (".cmd" if os.name == "nt" else ""))
        exe.write_text(f"@echo {version}\r\n" if os.name == "nt" else f"#!/bin/sh\necho {version}\n")
        exe.chmod(0o755)
        return exe

    @unittest.skipIf(os.name == "nt", "POSIX shell stubs")
    def test_js_runtime_detection(self):
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            self._fake_tool(d, "node", "v22.4.0")
            with mock.patch.dict(os.environ, {"PATH": str(d)}):
                os.environ.pop("VANTA_YTDLP_JS_RUNTIME", None); ytdlp.reset_caches()
                js = ytdlp.js_runtime_info()
            self.assertTrue(js["available"]); self.assertEqual(js["name"], "node"); self.assertEqual(js["arg"], f"node:{d / 'node'}")
            self._fake_tool(d, "node", "v18.19.0")                                  # too old for yt-dlp's solver
            with mock.patch.dict(os.environ, {"PATH": str(d)}):
                os.environ.pop("VANTA_YTDLP_JS_RUNTIME", None); ytdlp.reset_caches()
                js = ytdlp.js_runtime_info()
            self.assertFalse(js["available"]); self.assertIn("too old", js["note"]); self.assertEqual(js["found"][0]["supported"], False)
            with mock.patch.dict(os.environ, {"PATH": str(d), "VANTA_YTDLP_JS_RUNTIME": "none"}):
                ytdlp.reset_caches(); self.assertTrue(ytdlp.js_runtime_info()["disabled_by_setting"])
            with mock.patch.dict(os.environ, {"PATH": str(d), "VANTA_YTDLP_JS_RUNTIME": "evil; rm -rf /"}):
                ytdlp.reset_caches(); self.assertFalse(ytdlp.js_runtime_info()["available"])
        with mock.patch.dict(os.environ, {"PATH": "/nonexistent"}):
            os.environ.pop("VANTA_YTDLP_JS_RUNTIME", None); ytdlp.reset_caches()
            js = ytdlp.js_runtime_info()
        self.assertFalse(js["available"]); self.assertIn("Node.js", js["note"])


# ------------------------------------------------------------------------------------------------ runner against stub downloaders
def write_stub(dir_: Path, body: str) -> list[str]:
    path = dir_ / "stub_ytdlp.py"
    path.write_text("import os, sys, subprocess, time, json\nargs = sys.argv[1:]\nout = args[args.index('-o') + 1]\n"
                    "def media(ext='mp4', seconds=2):\n"
                    "    p = out.replace('%(ext)s', ext)\n"
                    "    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','lavfi','-i',f'testsrc=size=160x90:rate=10:duration={seconds}','-f','lavfi','-i',f'sine=duration={seconds}','-shortest','-c:v','libx264','-c:a','aac',p], check=True)\n"
                    "    return p\n" + textwrap.dedent(body), encoding="utf-8")
    return [sys.executable, str(path)]


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class RunnerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = isolate()
        ytdlp.reset_caches()

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix="stub-"))
        self.staging = self.dir / "staging"
        self.url = f"https://www.youtube.com/watch?v={VID}"

    def run_dl(self, body: str, **kw):
        base = write_stub(self.dir, body)
        kw.setdefault("sleep", lambda s: None)
        return ytdlp.download(self.url, self.staging, base=base, **kw)

    def test_success_streams_progress_and_returns_a_real_file(self):
        seen = []
        res = self.run_dl("""
            print('[info] abc: Downloading 2 format(s): 137+140')
            print('[download] Destination: ' + out.replace('%(ext)s','f137.mp4'))
            for p in (10.0, 55.5, 100.0): print(f'[download] {p:5.1f}% of 10.00MiB at 1.00MiB/s ETA 00:01', flush=True)
            print('[download] Destination: ' + out.replace('%(ext)s','f140.m4a'))
            print('[download] 100.0% of 1.00MiB')
            m = media(); print(m); print('VANTA_TITLE=Ünïcode títle 日本語')
        """, progress=lambda p, m: seen.append((p, m)))
        self.assertTrue(res.path.is_file() and res.path.stat().st_size > 0)
        self.assertEqual(res.title, "Ünïcode títle 日本語"); self.assertEqual(res.attempts, 1)
        fractions = [p for p, _ in seen if p is not None]
        self.assertTrue(fractions and fractions == sorted(fractions) and max(fractions) <= 1.0)
        self.assertTrue(any("video" in m for _, m in seen if m)); self.assertTrue(any("audio" in m for _, m in seen if m))

    def test_failure_with_python310_warning_is_reported_as_unavailable(self):
        with self.assertRaises(LinkError) as ctx:
            self.run_dl(f"""
                sys.stderr.write({PY310_WARNING!r} + '\\n')
                sys.stderr.write('ERROR: [youtube] {VID}: Video unavailable. This video is unavailable\\n'); sys.exit(1)
            """)
        self.assertEqual(ctx.exception.code, "unavailable"); self.assertFalse(ctx.exception.retryable)
        self.assertNotIn("outdated", str(ctx.exception).lower())

    def test_timeout_kills_the_process_and_reports_timeout(self):
        t0 = time.monotonic()
        with self.assertRaises(LinkError) as ctx:
            self.run_dl("time.sleep(60)", timeout=1, max_attempts=1)
        self.assertEqual(ctx.exception.code, "timeout"); self.assertLess(time.monotonic() - t0, 15)

    def test_cancellation_stops_the_download_promptly(self):
        t0 = time.monotonic()
        with self.assertRaises(LinkError) as ctx:
            self.run_dl("time.sleep(60)", cancelled=lambda: time.monotonic() - t0 > 0.8)
        self.assertEqual(ctx.exception.code, "cancelled"); self.assertLess(time.monotonic() - t0, 15)

    def test_transient_error_is_retried_then_succeeds(self):
        counter = self.dir / "count"
        res = self.run_dl(f"""
            from pathlib import Path
            c = Path({str(counter)!r}); n = int(c.read_text()) + 1 if c.exists() else 1; c.write_text(str(n))
            if n == 1:
                sys.stderr.write('ERROR: [youtube] x: Unable to download API page: Failed to resolve (Name or service not known)\\n'); sys.exit(1)
            print(media())
        """, max_attempts=3)
        self.assertEqual(res.attempts, 2); self.assertEqual(counter.read_text(), "2")

    def test_retries_are_bounded(self):
        counter = self.dir / "count"
        with self.assertRaises(LinkError) as ctx:
            self.run_dl(f"""
                from pathlib import Path
                c = Path({str(counter)!r}); c.write_text(str(int(c.read_text()) + 1 if c.exists() else 1))
                sys.stderr.write('ERROR: HTTP Error 503: Service Unavailable\\n'); sys.exit(1)
            """, max_attempts=3)
        self.assertEqual(ctx.exception.code, "server_error"); self.assertEqual(counter.read_text(), "3")

    def test_permanent_errors_are_not_retried(self):
        counter = self.dir / "count"
        with self.assertRaises(LinkError):
            self.run_dl(f"""
                from pathlib import Path
                c = Path({str(counter)!r}); c.write_text(str(int(c.read_text()) + 1 if c.exists() else 1))
                sys.stderr.write('ERROR: [youtube] x: Private video. Sign in if you have been granted access\\n'); sys.exit(1)
            """, max_attempts=4)
        self.assertEqual(counter.read_text(), "1")

    def test_exit_zero_without_a_file_is_a_failure_not_a_success(self):
        with self.assertRaises(LinkError) as ctx:
            self.run_dl("print('nothing written')")
        self.assertEqual(ctx.exception.code, "download_failed")

    def test_exit_zero_but_skipped_for_size_is_too_large(self):
        with self.assertRaises(LinkError) as ctx:
            self.run_dl("print('[download] File is larger than max-filesize (2000000000 bytes > 1000 bytes). Aborting.')")
        self.assertEqual(ctx.exception.code, "too_large")

    def test_unmerged_intermediate_files_are_not_picked(self):
        def body():
            return """
                (open(out.replace('%(ext)s','f137.mp4'),'wb')).write(b'x'*5000)
                print(out.replace('%(ext)s','f137.mp4'))
            """
        with self.assertRaises(LinkError):
            self.run_dl(body())

    def test_secrets_are_not_passed_to_the_downloader(self):
        self.staging.mkdir(parents=True)
        base = write_stub(self.dir, "print(media()); sys.stderr.write('KEY_VISIBLE=' + str('ANTHROPIC_API_KEY' in os.environ) + '\\n')")
        with mock.patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-secret"}):
            out = ytdlp.run_process([*base, "-o", str(self.staging / "source.%(ext)s"), "--", self.url], timeout=60, cancelled=lambda: False)
        self.assertIn("KEY_VISIBLE=False", out.stderr)

    def test_missing_ffmpeg_is_reported_before_starting(self):
        with mock.patch.object(ytdlp, "ffmpeg_info", return_value={"ffmpeg": None, "ffprobe": None, "version": None, "available": False, "dir": None}):
            with self.assertRaises(LinkError) as ctx:
                self.run_dl("print(media())")
        self.assertEqual(ctx.exception.code, "ffmpeg_missing"); self.assertIn("winget", ctx.exception.hint)

    def test_low_disk_space_is_reported_before_starting(self):
        with mock.patch("app.clipstudio.ytdlp.shutil.disk_usage", return_value=mock.Mock(free=1024)):
            with self.assertRaises(LinkError) as ctx:
                self.run_dl("print(media())")
        self.assertEqual(ctx.exception.code, "disk_full")

    def test_missing_ytdlp_gives_the_exact_install_command(self):
        with mock.patch.object(ytdlp, "base_command", return_value=None):
            with self.assertRaises(LinkError) as ctx:
                ytdlp.download(self.url, self.staging)
        self.assertEqual(ctx.exception.code, "adapter_missing"); self.assertIn(sys.executable, ctx.exception.hint)


# ------------------------------------------------------------------------------------------------ staged download -> validated source
@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class FetchPlatformTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = isolate()
        ytdlp.reset_caches()

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix="fetch-"))
        self.dest = self.dir / "dest"
        self.url = f"https://youtu.be/{VID}"
        self.env = mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "1"}); self.env.start()

    def tearDown(self):
        self.env.stop()

    def fetch(self, body: str):
        base = write_stub(self.dir, body)
        with mock.patch.object(ytdlp, "base_command", return_value=base), mock.patch.object(ytdlp, "time", wraps=time):
            return links.fetch_platform(self.url, self.dest)

    def test_success_registers_a_validated_file_in_the_destination(self):
        res = self.fetch("m = media(); print(m); print('VANTA_TITLE=My video')\nopen(out.replace('%(ext)s','en.vtt'),'w').write('WEBVTT\\n\\n00:00:00.000 --> 00:00:01.000\\nhello\\n')")
        self.assertEqual(res.path, self.dest / "source.mp4"); self.assertTrue(res.path.stat().st_size > 0)
        self.assertEqual((res.title, res.method, res.platform, res.video_id), ("My video", "yt-dlp", "youtube", VID))
        self.assertAlmostEqual(res.probe["duration"], 2, delta=0.5); self.assertEqual(res.subtitle_path, self.dest / "source.en.vtt")
        self.assertEqual([p.name for p in self.dest.iterdir() if p.name.startswith(".dl-")], [])      # staging removed

    def test_downloader_receives_the_canonical_url_not_the_raw_one(self):
        seen = self.dir / "url.txt"
        self.url = f"https://youtu.be/{VID}?si=trackingjunk&t=99"
        res = self.fetch(f"open({str(seen)!r}, 'w').write(args[-1]); print(media())")
        self.assertTrue(res.path.is_file())
        self.assertEqual(seen.read_text(), f"https://www.youtube.com/watch?v={VID}")

    def test_failure_leaves_nothing_behind_and_registers_nothing(self):
        with self.assertRaises(LinkError) as ctx:
            self.fetch("open(out.replace('%(ext)s','mp4.part'),'wb').write(b'partial'); sys.stderr.write('ERROR: Video unavailable\\n'); sys.exit(1)")
        self.assertEqual(ctx.exception.code, "unavailable")
        self.assertEqual(list(self.dest.iterdir()), [])

    def test_invalid_media_is_discarded_and_never_returned(self):
        with self.assertRaises(LinkError) as ctx:
            self.fetch("p = out.replace('%(ext)s','mp4'); open(p,'wb').write(b'not a video at all'*500); print(p)")
        self.assertEqual(ctx.exception.code, "invalid_media"); self.assertTrue(ctx.exception.retryable)
        self.assertEqual(list(self.dest.iterdir()), [])

    def test_too_long_video_is_discarded(self):
        with mock.patch.object(settings, "MAX_DURATION_SECONDS", 1.0):
            with self.assertRaises(LinkError) as ctx:
                self.fetch("print(media())")
        self.assertEqual(ctx.exception.code, "too_long"); self.assertEqual(list(self.dest.iterdir()), [])

    def test_disabled_flag_blocks_platform_downloads(self):
        with mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "0"}):
            with self.assertRaises(LinkError) as ctx:
                links.fetch_platform(self.url, self.dest)
        self.assertEqual(ctx.exception.code, "adapter_disabled")

    def test_truthy_spellings_of_the_flag(self):
        for value, expected in (("1", True), ("true", True), ("YES", True), (" on ", True), ("0", False), ("", False), ("enable", False)):
            with self.subTest(value=value), mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": value}):
                self.assertEqual(ytdlp.enabled(), expected)

    def test_bad_youtube_id_never_reaches_the_downloader(self):
        with mock.patch.object(ytdlp, "download", side_effect=AssertionError("must not run")):
            with self.assertRaises(LinkError) as ctx:
                links.fetch_platform("https://www.youtube.com/watch?v=short", self.dest)
        self.assertEqual(ctx.exception.code, "invalid_url")


# ------------------------------------------------------------------------------------------------ updater
class UpdaterTests(unittest.TestCase):
    def cp(self, rc=0, out="", err=""):
        return subprocess.CompletedProcess(args=[], returncode=rc, stdout=out, stderr=err)

    def test_targets_the_backend_interpreter_dry_runs_first_and_reports_versions(self):
        calls = []

        def fake_run(cmd, **kw):
            calls.append(list(cmd))
            if "pip" in cmd:
                return self.cp(0, "Successfully installed yt-dlp-2026.11.1 yt-dlp-ejs-0.8.0" if "--dry-run" not in cmd else "Would install yt-dlp-2026.11.1")
            return self.cp(0, "2026.11.1\n")
        with mock.patch("app.clipstudio.ytdlp.subprocess.run", side_effect=fake_run), mock.patch.object(ytdlp, "version", return_value="2026.10.21"):
            result = ytdlp.update()
        pip_calls = [c for c in calls if "pip" in c]
        self.assertEqual(len(pip_calls), 2); self.assertIn("--dry-run", pip_calls[0]); self.assertNotIn("--dry-run", pip_calls[1])
        for c in pip_calls:
            self.assertEqual(c[:4], [sys.executable, "-m", "pip", "install"]); self.assertEqual(c[-1], "yt-dlp[default]")
            self.assertNotIn("eager", c); self.assertIn("only-if-needed", c)
        self.assertEqual(calls[-1], [sys.executable, "-m", "yt_dlp", "--version"])
        self.assertEqual((result["ok"], result["executable"], result["previous_version"], result["version"], result["changed"]), (True, sys.executable, "2026.10.21", "2026.11.1", True))
        self.assertEqual(result["other_packages_changed"], ["yt_dlp_ejs-0.8.0"] if False else [p for p in result["installed_packages"] if not p.startswith("yt-dlp")])
        self.assertFalse(result["restart_required"]); self.assertIn(sys.executable, result["message"])

    def test_resolver_failure_changes_nothing(self):
        with mock.patch("app.clipstudio.ytdlp.subprocess.run", return_value=self.cp(1, "", "ERROR: Cannot install yt-dlp because these package versions have conflicting dependencies.")) as run:
            with self.assertRaises(ytdlp.UpdateError) as ctx:
                ytdlp.update()
        self.assertEqual(ctx.exception.status, 502); self.assertIn("nothing was changed", str(ctx.exception)); self.assertEqual(run.call_count, 1)

    def test_unchanged_version_is_reported_honestly(self):
        with mock.patch("app.clipstudio.ytdlp.subprocess.run", side_effect=lambda cmd, **kw: self.cp(0, "2026.10.21\n" if "yt_dlp" in cmd else "Requirement already satisfied")), \
             mock.patch.object(ytdlp, "version", return_value="2026.10.21"):
            result = ytdlp.update()
        self.assertFalse(result["changed"]); self.assertIn("already the newest", result["message"])

    def test_timeout_and_unverifiable_install_are_errors(self):
        with mock.patch("app.clipstudio.ytdlp.subprocess.run", side_effect=subprocess.TimeoutExpired("pip", 1)):
            with self.assertRaises(ytdlp.UpdateError) as ctx:
                ytdlp.update(timeout=1)
        self.assertEqual(ctx.exception.status, 504)
        with mock.patch("app.clipstudio.ytdlp.subprocess.run", side_effect=lambda cmd, **kw: self.cp(1, "", "boom") if "yt_dlp" in cmd else self.cp(0, "ok")):
            with self.assertRaises(ytdlp.UpdateError) as ctx:
                ytdlp.update()
        self.assertEqual(ctx.exception.status, 500)

    def test_concurrent_update_is_refused(self):
        self.assertTrue(ytdlp._UPDATE_LOCK.acquire(blocking=False))
        try:
            with self.assertRaises(ytdlp.UpdateError) as ctx:
                ytdlp.update()
            self.assertEqual(ctx.exception.status, 409)
        finally:
            ytdlp._UPDATE_LOCK.release()


# ------------------------------------------------------------------------------------------------ .env loading
class EnvLoadTests(unittest.TestCase):
    def test_parse_variants(self):
        text = '# comment\nA=1\nexport B = two\nC="quoted value" # trailing\nD=plain # inline comment\nE=\nF=\'single\'\nVANTA_ENABLE_YTDLP=1   # on\n'
        self.assertEqual(envload.parse_env(text), {"A": "1", "B": "two", "C": "quoted value", "D": "plain", "F": "single", "VANTA_ENABLE_YTDLP": "1"})

    def test_encodings_written_by_windows_tools(self):
        with tempfile.TemporaryDirectory() as d:
            for name, raw in (("utf8bom", b"\xef\xbb\xbfVANTA_ENABLE_YTDLP=1\r\n"), ("utf16", "VANTA_ENABLE_YTDLP=1\r\n".encode("utf-16")),
                              ("ansi", "NAME=caf\xe9\r\nVANTA_ENABLE_YTDLP=1\r\n".encode("cp1252"))):
                p = Path(d) / name; p.write_bytes(raw)
                self.assertEqual(envload.parse_env(envload.read_env_text(p))["VANTA_ENABLE_YTDLP"], "1", name)

    def test_real_environment_wins(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(os.environ, {"VANTA_T_A": "real"}):
            p = Path(d) / ".env"; p.write_text("VANTA_T_A=file\nVANTA_T_B=file\n")
            os.environ.pop("VANTA_T_B", None)
            envload.load_env(p)
            self.assertEqual((os.environ["VANTA_T_A"], os.environ["VANTA_T_B"]), ("real", "file"))
            os.environ.pop("VANTA_T_B", None)


if __name__ == "__main__":
    unittest.main()
