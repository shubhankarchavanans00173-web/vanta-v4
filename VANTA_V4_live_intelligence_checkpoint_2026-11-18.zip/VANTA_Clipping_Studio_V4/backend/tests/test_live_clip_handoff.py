"""Reviewed live clip -> real project: source, transcript, captions, and the existing analyze/render path.

The live pipeline stays review-only; this suite proves the handoff is complete enough that the normal routes take the
promoted clip over unchanged. Transcription is stubbed (no model, no download) exactly as other suites do; the media,
FFprobe, captions and one real render are genuine local FFmpeg work.
"""
from __future__ import annotations

import io
import json
import os
import subprocess
import tempfile
import threading
import time
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import db, pipeline, settings
from app.clipstudio.live import cli, handoff
from app.clipstudio.live.handoff import HandoffError, promote_live_clip
from app.clipstudio.live.live_clip_worker import LiveClipError
from app.clipstudio.live.review_pipeline import LiveReviewPipeline, clips_dir
from app.clipstudio.transcript import Segment, Transcript, Word, load_transcript_file
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video


def fake_transcript(clip: Path, info: dict) -> Transcript:
    return Transcript(
        [Segment(0.20, 1.40, "This is the moment",
                 [Word("This", 0.20, 0.40), Word("is", 0.40, 0.60), Word("the", 0.60, 0.80), Word("moment", 0.80, 1.40)]),
         Segment(1.60, 2.80, "that everyone will clip.",
                 [Word("that", 1.60, 1.80), Word("everyone", 1.80, 2.20), Word("will", 2.20, 2.40),
                  Word("clip.", 2.40, 2.80)])],
        "faster-whisper", "en")


class _UnavailableEngine:
    def available(self):
        return False, "faster-whisper is not installed"

    def transcribe(self, *args, **kwargs):  # pragma: no cover - must never be reached
        raise AssertionError("transcribe() must not run when the engine is unavailable")


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class PromoteLiveClipTests(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.clips = clips_dir(settings.BASE)
        self.clips.mkdir(parents=True, exist_ok=True)
        self.clip = make_video(self.clips / "session-1-chat-spike.mp4", duration=3, size="160x90")

    def tearDown(self):
        self.tmp.cleanup()

    def test_promote_creates_project_transcript_captions_and_candidate(self):
        result = promote_live_clip(self.clip, session_id="session-1", job_id="job-9", title="  Big laugh  ",
                                   evidence={"kind": "chat_spike", "sources": ["chat"]}, transcribe=fake_transcript)
        project = db.get_project(result.project["id"])
        self.assertIsNotNone(project)
        self.assertEqual(project["source_type"], "live")
        self.assertEqual(project["source_ref"], "job-9")
        self.assertEqual(project["name"], "Big laugh")
        self.assertTrue(Path(project["source_path"]).is_file())
        self.assertTrue(settings.is_inside(Path(project["source_path"]), settings.UPLOAD_DIR))
        self.assertAlmostEqual(project["probe"]["duration"], 3.0, places=1)
        self.assertIn("live", project["settings"])
        self.assertEqual(project["settings"]["live"]["session_id"], "session-1")
        self.assertEqual(project["settings"]["live"]["evidence"]["kind"], "chat_spike")

        # transcript: stored where the rest of the app looks for it
        self.assertTrue(pipeline.transcript_available(project))
        loaded = pipeline.load_project_transcript(project)
        self.assertIn("moment", " ".join(s.text for s in loaded.segments))
        self.assertTrue(result.transcript.word_level)

        # captions: a real SRT the app itself can read back
        srt = Path(result.captions_path)
        self.assertTrue(srt.is_file())
        self.assertIn("moment", srt.read_text(encoding="utf-8"))
        reparsed = load_transcript_file(srt)
        self.assertGreaterEqual(len(reparsed.segments), 2)
        self.assertEqual(project["settings"]["captions_srt"], str(srt))

        # one approved candidate covering the whole clip
        cands = db.list_candidates(project["id"])
        self.assertEqual(len(cands), 1)
        cand = cands[0]
        self.assertEqual(cand["status"], "approved")
        self.assertEqual(cand["origin"], "live")
        self.assertEqual(cand["start"], 0.0)
        self.assertAlmostEqual(cand["end"], 3.0, places=1)
        self.assertIn("moment", cand["excerpt"])
        self.assertTrue(any("reviewed" in r.lower() or "promoted" in r.lower() for r in cand["reasons"]))
        self.assertIn("chat_spike", json.dumps(cand["reasons"]))
        self.assertEqual(cand["analysis"]["captions_srt"], str(srt))

        # honest flags in the payload
        payload = result.to_dict()
        self.assertEqual(payload["project_id"], project["id"])
        self.assertTrue(payload["review_only"])
        self.assertFalse(payload["published"])
        self.assertEqual(payload["next"]["candidate_ids"], [cand["id"]])

    def test_promote_can_land_as_a_suggestion_instead_of_approved(self):
        result = promote_live_clip(self.clip, transcribe=fake_transcript, approved=False)
        self.assertEqual(result.candidate["status"], "suggested")

    def test_missing_local_engine_refuses_and_leaves_nothing_behind(self):
        with mock.patch.object(handoff, "get_engine", lambda name: _UnavailableEngine()):
            with self.assertRaises(HandoffError) as ctx:
                promote_live_clip(self.clip)
        self.assertEqual(ctx.exception.code, "no_transcript")
        self.assertIn("Nothing was created", ctx.exception.hint or "")
        self.assertEqual(db.list_projects(), [])
        self.assertEqual(list(settings.UPLOAD_DIR.iterdir()) if settings.UPLOAD_DIR.exists() else [], [])
        self.assertEqual(list(settings.TRANSCRIPT_DIR.glob("*.json")), [])

    def test_failure_after_creation_rolls_back_the_project_and_files(self):
        with mock.patch.object(handoff.captions, "write_srt", side_effect=OSError("disk full")):
            with self.assertRaises(HandoffError) as ctx:
                promote_live_clip(self.clip, transcribe=fake_transcript)
        self.assertEqual(ctx.exception.code, "failed")
        self.assertIn("disk full", str(ctx.exception))
        self.assertEqual(db.list_projects(), [])
        self.assertEqual(list(settings.UPLOAD_DIR.iterdir()) if settings.UPLOAD_DIR.exists() else [], [])
        self.assertEqual(list(settings.TRANSCRIPT_DIR.glob("*.json")), [])
        self.assertEqual(list(settings.TRANSCRIPT_DIR.glob("*.srt")), [])

    def test_refuses_a_clip_outside_vanta_data(self):
        outside = tempfile.TemporaryDirectory(prefix="vanta-elsewhere-")
        self.addCleanup(outside.cleanup)
        foreign = make_video(Path(outside.name) / "not-a-live-clip.mp4", duration=1, size="160x90")
        with self.assertRaises(HandoffError) as ctx:
            promote_live_clip(foreign, transcribe=fake_transcript)
        self.assertEqual(ctx.exception.code, "outside_data")
        self.assertEqual(db.list_projects(), [])

    def test_refuses_non_video_and_missing_files(self):
        text = settings.BASE / "notes.txt"
        text.write_text("not media", encoding="utf-8")
        with self.assertRaises(HandoffError) as ctx:
            promote_live_clip(text, transcribe=fake_transcript)
        self.assertEqual(ctx.exception.code, "unsupported_type")
        with self.assertRaises(HandoffError) as ctx:
            promote_live_clip(settings.BASE / "gone.mp4", transcribe=fake_transcript)
        self.assertEqual(ctx.exception.code, "not_found")
        self.assertEqual(db.list_projects(), [])

    def test_cli_promotes_a_reviewed_clip_and_initialises_a_fresh_data_folder(self):
        srt = settings.BASE / "reviewed.srt"
        srt.write_text("1\n00:00:00,200 --> 00:00:02,500\nReviewed and ready to publish.\n", encoding="utf-8")
        out = io.StringIO()
        with mock.patch.object(cli.db, "init", wraps=cli.db.init) as init, redirect_stdout(out):
            code = cli.main(["--promote", str(self.clip), "--transcript", str(srt), "--title", "From CLI", "--json"])
        self.assertEqual(code, 0)
        init.assert_called_once()                       # the CLI must work on a data folder the app never opened
        payload = json.loads(out.getvalue().strip().splitlines()[-1])
        project = db.get_project(payload["project_id"])
        self.assertEqual(project["source_type"], "live")
        self.assertEqual(project["name"], "From CLI")
        self.assertIn("Reviewed and ready", Path(payload["captions_srt"]).read_text(encoding="utf-8"))
        self.assertIn("Reviewed and ready", db.get_candidate(payload["candidate_id"])["excerpt"])

    def test_pipeline_requires_explicit_review_and_never_promotes_twice(self):
        live = LiveReviewPipeline.__new__(LiveReviewPipeline)
        live._jobs = {"j1": {"id": "j1", "status": "ready_for_review", "path": str(self.clip),
                             "session_id": "session-1", "event": {"kind": "chat_spike"}, "project_id": None}}
        live._lock = threading.RLock()

        with self.assertRaises(LiveClipError):
            live.promote("j1")                                   # reviewed=False
        self.assertEqual(db.list_projects(), [])

        payload = live.promote("j1", reviewed=True, transcribe=fake_transcript)
        self.assertEqual(payload["project_id"], db.list_projects()[0]["id"])
        self.assertEqual(live.get("j1")["project_id"], payload["project_id"])
        self.assertFalse(live.get("j1")["published"])
        with self.assertRaises(LiveClipError):
            live.promote("j1", reviewed=True, transcribe=fake_transcript)


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class PromotedClipFlowsThroughTheAppTests(unittest.TestCase):
    """The whole handoff: promote -> analyze via the API -> render via the API -> a real export file."""

    def setUp(self):
        self.tmp = isolate()
        self.clips = clips_dir(settings.BASE)
        self.clips.mkdir(parents=True, exist_ok=True)
        self.clip = make_video(self.clips / "session-2-event.mp4", duration=3, size="160x90")
        self.env = mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "0"}, clear=False)
        self.env.start()
        from app.main import app
        self.client = TestClient(app)
        self.client.__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        self.env.stop()
        self.tmp.cleanup()

    def _wait_job(self, job_id: str, done: set[str], timeout: float = 180.0) -> dict:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            r = self.client.get(f"/api/vanta/jobs/{job_id}")
            self.assertEqual(r.status_code, 200, r.text)
            job = r.json()
            if job["status"] in done:
                return job
            time.sleep(0.2)
        raise AssertionError(f"job {job_id} did not reach {done}")

    def test_promoted_clip_analyzes_renders_and_exports(self):
        payload = promote_live_clip(self.clip, session_id="session-2", job_id="job-2", title="Reviewed moment",
                                    transcribe=fake_transcript).to_dict()
        pid, cid = payload["project_id"], payload["candidate_id"]

        listed = self.client.get("/api/vanta/projects").json()
        assert any(p["id"] == pid for p in listed), listed
        one = self.client.get(f"/api/vanta/projects/{pid}").json()
        self.assertTrue(one["has_transcript"])
        self.assertTrue(one["has_source"])
        self.assertEqual(one["source_type"], "live")

        analyzed = self.client.post(f"/api/vanta/projects/{pid}/analyze",
                                    json={"count": 2, "target_duration": 10, "transcribe": False})
        self.assertEqual(analyzed.status_code, 200, analyzed.text)
        job = self._wait_job(analyzed.json()["id"], {"awaiting_approval", "failed", "completed"})
        self.assertEqual(job["status"], "awaiting_approval", job)
        self.assertTrue(any(c["id"] == cid for c in db.list_candidates(pid)))

        rendered = self.client.post(f"/api/vanta/projects/{pid}/render",
                                    json={"candidate_ids": [cid],
                                          "settings": {"aspect": "9:16", "fps": 15, "preset": "ultrafast", "crf": 30}})
        self.assertEqual(rendered.status_code, 200, rendered.text)
        done = self._wait_job(rendered.json()["id"], {"completed", "failed", "cancelled"})
        self.assertEqual(done["status"], "completed", done)

        exports = db.list_exports(pid)
        self.assertEqual(len(exports), 1, exports)
        out = Path(exports[0]["path"])
        self.assertTrue(out.is_file())
        self.assertTrue(settings.is_inside(out, settings.EXPORT_DIR))
        self.assertEqual(out.suffix, ".mp4")
        probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=width,height",
                                "-of", "json", str(out)], capture_output=True, text=True, check=True)
        stream = json.loads(probe.stdout)["streams"][0]
        self.assertEqual((stream["width"], stream["height"]), (1080, 1920))
        self.assertTrue(Path(exports[0]["srt_path"]).is_file() or not exports[0]["srt_path"])
        cand = db.get_candidate(cid)
        self.assertEqual(cand["status"], "rendered")


if __name__ == "__main__":
    unittest.main()
