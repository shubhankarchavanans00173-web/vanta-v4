"""Focused tests for the opt-in scheduler and VANTA YouTube review boundary."""
from __future__ import annotations

import sqlite3
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest import mock

from app.clipstudio import db, scheduler, settings, youtube_upload
from tests.vanta_fixtures import isolate


class SchedulerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.service = scheduler.SchedulerService()
        self.project = db.create_project("Scheduled", "upload", source_path=str(settings.SOURCE_DIR / "source.mp4"))
        self.candidate = db.add_candidate(self.project["id"], 1, 16, 80, "multi-signal", ["approved"], status="approved")

    def tearDown(self):
        self.service.stop()
        self.tmp.cleanup()

    def _queue(self):
        return db.create_scheduler_task(self.project["id"], self.candidate["id"], {"captions": False}, 1)

    def test_disabled_by_default_and_validates_timezone(self):
        cfg = db.get_scheduler_config()
        self.assertFalse(cfg["enabled"])
        self.assertEqual(scheduler.validate_config({**cfg, "timezone": "Asia/Kolkata", "time_of_day": "23:59"})["timezone"], "Asia/Kolkata")
        with self.assertRaises(scheduler.SchedulerError):
            scheduler.validate_config({**cfg, "timezone": "Not/AZone"})
        with self.assertRaises(scheduler.SchedulerError):
            scheduler.validate_config({**cfg, "time_of_day": "9:00"})

    def test_queue_retry_and_no_duplicate_after_recovery(self):
        task = self._queue()
        with self.assertRaises(sqlite3.IntegrityError):
            self._queue()
        cfg = db.update_scheduler_config(enabled=True, timezone="UTC", time_of_day="00:00", videos_per_run=1, retry_limit=1)
        self.assertTrue(cfg["enabled"])
        first = db.create_job(self.project["id"], "render")
        second = db.create_job(self.project["id"], "render")
        submitted = [first, second]
        now = datetime(2026, 10, 30, 1, tzinfo=timezone.utc)
        with mock.patch("app.clipstudio.scheduler.pipeline.submit_render", side_effect=lambda *a: submitted.pop(0)) as submit:
            self.assertEqual(len(self.service.run_once(now)), 1)
            active = db.get_scheduler_task(task["id"])
            self.assertEqual((active["status"], active["job_id"]), ("running", first["id"]))
            db.transition(first["id"], "rendering")
            db.transition(first["id"], "failed", error="renderer failed")
            # The first failure is durably requeued with a backoff, then retried
            # inside the same run without allowing a second video into it.
            self.service.run_once(now)
            waiting = db.get_scheduler_task(task["id"])
            self.assertEqual((waiting["status"], waiting["attempts"]), ("ready", 1))
            self.assertEqual(len(self.service.run_once(now.replace(second=31))), 1)
            retried = db.get_scheduler_task(task["id"])
            self.assertEqual((retried["status"], retried["job_id"]), ("running", second["id"]))
            self.assertEqual(submit.call_count, 2)

        # A restart cannot duplicate the original worker. Its dead render is
        # reconciled into the same durable task rather than creating another.
        db.transition(second["id"], "rendering")
        db.transition(second["id"], "failed", error="backend stopped")
        self.service.reconcile(now.replace(minute=2))
        self.assertEqual(db.get_scheduler_task(task["id"])["status"], "failed")

    def test_instance_lock_is_exclusive_and_stale_safe(self):
        first, second = scheduler.InstanceLock(), scheduler.InstanceLock()
        self.assertTrue(first.acquire())
        self.assertFalse(second.acquire())
        first.release()
        self.assertTrue(second.acquire())
        second.release()

    def test_scheduler_never_calls_upload_service(self):
        self._queue()
        db.update_scheduler_config(enabled=True, timezone="UTC", time_of_day="00:00", videos_per_run=1)
        job = db.create_job(self.project["id"], "render")
        with mock.patch("app.clipstudio.scheduler.pipeline.submit_render", return_value=job), mock.patch(
            "app.clipstudio.youtube_upload.submit"
        ) as upload:
            self.service.run_once(datetime(2026, 10, 30, 1, tzinfo=timezone.utc))
            upload.assert_not_called()


class YouTubeUploadTests(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.project = db.create_project("Export", "upload", source_path=str(settings.SOURCE_DIR / "source.mp4"))
        self.candidate = db.add_candidate(self.project["id"], 1, 16, 80, "multi-signal", ["approved"], status="rendered")
        self.path = settings.EXPORT_DIR / "clip.mp4"
        self.path.write_bytes(b"local-test-file")
        self.export = db.add_export(
            self.project["id"], self.candidate["id"], "job", str(self.path), self.path.name, "9:16", 15, self.path.stat().st_size,
            {"valid": True}, {"publish": {"title": "Reviewed title", "description": "Reviewed description", "hashtags": ["#test"]}}, None,
        )

    def tearDown(self):
        deadline = time.time() + 2
        while self.export["id"] in youtube_upload._IN_FLIGHT and time.time() < deadline:
            time.sleep(0.01)
        self.tmp.cleanup()

    def _wait(self):
        deadline = time.time() + 2
        state = {}
        while time.time() < deadline:
            state = (db.get_export(self.export["id"])["meta"] or {}).get("youtube_upload") or {}
            if state.get("state") in {"completed", "error"}:
                return state
            time.sleep(0.01)
        self.fail("mocked YouTube worker did not settle")

    def test_mocked_success_saves_id_only_after_response(self):
        with mock.patch.object(youtube_upload.youtube, "upload", return_value={"video_id": "abc123", "url": "https://youtu.be/abc123", "notes": []}), mock.patch.object(
            youtube_upload._EXECUTOR, "submit", side_effect=lambda fn, *args: fn(*args)
        ):
            accepted = youtube_upload.submit(self.export["id"], {"privacy": "private"})
            self.assertEqual(accepted["privacy"], "private")
            state = (db.get_export(self.export["id"])["meta"] or {}).get("youtube_upload")
        self.assertEqual((state["state"], state["video_id"]), ("completed", "abc123"))

    def test_mocked_quota_failure_never_saves_video_id(self):
        with mock.patch.object(youtube_upload.youtube, "upload", side_effect=RuntimeError("Daily YouTube API quota is used up")), mock.patch.object(
            youtube_upload._EXECUTOR, "submit", side_effect=lambda fn, *args: fn(*args)
        ):
            youtube_upload.submit(self.export["id"], {"privacy": "private"})
            state = (db.get_export(self.export["id"])["meta"] or {}).get("youtube_upload")
        self.assertEqual(state["state"], "error")
        self.assertIn("quota", state["error"].lower())
        self.assertNotIn("video_id", state)

    def test_http_route_requires_fresh_confirmation(self):
        from fastapi import HTTPException
        from app.clipstudio import router
        with self.assertRaises(HTTPException) as denied:
            router.upload_export_to_youtube(self.export["id"], router.YouTubeUploadRequest(privacy="private"))
        self.assertEqual(denied.exception.status_code, 428)
        with mock.patch("app.clipstudio.router.youtube_upload.status", return_value={"connected": True}), mock.patch(
            "app.clipstudio.router.youtube_upload.submit", return_value={"accepted": True, "state": "queued"}
        ) as submit:
            allowed = router.upload_export_to_youtube(self.export["id"], router.YouTubeUploadRequest(privacy="private", confirm=True))
        self.assertTrue(allowed["accepted"])
        submit.assert_called_once()


if __name__ == "__main__":
    unittest.main()
