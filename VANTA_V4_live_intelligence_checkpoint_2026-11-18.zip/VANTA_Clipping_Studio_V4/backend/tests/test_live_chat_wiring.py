"""Phase 5 step 2: real YouTube Live Chat / Twitch IRC adapters wired into the review pipeline.

Everything here runs against **fake transports** (a fake Google client, a fake IRC socket) plus one real local stream
for the end-to-end clip. That is exactly why the chat integrations stay labelled PARTIAL: no real credential is used.
"""
from __future__ import annotations

import io
import json
import os
import subprocess
import tempfile
import time
import unittest
import threading
from contextlib import redirect_stderr
from dataclasses import replace
from pathlib import Path
from unittest import mock

from app.clipstudio.live import cli, credentials
from app.clipstudio.live.chat_sources import StreamClock, TwitchChatSource, YouTubeChatSource
from app.clipstudio.live.chat_spike_detector import ChatMessage
from app.clipstudio.live.live_clip_worker import LiveClipWorker
from app.clipstudio.live.review_pipeline import LiveReviewPipeline
from app.clipstudio.live.rolling_buffer import BufferedSegment, RollingBuffer
from app.clipstudio.live.session_runner import LiveRunConfig, LiveSessionRunner
from app.clipstudio.live.stream_manager import LiveStreamManager
from app.clipstudio.live.twitch_adapter import TwitchAdapterError, TwitchChatStream
from app.clipstudio.live.youtube_adapter import YouTubeAdapterError, YouTubeLiveChatAdapter, find_live_chat_id
from tests.vanta_fixtures import HAVE_FFMPEG, make_video


def ffprobe_duration(path: Path) -> float:
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)],
                         capture_output=True, text=True, timeout=30, check=True)
    return float(out.stdout.strip())


class _FakeRequest:
    def __init__(self, payload):
        self.payload = payload

    def execute(self):
        if isinstance(self.payload, Exception):
            raise self.payload
        return self.payload


class FakeYouTubeService:
    def __init__(self, video_payload=None, chat_pages=None):
        self.video_payload, self.chat_pages, self.calls = video_payload, list(chat_pages or []), []

    def videos(self):
        return self

    def liveChatMessages(self):
        return self

    def list(self, **kwargs):
        self.calls.append(kwargs)
        return _FakeRequest(self.video_payload if "id" in kwargs else (self.chat_pages.pop(0) if self.chat_pages else {"items": []}))


class YouTubeDiscoveryTests(unittest.TestCase):
    def test_finds_the_active_chat_id(self):
        service = FakeYouTubeService({"items": [{"liveStreamingDetails": {"activeLiveChatId": "chat-123"}}]})
        self.assertEqual(find_live_chat_id(service, "vid-1"), "chat-123")
        self.assertEqual(service.calls[0]["id"], "vid-1")

    def test_explains_missing_video_and_inactive_chat(self):
        with self.assertRaises(YouTubeAdapterError) as missing:
            find_live_chat_id(FakeYouTubeService({"items": []}), "nope")
        self.assertIn("no video", str(missing.exception))
        with self.assertRaises(YouTubeAdapterError) as inactive:
            find_live_chat_id(FakeYouTubeService({"items": [{"liveStreamingDetails": {}}]}), "vid-2")
        self.assertIn("no active live chat", str(inactive.exception))
        with self.assertRaises(YouTubeAdapterError):
            find_live_chat_id(FakeYouTubeService({}), "  ")

    def test_transport_failure_is_reported_with_type_and_detail(self):
        service = FakeYouTubeService(RuntimeError("quota exceeded"))
        with self.assertRaises(YouTubeAdapterError) as caught:
            find_live_chat_id(service, "vid-3")
        self.assertIn("RuntimeError", str(caught.exception))
        self.assertIn("quota exceeded", str(caught.exception))


class YouTubeAdapterStampTests(unittest.TestCase):
    def test_messages_carry_stream_time_and_the_api_poll_interval(self):
        page = {"nextPageToken": "t2", "pollingIntervalMillis": 9000,
                "items": [{"snippet": {"displayMessage": "clutch"}, "authorDetails": {"channelId": "uc-1"}}]}
        adapter = YouTubeLiveChatAdapter(FakeYouTubeService(chat_pages=[page]), "chat-1", clock=lambda: 42.5)
        messages = adapter.poll()
        self.assertEqual([(m.timestamp, m.author, m.platform) for m in messages], [(42.5, "uc-1", "youtube")])
        self.assertEqual(adapter.poll_interval_ms, 9000)
        self.assertEqual(adapter.page_token, "t2")

    def test_poll_interval_is_clamped_and_errors_are_wrapped(self):
        adapter = YouTubeLiveChatAdapter(FakeYouTubeService(chat_pages=[{"pollingIntervalMillis": 1}]), "chat-1")
        adapter.poll()
        self.assertEqual(adapter.poll_interval_ms, 250)
        broken = YouTubeLiveChatAdapter(FakeYouTubeService(chat_pages=[RuntimeError("boom")]), "chat-1")
        with self.assertRaises(YouTubeAdapterError):
            broken.poll()


class YouTubeChatSourceTests(unittest.TestCase):
    def source(self, adapter=None):
        self.delivered = []
        adapter = adapter or YouTubeLiveChatAdapter(FakeYouTubeService(chat_pages=[
            {"pollingIntervalMillis": 1000, "items": [{"snippet": {"displayMessage": f"m{i}"}, "authorDetails": {"channelId": f"u{i}"}} for i in range(3)]}]), "chat-1")
        return YouTubeChatSource(adapter, self.delivered.append, clock=lambda: 7.0, min_interval=0.2, max_interval=5.0)

    def test_poll_once_delivers_stamped_messages_and_respects_the_api_interval(self):
        source = self.source()
        self.assertEqual(source.poll_once(), 3)
        self.assertEqual([m.timestamp for m in self.delivered], [7.0, 7.0, 7.0])
        self.assertEqual(source.interval, 1.0)
        self.assertEqual(source.status()["messages"], 3)

    def test_failures_are_recorded_not_raised(self):
        source = self.source(adapter=YouTubeLiveChatAdapter(FakeYouTubeService(chat_pages=[RuntimeError("403")]), "chat-1"))
        self.assertEqual(source.poll_once(), 0)
        self.assertEqual(source.status()["errors"], 1)
        self.assertIn("403", source.status()["last_error"])

    def test_the_thread_starts_and_stops(self):
        source = self.source()
        source.start()
        time.sleep(0.35)
        status = source.stop()
        self.assertFalse(status["running"])
        self.assertGreaterEqual(status["messages"], 3)


class FakeIrcSocket:
    def __init__(self, chunks):
        self.chunks, self.sent, self.closed, self.timeout = list(chunks), [], False, None

    def settimeout(self, value):
        self.timeout = value

    def sendall(self, data):
        self.sent.append(data.decode("utf-8"))

    def recv(self, _size):
        if not self.chunks:
            raise TimeoutError("no data")
        chunk = self.chunks.pop(0)
        if isinstance(chunk, Exception):
            raise chunk
        return chunk.encode("utf-8") if isinstance(chunk, str) else chunk

    def close(self):
        self.closed = True


class TwitchStreamTests(unittest.TestCase):
    def stream(self, chunks, **kwargs):
        self.sock = FakeIrcSocket(chunks)
        return TwitchChatStream("SomeChannel", socket_factory=lambda host, port: self.sock, wrap_tls=lambda sock: sock,
                                clock=lambda: 12.0, timeout=5, **kwargs)

    def test_join_is_read_only_and_anonymous_by_default(self):
        stream = self.stream([])
        stream.connect()
        self.assertTrue(stream.connected)
        self.assertEqual(stream.channel, "somechannel")
        self.assertTrue(any(line.startswith("NICK justinfan") for line in self.sock.sent))
        self.assertIn("JOIN #somechannel\r\n", self.sock.sent)
        self.assertFalse(any(line.startswith("PASS") for line in self.sock.sent))
        self.assertFalse(any("PRIVMSG" in line for line in self.sock.sent), "the reader must never speak in chat")

    def test_a_token_is_sent_when_provided(self):
        stream = self.stream([], token="abc123", nick="vanta")
        stream.connect()
        self.assertEqual(self.sock.sent[0], "PASS oauth:abc123\r\n")
        self.assertIn("NICK vanta\r\n", self.sock.sent)

    def test_ping_is_answered_and_split_lines_are_rejoined(self):
        stream = self.stream(["PING :tmi.twitch.tv\r\n:u1!u1@u1 PRIVMSG #somechannel :hel", "lo\r\n"])
        stream.connect()
        self.assertEqual(stream.read(), [])                       # only a PING in the first chunk
        self.assertIn("PONG :tmi.twitch.tv\r\n", self.sock.sent)
        messages = stream.read()
        self.assertEqual([(m.text, m.author, m.platform, m.timestamp) for m in messages], [("hello", "u1", "twitch", 12.0)])

    def test_reconnect_auth_failure_and_closed_socket_are_all_reported(self):
        for chunk, fragment in ((":tmi.twitch.tv RECONNECT\r\n", "reconnect"),
                                ("Login authentication failed\r\n", "TWITCH_OAUTH_TOKEN"),
                                (b"", "closed")):
            stream = self.stream([chunk])
            stream.connect()
            with self.assertRaises(TwitchAdapterError) as caught:
                stream.read()
            self.assertIn(fragment, str(caught.exception).lower() if fragment != "TWITCH_OAUTH_TOKEN" else str(caught.exception))


class FakeStream:
    channel = "somechannel"

    def __init__(self):
        self.connected, self.queue, self.fail_next, self.closed = False, [], 0, False

    def connect(self):
        self.connected = True

    def read(self):
        if self.fail_next:
            self.fail_next -= 1
            raise TwitchAdapterError("connection reset")
        messages, self.queue = self.queue, []
        return messages

    def close(self):
        self.closed, self.connected = True, False


class TwitchChatSourceTests(unittest.TestCase):
    def test_reconnects_once_then_delivers(self):
        stream = FakeStream()
        stream.fail_next = 1
        stream.queue = [ChatMessage(1.0, "u1", "no way", "twitch")]
        delivered = []
        source = TwitchChatSource(stream, delivered.append, clock=lambda: 3.0, reconnect_attempts=2, backoff=0.0, sleep=lambda _s: None)
        self.assertEqual(source.poll_once(), 0)                   # first read fails, reconnect happens
        self.assertEqual(source.status()["reconnects"], 1)
        self.assertTrue(source.status()["connected"])
        self.assertEqual(source.poll_once(), 1)
        self.assertEqual(delivered[0].text, "no way")

    def test_gives_up_after_the_reconnect_budget(self):
        stream = FakeStream()
        stream.fail_next = 10
        source = TwitchChatSource(stream, lambda _m: None, reconnect_attempts=1, backoff=0.0, sleep=lambda _s: None)
        source.poll_once()
        source.poll_once()
        self.assertTrue(source.status()["failed"])


class StreamClockTests(unittest.TestCase):
    def test_clock_reads_the_buffer_not_the_wall_clock(self):
        buffer = RollingBuffer(60)
        self.assertEqual(StreamClock(buffer).now(), 0.0)
        buffer.add(BufferedSegment(0.0, 12.0, Path("seg.ts")))
        self.assertEqual(StreamClock(buffer).now(), 12.0)
        self.assertEqual(StreamClock(buffer, latency=2.0).now(), 10.0)


class CredentialTests(unittest.TestCase):
    def test_twitch_environment_is_parsed_without_exposing_the_token(self):
        settings = credentials.twitch_settings({"TWITCH_CHANNEL": "#SomeChan", "TWITCH_OAUTH_TOKEN": "oauth:abc123"})
        self.assertEqual(settings, {"channel": "somechan", "token": "abc123", "nick": None})
        diagnostics = credentials.twitch_diagnostics({"TWITCH_CHANNEL": "ch", "TWITCH_OAUTH_TOKEN": "oauth:supersecret"})
        self.assertNotIn("supersecret", json.dumps(diagnostics))
        self.assertTrue(diagnostics["token_present"])

    def test_missing_channel_is_actionable(self):
        with self.assertRaises(credentials.CredentialsError) as caught:
            credentials.require_twitch_channel({})
        self.assertIn("TWITCH_CHANNEL", str(caught.exception))

    def test_youtube_diagnostics_never_reveal_the_token(self):
        with tempfile.TemporaryDirectory() as tmp:
            token = Path(tmp) / "youtube_token.json"
            token.write_text(json.dumps({"refresh_token": "supersecret", "token": "anothersecret"}), encoding="utf-8")
            diagnostics = credentials.youtube_diagnostics(token)
            dumped = json.dumps(diagnostics)
            self.assertTrue(diagnostics["token_found"])
            self.assertNotIn("supersecret", dumped)
            self.assertNotIn("anothersecret", dumped)

    def test_missing_youtube_token_explains_what_to_do(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(credentials.CredentialsError) as caught:
                credentials.youtube_service(Path(tmp) / "absent.json")
            message = str(caught.exception)
            self.assertIn("Connect YouTube", message)
            self.assertIn("absent.json", message)


class ScriptedChatSource:
    """Stand-in for a platform source: waits until media exists, then pushes one burst of distinct viewers."""

    name = "scripted"

    def __init__(self, messages, on_message, *, ready=lambda: True, clock=lambda: 0.0, timeout: float = 20.0):
        self.messages, self.on_message, self.ready, self.clock = messages, on_message, ready, clock
        self.timeout, self.running, self.sent = timeout, False, 0
        self._thread = None

    def start(self):
        self.running = True
        self._thread = threading.Thread(target=self._run, name="scripted-chat", daemon=True)
        self._thread.start()
        return self.status()

    def _run(self):
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline and not self.ready():
            time.sleep(0.1)
        stamp = float(self.clock())
        for message in self.messages:
            if not self.running:
                return
            self.on_message(replace(message, timestamp=stamp))
            self.sent += 1

    def stop(self):
        self.running = False
        if self._thread is not None:
            self._thread.join(2)
            self._thread = None
        return self.status()

    def status(self):
        return {"source": self.name, "running": self.running, "messages": self.sent}


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg/ffprobe are required for the end-to-end run")
class RunnerEndToEndTests(unittest.TestCase):
    def test_chat_only_spike_from_a_real_source_threading_is_rejected_and_monitoring_stays_safe(self):
        with tempfile.TemporaryDirectory(prefix="vanta-live-wire-") as tmp:
            root = Path(tmp)
            video = make_video(root / "stream.mp4", duration=12, size="320x240")
            manager = LiveStreamManager()
            pipeline = LiveReviewPipeline(manager, LiveClipWorker(root / "clips"), before_seconds=3, max_wait_seconds=25, poll_seconds=0.1)
            config = LiveRunConfig(platform="manual", stream_ref="authorised-local", source=str(video),
                                   buffer_seconds=60, post_event_seconds=2, segment_seconds=2, before_seconds=3)
            burst = [ChatMessage(0.0, f"viewer-{i}", text, "youtube")
                     for i, text in enumerate(["WHAT", "NO WAY", "clutch", "insane play", "OMG", "he did it", "wild", "lets go"])]
            runner = LiveSessionRunner(manager, pipeline, config, base_dir=root / "live",
                                       chat_factory=lambda live: ScriptedChatSource(
                                           burst, on_message=lambda message: manager.add_chat(live.session.id, message),
                                           ready=lambda: (live.session.buffer.latest_time or 0) >= 4.0,
                                           clock=live.clock.now))
            started = runner.start()
            try:
                self.assertEqual(started["platform"], "manual")
                self.assertTrue(started["ingest"]["running"])
                deadline = time.monotonic() + 20
                while time.monotonic() < deadline and not pipeline.jobs(runner.session.id):
                    time.sleep(0.1)
                jobs = runner.wait(timeout=40)
            finally:
                runner.stop(cleanup=True)
            self.assertEqual(jobs, [])
            self.assertEqual(pipeline.status()["rejected_chat_only"], 1)
            self.assertEqual(pipeline.status()["last_rejection"]["reason"], "chat_only_event")
            self.assertTrue(manager.on_event == pipeline.on_event, "the manager was not wired to the pipeline")


class CliTests(unittest.TestCase):
    def test_missing_platform_inputs_are_reported_without_a_traceback(self):
        for argv, fragment in ((["--platform", "youtube", "--check"], "--video-id"),
                               (["--platform", "twitch", "--check"], "TWITCH_CHANNEL"),
                               (["--platform", "twitch"], "--source")):
            buffer = io.StringIO()
            with mock.patch.dict(os.environ, {k: v for k, v in os.environ.items() if not k.startswith("TWITCH_")}, clear=True):
                with redirect_stderr(buffer):
                    code = cli.main(argv)
            self.assertEqual(code, 2, argv)
            self.assertIn(fragment, buffer.getvalue(), argv)

    def test_bad_media_source_fails_before_any_clip(self):
        with tempfile.TemporaryDirectory() as tmp:
            buffer = io.StringIO()
            with mock.patch.dict(os.environ, {"TWITCH_CHANNEL": "somechannel"}, clear=True):
                with redirect_stderr(buffer):
                    code = cli.main(["--platform", "twitch", "--source", str(Path(tmp) / "missing.mp4"), "--seconds", "1"])
            self.assertEqual(code, 2)
            self.assertIn("readable local file", buffer.getvalue())


if __name__ == "__main__":
    unittest.main()
