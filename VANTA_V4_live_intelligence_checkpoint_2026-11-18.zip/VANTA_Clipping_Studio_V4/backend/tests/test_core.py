import sys
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


BACKEND=Path(__file__).resolve().parents[1]
if str(BACKEND) not in sys.path:
    sys.path.insert(0,str(BACKEND))

from app.planner import build_plan
from app.renderer import (
    _add_audio_tracks,
    _download_authorized_video,
    _existing_ai_clip_motion_score,
    _normalise_scenes,
    _parse_srt_time,
    _select_clip_windows,
    _slice_srt,
    _style_prompt,
    _video_shot_prompt,
    dims,
)
from app.schemas import CreateJobRequest, UpdateMetadataRequest


class PlannerTests(unittest.TestCase):
    def test_topic_fallback_keeps_user_subject(self):
        plan=build_plan(topic="volcano science",script=None,source_text=None,duration=30,style="documentary",input_type="topic")
        self.assertEqual(plan["planner"],"template_fallback")
        self.assertIn("volcano science",plan["script"])
        self.assertGreaterEqual(len(plan["scenes"]),2)

    def test_supplied_script_is_segmented_without_replacement(self):
        script="First fact. Second fact. Third fact."
        plan=build_plan(topic="",script=script,source_text=None,duration=15,style="minimal",input_type="script")
        self.assertEqual(plan["planner"],"text_segmentation")
        self.assertEqual(plan["script"],script)
        self.assertIn("Second fact", " ".join(scene["narration"] for scene in plan["scenes"]))


class RendererTests(unittest.TestCase):
    def test_private_direct_video_urls_are_rejected_before_request(self):
        with self.assertRaisesRegex(RuntimeError,"public IP"):
            _download_authorized_video("https://127.0.0.1/video.mp4",Path("unused.mp4"))

    def test_clip_windows_use_detected_scenes_and_are_timestamped(self):
        windows=_select_clip_windows(45,[(15,0.5),(30,0.6)],15,5)
        self.assertEqual(windows,[(0.0,15.0),(15.0,30.0),(30.0,45.0)])

    def test_clip_windows_include_a_short_final_interval_instead_of_dropping_remainder(self):
        windows=_select_clip_windows(25,[(15,0.8)],15,5)
        self.assertEqual(len(windows),2)
        self.assertEqual(windows[-1][1],25)
        self.assertTrue(all(end>start for start,end in windows))

    def test_scene_subtitles_are_trimmed_and_retimed_to_clip(self):
        with tempfile.TemporaryDirectory() as directory:
            source=Path(directory)/"source.srt"
            target=Path(directory)/"clip.srt"
            source.write_text(
                "1\n00:00:10,000 --> 00:00:12,000\nBefore\n\n"
                "2\n00:00:12,500 --> 00:00:16,000\nInside\n",
                encoding="utf-8",
            )
            self.assertTrue(_slice_srt(source,target,12,15))
            content=target.read_text(encoding="utf-8")
        self.assertNotIn("Before",content)
        self.assertIn("00:00:00,500 --> 00:00:03,000",content)
        self.assertEqual(_parse_srt_time("01:02.500"),62.5)

    def test_supported_styles_produce_distinct_video_prompt_guidance(self):
        self.assertIn("hand-painted illustrated",_style_prompt("illustrated"))
        self.assertIn("anime visual style",_style_prompt("anime"))
        self.assertIn("educational documentary",_style_prompt("educational"))

    def test_existing_ai_clip_is_reused_only_after_duration_and_motion_checks(self):
        with tempfile.TemporaryDirectory() as directory:
            clip=Path(directory)/"generated_clip_001.mp4"
            clip.write_bytes(b"x"*6000)
            probe=subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=json.dumps({"streams":[{"codec_type":"video"}],"format":{"duration":"1.0"}}),
                stderr="",
            )
            with patch("app.renderer.subprocess.run",return_value=probe), patch(
                "app.renderer._temporal_motion_score",return_value=0.42,
            ) as motion:
                score=_existing_ai_clip_motion_score("ffmpeg","ffprobe",clip,1.0)
        self.assertEqual(score,0.42)
        motion.assert_called_once_with("ffmpeg",clip,1.0)

    def test_existing_ai_clip_with_incomplete_duration_is_not_reused(self):
        with tempfile.TemporaryDirectory() as directory:
            clip=Path(directory)/"generated_clip_001.mp4"
            clip.write_bytes(b"x"*6000)
            probe=subprocess.CompletedProcess(
                args=[],
                returncode=0,
                stdout=json.dumps({"streams":[{"codec_type":"video"}],"format":{"duration":"0.2"}}),
                stderr="",
            )
            with patch("app.renderer.subprocess.run",return_value=probe), patch(
                "app.renderer._temporal_motion_score",
            ) as motion:
                score=_existing_ai_clip_motion_score("ffmpeg","ffprobe",clip,1.0)
        self.assertIsNone(score)
        motion.assert_not_called()

    def test_audio_tracks_mix_narration_music_and_sound_effects(self):
        command=["ffmpeg"]
        filters=[]
        has_audio=_add_audio_tracks(
            command,filters,3,15,
            Path("narration.wav"),Path("music.mp3"),Path("effects.wav"),
        )
        self.assertTrue(has_audio)
        self.assertIn("audio_narration", ";".join(filters))
        self.assertIn("volume=0.16", ";".join(filters))
        self.assertIn("volume=0.35", ";".join(filters))
        self.assertIn("amix=inputs=3", ";".join(filters))
        self.assertIn("-stream_loop",command)
        self.assertIn("effects.wav",command)

    def test_video_prompt_keeps_cat_character_visibly_feline(self):
        cat_prompt=_video_shot_prompt("Consistent cat chef at a food stall","Folding the omelette","medium action shot")
        other_prompt=_video_shot_prompt("Consistent flower seller","Arranging roses","close detail shot")
        self.assertIn("unmistakably feline",cat_prompt)
        self.assertIn("human customer separately",cat_prompt)
        self.assertNotIn("unmistakably feline",other_prompt)

    def test_dimensions_cover_supported_formats(self):
        self.assertEqual(dims("9:16","draft"),(360,640))
        self.assertEqual(dims("16:9","balanced"),(1280,720))
        self.assertEqual(dims("1:1","quality"),(1080,1080))

    def test_valid_edited_scene_timing_is_preserved(self):
        scenes=[
            {"title":"A","narration":"one","caption":"one","start_seconds":0,"end_seconds":4},
            {"title":"B","narration":"two","caption":"two","start_seconds":4,"end_seconds":10},
        ]
        normalized=_normalise_scenes(scenes,10)
        self.assertEqual([(item["start_seconds"],item["end_seconds"]) for item in normalized],[(0,4),(4,10)])

    def test_invalid_scene_timing_falls_back_to_even_split(self):
        scenes=[{"title":"A","narration":"one","start_seconds":3,"end_seconds":4},{"title":"B","narration":"two"}]
        normalized=_normalise_scenes(scenes,10)
        self.assertEqual(normalized[0]["start_seconds"],0)
        self.assertEqual(normalized[-1]["end_seconds"],10)


class SchemaTests(unittest.TestCase):
    def test_video_clips_require_source_and_rights_confirmation(self):
        from pydantic import ValidationError

        with self.assertRaises(ValidationError):
            CreateJobRequest(input_type="video_clips",source_upload_id="a"*32)
        request=CreateJobRequest(
            input_type="video_clips",
            source_upload_id="a"*32,
            source_authorized=True,
            generation_mode="motion_graphics",
        )
        self.assertEqual(request.clip_count,5)

    def test_sound_effect_upload_is_recorded_for_a_job(self):
        request=CreateJobRequest(topic="cat cooks",sound_effects_upload_id="a"*32)
        self.assertEqual(request.sound_effects_upload_id,"a"*32)

    def test_metadata_is_trimmed_and_empty_values_are_removed(self):
        metadata=UpdateMetadataRequest(titles=["  A title  ",""],description="desc",hashtags=[" #shorts ",""])
        self.assertEqual(metadata.titles,["A title"])
        self.assertEqual(metadata.hashtags,["#shorts"])


if __name__ == "__main__":
    unittest.main()
