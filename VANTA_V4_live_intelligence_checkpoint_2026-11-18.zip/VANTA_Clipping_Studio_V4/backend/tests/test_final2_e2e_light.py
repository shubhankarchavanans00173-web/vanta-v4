"""A short real-media Final2 workflow check designed for constrained CI."""
from __future__ import annotations

import json
import os
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import settings
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class Final2LightE2E(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.media = tempfile.TemporaryDirectory(prefix="vanta-final2-")
        self.video = make_video(Path(self.media.name) / "dialogue.mp4", duration=18, size="160x90")
        self.srt = Path(self.media.name) / "dialogue.srt"
        self.srt.write_text(
            "1\n00:00:00,200 --> 00:00:07,500\nHere is a compact spoken dialogue test with a useful lesson.\n\n"
            "2\n00:00:07,700 --> 00:00:16,800\nThe clear takeaway is to review every clip before sharing it.\n",
            encoding="utf-8",
        )
        self.env = mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "0"}, clear=False)
        self.env.start()
        from app.main import app
        self.client = TestClient(app)
        self.client.__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        self.env.stop()
        self.media.cleanup()
        self.tmp.cleanup()

    def _wait(self, jid: str, wanted: set[str], timeout: float = 25) -> dict:
        end, last = time.time() + timeout, {}
        while time.time() < end:
            last = self.client.get("/api/vanta/jobs/" + jid).json()
            if last["status"] in wanted:
                return last
            if last["status"] in {"failed", "cancelled"}:
                self.fail(str(last))
            time.sleep(0.15)
        self.fail("job did not settle: " + str(last))

    def test_local_authorised_workflow_is_persistent_and_never_uploads(self):
        files = {
            "file": ("dialogue.mp4", self.video.read_bytes(), "video/mp4"),
            "transcript": ("dialogue.srt", self.srt.read_bytes(), "text/plain"),
        }
        project = self.client.post("/api/vanta/projects/upload", files=files, data={"name": "Final2 dialogue"}).json()
        self.assertTrue(project["has_transcript"])
        analyzed = self.client.post("/api/vanta/projects/" + project["id"] + "/analyze", json={"target_duration": 10, "count": 1, "transcribe": False})
        self.assertEqual(analyzed.status_code, 200, analyzed.text)
        self._wait(analyzed.json()["id"], {"awaiting_approval"})
        current = self.client.get("/api/vanta/projects/" + project["id"]).json()
        candidate = current["candidates"][0]
        self.assertTrue(candidate["analysis"]["summary"])
        approved = self.client.patch("/api/vanta/candidates/" + candidate["id"], json={"status": "approved"})
        self.assertEqual(approved.status_code, 200)
        rendered = self.client.post(
            "/api/vanta/projects/" + project["id"] + "/render",
            json={"candidate_ids": [candidate["id"]], "settings": {
                "aspect": "9:16", "captions": True, "fps": 15, "preset": "ultrafast",
                "caption_style": {"mode": "clean", "max_words_per_line": 6},
            }},
        )
        self.assertEqual(rendered.status_code, 200, rendered.text)
        done = self._wait(rendered.json()["id"], {"completed"})
        self.assertEqual(len(done["result"]["exported"]), 1)
        exported = self.client.get("/api/vanta/exports").json()[0]
        self.assertTrue(exported["validation"]["valid"])
        raw = self.client.get("/api/vanta/exports/" + exported["id"] + "/download")
        self.assertEqual((raw.status_code, raw.content[4:8]), (200, b"ftyp"))
        probe = json.loads(subprocess.run(
            ["ffprobe", "-v", "error", "-print_format", "json", "-show_streams", str(settings.EXPORT_DIR / project["id"] / exported["filename"])],
            check=True, capture_output=True, text=True,
        ).stdout)
        video = next(s for s in probe["streams"] if s["codec_type"] == "video")
        self.assertEqual((video["codec_name"], video["width"], video["height"]), ("h264", 1080, 1920))
        refreshed = self.client.get("/api/vanta/projects/" + project["id"]).json()
        self.assertEqual(len(refreshed["exports"]), 1)
        upload = self.client.get("/api/vanta/exports/" + exported["id"] + "/youtube").json()
        self.assertEqual(upload["state"], "not_started")


if __name__ == "__main__":
    unittest.main()
