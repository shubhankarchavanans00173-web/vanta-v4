"""The local review panel's backend: list live clip sidecars, play one, promote a reviewed one.

The app runs in a different process from the live CLI, so the only shared truth is the sidecar the pipeline writes.
These tests cover that contract plus the safety rules: ids instead of paths, server-side file resolution, one
promotion per clip, and no promotion before a clip is ready.
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import db, settings
from app.clipstudio.live import clip_store, handoff
from app.clipstudio.live.live_clip_worker import LiveClipError
from app.clipstudio.live.review_pipeline import LiveReviewPipeline, clips_dir
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video

SRT = b"1\n00:00:00,200 --> 00:00:02,600\nThis is the reviewed moment.\n"


class _Unavailable:
    def available(self):
        return False, "faster-whisper is not installed"

    def transcribe(self, *args, **kwargs):  # pragma: no cover
        raise AssertionError("must not transcribe")


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class LiveClipApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.clips = clips_dir(settings.BASE)
        self.clips.mkdir(parents=True, exist_ok=True)
        self.clip = make_video(self.clips / "ready.mp4", duration=2, size="160x90")
        self.ready = {"id": "sess-1-00001250-chat-spike", "session_id": "sess-1", "status": "ready_for_review",
                      "path": str(self.clip), "duration": 2.0, "segments": 3, "coverage": {"ready": True},
                      "event": {"kind": "chat_spike", "event_time": 12.5, "confidence": 82},
                      "requested_at": 0.0, "finished_at": 2.4, "error": None,
                      "review_only": True, "published": False}
        clip_store.write(self.clips, self.ready)
        self.waiting = {**self.ready, "id": "sess-1-00002000-loudness", "status": "waiting", "path": None,
                        "event": {"kind": "loudness", "event_time": 20.0, "confidence": 55}}
        clip_store.write(self.clips, self.waiting)
        self.env = mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "0"}, clear=False)
        self.env.start()
        from app.main import app
        self.client = TestClient(app)
        self.client.__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        self.env.stop()
        self.tmp.cleanup()

    def test_list_shows_clips_by_id_without_paths(self):
        body = self.client.get("/api/vanta/live/clips").json()
        self.assertEqual(body["count"], 2)
        self.assertTrue(body["review_only"])
        ids = {c["id"] for c in body["clips"]}
        self.assertIn(self.ready["id"], ids)
        serialized = json.dumps(body)
        self.assertNotIn(str(self.clip), serialized)
        self.assertNotIn("path", serialized)
        ready = next(c for c in body["clips"] if c["id"] == self.ready["id"])
        self.assertTrue(ready["file_ready"])
        self.assertFalse(ready["published"])
        self.assertEqual(ready["event"]["kind"], "chat_spike")

    def test_file_endpoint_streams_the_assembled_clip(self):
        r = self.client.get(f"/api/vanta/live/clips/{self.ready['id']}/file")
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(r.headers["content-type"], "video/mp4")
        self.assertIn(b"ftyp", r.content[:64])
        missing = self.client.get(f"/api/vanta/live/clips/{self.waiting['id']}/file")
        self.assertEqual(missing.status_code, 404)
        traversal = self.client.get("/api/vanta/live/clips/..%2F..%2Fvanta.db/file")
        self.assertEqual(traversal.status_code, 404)

    def test_promote_with_transcript_creates_a_project_and_marks_the_sidecar(self):
        r = self.client.post(f"/api/vanta/live/clips/{self.ready['id']}/promote",
                             files={"transcript": ("clip.srt", SRT, "text/plain")}, data={"title": "Reviewed moment"})
        self.assertEqual(r.status_code, 200, r.text)
        payload = r.json()
        self.assertFalse(payload["published"])
        self.assertTrue(payload["review_only"])
        project = db.get_project(payload["project_id"])
        self.assertEqual(project["source_type"], "live")
        self.assertEqual(project["name"], "Reviewed moment")
        self.assertTrue(project["has_transcript"] if "has_transcript" in project else bool(project["transcript_path"]))
        cand = db.get_candidate(payload["candidate_id"])
        self.assertEqual((cand["status"], cand["origin"]), ("approved", "live"))

        stored = clip_store.read(self.clips, self.ready["id"])
        self.assertEqual(stored["project_id"], payload["project_id"])
        self.assertFalse(stored["published"])
        listed = self.client.get("/api/vanta/live/clips").json()["clips"]
        self.assertEqual(next(c for c in listed if c["id"] == self.ready["id"])["project_id"], payload["project_id"])

        again = self.client.post(f"/api/vanta/live/clips/{self.ready['id']}/promote",
                                 files={"transcript": ("clip.srt", SRT, "text/plain")})
        self.assertEqual(again.status_code, 409)
        self.assertEqual(again.json()["detail"]["code"], "blocked")
        self.assertEqual(len(db.list_projects()), 1)

    def test_promote_without_transcript_refuses_clearly_when_no_engine_is_ready(self):
        with mock.patch.object(handoff, "get_engine", lambda name: _Unavailable()):
            r = self.client.post(f"/api/vanta/live/clips/{self.ready['id']}/promote")
        self.assertEqual(r.status_code, 400)
        detail = r.json()["detail"]
        self.assertEqual(detail["code"], "no_transcript")
        self.assertIn("Nothing was created", detail["hint"])
        self.assertEqual(db.list_projects(), [])
        self.assertIsNone(clip_store.read(self.clips, self.ready["id"]).get("project_id"))

    def test_promote_with_a_windows_traversal_id_and_transcript_upload_writes_nothing(self):
        from app.clipstudio.routes import live as live_routes
        before = set(settings.TMP_DIR.glob("*"))
        evil = "..%5C..%5Cevil"                     # decoded to ..\..\evil by the path parameter
        with mock.patch.object(live_routes, "_save_upload", wraps=live_routes._save_upload) as save:
            r = self.client.post(f"/api/vanta/live/clips/{evil}/promote",
                                 files={"transcript": ("clip.srt", SRT, "text/plain")})
        self.assertEqual(r.status_code, 404)
        save.assert_not_called()                    # the id is rejected before the upload is read at all
        self.assertEqual(set(settings.TMP_DIR.glob("*")) - before, set())
        for stray in (settings.TMP_DIR / "evil.srt", settings.BASE / "evil.srt", settings.BASE.parent / "evil.srt"):
            self.assertFalse(stray.exists(), stray)
        self.assertEqual(db.list_projects(), [])

    def test_promote_before_ready_or_with_a_bad_id_is_refused(self):
        early = self.client.post(f"/api/vanta/live/clips/{self.waiting['id']}/promote",
                                 files={"transcript": ("clip.srt", SRT, "text/plain")})
        self.assertEqual(early.status_code, 409)
        self.assertEqual(early.json()["detail"]["code"], "blocked")
        bad = self.client.post("/api/vanta/live/clips/..%2F..%2Fevil/promote")
        self.assertEqual(bad.status_code, 404)
        self.assertEqual(db.list_projects(), [])

    def test_store_refuses_traversal_ids_and_paths_outside_the_clip_folder(self):
        from app.clipstudio.live.handoff import HandoffError
        (self.clips.parent / "evil.job.json").write_text(
            json.dumps({**self.ready, "id": "evil", "path": str(self.clip)}), encoding="utf-8")
        with self.assertRaises(HandoffError) as ctx:
            clip_store.read(self.clips, "../evil")          # a sidecar one level up must stay unreachable
        self.assertEqual(ctx.exception.code, "not_found")
        outside = tempfile.TemporaryDirectory(prefix="vanta-foreign-")
        self.addCleanup(outside.cleanup)
        foreign = make_video(Path(outside.name) / "foreign.mp4", duration=1, size="160x90")
        clip_store.write(self.clips, {**self.ready, "id": "sess-9-foreign", "path": str(foreign)})
        self.assertEqual(self.client.get("/api/vanta/live/clips/sess-9-foreign/file").status_code, 404)

    def test_store_requires_explicit_review(self):
        from app.clipstudio.live.handoff import HandoffError
        from app.clipstudio.transcript import Segment, Transcript
        with self.assertRaises(HandoffError) as ctx:
            clip_store.promote(self.clips, self.ready["id"], reviewed=False,
                               transcript=Transcript([Segment(0.1, 1.0, "Not reviewed")], "subtitle-file"))
        self.assertEqual(ctx.exception.code, "not_reviewed")
        self.assertEqual(db.list_projects(), [])

    def test_pipeline_writes_and_updates_the_sidecar_it_promotes(self):
        live = LiveReviewPipeline.__new__(LiveReviewPipeline)
        live._jobs = {"j1": {"id": "j1", "status": "ready_for_review", "path": str(self.clip), "session_id": "s1",
                             "event": {"kind": "chat_spike"}, "project_id": None}}
        live._lock = threading.RLock()
        live._store_dir = self.clips
        live._set("j1", status="assembling")
        self.assertEqual(clip_store.read(self.clips, "j1")["status"], "assembling")
        live._set("j1", status="ready_for_review")

        from app.clipstudio.transcript import Segment, Transcript
        payload = live.promote("j1", reviewed=True,
                               transcript=Transcript([Segment(0.2, 1.8, "Reviewed moment")], "subtitle-file"))
        stored = clip_store.read(self.clips, "j1")
        self.assertEqual(stored["project_id"], payload["project_id"])
        self.assertEqual(stored["candidate_id"], payload["candidate_id"])
        with self.assertRaises(LiveClipError):
            live.promote("j1", reviewed=True, transcript=Transcript([Segment(0, 1, "x")], "subtitle-file"))


if __name__ == "__main__":
    unittest.main()
