"""Caption acceptance tests. They render REAL MP4s with the local FFmpeg and inspect REAL frames.

A subtitle file existing or FFmpeg exiting 0 is never treated as proof: captions count as visible only when glyph
pixels measurably differ from an otherwise identical render with captions off (independent of capfx's own verifier).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from PIL import Image, ImageChops

from app.clipstudio import capfx, captions, render
from app.clipstudio.errors import CaptionError, RenderError
from app.clipstudio.media import probe
from app.clipstudio.render import RenderSettings, render_clip
from app.clipstudio.transcript import Segment, Transcript, Word, parse_subtitles
from tests.vanta_fixtures import HAVE_FFMPEG, make_video

SRT = """1
00:00:00,300 --> 00:00:04,000
Here is the one mistake that ruins most first videos.

2
00:00:04,200 --> 00:00:09,500
Most people never check their audio before they hit record.
"""
VTT = "WEBVTT\n\n00:00.300 --> 00:04.000\nHere is the one mistake that ruins most first videos.\n\n00:04.200 --> 00:09.500\nMost people never check their audio before they hit record.\n"


def frame_at(video: Path, t: float, out: Path) -> Image.Image:
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", str(video), "-frames:v", "1", str(out)], check=True)
    return Image.open(out).convert("RGB")


def band_diff(a: Image.Image, b: Image.Image, top: float = 0.62, bottom: float = 0.95, thr: int = 60) -> int:
    """Pixels in the lower caption band whose luma differs by more than ``thr`` between two frames."""
    w, h = a.size
    box = (0, int(h * top), w, int(h * bottom))
    d = ImageChops.difference(a, b).convert("L").crop(box).point(lambda v: 255 if v > thr else 0)
    return d.histogram()[255]


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class CaptionRenderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dir = tempfile.TemporaryDirectory(prefix="vanta caption tests ")      # NOTE the space in the path
        cls.root = Path(cls.dir.name)
        cls.src = make_video(cls.root / "source talk.mp4", duration=20, size="1280x720")
        cls.info = probe(cls.src)
        cls.tr = Transcript(parse_subtitles(SRT), "subtitle-file")

    @classmethod
    def tearDownClass(cls):
        cls.dir.cleanup()

    def render(self, name, start=0.0, end=9.5, transcript=None, **kw):
        out = self.root / f"{name}.mp4"
        res = render_clip(self.src, out, self.root / f"tmp_{name}", start, end, self.info, RenderSettings(**kw),
                          self.tr if transcript is None else transcript)
        return out, res

    def baseline(self, start=0.0, end=9.5, **kw):
        """Same render with captions off - the independent reference for pixel comparisons."""
        out, _ = self.render(f"base_{start}_{end}_{abs(hash(str(kw)))}", start, end, captions=False, **kw)
        return out

    # 1 + 12 ---------------------------------------------------------------------------------------------
    def test_01_captions_enabled_are_visible_in_exported_mp4(self):
        out, res = self.render("on", 0.0, 9.5, captions=True)
        base = self.baseline(0.0, 9.5)
        t = 2.0                                                  # inside caption 1 (0.3-4.0)
        on, off = frame_at(out, t, self.root / "on.png"), frame_at(base, t, self.root / "off.png")
        changed = band_diff(on, off)
        self.assertGreater(changed, 5000, "caption pixels must appear in the exported frame")
        self.assertTrue(res["caption_verification"]["visible"])
        # output file is real, non-empty and has both streams at the requested size
        info = probe(out)
        self.assertGreater(out.stat().st_size, 10_000)
        self.assertEqual((info["width"], info["height"]), (1080, 1920))
        self.assertTrue(info["has_audio"]); self.assertEqual(info["video_codec"], "h264")
        self.assertTrue(res["validation"]["valid"])

    def test_02_captions_disabled_have_no_caption_pixels_and_verifier_notices(self):
        out, res = self.render("off", 0.0, 9.5, captions=False)
        self.assertEqual(res["captions_granularity"], "none")
        self.assertFalse((self.root / "tmp_off" / "captions.ass").exists())
        # negative control: the same probe that proves visibility must say "not visible" for an uncaptioned frame
        on_out, _ = self.render("on2", 0.0, 9.5, captions=True)
        probe_png = self.root / "tmp_on2" / "caption_probe.png"
        probe_png.parent.mkdir(exist_ok=True)
        # the working dir is removed only by the pipeline, so the probe is still on disk here
        self.assertTrue(probe_png.exists())
        frame_at(out, 2.0, self.root / "uncaptioned.png")
        cmp = capfx.compare_frame_to_probe(self.root / "uncaptioned.png", probe_png)
        self.assertFalse(cmp["visible"], cmp)

    # 3 --------------------------------------------------------------------------------------------------
    def test_03_missing_transcript_with_captions_requested_fails_loudly(self):
        for tr in (None, Transcript()):
            with self.assertRaises(CaptionError) as cm:
                render_clip(self.src, self.root / "x.mp4", self.root / "tmp_x", 0, 9, self.info, RenderSettings(captions=True), tr)
            self.assertEqual(cm.exception.code, "no_transcript")
            self.assertIn("transcript", str(cm.exception))
        self.assertFalse((self.root / "x.mp4").exists())

    def test_03b_no_speech_in_clip_range_fails_loudly(self):
        with self.assertRaises(CaptionError) as cm:
            render_clip(self.src, self.root / "y.mp4", self.root / "tmp_y", 12, 19, self.info, RenderSettings(captions=True), self.tr)
        self.assertEqual(cm.exception.code, "no_speech_in_range")
        self.assertFalse((self.root / "y.mp4").exists())

    # 4 --------------------------------------------------------------------------------------------------
    def test_04_srt_and_vtt_parse_to_identical_segments_and_render(self):
        a, b = parse_subtitles(SRT), parse_subtitles(VTT)
        self.assertEqual([(round(s.start, 2), round(s.end, 2), s.text) for s in a], [(round(s.start, 2), round(s.end, 2), s.text) for s in b])
        out, res = self.render("vtt", 0.0, 9.5, transcript=Transcript(b, "subtitle-file"), captions=True)
        self.assertTrue(res["caption_verification"]["visible"])

    # 5 --------------------------------------------------------------------------------------------------
    def test_05_sentence_level_track(self):
        track = captions.build_track(self.tr, 0.0, 9.5)
        self.assertEqual(track.granularity, "sentence")
        self.assertEqual([e.text for e in track.events][0], "Here is the one mistake that ruins most first videos.")

    # 6 --------------------------------------------------------------------------------------------------
    def test_06_word_level_track_highlights_and_is_visible(self):
        toks = "Here is the one mistake that ruins most first videos".split()
        words = [Word(w, 0.3 + i * 0.3, 0.3 + i * 0.3 + 0.28) for i, w in enumerate(toks)]
        tr = Transcript([Segment(0.3, 3.6, " ".join(toks), words)], "faster-whisper")
        track = captions.build_track(tr, 0.0, 4.0, None, 3)
        self.assertEqual(track.granularity, "word")
        out, res = self.render("word", 0.0, 4.0, transcript=tr, captions=True)
        ass = (self.root / "tmp_word" / "captions.ass").read_text(encoding="utf-8")
        self.assertIn("\\c&H", ass)                                  # per-word highlight colour is really in the file
        self.assertTrue(res["caption_verification"]["visible"])
        self.assertEqual(res["captions_granularity"], "word")

    # 7 --------------------------------------------------------------------------------------------------
    def test_07_non_zero_clip_start_is_retimed_to_clip_zero(self):
        track = captions.build_track(self.tr, 4.2, 9.5)
        self.assertAlmostEqual(track.events[0].start, 0.0, places=2)           # source 4.2 s -> clip 0 s
        self.assertAlmostEqual(track.events[0].end, 5.3, places=2)
        out, res = self.render("shift", 4.2, 9.5, captions=True)
        base = self.baseline(4.2, 9.5)
        self.assertGreater(band_diff(frame_at(out, 1.0, self.root / "s_on.png"), frame_at(base, 1.0, self.root / "s_off.png")), 5000)
        # after the (only) caption ends nothing should be left: last 0.1 s of a clip that ends with the caption
        self.assertAlmostEqual(res["duration"], 5.3, delta=0.4)

    def test_07b_caption_absent_before_it_starts(self):
        # clip 0-9.5: caption 1 starts at 0.3 -> frame at 0.1 s must have no caption pixels, frame at 2 s must
        out, _ = self.render("early", 0.0, 9.5, captions=True)
        base = self.baseline(0.0, 9.5)
        self.assertLess(band_diff(frame_at(out, 0.1, self.root / "e1.png"), frame_at(base, 0.1, self.root / "e2.png")), 1500)
        self.assertGreater(band_diff(frame_at(out, 2.0, self.root / "e3.png"), frame_at(base, 2.0, self.root / "e4.png")), 5000)

    # 8 --------------------------------------------------------------------------------------------------
    def test_08_unicode_and_punctuation(self):
        text = "Café – naïve “quotes” it's 100% [ok], {braces}; ¿Qué? Привет, мир! 50\\50 a:b 'x'"
        tr = Transcript([Segment(0.3, 4.0, text)], "subtitle-file")
        out, res = self.render("uni", 0.0, 5.0, transcript=tr, captions=True)
        self.assertTrue(res["caption_verification"]["visible"])
        ass = (self.root / "tmp_uni" / "captions.ass").read_text(encoding="utf-8")
        self.assertIn("Café", ass); self.assertIn("Привет", ass); self.assertNotIn("{braces}", ass)   # braces would be ASS override blocks

    # 9 --------------------------------------------------------------------------------------------------
    def test_09_paths_with_spaces_apostrophes_and_unicode(self):
        odd = self.root / "dir with spaces & it's ünï [x],y"
        odd.mkdir()
        src = odd / "my video's source.mp4"
        shutil.copy(self.src, src)
        out = odd / "out put.mp4"
        res = render_clip(src, out, odd / "tmp dir", 0.0, 9.5, self.info, RenderSettings(captions=True), self.tr)
        self.assertTrue(out.exists()); self.assertTrue(res["caption_verification"]["visible"])

    def test_09b_windows_filter_path_escaping(self):
        self.assertEqual(capfx.escape_filter_value(r"C:\Users\Me\it's [a],b;c.ass"), r"C\:/Users/Me/it\'s \[a\]\,b\;c.ass")
        self.assertEqual(capfx.ass_filter("captions.ass", "fonts"), "ass=captions.ass:fontsdir=fonts")
        self.assertEqual(capfx.ass_filter("captions.ass", r"C:\Windows\Fonts"), r"ass=captions.ass:fontsdir=C\:/Windows/Fonts")

    # 10 -------------------------------------------------------------------------------------------------
    def test_10_ffmpeg_missing(self):
        with mock.patch("app.clipstudio.render.shutil.which", return_value=None):
            with self.assertRaises(RenderError) as cm:
                render_clip(self.src, self.root / "z.mp4", self.root / "tmp_z", 0, 9, self.info, RenderSettings(captions=True), self.tr)
        self.assertIn("FFmpeg was not found", str(cm.exception))

    def test_10b_subtitle_filter_unavailable(self):
        with mock.patch.object(capfx, "ass_filter", lambda name, fontsdir: "nonexistent_subtitle_filter=1"):
            with self.assertRaises(CaptionError) as cm:
                render_clip(self.src, self.root / "w.mp4", self.root / "tmp_w", 0, 9, self.info, RenderSettings(captions=True), self.tr)
        self.assertEqual(cm.exception.code, "ass_filter_unavailable")
        self.assertIn("libass", str(cm.exception)); self.assertFalse((self.root / "w.mp4").exists())

    def test_10c_libass_cannot_draw_glyphs_is_an_error_not_a_silent_success(self):
        with mock.patch.object(capfx, "MIN_GLYPH_PIXELS", 10 ** 9):      # simulate "libass drew nothing"
            with self.assertRaises(CaptionError) as cm:
                render_clip(self.src, self.root / "v.mp4", self.root / "tmp_v", 0, 9, self.info, RenderSettings(captions=True), self.tr)
        self.assertEqual(cm.exception.code, "no_glyphs"); self.assertFalse((self.root / "v.mp4").exists())

    def test_10d_renders_captions_even_when_system_has_no_fonts(self):
        """The original silent failure: libass with an empty fontconfig. The bundled fonts must rescue it."""
        conf = self.root / "empty_fonts.conf"
        conf.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig></fontconfig>')
        with mock.patch.dict(os.environ, {"FONTCONFIG_FILE": str(conf)}):
            out, res = self.render("nofonts", 0.0, 9.5, captions=True)
        base = self.baseline(0.0, 9.5)
        self.assertGreater(band_diff(frame_at(out, 2.0, self.root / "nf_on.png"), frame_at(base, 2.0, self.root / "nf_off.png")), 5000)

    def test_10e_final_frame_check_discards_uncaptioned_output(self):
        """If the export somehow lacks captions, the file is discarded instead of delivered."""
        real = capfx.compare_frame_to_probe
        with mock.patch.object(capfx, "compare_frame_to_probe", lambda f, p: {**real(f, p), "visible": False, "match_ratio": 0.0}):
            with self.assertRaises(CaptionError) as cm:
                render_clip(self.src, self.root / "u.mp4", self.root / "tmp_u", 0, 9, self.info, RenderSettings(captions=True), self.tr)
        self.assertEqual(cm.exception.code, "captions_not_visible")
        self.assertFalse((self.root / "u.mp4").exists())
        self.assertTrue((self.root / "tmp_u" / "FAILED_render.mp4").exists())       # evidence is preserved

    # aspect ratios --------------------------------------------------------------------------------------
    def test_11_all_aspects_have_verified_captions(self):
        for aspect, size in (("9:16", (1080, 1920)), ("1:1", (1080, 1080)), ("16:9", (1920, 1080))):
            with self.subTest(aspect=aspect):
                out, res = self.render(f"asp{aspect.replace(':', 'x')}", 0.0, 9.5, captions=True, aspect=aspect)
                info = probe(out)
                self.assertEqual((info["width"], info["height"]), size)
                self.assertTrue(res["caption_verification"]["visible"], res["caption_verification"])

    def test_12_style_options_are_applied(self):
        out, res = self.render("styled", 0.0, 9.5, captions=True, caption_style={
            "font_size_pct": 6.0, "position": "top", "margin_pct": 8, "color": "#00FF00", "uppercase": True, "background": True})
        ass = (self.root / "tmp_styled" / "captions.ass").read_text(encoding="utf-8")
        self.assertIn("HERE IS THE ONE MISTAKE", ass)
        self.assertTrue(res["caption_verification"]["visible"])
        on, base = frame_at(out, 2.0, self.root / "st_on.png"), frame_at(self.baseline(0.0, 9.5), 2.0, self.root / "st_off.png")
        self.assertGreater(band_diff(on, base, top=0.02, bottom=0.30), 3000)         # top position really used
        self.assertLess(band_diff(on, base, top=0.75, bottom=0.95), 1500)           # ...and nothing at the bottom

    def test_13_long_whisper_style_segment_partially_inside_clip(self):
        tr = Transcript([Segment(0.0, 20.0, "This is one long segment produced by a speech recogniser that spans well beyond the clip we are exporting today")], "faster-whisper")
        out, res = self.render("longseg", 4.0, 12.0, transcript=tr, captions=True)
        self.assertTrue(res["caption_verification"]["visible"])
        self.assertIn("estimated", res["captions_note"])

    def test_14_safe_area_captions_stay_inside_frame(self):
        out, res = self.render("safe", 0.0, 9.5, captions=True, caption_style={"position": "bottom", "margin_pct": 14})
        mask = capfx.glyph_mask(self.root / "tmp_safe" / "caption_probe.png")
        l, t, r, b = mask.getbbox()
        self.assertGreater(l, 1080 * 0.03); self.assertLess(r, 1080 * 0.97); self.assertLess(b, 1920 * 0.95)


if __name__ == "__main__":
    unittest.main()
