import json
import os
import stat
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest import mock

import httpx

from app.clipstudio import analysis, captions, cost, db, links, pipeline, render, settings, router as vanta_router
from app.clipstudio.timeutil import TimeError, format_timestamp, parse_timestamp, validate_range
from app.clipstudio.transcript import Segment, Transcript, TranscriptError, Word, load_transcript_file, parse_json_transcript, parse_subtitles
from tests.vanta_fixtures import HAVE_FFMPEG, SCRIPT, isolate, make_video, script_srt


def script_transcript(words: bool = False) -> Transcript:
    segs = []
    for a, b, t in SCRIPT:
        ws = None
        if words:
            toks = t.split()
            step = (b - a) / len(toks)
            ws = [Word(w, a + i * step, a + (i + 1) * step - 0.02) for i, w in enumerate(toks)]
        segs.append(Segment(a, b, t, ws))
    return Transcript(segs, "test")


class TimeTests(unittest.TestCase):
    def test_parse_formats(self):
        for raw, want in [(12, 12.0), ("12.5", 12.5), ("1:02", 62.0), ("1:02.5", 62.5), ("01:02:03.250", 3723.25), ("00:00:05,500", 5.5), ("1m2.5s", 62.5), ("2h", 7200.0)]:
            self.assertEqual(parse_timestamp(raw), want, raw)

    def test_parse_rejects_garbage(self):
        for raw in ["", "abc", "-5", "1:99", "1:2:3:4", None, True, float("nan"), float("inf")]:
            with self.assertRaises(TimeError, msg=repr(raw)):
                parse_timestamp(raw)

    def test_format_roundtrip(self):
        self.assertEqual(format_timestamp(62.5), "1:02.500")
        self.assertEqual(parse_timestamp(format_timestamp(3723.25)), 3723.25)

    def test_clip_duration_limits(self):
        self.assertEqual(validate_range("0:10", "0:40", 100), (10.0, 40.0))
        with self.assertRaises(TimeError): validate_range(10, 10, 100)           # zero length
        with self.assertRaises(TimeError): validate_range(20, 10, 100)           # end before start
        with self.assertRaises(TimeError): validate_range(0, 2, 100)             # shorter than minimum
        with self.assertRaises(TimeError): validate_range(0, 181, 500)           # longer than a Short
        with self.assertRaises(TimeError): validate_range(90, 120, 100)          # beyond the video
        with self.assertRaises(TimeError): validate_range(100, 110, 100)         # start at/after the end
        self.assertEqual(validate_range(80, 100.02, 100), (80.0, 100.0))         # tiny overshoot is clamped


class TranscriptTests(unittest.TestCase):
    def test_srt_and_vtt(self):
        srt = parse_subtitles(script_srt())
        self.assertEqual(len(srt), len(SCRIPT))
        self.assertAlmostEqual(srt[0].start, 0.3)
        vtt = "WEBVTT\n\n00:00:01.000 --> 00:00:03.000\n<c>Hello</c> &amp; welcome\n\n00:00:03.000 --> 00:00:04.000\nHello &amp; welcome\n"
        segs = parse_subtitles(vtt)
        self.assertEqual(len(segs), 1)                       # exact repeat merged (auto-caption style)
        self.assertEqual(segs[0].text, "Hello & welcome")
        self.assertIsNone(segs[0].words)

    def test_json_with_words(self):
        data = {"segments": [{"start": 0, "end": 2, "text": "Hi there", "words": [{"word": "Hi", "start": 0, "end": .5}, {"word": "there", "start": .6, "end": 1.2}]}]}
        segs = parse_json_transcript(json.dumps(data))
        self.assertEqual(len(segs[0].words), 2)
        with self.assertRaises(TranscriptError): parse_json_transcript("{bad")
        with self.assertRaises(TranscriptError): parse_json_transcript(json.dumps({"segments": [{"text": "x"}]}))

    def test_missing_and_invalid_files(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(TranscriptError): load_transcript_file(Path(d) / "nope.srt")
            bad = Path(d) / "a.txt"; bad.write_text("x")
            with self.assertRaises(TranscriptError): load_transcript_file(bad)
            empty = Path(d) / "e.srt"; empty.write_text("not subtitles")
            with self.assertRaises(TranscriptError): load_transcript_file(empty)

    def test_word_level_flag(self):
        self.assertFalse(script_transcript(False).word_level)
        self.assertTrue(script_transcript(True).word_level)
        self.assertFalse(Transcript().available)


class AnalysisTests(unittest.TestCase):
    def test_units_merge_fragments_into_sentences(self):
        tr = Transcript([Segment(0, 2, "So the reason"), Segment(2.2, 4, "is simple."), Segment(5, 7, "Next point here.")])
        units = analysis.build_units(tr)
        self.assertEqual([u.text for u in units], ["So the reason is simple.", "Next point here."])

    def test_hook_scores_above_dangling_filler(self):
        units = analysis.build_units(script_transcript())
        hook = next(i for i, u in enumerate(units) if u.text.startswith("Here is the one mistake"))
        filler = next(i for i, u in enumerate(units) if u.text.startswith("And then"))
        s_hook, r_hook, _ = analysis.score_window(units, hook, hook + 1, 15, None, [])
        s_fill, r_fill, _ = analysis.score_window(units, filler, filler, 15, units[filler - 1].end, [])
        self.assertGreater(s_hook, s_fill + 15)
        self.assertTrue(any("opening" in r.lower() or "opens" in r.lower() for r in r_hook))
        self.assertTrue(any("mid-thought" in r for r in r_fill))

    def test_suggestions_are_sentence_aligned_and_non_overlapping(self):
        cands = analysis.suggest_clips(70, script_transcript(), [(10, 12), (22, 24)], [], target=15, count=5)
        self.assertTrue(cands)
        units = analysis.build_units(script_transcript())
        starts, ends = [u.start for u in units], [u.end for u in units]
        for c in cands:
            self.assertEqual(c.method, "transcript-heuristic")
            self.assertTrue(any(abs(c.start - s) <= 0.21 for s in starts), f"start {c.start} not on a sentence start")
            self.assertTrue(any(abs(c.end - e) <= 0.31 for e in ends), f"end {c.end} not on a sentence end")
            self.assertTrue(c.reasons)
            self.assertTrue(0 <= c.score <= 100)
            self.assertTrue(c.excerpt)
        for i, a in enumerate(cands):
            for b in cands[i + 1:]:
                self.assertLessEqual(analysis._overlap(a, b), analysis.MAX_OVERLAP + 1e-9)
        self.assertEqual([c.score for c in cands], sorted((c.score for c in cands), reverse=True))

    def test_target_duration_is_respected(self):
        for target in (15, 30, 45):
            lo, hi = analysis.length_bounds(target, 70)
            for c in analysis.suggest_clips(70, script_transcript(), [], [], target=target, count=3):
                self.assertGreaterEqual(c.duration, lo - 0.7)
                self.assertLessEqual(c.duration, hi + 0.7)

    def test_missing_transcript_uses_labelled_fallback(self):
        cands = analysis.suggest_clips(70, None, [(10, 12), (22, 24), (34, 36)], [(5.0, .6)], target=15, count=3)
        self.assertTrue(cands)
        for c in cands:
            self.assertEqual(c.method, "audio-visual-heuristic")
            self.assertEqual(c.excerpt, "")
            self.assertIn("No transcript", c.reasons[0])
        self.assertEqual(analysis.suggest_clips(70, Transcript(), [], [], 15, 3)[0].method, "audio-visual-heuristic")

    def test_too_short_video_has_no_suggestions(self):
        self.assertEqual(analysis.suggest_clips(2, None), [])

    def test_score_is_not_presented_as_virality(self):
        self.assertIn("not a prediction", analysis.SCORE_DISCLAIMER)


class CaptionTests(unittest.TestCase):
    def test_word_level_retimed_to_clip(self):
        tr = script_transcript(words=True)
        track = captions.build_track(tr, 24.3, 34.0, None, max_words=3)
        self.assertEqual(track.granularity, "word")
        self.assertAlmostEqual(track.events[0].words[0][1], 0.0, places=2)      # first word starts at clip time 0
        self.assertTrue(all(0 <= e.start < e.end <= 9.8 for e in track.events))
        texts = " ".join(e.text for e in track.events)
        self.assertIn("remember", texts); self.assertNotIn("mistake", texts)    # words outside the window excluded

    def test_sentence_level_fallback_is_labelled_and_has_no_word_timings(self):
        track = captions.build_track(script_transcript(False), 0.0, 10.0)
        self.assertEqual(track.granularity, "sentence")
        self.assertIn("no word timings", track.note)
        self.assertTrue(all(e.words is None for e in track.events))
        self.assertEqual(len(track.events), 2)

    def test_partial_sentences_are_dropped_in_sentence_mode(self):
        track = captions.build_track(script_transcript(False), 8.0, 20.0)      # only 1.5 s of the 5.3 s sentence is inside
        self.assertNotIn("Most people", " ".join(e.text for e in track.events))

    def test_no_transcript_no_captions(self):
        self.assertEqual(captions.build_track(None, 0, 10).granularity, "none")
        self.assertEqual(captions.build_track(Transcript(), 0, 10).events, [])

    def test_timing_after_silence_removal(self):
        keep = [(0.0, 4.0), (6.0, 10.0)]                       # a 2 s gap removed
        self.assertEqual(captions.remap_time(3.0, keep), 3.0)
        self.assertEqual(captions.remap_time(7.0, keep), 5.0)
        self.assertIsNone(captions.remap_time(5.0, keep))
        self.assertEqual(captions.kept_duration(10.0, keep), 8.0)
        tr = Transcript([Segment(0, 10, "a b c d", [Word("a", 1, 1.5), Word("b", 3, 3.5), Word("c", 6.5, 7), Word("d", 8, 8.5)])], "t")
        track = captions.build_track(tr, 0, 10, keep, max_words=2)
        flat = [w for e in track.events for w in e.words]
        self.assertEqual([w[0] for w in flat], ["a", "b", "c", "d"])
        self.assertAlmostEqual(flat[2][1], 4.5)                # 6.5 s -> 4.5 s on the shortened timeline
        self.assertAlmostEqual(flat[3][1], 6.0)

    def test_ass_and_srt_output(self):
        track = captions.build_track(script_transcript(True), 24.3, 34.0)
        with tempfile.TemporaryDirectory() as d:
            ass, srt = Path(d) / "c.ass", Path(d) / "c.srt"
            style = captions.CaptionStyle.from_dict({"highlight_color": "#00FF00", "position": "top", "uppercase": True, "background": True})
            captions.write_ass(track, ass, 1080, 1920, style)
            captions.write_srt(track, srt)
            text = ass.read_text()
            self.assertIn("PlayResY: 1920", text); self.assertIn("&H0000FF00&", text.upper().replace("&H0000FF00&", "&H0000FF00&"))
            self.assertIn("REMEMBER", text)
            self.assertRegex(srt.read_text(), r"1\n00:00:00,\d{3} --> 00:00:\d{2},\d{3}\n")

    def test_style_validation_clamps(self):
        s = captions.CaptionStyle.from_dict({"font_size_pct": 99, "position": "nowhere", "mode": "x", "max_words_per_line": 0})
        self.assertEqual((s.font_size_pct, s.position, s.mode, s.max_words_per_line), (10.0, "bottom", "word_highlight", 1))


class RenderUnitTests(unittest.TestCase):
    def test_keep_segments(self):
        self.assertEqual(render.compute_keep_segments(0, 20, []), [(0.0, 20.0)])
        keep = render.compute_keep_segments(5, 25, [(10, 12), (22, 24), (6, 6.3)], min_silence=0.7)
        self.assertEqual(keep[0][0], 0.0)
        self.assertAlmostEqual(keep[0][1], 5.15); self.assertAlmostEqual(keep[1][0], 6.85)   # 10-12 s silence cut, 0.15 s air each side
        self.assertEqual(keep[-1][1], 20.0)

    def test_command_is_an_argument_list_with_accurate_seek(self):
        info = {"width": 1920, "height": 1080, "has_audio": True}
        s = render.RenderSettings.from_dict({})
        hostile, produced = Path("/x") / "a b; rm -rf.mp4", Path("/o") / "out.mp4"
        cmd = render.build_command("ffmpeg", hostile, produced, 12.5, 40.0, info, s, "captions.ass", None, 27.5)
        self.assertIsInstance(cmd, list)
        self.assertLess(cmd.index("-ss"), cmd.index("-i"))
        self.assertIn(str(hostile), cmd)                          # hostile filename stays one literal argument
        graph = cmd[cmd.index("-filter_complex") + 1]
        self.assertIn("ass=captions.ass", graph); self.assertIn("gblur", graph)
        self.assertIn("libx264", cmd); self.assertIn("aac", cmd)

    def test_command_variants(self):
        info = {"width": 1280, "height": 720, "has_audio": False}
        s = render.RenderSettings.from_dict({"reframe": "center"})
        cmd = render.build_command("ffmpeg", Path("a.mp4"), Path("o.mp4"), 0, 10, info, s, None, None, 10)
        self.assertIn("-an", cmd); self.assertNotIn("gblur", cmd[cmd.index("-filter_complex") + 1])
        s2 = render.RenderSettings.from_dict({"music_path": "/m.mp3"})
        s2.music_path = "/m.mp3"
        cmd2 = render.build_command("ffmpeg", Path("a.mp4"), Path("o.mp4"), 0, 10, {**info, "has_audio": True}, s2, None, [(0, 4), (5, 10)], 9)
        g2 = cmd2[cmd2.index("-filter_complex") + 1]
        self.assertIn("sidechaincompress", g2); self.assertIn("concat=n=2", g2); self.assertIn("-stream_loop", cmd2)

    def test_settings_validation(self):
        with self.assertRaises(render.RenderError): render.RenderSettings.from_dict({"aspect": "4:3"})
        with self.assertRaises(render.RenderError): render.RenderSettings.from_dict({"reframe": "subject_tracking"})
        self.assertEqual(render.RenderSettings.from_dict({"volume": 99}).volume, 3.0)

    def test_safe_slug(self):
        self.assertEqual(render.safe_slug("../../etc/passwd; rm -rf /"), "etc-passwd-rm-rf")
        self.assertEqual(render.safe_slug("   "), "clip")
        self.assertLessEqual(len(render.safe_slug("x" * 500)), 40)


class JobStateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate(); self.addCleanup(self.tmp.cleanup)
        self.pid = db.create_project("p", "upload")["id"]

    def test_happy_path_analysis(self):
        j = db.create_job(self.pid, "analyze")
        self.assertEqual(j["status"], "queued")
        for state in ("validating", "transcribing", "analyzing", "awaiting_approval"):
            self.assertEqual(db.transition(j["id"], state)["status"], state)

    def test_happy_path_render_and_terminal_states(self):
        j = db.create_job(self.pid, "render")
        db.transition(j["id"], "rendering"); db.transition(j["id"], "completed", progress=1.0)
        for state in ("rendering", "failed", "queued"):
            with self.assertRaises(db.StateError): db.transition(j["id"], state)

    def test_illegal_transitions(self):
        j = db.create_job(self.pid, "analyze")
        for state in ("completed", "awaiting_approval", "analyzing", "bogus"):
            with self.assertRaises(db.StateError): db.transition(j["id"], state)
        with self.assertRaises(db.StateError): db.transition("missing", "failed")

    def test_progress_is_null_unless_reported(self):
        j = db.create_job(self.pid, "analyze")
        self.assertIsNone(db.transition(j["id"], "validating")["progress"])
        db.set_progress(j["id"], 0.4)
        self.assertEqual(db.get_job(j["id"])["progress"], 0.4)

    def test_restart_marks_active_jobs_failed(self):
        j = db.create_job(self.pid, "analyze"); db.transition(j["id"], "validating")
        done = db.create_job(self.pid, "render"); db.transition(done["id"], "rendering"); db.transition(done["id"], "completed")
        self.assertEqual(db.fail_interrupted(), 1)
        self.assertEqual(db.get_job(j["id"])["status"], "failed"); self.assertIn("restarted", db.get_job(j["id"])["error"])
        self.assertEqual(db.get_job(done["id"])["status"], "completed")

    def test_cancel_queued_job_and_reject_cancelling_finished(self):
        j = db.create_job(self.pid, "analyze")
        self.assertEqual(pipeline.cancel_job(j["id"])["status"], "cancelled")
        with self.assertRaises(db.StateError): pipeline.cancel_job(j["id"])

    def test_candidate_overlap_survives_reanalysis_only_for_user_work(self):
        a = db.add_candidate(self.pid, 0, 10, 50, "m", [], rank=1)
        b = db.add_candidate(self.pid, 20, 30, 40, "m", [], rank=2); db.update_candidate(b["id"], status="approved")
        c = db.add_candidate(self.pid, 40, 50, None, "manual", [], origin="custom", status="approved")
        db.clear_auto_candidates(self.pid)
        left = {x["id"] for x in db.list_candidates(self.pid)}
        self.assertEqual(left, {b["id"], c["id"]})


class LinkSecurityTests(unittest.TestCase):
    PUBLIC = staticmethod(lambda host, *a, **k: [(2, 1, 6, "", ("93.184.216.34", 0))])

    def test_normalise_rejects_bad_urls(self):
        for bad in ["", "file:///etc/passwd", "ftp://x.com/a.mp4", "javascript:alert(1)", "https://user:pw@x.com/a.mp4", "https://x.com:8080/a.mp4",
                    "https://x.com/a b.mp4", "http://", "https://" + "a" * 3000]:
            with self.assertRaises(links.LinkError, msg=bad): links.normalise_url(bad)

    def test_private_and_local_hosts_blocked(self):
        for ip in ["127.0.0.1", "10.0.0.5", "192.168.1.9", "169.254.169.254", "::1", "172.16.0.1", "0.0.0.0"]:
            fake = lambda host, *a, _ip=ip, **k: [(2, 1, 6, "", (_ip, 0))]
            with self.assertRaises(links.LinkError, msg=ip): links.assert_public_host("evil.example", fake)
        with self.assertRaises(links.LinkError): links.assert_public_host("nonexistent.invalid", mock.Mock(side_effect=OSError))
        links.assert_public_host("example.com", self.PUBLIC)                                   # public passes

    def test_dns_rebinding_between_checks_is_blocked(self):
        answers = iter([[(2, 1, 6, "", ("93.184.216.34", 0))], [(2, 1, 6, "", ("127.0.0.1", 0))]])
        with self.assertRaises(links.LinkError): links.assert_public_host("x.example", lambda *a, **k: next(answers))

    def test_classify(self):
        self.assertEqual(links.classify("https://www.youtube.com/watch?v=1"), "youtube")
        self.assertEqual(links.classify("https://youtu.be/abc"), "youtube")
        self.assertEqual(links.classify("https://www.youtube.com/shorts/abc123"), "youtube")
        self.assertEqual(links.classify("https://www.youtube-nocookie.com/embed/abc123"), "youtube")
        self.assertEqual(links.classify("https://www.netflix.com/title/1"), "known_unsupported")
        self.assertEqual(links.classify("https://cdn.example.com/a/b.MP4"), "direct_media")
        self.assertEqual(links.classify("https://example.com/watch"), "unknown_page")

    def _fetch(self, handler, **kw):
        d = tempfile.mkdtemp()
        self.addCleanup(lambda: __import__("shutil").rmtree(d, ignore_errors=True))
        return links.fetch_direct("https://cdn.example.com/v.mp4", Path(d), resolver=self.PUBLIC, transport=httpx.MockTransport(handler), **kw), Path(d)

    def test_direct_download_success_and_partial_cleanup(self):
        res, d = self._fetch(lambda r: httpx.Response(200, headers={"content-type": "video/mp4"}, content=b"x" * 5000))
        self.assertTrue(res.path.is_file()); self.assertEqual(res.path.stat().st_size, 5000); self.assertEqual(res.method, "http")
        self.assertFalse((d / "download.part").exists())

    def test_direct_download_errors_are_specific(self):
        cases = [(lambda r: httpx.Response(200, headers={"content-type": "text/html"}, content=b"<html>"), "not_video"),
                 (lambda r: httpx.Response(404), "unavailable"), (lambda r: httpx.Response(403), "login_required"),
                 (lambda r: httpx.Response(429), "rate_limited"), (lambda r: httpx.Response(500), "download_failed"),
                 (lambda r: httpx.Response(200, headers={"content-type": "video/mp4"}, content=b""), "download_failed")]
        for handler, code in cases:
            with self.assertRaises(links.LinkError) as ctx:
                self._fetch(handler)
            self.assertEqual(ctx.exception.code, code)

    def test_size_limit_enforced(self):
        with mock.patch.object(settings, "MAX_REMOTE_BYTES", 1000):
            with self.assertRaises(links.LinkError) as ctx:
                self._fetch(lambda r: httpx.Response(200, headers={"content-type": "video/mp4", "content-length": "5000"}, content=b"x" * 5000))
            self.assertEqual(ctx.exception.code, "too_large")
            with self.assertRaises(links.LinkError) as ctx:
                self._fetch(lambda r: httpx.Response(200, headers={"content-type": "video/mp4"}, content=b"x" * 5000))
            self.assertEqual(ctx.exception.code, "too_large")

    def test_redirect_to_private_host_is_blocked(self):
        calls = []

        def resolver(host, *a, **k):
            ip = "127.0.0.1" if host == "internal.example" else "93.184.216.34"
            return [(2, 1, 6, "", (ip, 0))]

        def handler(r):
            calls.append(str(r.url))
            return httpx.Response(302, headers={"location": "https://internal.example/secret.mp4"})
        d = tempfile.mkdtemp()
        with self.assertRaises(links.LinkError) as ctx:
            links.fetch_direct("https://cdn.example.com/v.mp4", Path(d), resolver=resolver, transport=httpx.MockTransport(handler))
        self.assertEqual(ctx.exception.code, "blocked_host"); self.assertEqual(len(calls), 1)

    def test_redirect_loop_is_capped(self):
        with self.assertRaises(links.LinkError):
            self._fetch(lambda r: httpx.Response(302, headers={"location": "https://cdn.example.com/v.mp4"}))

    def test_platform_downloads_disabled_by_default(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("VANTA_ENABLE_YTDLP", None)
            with self.assertRaises(links.LinkError) as ctx:
                links.fetch_platform("https://www.youtube.com/watch?v=abc", Path(tempfile.mkdtemp()))
            self.assertEqual(ctx.exception.code, "adapter_disabled")
            self.assertFalse(links.support_info()["platforms"]["available"])

    def test_known_drm_and_unknown_platforms_refused(self):
        with self.assertRaises(links.LinkError) as ctx:
            links.fetch("https://www.netflix.com/watch/1", Path(tempfile.mkdtemp()))
        self.assertEqual(ctx.exception.code, "unsupported_platform")

    def test_ytdlp_error_classification(self):
        cases = [
            ("ERROR: Sign in to confirm your age", "login_required"),
            ("ERROR: Private video", "login_required"),
            ("ERROR: Confirm you are not a bot", "bot_check"),
            ("ERROR: Sign in to confirm you are not a bot", "bot_check"),
            ("ERROR: Video unavailable in your country", "geo_blocked"),
            ("ERROR: yt-dlp is out of date", "extraction_failed"),      # never reported as a generic "update yt-dlp" for everything
            ("ERROR: Unable to download webpage: timed out", "timeout"),
            ("ERROR: Video unavailable", "unavailable"),
            ("This video is DRM protected", "drm"),
            ("ERROR: Unsupported URL: x", "unsupported_platform"),
            ("ERROR: HTTP Error 429: Too Many Requests", "rate_limited"),
            ("ERROR: weird failure", "unknown_error"),
        ]
        for text, code in cases:
            with self.subTest(text=text):
                error = links.classify_ytdlp_error(text)
                self.assertEqual(error.code, code, text)
                self.assertTrue(str(error))



class PaidAIGateTests(unittest.TestCase):
    def setUp(self):
        self._env = mock.patch.dict(os.environ, {}, clear=False); self._env.start(); self.addCleanup(self._env.stop)
        for k in ("VANTA_CLOUD_AI_ENABLED", "VANTA_CLOUD_AI_MODEL", "ANTHROPIC_API_KEY", "VANTA_CLOUD_PRICE_IN_PER_MTOK", "VANTA_CLOUD_PRICE_OUT_PER_MTOK"):
            os.environ.pop(k, None)
        cost._ESTIMATES.clear()

    def enable(self, prices=True):
        os.environ.update({"VANTA_CLOUD_AI_ENABLED": "1", "VANTA_CLOUD_AI_MODEL": "some-model", "ANTHROPIC_API_KEY": "sk-test-secret"})
        if prices:
            os.environ.update({"VANTA_CLOUD_PRICE_IN_PER_MTOK": "1", "VANTA_CLOUD_PRICE_OUT_PER_MTOK": "5"})

    def test_disabled_by_default(self):
        st = cost.provider_status()
        self.assertFalse(st["enabled"]); self.assertFalse(st["configured"])
        with self.assertRaises(cost.PaidAIError) as ctx: cost.estimate(1000)
        self.assertEqual(ctx.exception.status, 403)
        with self.assertRaises(cost.PaidAIError) as ctx: cost.authorize("x", True)
        self.assertEqual(ctx.exception.status, 403)

    def test_enabled_without_key_or_model_is_not_configured(self):
        os.environ["VANTA_CLOUD_AI_ENABLED"] = "1"
        with self.assertRaises(cost.PaidAIError) as ctx: cost.estimate(10)
        self.assertEqual(ctx.exception.status, 503)

    def test_secret_never_exposed_in_status(self):
        self.enable()
        self.assertNotIn("sk-test-secret", json.dumps(cost.provider_status()))

    def test_confirmation_is_required_and_estimate_single_use(self):
        self.enable()
        est = cost.estimate(3000)
        self.assertEqual((est["provider"], est["model"]), ("anthropic", "some-model")); self.assertIsNotNone(est["est_cost_usd"])
        for confirm in (False, None, "yes", 1):
            with self.assertRaises(cost.PaidAIError) as ctx: cost.authorize(est["estimate_id"], confirm)
            self.assertEqual(ctx.exception.status, 428)
        self.assertEqual(cost.authorize(est["estimate_id"], True)["estimate_id"], est["estimate_id"])
        with self.assertRaises(cost.PaidAIError) as ctx: cost.authorize(est["estimate_id"], True)      # no replay / auto retry
        self.assertEqual(ctx.exception.status, 409)
        with self.assertRaises(cost.PaidAIError): cost.authorize("never-issued", True)

    def test_unknown_prices_are_reported_as_unknown(self):
        self.enable(prices=False)
        est = cost.estimate(3000)
        self.assertIsNone(est["est_cost_usd"]); self.assertFalse(est["price_known"]); self.assertIn("unknown", est["note"])

    def test_provider_call_is_single_shot_and_parses_usage(self):
        self.enable()
        est = cost.estimate(500); calls = []

        def ok(r):
            calls.append(r)
            self.assertEqual(r.headers["x-api-key"], "sk-test-secret")
            return httpx.Response(200, json={"content": [{"type": "text", "text": '{"ratings":[{"id":"a","score":88,"reason":"strong hook"}]}'}], "usage": {"input_tokens": 120, "output_tokens": 30}})
        out = cost.rank_with_claude([{"id": "a", "start": 0, "end": 10, "excerpt": "hello"}], est, httpx.MockTransport(ok))
        self.assertEqual(out["ratings"]["a"]["score"], 88); self.assertEqual(out["usage"], {"input_tokens": 120, "output_tokens": 30}); self.assertEqual(len(calls), 1)
        failing = []
        with self.assertRaises(cost.PaidAIError) as ctx:
            cost.rank_with_claude([{"id": "a", "start": 0, "end": 1, "excerpt": "x"}], est, httpx.MockTransport(lambda r: failing.append(1) or httpx.Response(500)))
        self.assertEqual(ctx.exception.status, 502); self.assertEqual(len(failing), 1)                  # no automatic retry
        with self.assertRaises(cost.PaidAIError):
            cost.rank_with_claude([], est, httpx.MockTransport(lambda r: httpx.Response(200, json={"content": [{"type": "text", "text": "not json"}]})))


class PathSafetyTests(unittest.TestCase):
    def test_is_inside(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d) / "root"; root.mkdir(); outside = Path(d) / "secret.txt"; outside.write_text("x")
            (root / "ok.txt").write_text("x")
            try:
                (root / "link").symlink_to(outside)
            except (OSError, NotImplementedError) as error:   # Windows needs Developer Mode / admin for symlinks
                self.skipTest(f"cannot create a symlink here: {error}")
            self.assertTrue(settings.is_inside(root / "ok.txt", root))
            self.assertFalse(settings.is_inside(root / ".." / "secret.txt", root))
            self.assertFalse(settings.is_inside(root / "link", root))
            self.assertFalse(settings.is_inside(Path("/etc/passwd"), root))


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class MediaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from app.clipstudio import media
        cls.media = media
        cls.tmp = tempfile.TemporaryDirectory()
        cls.video = make_video(Path(cls.tmp.name) / "v.mp4", duration=14)
        cls.silent = make_video(Path(cls.tmp.name) / "s.mp4", duration=4, audio=False)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_probe(self):
        info = self.media.probe(self.video)
        self.assertEqual((info["width"], info["height"], info["has_audio"], info["video_codec"]), (640, 360, True, "h264"))
        self.assertAlmostEqual(info["duration"], 14, delta=0.3); self.assertAlmostEqual(info["fps"], 30, delta=0.1)
        self.assertFalse(self.media.probe(self.silent)["has_audio"])

    def test_probe_rejects_non_media_and_missing(self):
        bad = Path(self.tmp.name) / "fake.mp4"; bad.write_bytes(b"this is not a video" * 100)
        with self.assertRaises(self.media.MediaError): self.media.probe(bad)
        with self.assertRaises(self.media.MediaError): self.media.probe(Path(self.tmp.name) / "missing.mp4")
        audio_only = Path(self.tmp.name) / "a.m4a"
        import subprocess
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=duration=2", str(audio_only)], check=True)
        with self.assertRaises(self.media.MediaError) as ctx: self.media.probe(audio_only)
        self.assertIn("no video", str(ctx.exception))

    def test_duration_limit(self):
        with self.assertRaises(self.media.MediaError): self.media.validate_source(self.video, max_duration=5)

    def test_silence_detection(self):
        sil = self.media.detect_silences(self.video)
        self.assertEqual(len(sil), 1); self.assertAlmostEqual(sil[0][0], 10.0, delta=0.1); self.assertAlmostEqual(sil[0][1], 12.0, delta=0.1)
        self.assertEqual(self.media.detect_silences(self.silent), [])    # no audio stream -> nothing to report


if __name__ == "__main__":
    unittest.main()
