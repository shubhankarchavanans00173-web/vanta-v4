"""verify_all.py: classification, scrubbing, command building. No network; only tiny local subprocesses."""
from __future__ import annotations

import subprocess
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

import verify_all as v

ROOT = Path(__file__).resolve().parents[2]


def fake_runner(rc=0, out=b"", err=b"", raise_timeout=False):
    def run(cmd, **kw):
        if raise_timeout:
            raise subprocess.TimeoutExpired(cmd, kw.get("timeout", 1), output=b"partial output")
        return SimpleNamespace(returncode=rc, stdout=out, stderr=err)
    return run


class Redaction(unittest.TestCase):
    def test_tokens_keys_and_home_are_removed(self):
        text = "key sk-ant-ABCDEFGHIJKL1234 and AIzaSyA1234567890123456789012 ya29.A0AbCdEfGhIjKl path C:\\Users\\Ravi\\x api_key=SECRETVALUE Bearer abcdefghijklmnop"
        out = v.redact(text, home="C:\\Users\\Ravi")
        for bad in ("sk-ant-ABCDEFGHIJKL1234", "AIzaSyA1234567890123456789012", "ya29.A0AbCdEfGhIjKl", "SECRETVALUE", "abcdefghijklmnop", "Ravi"):
            self.assertNotIn(bad, out)

    def test_exact_env_secret_values_are_removed(self):
        self.assertNotIn("hunter2hunter2", v.redact("value=hunter2hunter2 here", extra_secrets=["hunter2hunter2"]))

    def test_secret_values_from_env_only_secretish_names(self):
        vals = v.secret_values_from_env({"MY_API_KEY": "abcdefgh", "PATH": "c:\\bin", "SHORT_TOKEN": "x"})
        self.assertEqual(vals, ["abcdefgh"])


class Classification(unittest.TestCase):
    def step(self, **kw):
        return v.Step("k", "t", cmd=["x"], **kw)

    def test_exit_zero_passes_and_nonzero_fails(self):
        self.assertEqual(v.classify(self.step(), 0, False, "")[0], v.PASS)
        self.assertEqual(v.classify(self.step(), 1, False, "")[0], v.FAIL)

    def test_skip_code_is_skipped_not_pass(self):
        st, why = v.classify(self.step(skip_codes={2: "model missing"}), 2, False, "")
        self.assertEqual((st, why), (v.SKIPPED, "model missing"))

    def test_unknown_code_is_a_failure_even_if_skip_codes_exist(self):
        self.assertEqual(v.classify(self.step(skip_codes={2: "x"}), 3, False, "")[0], v.FAIL)

    def test_timeout_is_a_failure(self):
        self.assertEqual(v.classify(self.step(), None, True, "")[0], v.FAIL)

    def test_unittest_ok_and_failed(self):
        ok = "....\n----\nRan 12 tests in 1.2s\n\nOK\n"
        bad = "F\n----\nRan 3 tests in 0.1s\n\nFAILED (failures=1)\n"
        t = lambda: v.Step("tests.x", "t", cmd=["x"], group="tests")
        self.assertEqual(v.classify(t(), 0, False, ok), (v.PASS, "12 tests OK"))
        st, why = v.classify(t(), 1, False, bad)
        self.assertEqual(st, v.FAIL)
        self.assertIn("failures=1", why)

    def test_exit_zero_without_ok_summary_is_not_a_pass(self):
        self.assertEqual(v.classify(v.Step("tests.x", "t", cmd=["x"], group="tests"), 0, False, "nothing useful")[0], v.FAIL)

    def test_skipped_tests_are_noted_but_still_pass(self):
        out = "Ran 5 tests in 1s\n\nOK (skipped=2)\n"
        st, why = v.classify(v.Step("tests.x", "t", cmd=["x"], group="tests"), 0, False, out)
        self.assertEqual(st, v.PASS)
        self.assertIn("skipped", why)


class Running(unittest.TestCase):
    def test_skip_reason_short_circuits(self):
        r = v.run_step(v.Step("a", "A", skip_reason="because"), {}, runner=fake_runner(rc=1))
        self.assertEqual((r.status, r.reason), (v.SKIPPED, "because"))

    def test_timeout_is_reported_with_partial_output(self):
        r = v.run_step(v.Step("a", "A", cmd=["x"], timeout=3), {}, runner=fake_runner(raise_timeout=True))
        self.assertEqual(r.status, v.FAIL)
        self.assertIn("timed out", r.reason)
        self.assertIn("partial output", r.output)

    def test_missing_executable_fails_cleanly(self):
        r = v.run_step(v.Step("a", "A", cmd=["definitely-not-a-real-program-xyz"]), {})
        self.assertEqual(r.status, v.FAIL)
        self.assertIn("could not start", r.reason)

    def test_real_subprocess_pass_skip_fail(self):
        py = sys.executable
        self.assertEqual(v.run_step(v.Step("a", "A", cmd=[py, "-c", "print('hi')"]), {}).status, v.PASS)
        self.assertEqual(v.run_step(v.Step("a", "A", cmd=[py, "-c", "raise SystemExit(2)"], skip_codes={2: "r"}), {}).status, v.SKIPPED)
        self.assertEqual(v.run_step(v.Step("a", "A", cmd=[py, "-c", "raise SystemExit(1)"]), {}).status, v.FAIL)

    def test_utf16_output_is_decoded(self):
        r = v.run_step(v.Step("a", "A", cmd=["x"]), {}, runner=fake_runner(out="hello".encode("utf-16")))
        self.assertIn("hello", r.output)


class Building(unittest.TestCase):
    def build(self, windows, **kw):
        args = dict(url="https://example.com/v", video=None, skip_network=False, skip_tests=False, only_tests=None, test_timeout=10, windows=windows)
        args.update(kw)
        return v.build_steps(ROOT, sys.executable, **args)

    def test_windows_mode_runs_the_real_bat_files(self):
        blob = " ".join(s.cmd for s in self.build(True) if isinstance(s.cmd, str))
        for name in ("check_system.bat", "diagnose_youtube.bat", "check_transcription.bat", "check_captions.bat"):
            self.assertIn(name, blob)

    def test_the_scheduler_task_is_never_touched_in_any_mode(self):
        for windows in (True, False):
            for s in self.build(windows):
                blob = s.cmd if isinstance(s.cmd, str) else " ".join(s.cmd or [])
                for token in v.FORBIDDEN_TOKENS:
                    self.assertNotIn(token, blob.lower())

    def test_skip_flags(self):
        steps = {s.key: s for s in self.build(False, skip_network=True, skip_tests=True)}
        self.assertIn("NOT verified", steps["youtube"].skip_reason)
        self.assertTrue(steps["tests"].skip_reason)

    def test_every_test_module_gets_its_own_step_and_timeout(self):
        mods = [s for s in self.build(False) if s.group == "tests"]
        self.assertGreaterEqual(len(mods), 10)
        self.assertTrue(all(s.timeout == 10 for s in mods))
        self.assertIn("tests.test_verify_all", [s.key for s in mods])

    def test_selected_tests_and_unknown_module(self):
        steps = self.build(False, only_tests=["core", "test_nope"])
        keys = [s.key for s in steps if s.group == "tests"]
        self.assertEqual(keys, ["tests.test_nope", "tests.test_core"])
        self.assertTrue(steps[[s.key for s in steps].index("tests.test_nope")].skip_reason)

    def test_windows_command_line_survives_spaces(self):
        line = v.windows_cmd_line(Path("C:/My Folder/check.bat"), "https://x/y?a=1&b=2")
        self.assertTrue(line.startswith('cmd.exe /d /s /c ""'))
        self.assertIn('"C:', line)
        self.assertTrue(line.endswith('""'))

    def test_video_argument_reaches_transcription(self):
        s = {x.key: x for x in self.build(False, video="D:/talk.mp4")}["transcription"]
        self.assertIn("D:/talk.mp4", s.cmd)


class Environment(unittest.TestCase):
    def test_test_processes_get_blank_keys_and_a_throwaway_data_dir(self):
        env = v.test_env({"ANTHROPIC_API_KEY": "sk-real", "VANTA_CLOUD_AI_ENABLED": "1", "PATH": "p"}, "/tmp/x")
        self.assertEqual(env["ANTHROPIC_API_KEY"], "")
        self.assertEqual(env["VANTA_CLOUD_AI_ENABLED"], "")
        self.assertEqual(env["VANTA_DATA_DIR"], "/tmp/x")
        self.assertEqual(env["PATH"], "p")


class Report(unittest.TestCase):
    def results(self):
        s = lambda k, **kw: v.Step(k, k.upper(), cmd=["x"], **kw)
        return [v.Result(s("a"), v.PASS, "exit code 0", 2, 0, "fine"),
                v.Result(s("b"), v.FAIL, "exit code 1", 1, 1, "boom with sk-ant-SECRETSECRET1234 in C:\\Users\\Ravi\\f"),
                v.Result(s("c"), v.SKIPPED, "no model")]

    def test_report_marks_every_status_and_scrubs(self):
        text = v.render_report(self.results(), {"started": "now"}, "C:\\Users\\Ravi", [])
        self.assertIn("[PASS   ]", text)
        self.assertIn("[FAIL   ]", text)
        self.assertIn("[SKIPPED]", text)
        self.assertIn("OVERALL  : FAIL", text)
        self.assertNotIn("SECRETSECRET", text)
        self.assertNotIn("Ravi", text)

    def test_skips_are_not_reported_as_a_clean_pass(self):
        rs = [r for r in self.results() if r.status != v.FAIL]
        text = v.render_report(rs, {}, None, [])
        self.assertIn("PASS WITH SKIPS", text)
        self.assertIn("NOT verified", text)

    def test_tail_truncates_long_output(self):
        out = v.tail("\n".join(str(i) for i in range(500)), 10)
        self.assertIn("490 earlier lines omitted", out)
        self.assertTrue(out.rstrip().endswith("499"))


if __name__ == "__main__":
    unittest.main()
