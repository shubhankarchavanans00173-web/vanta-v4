from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import array

from app.clipstudio.live.media_evidence import MediaEvidenceWorker
from app.clipstudio.live.event_correlator import EvidenceEvent


class FakeBuffer:
    def snapshot(self): return []

class FakeSession:
    id = "test-session"
    buffer = FakeBuffer()
    events = []

class FakeManager:
    def __init__(self): self.evidence=[]; self.on_event=None
    def add_evidence(self, sid, event): self.evidence.append(event)


def test_audio_energy_is_explicitly_labelled_and_emits_event():
    manager, session = FakeManager(), FakeSession()
    session.events = []
    worker = MediaEvidenceWorker(manager, session, ffmpeg="ffmpeg", min_rms=1000, ratio=2,
                                 refractory_seconds=0)
    # 0.5 seconds quiet followed by 0.5 seconds loud PCM at 8 kHz.
    pcm = array.array("h", [100] * 4000 + [12000] * 4000).tobytes()
    result = SimpleNamespace(returncode=0, stdout=pcm, stderr=b"")
    with patch("app.clipstudio.live.media_evidence.subprocess.run", return_value=result):
        worker._analyse(Path("segment.ts"), 0, 1)
    assert manager.evidence
    assert manager.evidence[0].kind == "audio intensity"
    assert "only" in manager.evidence[0].evidence
    assert session.events[0].kind == "audio intensity"


def test_missing_ffmpeg_disables_evidence_without_claiming_semantics():
    worker = MediaEvidenceWorker(FakeManager(), FakeSession(), ffmpeg=None)
    worker.ffmpeg = None
    worker._analyse(Path("missing.ts"), 0, 1)
    assert "unavailable" in worker.status()["error"].lower()
    assert "laughter" in worker.status()["capability_note"]
