"""Phase 5 step 1: local segment ingest, rolling-buffer feeding, and review-only clip assembly.

Two layers of proof:
* fake process + fake list file, so the publication rules (never publish a partial file, never delete outside
  the session folder, honour the disk cap) are tested deterministically and fast;
* a real FFmpeg segment muxer reading a paced local file ("a real local stream" on this machine) that feeds a
  real RollingBuffer, and a real concat+encode by LiveClipWorker that produces an MP4 verified with ffprobe.

Chat platforms are exercised with fake transports only. That is why the report labels chat integrations
PARTIAL: nothing here touches a real YouTube/Twitch credential.
"""
from __future__ import annotations

import subprocess
import tempfile
import threading
import time
import unittest
from dataclasses import replace
from pathlib import Path
from unittest import mock

from app.clipstudio.live import (
    IngestConfig, IngestError, LiveClipError, LiveClipWorker, LiveReviewPipeline, LiveStreamManager,
    RollingBuffer, SegmentIngest, build_command, resolve_source,
)
from app.clipstudio.live.event_correlator import LiveEvent
from app.clipstudio.live.rolling_buffer import BufferedSegment
from app.clipstudio.live.twitch_adapter import parse_irc_line
from app.clipstudio.live.youtube_adapter import YouTubeAdapterError, YouTubeLiveChatAdapter
from app.clipstudio.live import live_clip_worker as clip_worker_module
from tests.vanta_fixtures import HAVE_FFMPEG, make_video


def ffprobe_duration(path: Path) -> float:
    result = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)],
                            capture_output=True, text=True, timeout=30, check=True)
    return float(result.stdout.strip())


class FakeProcess:
    """Stand-in for the FFmpeg process: lets tests drive the segment list without spawning anything."""
    last: "FakeProcess | None" = None

    def __init__(self, command, **kwargs):
        self.command, self.kwargs = command, kwargs
        self.pid, self.returncode, self.terminated, self.killed = 4242, None, False, False
        FakeProcess.last = self

    def poll(self):
        return self.returncode

    def terminate(self):
        self.terminated, self.returncode = True, 1

    def kill(self):
        self.killed, self.returncode = True, -9

    def wait(self, timeout=None):
        return self.returncode


class IngestUnitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="vanta-ingest-")
        self.root = Path(self.tmp.name)
        self.session_dir = self.root / "session"
        self.source = self.root / "source.mp4"
        self.source.write_bytes(b"pretend media")
        self.buffer = RollingBuffer(60, max_segments=200)
        self.config = IngestConfig(source=str(self.source), segment_seconds=2, realtime=False)
        self.ingest = SegmentIngest(self.session_dir, self.buffer, self.config, ffmpeg="ffmpeg", popen=FakeProcess)

    def tearDown(self):
        if self.ingest.is_running:
            self.ingest.stop()               # release the log handle before Windows deletes the temp folder
        self.tmp.cleanup()

    def list_segment(self, name: str, start: float, end: float, size: int = 128) -> Path:
        path = self.session_dir / "segments" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"x" * size)
        with (self.session_dir / "segments.csv").open("a", encoding="utf-8") as handle:
            handle.write(f"{name},{start:.6f},{end:.6f}\n")
        return path

    # ---------------------------------------------------------------- sources
    def test_source_validation_rejects_unsafe_and_missing_inputs(self):
        for bad in ("", "   ", str(self.root / "missing.mp4"), "concat:a|b", "pipe:0", "file:///etc/passwd",
                    "ftp://example.com/x.ts", "md5:abc"):
            with self.subTest(source=bad), self.assertRaises(IngestError):
                resolve_source(bad)

    def test_source_validation_accepts_a_local_file_and_an_authorised_url(self):
        path, local = resolve_source(str(self.source))
        self.assertTrue(local)
        self.assertEqual(Path(path), self.source.resolve())
        url, local = resolve_source("https://example.com/live.m3u8?token=abc")
        self.assertFalse(local)
        self.assertEqual(url, "https://example.com/live.m3u8?token=abc")

    def test_command_is_an_argument_list_with_no_shell_and_no_extra_flags(self):
        command = build_command("ffmpeg", "https://example.com/live", local_file=False,
                                config=replace(self.config, source="https://example.com/live"),
                                segments_dir=Path("s/segments"), list_path=Path("s/segments.csv"))
        self.assertTrue(all(isinstance(part, str) for part in command))
        self.assertNotIn("-re", command)                       # pacing only applies to local files
        self.assertEqual(command[command.index("-i") + 1], "https://example.com/live")
        self.assertEqual(command[command.index("-segment_time") + 1], "2")
        self.assertIn("+live", command)                        # the list is flushed as segments close
        self.assertEqual(command[command.index("-segment_list_type") + 1], "csv")
        self.assertEqual(command[command.index("-reset_timestamps") + 1], "1")
        self.assertTrue(command[-1].endswith("seg_%05d.ts"))
        self.assertIn("segments", command[-1])

    def test_local_file_is_paced_and_audio_can_be_disabled(self):
        paced = build_command("ffmpeg", str(self.source), local_file=True, config=replace(self.config, realtime=True),
                              segments_dir=Path("s"), list_path=Path("s.csv"))
        self.assertIn("-re", paced)
        silent = build_command("ffmpeg", str(self.source), local_file=True, config=replace(self.config, audio=False),
                               segments_dir=Path("s"), list_path=Path("s.csv"))
        self.assertIn("-an", silent)
        copy_mode = build_command("ffmpeg", str(self.source), local_file=True, config=replace(self.config, transcode=False),
                                  segments_dir=Path("s"), list_path=Path("s.csv"))
        self.assertIn("copy", copy_mode)
        self.assertNotIn("libx264", copy_mode)

    def test_config_rejects_impossible_values(self):
        for kwargs in ({"segment_seconds": 0.5}, {"segment_seconds": 31}, {"start_at": -1}, {"max_bytes": 1024}):
            with self.subTest(**kwargs), self.assertRaises(ValueError):
                IngestConfig(source="x", **{**{}, **kwargs})

    def test_start_fails_clearly_when_ffmpeg_is_missing(self):
        ingest = SegmentIngest(self.session_dir, self.buffer, self.config, ffmpeg=None, popen=FakeProcess)
        with mock.patch("app.clipstudio.live.segment_ingest._which_ffmpeg", return_value=None):
            with self.assertRaises(IngestError):
                ingest.start()

    # ---------------------------------------------------------------- publication rules
    def test_a_partial_or_unlisted_file_is_never_published(self):
        self.ingest.start(background=False)
        partial = self.session_dir / "segments" / "seg_00000.ts"
        partial.write_bytes(b"")                                # allocated but empty
        self.assertEqual(self.ingest.poll(), [])
        self.list_segment("seg_00001.ts", 0.0, 0.0, size=64)     # listed with no duration
        self.assertEqual(self.ingest.poll(), [])
        empty = self.session_dir / "segments" / "seg_00002.ts"  # listed with a duration but still zero bytes
        empty.write_bytes(b"")
        with (self.session_dir / "segments.csv").open("a", encoding="utf-8") as handle:
            handle.write("seg_00002.ts,4.000000,6.000000\n")
        self.assertEqual(self.ingest.poll(), [])
        self.assertFalse(empty.read_bytes())
        self.list_segment("seg_00000.ts", 0.0, 2.0, size=2048)   # now complete and listed
        published = self.ingest.poll()
        self.assertEqual([segment.path.name for segment in published], ["seg_00000.ts"])
        self.assertEqual([(s.start, s.end) for s in published], [(0.0, 2.0)])
        self.assertEqual(self.ingest.poll(), [])                 # never published twice

    def test_retired_media_is_deleted_but_never_outside_the_session_folder(self):
        self.buffer = RollingBuffer(15, max_segments=100)         # the smallest retention the buffer allows
        self.ingest = SegmentIngest(self.session_dir, self.buffer, self.config, ffmpeg="ffmpeg", popen=FakeProcess)
        outside = self.root / "user-video.mp4"
        outside.write_bytes(b"do not delete")
        self.buffer.add(BufferedSegment(0.0, 1.0, outside))       # a rogue reference from elsewhere
        self.ingest.start(background=False)
        first = self.list_segment("seg_00000.ts", 0.0, 2.0)
        self.ingest.poll()
        kept = self.list_segment("seg_00001.ts", 2.0, 12.0)
        self.ingest.poll()
        self.list_segment("seg_00002.ts", 12.0, 18.0)            # cutoff 3s retires 0-2 and the rogue entry
        self.ingest.poll()
        self.assertFalse(first.exists())                          # retired and deleted
        self.assertTrue(kept.exists())
        self.assertTrue(outside.exists())                         # refused, because it is outside the folder
        self.assertIn(str(outside), self.ingest.status()["refused_deletions"])

    def test_list_names_cannot_escape_the_segments_folder(self):
        self.ingest.start(background=False)
        evil = self.root / "evil.ts"
        evil.write_bytes(b"payload")
        with (self.session_dir / "segments.csv").open("a", encoding="utf-8") as handle:
            handle.write("../../evil.ts,0.000000,2.000000\n")
        self.assertEqual(self.ingest.poll(), [])
        self.assertTrue(evil.exists())

    def test_disk_cap_evicts_and_deletes_the_oldest_segment(self):
        self.buffer = RollingBuffer(600, max_segments=100)
        config = replace(self.config, max_bytes=8 * 1024 * 1024)
        self.ingest = SegmentIngest(self.session_dir, self.buffer, config, ffmpeg="ffmpeg", popen=FakeProcess)
        self.ingest.start(background=False)
        chunks = []
        for index in range(3):
            chunks.append(self.list_segment(f"seg_0000{index}.ts", index * 2.0, index * 2.0 + 2.0, size=3 * 1024 * 1024))
            self.ingest.poll()
        self.assertFalse(chunks[0].exists())                      # oldest removed to stay under the cap
        self.assertTrue(chunks[-1].exists())
        self.assertEqual(self.ingest.status()["evicted_for_size"], 1)
        self.assertLessEqual(self.ingest.status()["bytes"], 8 * 1024 * 1024)

    # ---------------------------------------------------------------- lifecycle
    def test_stop_terminates_the_process_and_publishes_the_final_segment(self):
        self.ingest.start(background=False)
        self.list_segment("seg_00000.ts", 0.0, 2.0)
        process = FakeProcess.last
        status = self.ingest.stop()
        self.assertTrue(process.terminated)
        self.assertFalse(status["running"])
        self.assertIsNone(status["error"])                        # stopped by us is not a failure
        self.assertEqual(status["segments_published"], 1)

    def test_unexpected_ffmpeg_exit_reports_the_log_tail(self):
        self.ingest.start(background=False)
        (self.session_dir / "ingest.log").write_bytes(b"Invalid data found when processing input\n")
        process = FakeProcess.last
        process.returncode = 1                                    # died on its own
        status = self.ingest.stop()
        self.assertIn("Invalid data found", status["error"])

    def test_cleanup_refuses_while_running_and_keeps_the_source(self):
        self.ingest.start(background=False)
        self.list_segment("seg_00000.ts", 0.0, 2.0)
        self.ingest.poll()
        self.assertFalse(self.ingest.cleanup()["cleaned"])
        self.ingest.stop()
        result = self.ingest.cleanup()
        self.assertTrue(result["cleaned"])
        self.assertEqual(result["removed_segments"], 1)
        self.assertTrue(self.source.exists())
        self.assertFalse((self.session_dir / "segments" / "seg_00000.ts").exists())
        self.assertTrue((self.session_dir / "ingest.log").exists())

    def test_disk_cap_defers_deleting_a_pinned_segment_until_the_reader_releases_it(self):
        self.buffer = RollingBuffer(600, max_segments=100)
        config = replace(self.config, max_bytes=8 * 1024 * 1024)
        self.ingest = SegmentIngest(self.session_dir, self.buffer, config, ffmpeg="ffmpeg", popen=FakeProcess)
        self.ingest.start(background=False)
        first = self.list_segment("seg_00000.ts", 0.0, 2.0, size=3 * 1024 * 1024)
        self.ingest.poll()
        self.buffer.pin_many([first])                 # as if a clip assembly were reading it
        for index in (1, 2):
            self.list_segment(f"seg_0000{index}.ts", index * 2.0, index * 2.0 + 2.0, size=3 * 1024 * 1024)
            self.ingest.poll()
        self.assertTrue(first.exists(), "an in-flight clip lost its segment to the disk cap")
        self.assertGreaterEqual(self.ingest.status()["deferred_deletions"], 1)
        self.buffer.unpin_many([first])
        self.ingest.poll()                             # retried once the lease is gone
        self.assertFalse(first.exists())
        self.assertEqual(self.ingest.status()["deferred_deletions"], 0)
        self.assertGreaterEqual(self.ingest.status()["deleted_after_release"], 1)

    def test_retention_retirement_also_defers_a_pinned_segment(self):
        self.buffer = RollingBuffer(15, max_segments=100)
        self.ingest = SegmentIngest(self.session_dir, self.buffer, self.config, ffmpeg="ffmpeg", popen=FakeProcess)
        self.ingest.start(background=False)
        oldest = self.list_segment("seg_00000.ts", 0.0, 2.0)
        self.ingest.poll()
        self.buffer.pin_many([oldest])
        self.list_segment("seg_00001.ts", 2.0, 12.0)
        self.ingest.poll()
        self.list_segment("seg_00002.ts", 12.0, 18.0)   # cutoff 3s retires the pinned 0-2 segment
        self.ingest.poll()
        self.assertTrue(oldest.exists())
        self.buffer.unpin_many([oldest])
        self.ingest.poll()
        self.assertFalse(oldest.exists())

    def test_status_states_it_is_review_only(self):
        self.ingest.start(background=False)
        status = self.ingest.status()
        self.assertTrue(status["review_only"])
        self.assertIn("rolling buffer", status["note"])


class SegmentLeaseTests(unittest.TestCase):
    """A reader pins what it is about to open, so pruning cannot pull the file away mid-encode."""

    def setUp(self):
        self.buffer = RollingBuffer(60)
        self.segments = [BufferedSegment(index * 2.0, index * 2.0 + 2.0, Path(f"seg{index}.ts")) for index in range(6)]
        for segment in self.segments:
            self.assertFalse(self.buffer.add(segment))

    def test_lease_pins_only_its_window_and_release_unpins(self):
        window, coverage, lease = self.buffer.lease_window(5.0, before_seconds=2.0, after_seconds=2.0)
        self.assertTrue(window)
        self.assertTrue(all(self.buffer.is_pinned(segment.path) for segment in window))
        self.assertFalse(self.buffer.is_pinned(self.segments[-1].path))
        lease.release()
        self.assertTrue(lease.released)
        self.assertFalse(any(self.buffer.is_pinned(segment.path) for segment in window))
        self.assertEqual(lease.paths, tuple(segment.path for segment in window))

    def test_lease_is_a_context_manager_and_releases_on_exception(self):
        _, _, lease = self.buffer.lease_window(5.0, 2.0, 2.0)
        with self.assertRaises(RuntimeError):
            with lease:
                self.assertTrue(self.buffer.is_pinned(self.segments[2].path))
                raise RuntimeError("boom")
        self.assertFalse(self.buffer.is_pinned(self.segments[2].path))

    def test_plain_window_does_not_pin_anything(self):
        self.buffer.window(5.0, 2.0, 2.0)
        self.assertFalse(any(self.buffer.is_pinned(segment.path) for segment in self.segments))

    def test_pins_are_reference_counted(self):
        path = self.segments[0].path
        self.buffer.pin_many([path, path])
        self.buffer.unpin_many([path])
        self.assertTrue(self.buffer.is_pinned(path))
        self.buffer.unpin_many([path])
        self.assertFalse(self.buffer.is_pinned(path))


class PipelineSubmissionTests(unittest.TestCase):
    """A visible job must always be joinable: wait()/drain() once raced an unstarted thread."""

    def pipeline(self, tmp: str) -> tuple:
        manager = LiveStreamManager()
        pipeline = LiveReviewPipeline(manager, LiveClipWorker(Path(tmp) / "clips"), poll_seconds=0.01, max_wait_seconds=0.05)
        session = manager.start("manual", "authorised-test", buffer_seconds=60, post_event_seconds=0)
        return manager, pipeline, session

    def test_a_submitted_job_has_an_already_started_thread(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, pipeline, session = self.pipeline(tmp)
            job_id = pipeline.submit(session, LiveEvent(0.0, 0.0, "manual", 10.0, ()))
            self.assertIsNotNone(pipeline._threads[job_id].ident, "submit returned before its thread was started")
            pipeline.drain(timeout=5)

    def test_drain_does_not_raise_while_jobs_are_being_submitted(self):
        with tempfile.TemporaryDirectory() as tmp:
            _, pipeline, session = self.pipeline(tmp)
            errors: list[BaseException] = []

            def submit_many():
                try:
                    for index in range(6):
                        pipeline.submit(session, LiveEvent(float(index), float(index), "manual", 10.0, ()))
                except BaseException as exc:          # surfaced below instead of in a bare thread
                    errors.append(exc)

            submitters = [threading.Thread(target=submit_many) for _ in range(3)]
            for thread in submitters:
                thread.start()
            while any(thread.is_alive() for thread in submitters):
                pipeline.drain(timeout=0.01)               # concurrent with submission on purpose
            for thread in submitters:
                thread.join(5)
            self.assertEqual(errors, [])
            pipeline.drain(timeout=10)


class FakeYouTubeService:
    """Minimal stand-in for the Google client: no network, no credentials."""

    def __init__(self, pages):
        self.pages, self.calls = list(pages), []

    def liveChatMessages(self):
        return self

    def list(self, **kwargs):
        self.calls.append(kwargs)
        return self

    def execute(self):
        if not self.pages:
            return {"items": []}
        page = self.pages.pop(0)
        if isinstance(page, Exception):
            raise page
        return page


def chat_page(items, token="next-page"):
    return {"nextPageToken": token, "items": [
        {"snippet": {"displayMessage": text}, "authorDetails": {"channelId": author}} for author, text in items]}


class FakeChatTransportTests(unittest.TestCase):
    def test_youtube_adapter_reads_a_fake_transport_and_pages(self):
        service = FakeYouTubeService([chat_page([("uc-1", "what was that"), ("uc-2", "no way")]),
                                      chat_page([("uc-3", "clutch")], token="page-3")])
        adapter = YouTubeLiveChatAdapter(service, "live-chat-id")
        first = adapter.poll()
        self.assertEqual([message.text for message in first], ["what was that", "no way"])
        self.assertEqual({message.platform for message in first}, {"youtube"})
        self.assertEqual(first[0].author, "uc-1")
        self.assertEqual(service.calls[0]["liveChatId"], "live-chat-id")
        self.assertIsNone(service.calls[0]["pageToken"])
        adapter.poll()
        self.assertEqual(service.calls[1]["pageToken"], "next-page")

    def test_youtube_transport_errors_are_reported_not_swallowed(self):
        adapter = YouTubeLiveChatAdapter(FakeYouTubeService([RuntimeError("quota exceeded")]), "live-chat-id")
        with self.assertRaises(YouTubeAdapterError) as caught:
            adapter.poll()
        self.assertIn("RuntimeError", str(caught.exception))
        self.assertIn("quota exceeded", str(caught.exception))

    def test_twitch_irc_lines_parse_with_bot_flags_and_ignore_pings(self):
        line = ("@badges=;color=#1E90FF;display-name=Viewer;user-id=42;user-type= :viewer!viewer@viewer.tmi.twitch.tv "
                "PRIVMSG #channel :NO WAY that was insane")
        message = parse_irc_line(line, 12.5)
        self.assertIsNotNone(message)
        self.assertEqual((message.author, message.platform, message.timestamp), ("42", "twitch", 12.5))
        self.assertIn("NO WAY", message.text)
        bot = parse_irc_line("@user-id=7;user-type=bot :chatbot!x@y PRIVMSG #c :beep boop", 1.0)
        self.assertTrue(bot and bot.is_bot)
        self.assertIsNone(parse_irc_line("PING :tmi.twitch.tv", 1.0))


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg/ffprobe are required for the real local-stream tests")
class RealLocalStreamTests(unittest.TestCase):
    """Real FFmpeg, real segment muxer, real rolling buffer, real concat encode. The source is a local file
    paced with -re, which is the same code path a live URL takes once FFmpeg has connected."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix="vanta-live-real-")
        cls.root = Path(cls.tmp.name)
        cls.video = make_video(cls.root / "stream.mp4", duration=14, size="320x240")
        cls.video_bytes = cls.video.stat().st_size

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def ingest(self, buffer, session_dir: Path) -> SegmentIngest:
        return SegmentIngest(session_dir, buffer,
                             IngestConfig(source=str(self.video), segment_seconds=2, realtime=True), stop_timeout=10)

    def feed(self, ingest: SegmentIngest, buffer: RollingBuffer, until: float, limit: float = 30.0) -> None:
        deadline = time.monotonic() + limit
        while time.monotonic() < deadline:
            ingest.poll()
            latest = buffer.status()["end"]
            if latest is not None and latest >= until:
                return
            time.sleep(0.2)

    def test_paced_stream_feeds_the_buffer_and_assembles_a_verified_clip(self):
        buffer = RollingBuffer(60)
        ingest = self.ingest(buffer, self.root / "session-a")
        ingest.start()
        try:
            self.feed(ingest, buffer, until=11.0)
            partial = ingest.status()
        finally:
            final = ingest.stop()
        self.assertGreaterEqual(partial["segments_published"], 2, partial)
        status = buffer.status()
        self.assertGreaterEqual(status["segments"], 3)
        segments = sorted(buffer.window(6.0, 1.0, 8.0)[0], key=lambda s: s.start)
        self.assertTrue(all(segment.path.is_file() and segment.path.stat().st_size > 0 for segment in segments))
        self.assertTrue(all(b.start >= a.end - 0.01 for a, b in zip(segments, segments[1:])), "overlapping segments")
        self.assertFalse(final["running"])
        self.assertIsNone(final["error"], final)
        self.assertEqual(self.video.stat().st_size, self.video_bytes, "the ingest must not touch its source")

        worker = LiveClipWorker(self.root / "clips")
        event = LiveEvent(7.0, 7.0, "manual", 90.0, ("operator marked this second",))
        result = worker.assemble(buffer, event, "real-local", 3.0, 3.0)
        self.assertEqual(result["status"], "ready_for_review", result)
        clip = Path(result["path"])
        self.assertTrue(clip.is_file() and clip.stat().st_size > 5000)
        self.assertAlmostEqual(ffprobe_duration(clip), 6.0, delta=1.5)

    def test_assembly_pins_its_segments_for_the_whole_ffmpeg_run(self):
        buffer = RollingBuffer(60)
        ingest = SegmentIngest(self.root / "session-pins", buffer,
                               IngestConfig(source=str(self.video), segment_seconds=2, realtime=False), stop_timeout=20)
        ingest.start()
        try:
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline and (buffer.status()["end"] or 0) < 10:
                time.sleep(0.2)
        finally:
            ingest.stop()
        self.assertGreaterEqual(buffer.status()["end"] or 0, 10, buffer.status())

        worker = LiveClipWorker(self.root / "clips-pins")
        checked: list[tuple[Path, bool]] = []
        real_run = clip_worker_module.subprocess.run

        def run_spy(command, **kwargs):
            manifest = Path(command[command.index("-i") + 1])
            for line in manifest.read_text(encoding="utf-8").splitlines():
                if line.startswith("file '"):
                    path = Path(line[len("file '"):-1])
                    checked.append((path, buffer.is_pinned(path)))
            return real_run(command, **kwargs)

        with mock.patch.object(clip_worker_module.subprocess, "run", side_effect=run_spy):
            result = worker.assemble(buffer, LiveEvent(6.0, 6.0, "manual", 90.0, ("pins test",)), "pinned-clip", 2.0, 2.0)
        self.assertEqual(result["status"], "ready_for_review", result)
        self.assertTrue(checked)
        self.assertTrue(all(pinned for _, pinned in checked), f"unpinned during assembly: {[str(p) for p, ok in checked if not ok]}")
        self.assertFalse(any(buffer.is_pinned(path) for path, _ in checked), "leases must be released after assembly")

    def test_a_failed_assembly_releases_its_lease(self):
        buffer = RollingBuffer(60)
        buffer.add(BufferedSegment(0.0, 2.0, self.root / "gone.ts"))
        worker = LiveClipWorker(self.root / "clips-gone")
        with self.assertRaises(LiveClipError):
            worker.assemble(buffer, LiveEvent(1.0, 1.0, "manual", 90.0, ()), "missing-lease", 1.0, 1.0)
        self.assertFalse(buffer.is_pinned(self.root / "gone.ts"))

    def test_worker_refuses_incomplete_coverage_and_missing_segments(self):
        buffer = RollingBuffer(60)
        worker = LiveClipWorker(self.root / "clips")
        early = worker.assemble(buffer, LiveEvent(50.0, 50.0, "manual", 50.0, ()), "too-early", 5.0, 5.0)
        self.assertEqual(early["status"], "pending_post_event_footage")
        ghost = self.root / "ghost.ts"
        ghost.write_bytes(b"x")
        segments_dir = (self.root / "session-ghost" / "segments")
        segments_dir.mkdir(parents=True, exist_ok=True)
        (segments_dir / "seg_00000.ts").write_bytes(b"x" * 4096)
        buffer.add(BufferedSegment(0.0, 2.0, segments_dir / "seg_00000.ts"))
        segments_dir.joinpath("seg_00000.ts").unlink()            # retired while the buffer still points at it
        with self.assertRaises(LiveClipError):
            worker.assemble(buffer, LiveEvent(2.0, 2.0, "manual", 50.0, ()), "missing", 2.0, 0.0)


@unittest.skipUnless(HAVE_FFMPEG, "FFmpeg/ffprobe are required for the end-to-end live clip test")
class DetectedEventProducesReviewClipTests(unittest.TestCase):
    """Fake chat transport + real local stream: a detected spike must produce exactly one review-only MP4."""

    def test_youtube_chat_spike_produces_one_review_only_clip(self):
        with tempfile.TemporaryDirectory(prefix="vanta-live-e2e-") as tmp:
            root = Path(tmp)
            video = make_video(root / "stream.mp4", duration=18, size="320x240")
            manager = LiveStreamManager()
            session = manager.start("youtube", "authorised-local-test", buffer_seconds=60, post_event_seconds=2)
            ingest = SegmentIngest(root / "session", session.buffer,
                                   IngestConfig(source=str(video), segment_seconds=2, realtime=True), stop_timeout=10)
            pipeline = LiveReviewPipeline(manager, LiveClipWorker(root / "clips"), before_seconds=3,
                                          max_wait_seconds=25, poll_seconds=0.1)
            manager.on_event = pipeline.on_event
            ingest.start()
            try:
                deadline = time.monotonic() + 30
                while time.monotonic() < deadline and (session.buffer.status()["end"] or 0) < 9:
                    ingest.poll()
                    time.sleep(0.2)
                stamp = session.buffer.status()["end"]
                self.assertGreaterEqual(stamp or 0, 9, session.buffer.status())

                # Fake transport pages: eight distinct viewers reacting within a second.
                reactions = [("uc-1", "WHAT"), ("uc-2", "NO WAY"), ("uc-3", "clutch"), ("uc-4", "insane play"),
                             ("uc-5", "OMG"), ("uc-6", "he actually did it"), ("uc-7", "that was wild"), ("uc-8", "lets go")]
                adapter = YouTubeLiveChatAdapter(FakeYouTubeService([chat_page(reactions)]), "live-chat-id")
                for index, message in enumerate(adapter.poll()):
                    manager.add_chat(session.id, replace(message, timestamp=stamp + index * 0.01))

                self.assertTrue(session.events, "the fake chat spike did not become an event")
                jobs = pipeline.jobs(session.id)
                self.assertEqual(len(jobs), 1, jobs)
                job = pipeline.wait(jobs[0]["id"], timeout=30)
            finally:
                ingest.stop()
                pipeline.drain(timeout=10)

            self.assertEqual(job["status"], "ready_for_review", job)
            self.assertTrue(job["review_only"])
            self.assertFalse(job["published"])
            clip = Path(job["path"])
            self.assertTrue(clip.is_file() and clip.stat().st_size > 5000, job)
            self.assertAlmostEqual(ffprobe_duration(clip), 5.0, delta=2.0)
            self.assertIn(session.id, clip.name)
            self.assertEqual(pipeline.status()["review_only"], True)


if __name__ == "__main__":
    unittest.main()
