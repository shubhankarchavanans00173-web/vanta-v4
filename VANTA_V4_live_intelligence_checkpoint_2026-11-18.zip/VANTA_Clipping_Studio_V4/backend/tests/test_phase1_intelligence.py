"""Phase 1 regression tests for contextual conversation and humour signals.

All examples are synthetic transcripts.  No model, network service, or video
decoder is needed to prove the transcript decision path.
"""
from __future__ import annotations

import unittest

from app.clipstudio import analysis, db
from app.clipstudio.intelligence import analyze_conversation, analyze_humor, classify_event
from app.clipstudio.selection import candidates as candidate_builder
from app.clipstudio.selection import features


def units(*texts: str):
    return [analysis.Unit(index * 4.0, index * 4.0 + 3.0, text) for index, text in enumerate(texts)]


class ContextualHumorTests(unittest.TestCase):
    def setUp(self):
        self.exchange = units(
            "Guys, I'm actually a professional player.",
            "Then why are you losing?",
            "I'm letting them win.",
            "Chat says COPIUM after that answer.",
        )

    def test_setup_and_punchline_outscore_a_lone_laughter_word(self):
        complete = analyze_humor(self.exchange)
        lone_reaction = analyze_humor(units("LOL LOL LOL"))
        self.assertGreaterEqual(complete["value"], 0.7)
        self.assertEqual(complete["kind"], "setup-punchline")
        self.assertTrue(complete["requires_setup"] is False)
        self.assertEqual(lone_reaction["value"], 0.0)

    def test_banter_uses_context_and_does_not_assume_speaker_identity(self):
        result = analyze_conversation(self.exchange)
        self.assertGreaterEqual(result["value"], 0.5)
        self.assertIn("response exchange", result["events"])
        self.assertIn("streamer-viewer interaction", result["events"])
        self.assertNotIn("speaker", result["evidence"].lower())

    def test_punchline_without_setup_is_caveated(self):
        result = analyze_humor(units("I'm letting them win."))
        self.assertTrue(result["requires_setup"])
        self.assertLess(result["value"], 0.4)
        self.assertIn("needs prior context", result["evidence"])

    def test_semantic_anchor_expands_to_the_detected_setup(self):
        starts = candidate_builder._starts(self.exchange, 2)
        self.assertIn(1, starts)  # the preceding question is setup for the answer

    def test_feature_and_event_explanations_are_evidence_based(self):
        window = features.Window(self.exchange, 0.0, 15.0, 0, 3, self.exchange, 15.0, 15.0, 45.0)
        extracted = features.extract(window, scenes_known=False)
        event = classify_event(self.exchange)
        self.assertGreater(extracted["humor_quality"]["value"], 0.65)
        self.assertGreater(extracted["conversation_significance"]["value"], 0.5)
        self.assertEqual(extracted["event_type"]["kind"], event["category"])
        self.assertIn("letting them win", extracted["humor_quality"]["evidence"].lower())

    def test_requested_editor_feedback_labels_are_available_without_dropping_legacy_rows(self):
        requested = {"excellent", "good", "average", "bad", "missed_context", "not_funny", "duplicate", "wrong_boundaries"}
        self.assertTrue(requested.issubset(db.FEEDBACK_LABELS))
        self.assertIn("missing_context", db.LEGACY_FEEDBACK_LABELS)


if __name__ == "__main__":
    unittest.main()
