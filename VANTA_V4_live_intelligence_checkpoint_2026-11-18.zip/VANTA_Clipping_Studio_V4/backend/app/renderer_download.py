"""Authorised direct-URL video download for the legacy renderer.

Split from renderer.py (Phase 2c); re-exported there, behaviour unchanged.
"""
from __future__ import annotations

import httpx
import ipaddress
import socket
from pathlib import Path
from urllib.parse import urlparse
from .renderer_common import MAX_DIRECT_VIDEO_BYTES


def _download_authorized_video(url: str, destination: Path) -> Path:
    parsed=urlparse(url)
    if parsed.scheme!="https" or not parsed.hostname or parsed.username or parsed.password or parsed.port not in {None,443}:
        raise RuntimeError("Video URLs must be direct HTTPS media links without credentials or custom ports.")
    try:
        addresses={item[4][0] for item in socket.getaddrinfo(parsed.hostname,None,type=socket.SOCK_STREAM)}
        if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
            raise RuntimeError("The video URL host must resolve only to public IP addresses.")
        confirmed={item[4][0] for item in socket.getaddrinfo(parsed.hostname,None,type=socket.SOCK_STREAM)}
        if addresses!=confirmed:
            raise RuntimeError("The video URL host changed its DNS address during validation.")
    except (OSError,ValueError) as error:
        raise RuntimeError("Could not safely resolve the public video URL host.") from error

    response=None
    try:
        with httpx.Client(
            timeout=httpx.Timeout(connect=15,read=60,write=30,pool=15),
            follow_redirects=False,
        ) as client:
            with client.stream("GET",url,headers={"User-Agent":"UniversalAIShortsStudio/2.1"}) as response:
                if response.is_redirect:
                    raise RuntimeError("Video URL redirects are not followed. Use a direct HTTPS media URL.")
                response.raise_for_status()
                content_type=response.headers.get("content-type","").split(";",1)[0].lower()
                suffix=Path(parsed.path).suffix.lower()
                if content_type not in {"application/octet-stream","binary/octet-stream"} and not content_type.startswith("video/"):
                    raise RuntimeError("The supplied URL did not return a video media response.")
                if suffix not in {".mp4",".mov",".mkv",".webm"}:
                    suffix={ "video/mp4":".mp4","video/quicktime":".mov","video/x-matroska":".mkv","video/webm":".webm"}.get(content_type,".mp4")
                length=int(response.headers.get("content-length") or 0)
                if length>MAX_DIRECT_VIDEO_BYTES:
                    raise RuntimeError("The remote video exceeds the 512 MiB direct-URL limit.")
                destination=destination.with_suffix(suffix)
                total=0
                with destination.open("wb") as output:
                    for chunk in response.iter_bytes(1024*1024):
                        total+=len(chunk)
                        if total>MAX_DIRECT_VIDEO_BYTES:
                            raise RuntimeError("The remote video exceeded the 512 MiB direct-URL limit.")
                        output.write(chunk)
        if total==0:
            raise RuntimeError("The video URL returned an empty file.")
        return destination
    except Exception:
        destination.unlink(missing_ok=True)
        raise
