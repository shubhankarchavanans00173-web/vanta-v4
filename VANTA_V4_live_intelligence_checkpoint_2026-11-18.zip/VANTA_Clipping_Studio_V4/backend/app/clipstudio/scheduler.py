"""Opt-in persistent scheduler for approved VANTA clips.

The scheduler can only render an already-approved local candidate. It never
downloads a source, calls a hosted AI service, or invokes YouTube upload code.
Its state lives in the VANTA SQLite database, while a small local lock prevents
two backend processes from dispatching the same task.
"""
from __future__ import annotations

import logging
import os
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from . import db, pipeline, settings
from .render import RenderError, RenderSettings

LOG = logging.getLogger("vanta.scheduler")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
POLL_SECONDS = 5


class SchedulerError(RuntimeError):
    pass


def validate_config(values: dict) -> dict:
    """Validate user-facing values before they are persisted."""
    out = dict(values)
    zone = str(out.get("timezone", "UTC")).strip() or "UTC"
    try:
        ZoneInfo(zone)
    except ZoneInfoNotFoundError as error:
        raise SchedulerError("Timezone must be an IANA name such as UTC or Asia/Kolkata.") from error
    clock = str(out.get("time_of_day", "09:00")).strip()
    if not TIME_RE.fullmatch(clock):
        raise SchedulerError("time_of_day must use 24-hour HH:MM format.")
    for key, low, high in (("videos_per_run", 1, 10), ("retry_limit", 0, 5)):
        try:
            value = int(out.get(key, 1 if key == "videos_per_run" else 1))
        except (TypeError, ValueError) as error:
            raise SchedulerError(f"{key} must be a whole number.") from error
        if not low <= value <= high:
            raise SchedulerError(f"{key} must be between {low} and {high}.")
        out[key] = value
    out["timezone"], out["time_of_day"] = zone, clock
    out["enabled"], out["paused"] = bool(out.get("enabled", False)), bool(out.get("paused", False))
    return out


def _utc(value: datetime | None = None) -> datetime:
    if value is None:
        return datetime.now(timezone.utc)
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def _after(value: datetime, seconds: int) -> str:
    return (value + timedelta(seconds=seconds)).isoformat()


class _AppendFileHandler(logging.Handler):
    """Append one line per record and hold no open handle between records.

    A standard ``FileHandler`` keeps the log file open for the life of the process. On Windows that
    blocks deleting or moving the folder that holds it (our own tests could not remove their temp
    data folder), so the file is opened only for the write.
    """

    def __init__(self, path: Path) -> None:
        super().__init__()
        self.path = Path(path)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path, "a", encoding="utf-8") as handle:
                handle.write(self.format(record) + "\n")
        except Exception:  # logging must never break the scheduler
            self.handleError(record)


def _ensure_log_file() -> None:
    path = settings.DIAG_DIR / "scheduler.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    if any(getattr(h, "_vanta_scheduler_path", None) == str(path) for h in LOG.handlers):
        return
    # The data folder can change in one process (tests, or a restarted configuration): detach the
    # handler that points at the previous log instead of accumulating handlers.
    for old in list(LOG.handlers):
        if getattr(old, "_vanta_scheduler_path", None):
            LOG.removeHandler(old)
            old.close()
    handler = _AppendFileHandler(path)
    handler._vanta_scheduler_path = str(path)  # type: ignore[attr-defined]
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    LOG.addHandler(handler)
    LOG.setLevel(logging.INFO)


class InstanceLock:
    """Portable create-exclusive lock with stale-PID recovery for local backends."""

    def __init__(self) -> None:
        self.path: Path | None = None
        self.held = False

    @staticmethod
    def _pid_is_live(pid: int) -> bool:
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError:
            return False
        return True

    def acquire(self) -> bool:
        if self.held:
            return True
        path = settings.BASE / "scheduler.lock"
        path.parent.mkdir(parents=True, exist_ok=True)
        for attempt in range(2):
            try:
                fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w", encoding="ascii") as handle:
                    handle.write(str(os.getpid()))
                self.path, self.held = path, True
                return True
            except FileExistsError:
                try:
                    owner = int(path.read_text(encoding="ascii").strip())
                except (OSError, ValueError):
                    owner = 0
                if attempt == 0 and not self._pid_is_live(owner):
                    try:
                        path.unlink()
                    except OSError:
                        pass
                    continue
                return False
        return False

    def release(self) -> None:
        if self.held and self.path:
            try:
                self.path.unlink()
            except FileNotFoundError:
                pass
        self.path, self.held = None, False


class SchedulerService:
    def __init__(self) -> None:
        self._lock = InstanceLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive() and self._lock.held)

    def start(self) -> bool:
        _ensure_log_file()
        if self.running:
            return True
        if not self._lock.acquire():
            raise SchedulerError("Another VANTA backend already owns the scheduler lock. Stop it before enabling scheduling here.")
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="vanta-scheduler")
        self._thread.start()
        LOG.info("scheduler started")
        return True

    def stop(self) -> None:
        self._stop.set()
        thread = self._thread
        if thread and thread is not threading.current_thread():
            thread.join(timeout=POLL_SECONDS + 1)
        self._thread = None
        self._lock.release()
        LOG.info("scheduler stopped")

    def startup(self) -> None:
        """Recover old task state, then start only when the persisted switch is on."""
        _ensure_log_file()
        self.reconcile(_utc())
        if db.get_scheduler_config()["enabled"]:
            self.start()

    def _loop(self) -> None:
        while not self._stop.wait(POLL_SECONDS):
            try:
                self.run_once()
            except Exception:
                LOG.exception("scheduler tick failed")

    def reconcile(self, current: datetime | None = None) -> None:
        current = _utc(current)
        for task in db.recover_scheduler_dispatches():
            jid = task.get("job_id")
            job = db.get_job(jid) if jid else None
            if not jid or not job:
                db.scheduler_task_retry(task["id"], "Backend restarted before the scheduled render job was attached.", _after(current, 30))
                LOG.warning("requeued interrupted scheduler task %s without a job", task["id"])
            elif job["status"] == "completed":
                db.scheduler_task_complete(task["id"])
                LOG.info("marked scheduler task %s complete after restart", task["id"])
            elif job["status"] in {"failed", "cancelled"}:
                self._retry(task, job.get("error") or f"Render job {job['status']}", current)

    def _retry(self, task: dict, reason: str, current: datetime) -> None:
        attempt = int(task.get("attempts") or 0) + 1
        updated = db.scheduler_task_retry(task["id"], reason, _after(current, 30 * attempt))
        if updated and updated["status"] == "ready":
            LOG.warning("scheduled task %s will retry (%s/%s): %s", task["id"], attempt, task["retry_limit"], reason)
        else:
            LOG.error("scheduled task %s exhausted retries: %s", task["id"], reason)

    def _dispatch_task(self, task: dict, current: datetime) -> None:
        candidate = db.get_candidate(task["candidate_id"])
        if candidate is None:
            db.finish_scheduler_task(task["id"], "failed", "The scheduled clip was deleted.")
            LOG.error("scheduler task %s has no candidate", task["id"])
            return
        if candidate["status"] == "rendered":
            db.finish_scheduler_task(task["id"], "completed")
            LOG.info("scheduler task %s was already rendered", task["id"])
            return
        if candidate["status"] not in {"approved", "failed"}:
            db.finish_scheduler_task(task["id"], "cancelled", f"Clip is {candidate['status']}, not approved for rendering.")
            LOG.warning("cancelled scheduler task %s because candidate is %s", task["id"], candidate["status"])
            return
        try:
            RenderSettings.from_dict(task["render_settings"])
            pipeline.resolve_music(task["render_settings"].get("music_id"))
            job = pipeline.submit_render(task["project_id"], [task["candidate_id"]], task["render_settings"])
        except pipeline.Busy as error:
            db.defer_scheduler_task(task["id"], str(error), _after(current, 30))
            LOG.info("deferred scheduler task %s: %s", task["id"], error)
            return
        except (RenderError, ValueError, KeyError) as error:
            self._retry(task, str(error), current)
            return
        except Exception as error:
            self._retry(task, f"{type(error).__name__}: {error}", current)
            LOG.exception("scheduler task %s could not be submitted", task["id"])
            return
        db.scheduler_task_running(task["id"], job["id"])
        LOG.info("dispatched scheduler task %s as render job %s", task["id"], job["id"])

    def _dispatch(self, run_key: str, config: dict, current: datetime) -> list[dict]:
        db.reset_stale_scheduler_run(run_key)
        tasks = db.claim_scheduler_tasks(run_key, config["videos_per_run"], current.isoformat())
        for task in tasks:
            self._dispatch_task(task, current)
        return tasks

    def run_once(self, current: datetime | None = None) -> list[dict]:
        """Run one durable tick. Public for deterministic automated tests."""
        current = _utc(current)
        self.reconcile(current)
        config = db.get_scheduler_config()
        if not config["enabled"] or config["paused"]:
            return []
        local = current.astimezone(ZoneInfo(config["timezone"]))
        run_key = f"daily:{local.date().isoformat()}"
        hour, minute = (int(x) for x in config["time_of_day"].split(":"))
        if (local.hour, local.minute) < (hour, minute):
            return []
        if config.get("last_run_key") != run_key:
            db.update_scheduler_config(last_run_key=run_key)
            LOG.info("starting scheduler run %s", run_key)
        return self._dispatch(run_key, config, current)

    def run_now(self, current: datetime | None = None) -> list[dict]:
        """Explicit user-triggered local render batch. It does not enable recurring scheduling."""
        current = _utc(current)
        self.reconcile(current)
        config = db.get_scheduler_config()
        if config["paused"]:
            raise SchedulerError("Resume the scheduler before running a queued batch.")
        run_key = "manual:" + current.strftime("%Y%m%dT%H%M%SZ")
        tasks = self._dispatch(run_key, config, current)
        LOG.info("manual scheduler run %s dispatched %d task(s)", run_key, len(tasks))
        return tasks


SERVICE = SchedulerService()


def startup() -> None:
    SERVICE.startup()


def shutdown() -> None:
    SERVICE.stop()


def apply_config(values: dict) -> dict:
    config = validate_config({**db.get_scheduler_config(), **values})
    saved = db.update_scheduler_config(**{key: config[key] for key in (
        "enabled", "paused", "timezone", "time_of_day", "videos_per_run", "retry_limit")})
    if saved["enabled"]:
        SERVICE.start()
    else:
        SERVICE.stop()
    return {**saved, "running": SERVICE.running}


def status() -> dict:
    return {**db.get_scheduler_config(), "running": SERVICE.running, "task_counts": {
        state: sum(1 for task in db.list_scheduler_tasks() if task["status"] == state)
        for state in db.SCHEDULER_TASK_STATES
    }}
