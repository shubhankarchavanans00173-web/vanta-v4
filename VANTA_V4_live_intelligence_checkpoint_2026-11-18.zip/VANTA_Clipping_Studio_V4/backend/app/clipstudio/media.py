"""Source-media inspection (ffprobe) and light-weight analysis signals (silence, scene changes)."""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path

PROBE_TIMEOUT = 60
ANALYSIS_TIMEOUT = 900


class MediaError(RuntimeError):
    """The file is not usable media (missing, corrupt, no video stream, too long...)."""


def _tool(name: str) -> str:
    found = shutil.which(name)
    if not found:
        raise MediaError(f"{name} was not found on PATH. Install FFmpeg and restart the backend.")
    return found


def _fraction(value: str | None) -> float:
    try:
        if value and "/" in value:
            a, b = value.split("/", 1)
            return float(a) / float(b) if float(b) else 0.0
        return float(value) if value else 0.0
    except (ValueError, ZeroDivisionError):
        return 0.0


def probe(path: Path) -> dict:
    """Inspect a media file with ffprobe. Raises MediaError when it is not playable video."""
    path = Path(path)
    if not path.is_file():
        raise MediaError("The media file does not exist.")
    try:
        result = subprocess.run(
            [_tool("ffprobe"), "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
            capture_output=True, text=True, timeout=PROBE_TIMEOUT,
        )
    except subprocess.TimeoutExpired as error:
        raise MediaError("Inspecting the file timed out.") from error
    if result.returncode != 0:
        raise MediaError("This file is not readable media: " + ((result.stderr or "ffprobe failed").strip().splitlines() or ["ffprobe failed"])[-1][:200])
    try:
        data = json.loads(result.stdout or "{}")
    except json.JSONDecodeError as error:
        raise MediaError("ffprobe returned unreadable output.") from error
    streams = data.get("streams") or []
    video = next((s for s in streams if s.get("codec_type") == "video" and s.get("disposition", {}).get("attached_pic") != 1), None)
    audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
    if not video:
        raise MediaError("The file has no video stream.")
    fmt = data.get("format") or {}
    try:
        duration = float(fmt.get("duration") or video.get("duration") or 0)
    except ValueError:
        duration = 0.0
    if duration <= 0:
        raise MediaError("The video has no readable duration.")
    rotation = 0
    for item in video.get("side_data_list") or []:
        if "rotation" in item:
            rotation = int(abs(float(item["rotation"]))) % 360
    width, height = int(video.get("width") or 0), int(video.get("height") or 0)
    if rotation in (90, 270):
        width, height = height, width
    return {
        "duration": round(duration, 3),
        "width": width, "height": height,
        "fps": round(_fraction(video.get("avg_frame_rate") or video.get("r_frame_rate")), 3),
        "video_codec": video.get("codec_name"),
        "audio_codec": audio.get("codec_name") if audio else None,
        "has_audio": audio is not None,
        "size_bytes": int(fmt.get("size") or path.stat().st_size),
        "container": fmt.get("format_name"),
    }


def validate_source(path: Path, max_duration: float) -> dict:
    info = probe(path)
    if info["duration"] > max_duration:
        raise MediaError(f"The video is {info['duration'] / 60:.0f} minutes long; the configured limit is {max_duration / 60:.0f} minutes.")
    if info["width"] < 2 or info["height"] < 2:
        raise MediaError("The video has invalid dimensions.")
    return info


def detect_silences(path: Path, noise_db: float = -35.0, min_silence: float = 0.5) -> list[tuple[float, float]]:
    """Return (start, end) silences from ffmpeg silencedetect. Empty list when no audio."""
    if not probe(path)["has_audio"]:
        return []
    cmd = [_tool("ffmpeg"), "-hide_banner", "-nostats", "-i", str(path), "-vn", "-af",
           f"silencedetect=noise={noise_db}dB:d={min_silence}", "-f", "null", "-"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=ANALYSIS_TIMEOUT)
    except subprocess.TimeoutExpired as error:
        raise MediaError("Silence detection timed out.") from error
    if result.returncode != 0:
        raise MediaError("Silence detection failed: " + (result.stderr or "").strip()[-300:])
    starts = [float(m) for m in re.findall(r"silence_start: (-?[0-9.]+)", result.stderr)]
    ends = [float(m) for m in re.findall(r"silence_end: ([0-9.]+)", result.stderr)]
    out = []
    for i, s in enumerate(starts):
        e = ends[i] if i < len(ends) else None
        if e is not None:
            out.append((max(0.0, s), e))
    return out


def detect_scene_changes(path: Path, threshold: float = 0.3) -> list[tuple[float, float]]:
    """(time, score) of visual scene changes using ffmpeg's scene score."""
    cmd = [_tool("ffmpeg"), "-hide_banner", "-nostats", "-i", str(path), "-an",
           "-vf", f"select='gt(scene,{threshold})',metadata=print", "-f", "null", "-"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=ANALYSIS_TIMEOUT)
    except subprocess.TimeoutExpired as error:
        raise MediaError("Scene detection timed out.") from error
    if result.returncode != 0:
        raise MediaError("Scene detection failed: " + (result.stderr or "").strip()[-300:])
    events, current = [], None
    for line in result.stderr.splitlines():
        t = re.search(r"pts_time:([0-9.]+)", line)
        s = re.search(r"lavfi\.scene_score=([0-9.]+)", line)
        if t:
            current = float(t.group(1))
        elif s and current is not None:
            events.append((current, float(s.group(1))))
            current = None
    return events
