"""Constants shared by the yt-dlp modules (split from ytdlp.py; behaviour unchanged)."""
from __future__ import annotations



MEDIA_SUFFIXES = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mpg", ".mpeg", ".ts"}
DEFAULT_FORMAT = "bv*[height<=1080]+ba/b[height<=1080]/bv*+ba/b"
PIP_SPEC = "yt-dlp[default]"          # [default] pulls yt-dlp-ejs, the local YouTube JS-challenge solver scripts
JS_RUNTIMES = ("deno", "node", "quickjs", "bun")
_JS_MIN_MAJOR = {"deno": 2, "node": 20, "bun": 1, "quickjs": 0}
AUTO_RETRY_CODES = {"network_error", "timeout", "server_error"}
ALLOWED_REMOTE_COMPONENTS = {"ejs:github", "ejs:npm"}
