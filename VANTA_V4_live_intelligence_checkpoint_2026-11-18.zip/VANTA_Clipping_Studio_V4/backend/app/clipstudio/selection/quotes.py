"""Quote integrity: any transcript text shown to the user must actually occur in the transcript.

Hook, payoff, setup and excerpt strings are checked against the real transcript (whitespace, case, quote style and
punctuation-insensitive). A string that cannot be found is removed from the explanation and the removal is recorded -
the UI never shows a "quotation" that is not in the transcript.
"""
from __future__ import annotations

import re

from ..transcript import Transcript

_QUOTES = str.maketrans({"\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"', "\u2013": "-", "\u2014": "-", "\u00a0": " "})


def normalize(text: str) -> str:
    t = (text or "").translate(_QUOTES).lower()
    t = re.sub(r"[^\w\s']", " ", t, flags=re.UNICODE)
    return re.sub(r"\s+", " ", t).strip()


def transcript_blob(transcript: Transcript | None) -> str:
    if transcript is None or not transcript.available:
        return ""
    return " " + normalize(" ".join(s.text for s in transcript.segments)) + " "


def is_quote_in(quote: str | None, blob: str) -> bool:
    q = normalize((quote or "").rstrip("…").rstrip("."))
    return bool(q) and bool(blob) and (" " + q + " ") in blob


def verify_analysis(analysis: dict, excerpt: str, blob: str) -> tuple[dict, str, dict]:
    """Return (analysis, excerpt, report). Unverifiable strings are dropped; ``report`` lists what was checked."""
    report = {"verified": [], "dropped": []}
    if not blob:
        return analysis, excerpt, report

    def check(label: str, text: str | None) -> str | None:
        if not text:
            return text
        if is_quote_in(text, blob):
            report["verified"].append(label)
            return text
        report["dropped"].append(label)
        return None

    analysis["hook"] = check("hook", analysis.get("hook"))
    analysis["payoff"] = check("payoff", analysis.get("payoff"))
    sug = analysis.get("suggested_setup")
    if sug:
        if check("suggested_setup", sug.get("setup")) is None:
            analysis["suggested_setup"], analysis["needs_setup"] = None, False
    ex = check("excerpt", excerpt)
    analysis["quote_check"] = report
    return analysis, (ex or ""), report
