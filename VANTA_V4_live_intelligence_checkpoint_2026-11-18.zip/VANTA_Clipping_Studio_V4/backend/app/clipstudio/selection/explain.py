"""Explanations built only from measured features and real transcript text. Nothing here is free-written or generic."""
from __future__ import annotations

SCORE_MEANING = ("Relative ranking score (0–100) that orders clips within THIS video using the signals listed. "
                 "It is not a probability and does not predict views or virality.")
CONFIDENCE_DEFINITION = ("Confidence describes how much of the rubric could be measured and how clean the cut points are, not how popular the clip will be. "
                         "high = transcript used, ≥85% of the rubric measurable, clean start and end; medium = transcript used but some signals or boundaries are weak; "
                         "low = no transcript (audio/scene cues only), so meaning was not assessed.")

_POSITIVE = [("humor_quality", 0.65), ("conversation_significance", 0.6), ("unexpectedness", 0.6), ("hook", 0.65), ("payoff", 0.65), ("standalone_clarity", 0.8), ("story_completeness", 0.8), ("ending_quality", 0.7),
             ("opening_quality", 0.7), ("information_value", 0.7), ("pause_before_payoff", 0.9)]


def build(feats: dict, penalties: dict, window_units: list, signals_used: list[str], boundary: float, coverage: float, has_text: bool) -> dict:
    pos = [feats[k]["evidence"] for k, thr in _POSITIVE if (feats.get(k, {}).get("value") or 0) >= thr and feats[k].get("evidence")]
    caveats: list[str] = []
    ctx = feats.get("context_dependency", {})
    if (ctx.get("value") or 0) >= 0.4:
        caveats.append(ctx["evidence"] + " It may need a short setup before it.")
    rep = feats.get("repetition", {})
    if (rep.get("value") or 0) >= 0.35:
        caveats.append("Repetitive: " + rep["evidence"])
    lv = feats.get("low_value_content", {})
    if (lv.get("value") or 0) >= 0.3:
        caveats.append(lv["evidence"])
    humor = feats.get("humor_quality", {})
    if humor.get("requires_setup"):
        caveats.append("A possible punchline was detected without its setup; check that the clip begins early enough to make the joke understandable.")
    for k, label in (("story_completeness", "Possibly incomplete"), ("opening_quality", "Weak opening"), ("ending_quality", "Weak ending")):
        v = feats.get(k, {}).get("value")
        if v is not None and v < 0.4:
            caveats.append(f"{label}: {feats[k]['evidence']}")
    hk = feats.get("hook", {})
    hook_text = hk.get("text") if (hk.get("value") or 0) >= 0.5 else None
    po = feats.get("payoff", {})
    payoff_text = po.get("text") if po.get("kind") not in (None, "none") else None

    level = "low"
    if has_text:
        level = "high" if (coverage >= 0.85 and boundary >= 0.7 and not caveats) else "medium"
    if has_text:
        summary = " ".join(pos[:3]) if pos else "No strong hook or payoff was detected; ranked on the remaining measurable signals."
    else:
        summary = ("No transcript: ranked on " + " and ".join(signals_used or ["duration"]) + " only, so the meaning of this moment was not assessed. "
                   "Add subtitles or enable local transcription for a content-aware ranking.")
    uncertain = []
    if boundary < 0.5:
        uncertain.append("cut points are uncertain; check the start and end in the preview")
    return {
        "summary": summary, "reasons": pos + ([] if has_text else [summary]), "caveats": caveats, "hook": hook_text, "payoff": payoff_text,
        "confidence": {"level": level, "rubric_coverage": round(coverage, 2), "boundary_quality": round(boundary, 2), "uncertain": uncertain,
                       "definition": CONFIDENCE_DEFINITION},
    }
