"""Normalised feature scores -> one relative ranking score. Missing signals are removed and the remaining weights renormalised.

The score orders candidates *within one video*. It is not a probability and does not predict views or virality.
"""
from __future__ import annotations

import json
import os

DEFAULT_WEIGHTS: dict[str, float] = {
    # These are ranking weights, not view predictions.  They intentionally
    # favour a complete, understandable moment over a loud isolated reaction.
    "humor_quality": 0.20, "unexpectedness": 0.15, "conversation_significance": 0.10,
    "story_completeness": 0.10, "emotional_intensity": 0.10, "visual_activity": 0.10,
    "standalone_clarity": 0.05, "payoff": 0.05, "hook": 0.05, "energy_dynamics": 0.05,
    "duration_fit": 0.01, "caption_readability": 0.02, "speech_activity": 0.01, "pause_before_payoff": 0.01,
}
# Maximum points subtracted when the penalty feature is 1.0.
PENALTY_MAX: dict[str, float] = {"context_dependency": 20.0, "repetition": 15.0, "low_value_content": 25.0}

SIGNAL_OF = {  # which input signal a feature depends on
    "speech_activity": "audio-loudness", "energy_dynamics": "audio-loudness", "pause_before_payoff": "audio-loudness",
    "visual_activity": "scene-cuts",
}


def weights(override: dict | None = None) -> dict[str, float]:
    """Defaults, optionally overridden by ``override`` or the VANTA_RANK_WEIGHTS env var (JSON object). Unknown keys are ignored."""
    w = dict(DEFAULT_WEIGHTS)
    src = override
    if src is None and os.getenv("VANTA_RANK_WEIGHTS"):
        try:
            src = json.loads(os.environ["VANTA_RANK_WEIGHTS"])
        except ValueError:
            src = None
    if isinstance(src, dict):
        for k, v in src.items():
            if k in w and isinstance(v, (int, float)) and v >= 0:
                w[k] = float(v)
    return w


def combine(feats: dict[str, dict], w: dict[str, float] | None = None) -> dict:
    """Return {score, coverage, used, missing, penalties}. ``coverage`` = share of total rubric weight that was measurable."""
    w = w or weights()
    total = sum(w.values()) or 1.0
    used = {k: v for k, v in w.items() if feats.get(k, {}).get("value") is not None and v > 0}
    missing = [k for k in w if feats.get(k, {}).get("value") is None]
    wsum = sum(used.values())
    base = 100 * sum(feats[k]["value"] * v for k, v in used.items()) / wsum if wsum else 0.0
    pens: dict[str, float] = {}
    for k, mx in PENALTY_MAX.items():
        val = feats.get(k, {}).get("value")
        if val:
            pens[k] = round(mx * val, 1)
    score = max(0.0, min(100.0, base - sum(pens.values())))
    return {"score": round(score, 1), "base": round(base, 1), "coverage": round(wsum / total, 3), "used": sorted(used),
            "missing": missing, "penalties": pens}
