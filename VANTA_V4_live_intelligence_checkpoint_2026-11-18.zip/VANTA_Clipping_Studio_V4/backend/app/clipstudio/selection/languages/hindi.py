"""Hindi and romanised-Hindi (Hinglish) surface cues.

What this module does: it finds **words and phrases the speaker actually used** and returns them as
inspectable evidence, grouped into a few broad categories. It is the multilingual counterpart of the
English regexes in ``selection/lexicon.py`` and has the same status: rules, not understanding.

What it does not do: translate, resolve meaning, judge tone, or hear anything. A hit means the
transcript contained that surface form - *not* that the moment is funny, sarcastic or worth posting.
Devanagari is matched literally (word-boundary rules do not apply reliably across scripts); romanised
forms use a Latin-letter boundary so an English word cannot trigger them from inside another word.
"""
from __future__ import annotations

import re

# Romanised cues must stand alone: `(?<![A-Za-z])` / `(?![A-Za-z])`. Devanagari cues are matched as-is.
_L, _R = r"(?<![A-Za-z])", r"(?![A-Za-z])"

# Devanagari is written alternately with and without the nukta (मज़ाक / मजाक), so both are listed.
CUES: dict[str, tuple[str, ...]] = {
    "laughter": (r"(?:हा){2,}", r"(?:ही){2,}", "हँस", "हसी", _L + r"(?:ha){2,}" + _R, _L + r"(?:he){2,}" + _R, _L + r"(?:hi){2,}" + _R,
                 _L + r"hans(i|na|ne|raha|rahi)?" + _R),
    "humour": ("मज़ाक", "मजाक", "मज़ेदार", "मजेदार", "चुटकुला", "ठठा", _L + r"maza+k" + _R, _L + r"mazed+a+r" + _R,
               _L + r"majak" + _R, _L + r"chutkula" + _R),
    "banter": ("यार", "भाई", "अरे", "अबे", "पगल", "बकवास", "फालतू", "चुप", "साला", _L + r"ya+r" + _R, _L + r"bhai" + _R,
               _L + r"arey" + _R, _L + r"arre" + _R, _L + r"abe" + _R, _L + r"pa?agal" + _R, _L + r"bakwa+s" + _R,
               _L + r"bakwas" + _R, _L + r"faltu" + _R, _L + r"chup" + _R, _L + r"saale" + _R, _L + r"matlab" + _R),
    "sarcasm": ("वाह", "हाँ हाँ", "ज़रूर", "जरूर", "सही है", "क्या बात", "बिल्कुल सही", _L + r"wah" + _R,
                _L + r"haan[ -]haan" + _R, _L + r"zaroor" + _R, _L + r"jaroor" + _R, _L + r"sahi hai" + _R,
                _L + r"kya baat" + _R, _L + r"bilkul sahi" + _R),
    "surprise": ("सच में", "अरे वाह", "क्या हुआ", _L + r"kya" + _R, _L + r"sach mei?n" + _R,
                 _L + r"sach me" + _R, _L + r"arey wah" + _R, _L + r"kya hua" + _R),
    "frustration": ("बस कर", "छोड़", "परेशान", "क्या कर रहा", "सिर दर्द", _L + r"bas kar" + _R, _L + r"chho?d" + _R,
                    _L + r"pareshan" + _R, _L + r"kya kar rahi?" + _R, _L + r"sar dard" + _R),
    "agreement": ("हाँ", "हां", "बिल्कुल", "सही", _L + r"haan" + _R, _L + r"han" + _R, _L + r"bilkul" + _R, _L + r"sahi" + _R),
    "disagreement": ("नहीं", "गलत", "झूठ", _L + r"nahi+n?" + _R, _L + r"galat" + _R, _L + r"jhoo?th" + _R),
}

_COMPILED: dict[str, tuple[re.Pattern[str], ...]] = {
    category: tuple(re.compile(pattern, re.IGNORECASE) for pattern in patterns) for category, patterns in CUES.items()
}

# Distinctive Hindi words used only to recognise Hinglish written in Latin letters. Deliberately
# excludes "hai"/"ka"/"ki", which occur inside ordinary English words ("Haiti").
ROMANISED_MARKERS = (re.compile(
    _L + r"(?:ya+r|bhai|arey|arre|abe|pa?agal|bakwa+s|bakwas|faltu|matlab|kya|sach|haan|nahi+n?|galat|jhoo?th|maza+k|bas kar|bilkul)" + _R,
    re.IGNORECASE),)
DEVANAGARI_BLOCK = (0x0900, 0x097F)

LIMITS = ("Surface word/phrase matching on transcript text only: no translation, no semantic understanding, "
          "no audio tone, no faces, no chat. A match means the speaker used that word - not that the moment "
          "is funny, sarcastic, or worth publishing.")


def has_devanagari(text: str) -> bool:
    return any(DEVANAGARI_BLOCK[0] <= ord(ch) <= DEVANAGARI_BLOCK[1] for ch in text)


def applies_to(text: str) -> bool:
    """True when the text is Devanagari or contains a distinctive romanised-Hindi word."""
    return bool(text) and (has_devanagari(text) or any(marker.search(text) for marker in ROMANISED_MARKERS))


def cues(text: str) -> dict[str, list[str]]:
    """Category -> the literal matches found, first occurrence order, case-insensitively de-duplicated."""
    found: dict[str, list[str]] = {}
    for category, patterns in _COMPILED.items():
        seen: set[str] = set()
        hits: list[str] = []
        for pattern in patterns:
            for match in pattern.finditer(text or ""):
                surface = match.group(0)
                key = surface.casefold()
                if key not in seen:
                    seen.add(key)
                    hits.append(surface)
        if hits:
            found[category] = hits
    return found


def describe(text: str) -> dict:
    """The structured result the caller stores with a candidate. Always states its own limits."""
    found = cues(text)
    hits = sum(len(values) for values in found.values())
    confidence = round(min(0.95, 0.20 + 0.15 * len(found) + 0.05 * hits), 3) if found else 0.0
    evidence = ("Matched Hindi/Hinglish surface cues: "
                + "; ".join(f"{category}: {', '.join(values)}" for category, values in found.items())) if found \
        else "No Hindi/Hinglish surface cues matched."
    return {"language": "hindi", "script": "devanagari" if has_devanagari(text) else "latin", "cues": found,
            "hits": hits, "confidence": confidence, "evidence": evidence,
            "semantic_understanding": False, "limits": LIMITS}
