"""Language-specific surface cues for the clip ranker.

The registry keeps each language in its own module with the same tiny contract: ``applies_to(text)`` and
``describe(text)``. Adding a language must never change another language's output, so a text that no
adapter claims returns an explicitly empty result.

This is deliberately **not** semantic understanding: no translation, no model, no audio. It exposes
inspectable evidence ("the speaker said 'bakwaas'") that a human, or a later stage, can weigh. Nothing
here changes the ranking score yet - see ``docs/INTELLIGENT_CLIPS.md`` for the current status.
"""
from __future__ import annotations

from . import hindi

_ADAPTERS = {"hindi": hindi}

DEVANAGARI_BLOCK = hindi.DEVANAGARI_BLOCK


def script_of(text: str) -> str:
    """``devanagari``, ``latin``, ``mixed`` or ``none`` - based on the characters actually present."""
    has_dev = any(DEVANAGARI_BLOCK[0] <= ord(ch) <= DEVANAGARI_BLOCK[1] for ch in text or "")
    has_latin = any(ch.isascii() and ch.isalpha() for ch in text or "")
    if has_dev and has_latin:
        return "mixed"
    if has_dev:
        return "devanagari"
    if has_latin:
        return "latin"
    return "none"


def empty_result(text: str = "") -> dict:
    return {"language": None, "script": script_of(text), "cues": {}, "hits": 0, "confidence": 0.0,
            "evidence": "No language-specific cues matched.", "semantic_understanding": False,
            "limits": hindi.LIMITS}


def analyze_cues(text: str) -> dict:
    """First adapter that claims the text wins; everyone else is left untouched."""
    for name, adapter in _ADAPTERS.items():
        if adapter.applies_to(text or ""):
            return adapter.describe(text or "")
    return empty_result(text or "")


__all__ = ["analyze_cues", "script_of", "empty_result", "hindi"]
