"""Language cues used by the text features. All matching is on the actual transcript; nothing here is a trained model.

Tokenisation is Unicode-aware so Devanagari, romanised Hindi and Hinglish reach the same features as English.
ASCII text keeps taking the exact regex path it always took, so English tokenisation is unchanged by construction.
"""
from __future__ import annotations

import re
import unicodedata

STOPWORDS = frozenset("""a an the and or but if so of to in on at for with from by as is are was were be been being am do does did have has had
i you he she it we they me him her us them my your his its our their this that these those there here what which who whom whose
not no yes just very really kind sort like um uh oh okay ok yeah right well also then than too can could would should will
about into over out up down off again more most some any all each few other such own same only s t don didn isn aren wasn""".split())

WORD = re.compile(r"[A-Za-z0-9']+")            # ASCII fast path; identical to the original pattern
TERMINAL = re.compile(r"[.!?…।॥][\"')\]]*$")   # + Devanagari danda (।) and double danda (॥)

# Unicode word characters: letters, combining marks (matras, virama, nukta) and numbers.
# Marks must be included or "हिन्दी" would split into ह / न / द and lose its meaning.
_WORD_CATEGORIES = frozenset("LMN")
_APOSTROPHES = frozenset({"'", "’"})

GREETING = re.compile(r"^(hey|hi|hello|welcome|what'?s up|good (?:morning|evening)|thanks for (?:watching|joining)|before we (?:start|begin)|"
                      r"don'?t forget to (?:like|subscribe)|today(?:,)? (?:we(?:'re| are)|i(?:'m| am)) (?:going|gonna)|in this video)\b", re.I)
FILLER_START = re.compile(r"^(um+|uh+|hmm+|er+|okay|ok|yeah|right|so|well|alright|anyway)\b[,.\s]*", re.I)
DANGLING = re.compile(r"^(and|but|so|or|because|then|which|that|this|these|those|it|its|they|them|he|she|also|however|anyway|"
                      r"yeah|well|plus|though|although|whereas|since|while|as|like)\b", re.I)
BACKREF = re.compile(r"\b(as i (?:said|mentioned|told)|like i (?:said|mentioned)|as (?:we|you) (?:saw|discussed|know)|"
                     r"earlier|previous(?:ly)?|last time|before that|the (?:other|same) (?:one|thing)|mentioned (?:before|above)|"
                     r"going back to|remember when i|that guy|that thing)\b", re.I)
CONTINUATION = re.compile(r"^(and|but|so|because|which|then|also|plus|or|that'?s why|which means|and then)\b", re.I)

QUESTION_HOOK_MIN_WORDS = 4
HOOK_PROMISE = re.compile(r"\b(here'?s (?:how|why|what|the)|the (?:secret|truth|reason|real|biggest|one|trick|mistake)|"
                          r"(?:i'?ll|let me|i'?m going to) (?:show|tell|explain)|you (?:won'?t|wouldn'?t|never) (?:believe|guess|expect)|"
                          r"nobody (?:tells|talks|knows)|most people|stop |never |imagine|what if|did you know|"
                          r"the (?:first|only) (?:thing|time)|(?:biggest|worst|best) (?:mistake|thing))\b", re.I)
CLAIM = re.compile(r"\b(is (?:wrong|a myth|not what)|isn'?t what|doesn'?t work|(?:costs?|lost|made|saved|earned) \$?\d|\d+(?:\.\d+)?\s?(?:%|percent|times|x|years?|months?|days?|hours?|million|billion|thousand))\b", re.I)
SURPRISE = re.compile(r"\b(turns out|actually|it was(?:n'?t)? (?:actually|really)|plot twist|surpris\w+|the (?:real|twist)|except|but here'?s the|"
                      r"contrary to|opposite|myth|wrong about|i was wrong|never (?:told|knew|expected)|unexpected)\b", re.I)
CONTRAST = re.compile(r"\b(but|however|instead|yet|although|except|until|then one day|suddenly)\b", re.I)
ANSWER_CUE = re.compile(r"^(because|the answer|it'?s|it is|that'?s|simple|basically|well|you|they|we|i|the|so)\b", re.I)
PUNCHLINE_MARK = re.compile(r"\b(and that'?s (?:why|when|how|what)|that'?s (?:the|when|why)|which is why|so (?:now|that'?s)|"
                            r"the (?:lesson|point|takeaway|result|answer) is|in the end|turned out|and (?:it|that) worked|and (?:i|we) (?:won|learned|realized))\b", re.I)
EXPLAIN = re.compile(r"\b(because|the reason|that'?s why|which means|so that|for example|for instance|step|first|second|third|how to|"
                     r"the key|the trick|rule|lesson|tip|in other words|this means|the difference)\b", re.I)
STORY_SETUP = re.compile(r"\b(i remember|one day|when i|years? ago|back then|we were|that night|the first time|i was|there was a)\b", re.I)
STORY_TURN = re.compile(r"\b(then|suddenly|but|until|that'?s when|all of a sudden|and then)\b", re.I)
EMOTION = re.compile(r"\b(love|hate|afraid|scared|terrified|angry|heartbreak\w*|proud|cried|cry|laugh\w*|painful|grateful|hurt|fear|"
                     r"struggl\w*|devastat\w*|thrilled|furious|embarrass\w*)\b", re.I)
REACTION = re.compile(r"\b(oh my|no way|wow|unbelievable|i can'?t believe|what\?!|are you kidding|that'?s insane|hilarious)\b", re.I)


def _is_word_char(ch: str) -> bool:
    return ch in _APOSTROPHES or unicodedata.category(ch)[0] in _WORD_CATEGORIES


def _scan_words(text: str) -> list[str]:
    """Group runs of Unicode word characters. Punctuation, danda, emoji, control and format characters separate."""
    out: list[str] = []
    buf: list[str] = []
    for ch in text:
        if _is_word_char(ch):
            buf.append(ch)
        elif buf:
            out.append("".join(buf)); buf = []
    if buf:
        out.append("".join(buf))
    return out


def words(text: str) -> list[str]:
    """Words in ``text``. Pure-ASCII input uses the original regex, so its output cannot have changed.

    Non-ASCII input is normalised to NFC first (some sources emit decomposed Devanagari) and scanned with
    Unicode categories: letters, marks and digits stay in a word, everything else separates.
    """
    if not text:
        return []
    if text.isascii():
        return WORD.findall(text)
    return _scan_words(unicodedata.normalize("NFC", text))


def content_words(text: str) -> list[str]:
    return [w.lower() for w in words(text) if w.lower() not in STOPWORDS and len(w) > 2]


def ends_terminal(text: str) -> bool:
    return bool(TERMINAL.search(text.strip()))


def trigrams(text: str) -> list[tuple[str, str, str]]:
    ws = [w.lower() for w in words(text)]
    return [tuple(ws[i:i + 3]) for i in range(len(ws) - 2)]  # type: ignore[misc]

OUTRO = re.compile(r"\b(thanks for (?:watching|listening)|see you (?:next|in the next)|like and subscribe|subscribe|hit the bell|"
                   r"that'?s (?:it|all) for (?:today|this)|until next time|catch you (?:later|next)|link in the (?:description|bio)|sponsor(?:ed)? by)\b", re.I)
FILLER_PHRASE = re.compile(r"\b(um+|uh+|you know|kind of|sort of|i mean|stuff|whatever|blah|and so on|went on about)\b", re.I)

# Talk about the conversation itself ("where I was going with that", "anyway", "never mind") makes a poor opener.
META_TALK = re.compile(r"^(honestly[,.\s]|anyway|anyhow|never mind|i mean[,.\s]|look[,.\s]|as i was saying|(?:i|we) (?:don'?t|do not) (?:even )?(?:remember|know)|"
                       r"where (?:i|we) was|(?:it|that)'?s (?:one of those|a thing|just a thing)|i (?:was|am) (?:just )?(?:thinking|saying))", re.I)

HANGING_END = re.compile(r"\b(and|but|so|because|which|that|or|the|a|an|to|of|with|then|if|when|as|like)[,\s]*[.…]*$", re.I)
