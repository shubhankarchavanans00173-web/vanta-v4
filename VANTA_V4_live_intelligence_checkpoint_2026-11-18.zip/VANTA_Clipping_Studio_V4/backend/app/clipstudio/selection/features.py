"""Feature extraction for one candidate window. Every feature is normalised to 0..1 (higher is better) or ``None`` when the
signal it needs is unavailable. Each carries the evidence it was computed from, so explanations are never invented.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..analysis import Unit
from ..intelligence import classify_event
from . import lexicon as L
from .audio import Envelope


@dataclass
class Window:
    units: list[Unit]               # sentence units inside the clip
    start: float                    # padded clip start/end (seconds)
    end: float
    i: int                          # index of first/last unit in the full unit list
    j: int
    all_units: list[Unit]
    target: float
    min_len: float
    max_len: float
    envelope: Envelope | None = None
    scenes: list[tuple[float, float]] = field(default_factory=list)
    word_level: bool = False

    @property
    def duration(self) -> float:
        return max(0.1, self.end - self.start)

    @property
    def text(self) -> str:
        return " ".join(u.text for u in self.units)

    @property
    def prev(self) -> Unit | None:
        return self.all_units[self.i - 1] if self.i > 0 else None

    @property
    def nxt(self) -> Unit | None:
        return self.all_units[self.j + 1] if self.j + 1 < len(self.all_units) else None


def _f(value: float | None, evidence: str = "", **extra) -> dict:
    out = {"value": None if value is None else round(max(0.0, min(1.0, value)), 3), "evidence": evidence}
    out.update(extra)
    return out


def _q(text: str, n: int = 110) -> str:
    text = " ".join(text.split())
    return f"“{text if len(text) <= n else text[:n - 1].rsplit(' ', 1)[0] + '…'}”"


# ------------------------------------------------------------------ text features
def hook(w: Window) -> dict:
    first = w.units[0].text.strip()
    nwords = len(L.words(first))
    if L.GREETING.search(first):
        return _f(0.05, f"Opens with a greeting or channel intro, not a hook: {_q(first)}", kind="greeting")
    if L.FILLER_START.match(first) and nwords <= 4:
        return _f(0.0, f"Opens with filler: {_q(first)}", kind="filler")
    score, kind, why = 0.15, "plain", f"Opens with a plain statement: {_q(first)}"
    if "?" in first and nwords >= L.QUESTION_HOOK_MIN_WORDS:
        score, kind, why = 0.9, "question", f"Opens with a direct question: {_q(first)}"
    elif L.HOOK_PROMISE.search(first):
        score, kind, why = 0.85, "promise", f"Opens by promising a payoff: {_q(first)}"
    elif L.SURPRISE.search(first) or L.CLAIM.search(first):
        score, kind, why = 0.7, "claim", f"Opens with a surprising or specific claim: {_q(first)}"
    elif re.search(r"\d", first) and nwords <= 20:
        score, kind, why = 0.5, "number", f"Opens with a concrete number or fact: {_q(first)}"
    elif len(w.units) > 1 and ("?" in w.units[1].text):
        score, kind, why = 0.45, "question-2nd", f"Second sentence poses a question: {_q(w.units[1].text)}"
    if nwords < 4:
        score *= 0.5; why += " (very short opener)"
    return _f(score, why, kind=kind, text=first)


def context_dependency(w: Window) -> dict:
    """0 = fully self-contained, 1 = clearly depends on earlier video content. Higher is WORSE (used as a penalty)."""
    first = w.units[0].text.strip()
    pts, notes = 0.0, []
    if L.DANGLING.search(first) and "?" not in first:
        pts += 0.45; notes.append(f"starts mid-thought ({_q(first, 60)})")
    head = " ".join(u.text for u in w.units[:2])
    if L.BACKREF.search(head):
        pts += 0.4; notes.append("refers back to something said earlier")
    inner = sum(1 for u in w.units[2:] if L.BACKREF.search(u.text))
    if inner:
        pts += min(0.3, 0.15 * inner); notes.append(f"{inner} later sentence(s) refer back to material that may not be in the clip")
    if L.META_TALK.match(first):
        pts += 0.3; notes.append("opens by talking about the conversation itself, not the topic")
    m = re.match(r"^(it|they|he|she|this|that|these|those)\b", first, re.I)
    if m and not L.DANGLING.search(first):
        pts += 0.25; notes.append(f"opens with the pronoun “{m.group(1)}” with no stated subject")
    return _f(min(1.0, pts), "; ".join(notes).capitalize() + "." if notes else "No back-references or dangling openers detected.")


def standalone_clarity(w: Window, ctx: dict) -> dict:
    first = w.units[0].text
    names_topic = bool(L.content_words(first)) and len(L.content_words(first)) >= 2
    v = (1.0 - ctx["value"]) * (1.0 if names_topic else 0.7)
    ev = ("Opening names its own topic and has no back-references." if v >= 0.8
          else "Opening leans on context that is not in the clip." if v < 0.5 else "Mostly understandable on its own.")
    return _f(v, ev)


def _payoff_index(w: Window) -> tuple[int | None, str]:
    """Index (within w.units) of the payoff sentence and the kind of payoff, from actual text patterns."""
    us = w.units
    qi = next((k for k, u in enumerate(us[:-1]) if "?" in u.text and len(L.words(u.text)) >= 4), None)
    if qi is not None:
        for k in range(qi + 1, min(len(us), qi + 4)):
            if len(L.words(us[k].text)) >= 5 and "?" not in us[k].text:
                return k, "answer"
    for k in range(1, len(us)):
        if L.PUNCHLINE_MARK.search(us[k].text):
            return k, "conclusion"
    for k in range(1, len(us)):
        if L.SURPRISE.search(us[k].text) or (L.CONTRAST.search(us[k].text[:40]) and k >= len(us) // 2):
            return k, "turn"
    return None, ""


def payoff(w: Window) -> dict:
    k, kind = _payoff_index(w)
    if k is None:
        return _f(0.15, "No question→answer, turn or conclusion detected inside the clip.", kind="none")
    txt = w.units[k].text
    base = {"answer": 0.9, "conclusion": 0.8, "turn": 0.65}[kind]
    if k >= len(w.units) - 2:
        base += 0.1  # payoff lands near the end, where a viewer expects it
    label = {"answer": "Question is answered", "conclusion": "Reaches a conclusion", "turn": "Contains a turn or reveal"}[kind]
    return _f(base, f"{label}: {_q(txt)}", kind=kind, text=txt, index=k)


def story_completeness(w: Window) -> dict:
    last = w.units[-1].text.strip()
    pts, parts = 0.0, []
    term = L.ends_terminal(last)
    pts += 0.35 if term else 0.0
    parts.append("ends on a complete sentence" if term else "ends without sentence-final punctuation")
    qs = [k for k, u in enumerate(w.units) if "?" in u.text]
    if qs and qs[-1] == len(w.units) - 1:
        parts.append("ends on an unanswered question")
    else:
        pts += 0.25
    if len(L.words(last)) >= 5 and not L.HANGING_END.search(last):
        pts += 0.2
    else:
        parts.append("the last sentence trails off")
    nx = w.nxt
    if nx and L.CONTINUATION.search(nx.text) and nx.start - w.units[-1].end < 1.0:
        parts.append("the next sentence continues the same thought")
    else:
        pts += 0.2
    return _f(pts, ("Complete: " if pts >= 0.8 else "Possibly incomplete: ") + ", ".join(parts) + ".")


def information_value(w: Window) -> dict:
    ws = L.words(w.text)
    cw = L.content_words(w.text)
    if len(ws) < 8:
        return _f(0.1, "Too little speech to carry information.")
    ratio = len(set(cw)) / max(1, len(ws))
    explain = len(L.EXPLAIN.findall(w.text))
    specifics = len(re.findall(r"\d", w.text)) > 0
    v = min(1.0, (ratio - 0.18) / 0.27) * 0.65 + min(1.0, explain / 3) * 0.25 + (0.1 if specifics else 0)
    return _f(v, f"{len(set(cw))} distinct content words in {len(ws)} words; {explain} explanatory cue(s)" + ("; includes specific figures" if specifics else "") + ".")


def emotion(w: Window) -> dict:
    n = len(L.EMOTION.findall(w.text)); r = len(L.REACTION.findall(w.text))
    v = min(1.0, n / 3 * 0.6 + r * 0.5)
    return _f(v, f"{n} emotional-language cue(s), {r} reaction phrase(s) in the text (wording only; tone of voice and faces are not analysed).")


def humor_quality(w: Window, event: dict | None = None) -> dict:
    """A conservative contextual-humour score; reaction words alone do not qualify."""
    event = event or classify_event(w.units, w.prev)
    info = event["humor"]
    return _f(info["value"], info["evidence"], kind=info.get("kind", "none"),
              requires_setup=bool(info.get("requires_setup")), setup_index=info.get("setup_index"),
              punchline_index=info.get("punchline_index"))


def conversation_significance(w: Window, event: dict | None = None) -> dict:
    """Score visible conversational structure, not assumed speaker identities."""
    event = event or classify_event(w.units, w.prev)
    info = event["conversation"]
    return _f(info["value"], info["evidence"], kind=", ".join(info.get("events") or []) or "none")


def unexpectedness(w: Window, event: dict | None = None) -> dict:
    event = event or classify_event(w.units, w.prev)
    cues = [u.text for u in w.units if L.SURPRISE.search(u.text) or L.CONTRAST.search(u.text)]
    value = min(1.0, len(cues) * 0.42 + (0.25 if event["category"] in {"humour", "banter / interaction"} else 0.0))
    if cues:
        return _f(value, f"Unexpected-turn wording: {_q(cues[0])}", kind="transcript turn")
    if event["category"] == "humour":
        return _f(value, "A detected setup/payoff creates an unexpected conversational reversal.", kind="setup-payoff")
    return _f(value, "No explicit unexpected turn was detected in the transcript.", kind="none")


def emotional_intensity(w: Window) -> dict:
    """Kept separate from raw loudness: it is transcript wording only."""
    base = emotion(w)
    return _f(base["value"], base["evidence"], kind="transcript wording")


def event_type(w: Window, event: dict | None = None) -> dict:
    event = event or classify_event(w.units, w.prev)
    return _f(event["confidence"], event["evidence"], kind=event["category"])


def opening_quality(w: Window) -> dict:
    first = w.units[0]
    pts, notes = 0.0, []
    if not L.FILLER_START.match(first.text) and not L.DANGLING.search(first.text) and not L.META_TALK.match(first.text):
        pts += 0.5; notes.append("starts on a fresh sentence")
    gap = first.start - w.prev.end if w.prev else 99.0
    if gap >= 0.4:
        pts += 0.3; notes.append(f"begins after a {min(gap, 9.9):.1f}s pause")
    elif gap >= 0.15:
        pts += 0.1
    if len(L.words(first.text)) >= 4:
        pts += 0.2
    if w.prev and w.prev.text.rstrip().endswith("?") and not first.text.rstrip().endswith("?"):
        pts -= 0.3; notes.append("the question it answers is just before the clip")
    return _f(pts, ("Opening: " + ", ".join(notes) + ".") if notes else "Opening starts abruptly.")


def ending_quality(w: Window) -> dict:
    last = w.units[-1]
    pts, notes = 0.0, []
    if L.ends_terminal(last.text):
        pts += 0.45; notes.append("ends on a complete sentence")
    gap = (w.nxt.start - last.end) if w.nxt else 99.0
    if gap >= 0.4:
        pts += 0.25; notes.append("followed by a pause" if w.nxt else "ends at the end of the video")
    if w.nxt and L.CONTINUATION.search(w.nxt.text) and gap < 1.0:
        pts -= 0.35; notes.append("cuts off a continuing thought")
    k, _ = _payoff_index(w)
    if k is not None and k >= len(w.units) - 3:
        pts += 0.3; notes.append("payoff is inside the final sentences")
    elif k is not None:
        pts += 0.1; notes.append("some material follows the payoff")
    return _f(pts, ("Ending: " + ", ".join(notes) + ".") if notes else "Ending is abrupt.")


def repetition(w: Window) -> dict:
    """0 = no repetition, 1 = heavily repetitive. Higher is WORSE (used as a penalty)."""
    tg = L.trigrams(w.text)
    if len(tg) < 10:
        return _f(0.0, "Too short to measure repetition.")
    rep = 1 - len(set(tg)) / len(tg)
    sents = [" ".join(L.content_words(u.text)) for u in w.units]
    dup = sum(1 for k in range(len(sents)) for m in range(k) if sents[k] and sents[k] == sents[m])
    cw = L.content_words(w.text)
    ttr = len(set(cw)) / len(cw) if len(cw) >= 8 else 1.0      # few distinct content words for the amount of speech = circling one idea
    v = min(1.0, rep * 3 + dup * 0.3 + max(0.0, 0.55 - ttr) * 2)
    return _f(v, f"{rep * 100:.0f}% of 3-word sequences repeat" + (f"; {dup} repeated sentence(s)" if dup else "")
              + (f"; only {len(set(cw))} distinct content words in {len(cw)}" if ttr < 0.55 else "") + ".")


def low_value_content(w: Window) -> dict:
    """0 = substantive, 1 = mostly intro/outro/filler talk. Higher is WORSE (used as a penalty)."""
    n = len(w.units)
    meta = [u for u in w.units if L.OUTRO.search(u.text) or L.GREETING.search(u.text)]
    ws = max(1, len(L.words(w.text)))
    filler = len(L.FILLER_PHRASE.findall(w.text)) / ws
    v = min(1.0, len(meta) / max(1, n) * 2.5 + max(0.0, filler - 0.02) * 8)
    notes = []
    if meta:
        notes.append(f"contains intro/outro talk ({_q(meta[0].text, 70)})")
    if filler > 0.03:
        notes.append(f"{filler * 100:.0f}% filler words")
    return _f(v, ("Low-value content: " + "; ".join(notes) + ".") if notes else "No intro/outro or filler talk detected.")


def caption_readability(w: Window) -> dict:
    ws = len(L.words(w.text)); wps = ws / max(1.0, w.units[-1].end - w.units[0].start)
    avg = ws / len(w.units)
    v = 1.0
    if wps > 3.6:
        v -= min(0.6, (wps - 3.6) / 2.0)
    if wps < 1.4:
        v -= min(0.4, (1.4 - wps) / 2.0)
    if avg > 30:
        v -= 0.2
    note = f"{wps:.1f} words/s, {avg:.0f} words per sentence"
    if not w.word_level:
        note += "; sentence-level captions (transcript has no word timings)"
    return _f(v, note + ".")


def duration_fit(w: Window) -> dict:
    d = w.end - w.start
    v = max(0.0, 1 - abs(d - w.target) / max(w.target, 1.0))
    if d < w.min_len - 0.01 or d > w.max_len + 0.01:
        v = 0.0
    return _f(v, f"{d:.0f}s against a {w.target:.0f}s target (accepted {w.min_len:.0f}–{w.max_len:.0f}s).")


# ------------------------------------------------------------------ audio features (None when no envelope)
def speech_activity(w: Window) -> dict:
    if w.envelope is None:
        return _f(None, "Audio was not analysed.")
    r = w.envelope.speech_ratio(w.start, w.end)
    if r is None:
        return _f(None, "No audio samples in this window.")
    v = 1.0 if 0.7 <= r <= 0.97 else (r / 0.7 if r < 0.7 else max(0.5, 1 - (r - 0.97) * 5))
    return _f(v, f"Sound is present for {r * 100:.0f}% of the clip" + (" (long quiet stretches)" if r < 0.5 else "") + ".")


def energy_dynamics(w: Window) -> dict:
    if w.envelope is None:
        return _f(None, "Audio was not analysed.")
    d = w.envelope.dynamics(w.start, w.end)
    if d is None:
        return _f(None, "Not enough audible samples to measure loudness changes.")
    return _f(min(1.0, d / 1.3), f"Loudness varies {d:.1f}× the video's typical amount (a mild signal only; loud ≠ interesting).")


def pause_before_payoff(w: Window) -> dict:
    if w.envelope is None:
        return _f(None, "Audio was not analysed.")
    k, _ = _payoff_index(w)
    if k is None:
        return _f(None, "No payoff detected, so no pause to look for.")
    p = w.envelope.pause_before(w.units[k].start)
    return _f(1.0 if p else 0.3, f"{p:.1f}s pause right before the payoff." if p else "No pause before the payoff.")


# ------------------------------------------------------------------ visual features (scene cuts only)
def visual_activity(w: Window, scenes_known: bool) -> dict:
    if not scenes_known:
        return _f(None, "Scene changes were not analysed.")
    n = sum(1 for t, _ in w.scenes if w.start <= t <= w.end)
    per10 = n / (w.duration / 10)
    v = 0.5 if n == 0 else min(1.0, 0.55 + per10 / 3)
    return _f(v, f"{n} scene change(s) in the clip (cut detection only; no content or faces analysed).")


TEXT_FEATURES = ("hook", "standalone_clarity", "story_completeness", "information_value", "payoff", "opening_quality",
                 "ending_quality", "emotion", "caption_readability")


def extract(w: Window, scenes_known: bool) -> dict[str, dict]:
    ctx = context_dependency(w)
    event = classify_event(w.units, w.prev)
    return {
        "hook": hook(w), "standalone_clarity": standalone_clarity(w, ctx), "story_completeness": story_completeness(w),
        "information_value": information_value(w), "payoff": payoff(w), "opening_quality": opening_quality(w),
        "ending_quality": ending_quality(w), "emotion": emotion(w), "emotional_intensity": emotional_intensity(w),
        "humor_quality": humor_quality(w, event), "conversation_significance": conversation_significance(w, event),
        "unexpectedness": unexpectedness(w, event), "event_type": event_type(w, event), "caption_readability": caption_readability(w),
        "duration_fit": duration_fit(w), "speech_activity": speech_activity(w), "energy_dynamics": energy_dynamics(w),
        "pause_before_payoff": pause_before_payoff(w), "visual_activity": visual_activity(w, scenes_known),
        # penalties (higher = worse)
        "context_dependency": ctx, "repetition": repetition(w), "low_value_content": low_value_content(w),
    }
