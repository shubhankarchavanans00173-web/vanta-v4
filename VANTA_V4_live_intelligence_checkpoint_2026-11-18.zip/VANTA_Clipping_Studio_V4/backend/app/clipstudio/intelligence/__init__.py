"""Deterministic, local-first semantic signals used by VANTA's clip ranker.

The modules in this package deliberately work on transcript-sized windows.  They
are not a replacement for a local model: their job is to expose inspectable
evidence when an LLM is unavailable, slow, or disabled.
"""

from .conversation_analyzer import analyze_conversation
from .event_classifier import classify_event
from .humor_detector import analyze_humor, semantic_anchor_score, setup_index_for

__all__ = ["analyze_conversation", "analyze_humor", "classify_event", "semantic_anchor_score", "setup_index_for"]
