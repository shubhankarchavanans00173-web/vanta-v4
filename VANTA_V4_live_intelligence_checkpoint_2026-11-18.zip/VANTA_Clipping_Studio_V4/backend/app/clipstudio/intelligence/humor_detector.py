"""Contextual humour signals for transcript windows.

This is intentionally conservative.  Laughter words and emoji-style language
can support a detected setup/payoff, but cannot create a humour event alone.
"""
from __future__ import annotations

import re
from typing import Iterable


_PUNCHLINE = re.compile(
    r"\b(that'?s what she said|the joke is|punchline|skill issue|copium|i(?:'m| am) (?:so )?(?:bad|washed|the problem)|"
    r"professional .*los(?:e|ing)|let(?:ting)? (?:them|you) win|at least|plot twist|turns out|yeah right|sure[,! ]|"
    r"that went well|nailed it|who could have guessed|apparently)\b", re.I)
_SETUP = re.compile(
    r"\b(i(?:'m| am)|we(?:'re| are)|this is|i can|i will|definitely|always|never|promise|watch me|bet|"
    r"why|how|what happens|supposed to|professional|easy|guarantee)\b", re.I)
_LAUGHTER = re.compile(r"\b(?:ha){2,}|\b(?:lol|lmao|rofl|haha|hahaha)\b|😂|🤣|💀", re.I)
_SELF_DEPRECATION = re.compile(r"\b(i(?:'m| am) (?:so )?(?:bad|terrible|washed|an idiot|the problem)|my aim|my brain|i cannot)\b", re.I)
_MISUNDERSTANDING = re.compile(r"\b(i thought|you thought|wait,? what|that's not what|misunderstood|heard that as)\b", re.I)
_CONTRAST = re.compile(r"\b(but|except|instead|actually|turns out|yeah right|sure)\b", re.I)


def _text(unit) -> str:
    return str(getattr(unit, "text", unit)).strip()


def _quote(text: str, limit: int = 120) -> str:
    compact = " ".join(text.split())
    if len(compact) > limit:
        compact = compact[:limit - 1].rsplit(" ", 1)[0] + "…"
    return f"“{compact}”"


def _is_setup(text: str) -> bool:
    return bool("?" in text or _SETUP.search(text)) and len(re.findall(r"[A-Za-z0-9']+", text)) >= 4


def setup_index_for(units: Iterable, punchline_index: int) -> int | None:
    us = list(units)
    if punchline_index <= 0 or punchline_index >= len(us):
        return None
    for index in range(punchline_index - 1, max(-1, punchline_index - 4), -1):
        if _is_setup(_text(us[index])):
            return index
    return None


def analyze_humor(units: Iterable, previous=None) -> dict:
    us = list(units)
    if not us:
        return {"value": 0.0, "evidence": "No transcript text is available for humour analysis.", "kind": "none", "requires_setup": False}
    texts = [_text(u) for u in us]
    score, kind, evidence = 0.0, "none", []
    punch = next((i for i, text in enumerate(texts) if _PUNCHLINE.search(text)), None)
    if punch is None:
        # A contrast late in the window is a weak possible payoff, never enough
        # on its own to label a moment funny.
        punch = next((i for i, text in enumerate(texts[1:], 1) if _CONTRAST.search(text) and len(text.split()) >= 5), None)
    setup = setup_index_for(us, punch) if punch is not None else None
    if setup is not None and punch is not None:
        score += 0.72
        kind = "setup-punchline"
        evidence.append(f"Setup → payoff: {_quote(texts[setup])} → {_quote(texts[punch])}")
    elif punch is not None:
        score += 0.22
        kind = "possible punchline without setup"
        evidence.append(f"Possible payoff needs prior context: {_quote(texts[punch])}")

    for text in texts:
        if _SELF_DEPRECATION.search(text):
            score += 0.18
            kind = "self-deprecating humour" if kind == "none" else kind
            evidence.append(f"Self-deprecating wording: {_quote(text)}")
            break
    for text in texts:
        if _MISUNDERSTANDING.search(text):
            score += 0.16
            kind = "funny misunderstanding" if kind == "none" else kind
            evidence.append(f"Misunderstanding cue: {_quote(text)}")
            break
    if punch is not None and any(_LAUGHTER.search(text) for text in texts):
        score += 0.10
        evidence.append("Laughter wording appears alongside a detected setup/payoff.")

    return {
        "value": round(min(1.0, score), 3),
        "evidence": "; ".join(evidence) + "." if evidence else "No complete joke structure was detected in this window.",
        "kind": kind,
        "setup_index": setup,
        "punchline_index": punch,
        "requires_setup": bool(punch is not None and setup is None),
    }


def semantic_anchor_score(units: Iterable, index: int) -> float:
    """Return a conservative anchor score around one sentence for candidate generation."""
    us = list(units)
    if not 0 <= index < len(us):
        return 0.0
    start, end = max(0, index - 2), min(len(us), index + 2)
    result = analyze_humor(us[start:end])
    text = _text(us[index])
    local = float(result["value"])
    if _PUNCHLINE.search(text):
        local = max(local, 0.65)
    return round(local, 3)
