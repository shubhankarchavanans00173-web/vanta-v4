"""Small, explainable conversational-intelligence rules.

Transcripts normally do not identify speakers, so these rules never claim that
they do.  Instead they recognise observable turn structures (question/answer,
rebuttal, direct address, and contrast) and return the exact sentence that
provided each piece of evidence.
"""
from __future__ import annotations

import re
from typing import Iterable


def _text(unit) -> str:
    return str(getattr(unit, "text", unit)).strip()


def _quote(text: str, limit: int = 120) -> str:
    compact = " ".join(text.split())
    if len(compact) > limit:
        compact = compact[:limit - 1].rsplit(" ", 1)[0] + "…"
    return f"“{compact}”"


_DIRECT_ADDRESS = re.compile(r"\b(chat|guys|you all|y'?all|viewers?|comments?|someone in chat|mods?)\b", re.I)
_REBUTTAL = re.compile(r"\b(then why|but why|actually|no[,! ]|wrong|sure[,! ]|yeah right|as if|skill issue|copium|nice try|imagine)\b", re.I)
_SARCASTIC = re.compile(r"\b(yeah right|sure[,! ]|totally|definitely|obviously|as if|great job|nice one)\b", re.I)
_TWIST = re.compile(r"\b(but|except|instead|turns out|plot twist|actually|until|suddenly|never expected|didn't expect|wasn't expecting)\b", re.I)
_REACTION = re.compile(r"\b(no way|what[!?]|oh my|are you kidding|i can't believe|unbelievable|insane|wow)\b", re.I)


def analyze_conversation(units: Iterable, previous=None) -> dict:
    """Score observable conversational significance and return auditable evidence.

    ``previous`` may be a unit just outside the candidate.  It is used only to
    find a question/setup; no synthetic dialogue is inferred.
    """
    us = list(units)
    texts = [_text(u) for u in us]
    if not texts:
        return {"value": 0.0, "evidence": "No transcript text is available for conversational analysis.", "events": []}

    score, events, evidence = 0.0, [], []
    all_units = ([previous] if previous is not None else []) + us
    all_texts = [_text(u) for u in all_units]

    for i, text in enumerate(all_texts):
        if _DIRECT_ADDRESS.search(text):
            score += 0.18
            events.append("streamer-viewer interaction")
            evidence.append(f"Direct audience address: {_quote(text)}")
            break

    # A meaningful exchange requires a setup/question and a later substantive
    # response.  This prevents a lone 'bro' or 'LOL' from becoming a moment.
    for i, text in enumerate(all_texts[:-1]):
        if "?" not in text and not _DIRECT_ADDRESS.search(text):
            continue
        for reply in all_texts[i + 1:i + 4]:
            if len(re.findall(r"[A-Za-z0-9']+", reply)) < 3:
                continue
            score += 0.30
            events.append("response exchange")
            evidence.append(f"Setup and response: {_quote(text)} → {_quote(reply)}")
            break
        if "response exchange" in events:
            break

    for text in texts:
        if _REBUTTAL.search(text):
            score += 0.25
            events.append("banter or rebuttal")
            evidence.append(f"Banter/rebuttal cue: {_quote(text)}")
            break
    for text in texts:
        if _SARCASTIC.search(text):
            score += 0.22
            events.append("possible sarcasm")
            evidence.append(f"Sarcastic wording cue: {_quote(text)}")
            break
    for text in texts:
        if _TWIST.search(text):
            score += 0.18
            events.append("conversational turn")
            evidence.append(f"Conversational turn: {_quote(text)}")
            break
    for text in texts:
        if _REACTION.search(text):
            score += 0.12
            events.append("spoken reaction")
            evidence.append(f"Spoken reaction: {_quote(text)}")
            break

    # Repeated generic reaction words by themselves are deliberately weak.
    value = min(1.0, score)
    if not evidence:
        return {"value": round(value, 3), "evidence": "No clear multi-turn interaction, banter, or conversational turn was detected.", "events": []}
    return {"value": round(value, 3), "evidence": "; ".join(evidence[:3]) + ".", "events": list(dict.fromkeys(events))}
