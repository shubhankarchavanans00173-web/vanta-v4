"""Explainable event labels derived from local transcript evidence."""
from __future__ import annotations

from .conversation_analyzer import analyze_conversation
from .humor_detector import analyze_humor


def classify_event(units, previous=None) -> dict:
    """Classify a transcript event without overstating unavailable modalities."""
    humor = analyze_humor(units, previous)
    conversation = analyze_conversation(units, previous)
    text = " ".join(str(getattr(u, "text", u)) for u in units)
    emotional = any(token in text.lower() for token in ("scared", "cry", "angry", "furious", "love", "heartbreak", "unbelievable"))
    if humor["value"] >= 0.65:
        category, confidence = "humour", humor["value"]
        evidence = humor["evidence"]
    elif conversation["value"] >= 0.55:
        category, confidence = "banter / interaction", conversation["value"]
        evidence = conversation["evidence"]
    elif emotional:
        category, confidence = "emotional reaction", 0.45
        evidence = "Emotional wording in the transcript; vocal tone and faces were not analysed."
    else:
        category, confidence = "conversation", max(float(humor["value"]), float(conversation["value"]))
        evidence = "No specific humour, banter, or emotional event was confirmed."
    return {"category": category, "confidence": round(min(1.0, confidence), 3), "evidence": evidence,
            "humor": humor, "conversation": conversation}
