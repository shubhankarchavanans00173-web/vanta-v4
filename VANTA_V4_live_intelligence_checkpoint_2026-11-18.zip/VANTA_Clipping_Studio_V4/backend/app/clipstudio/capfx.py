"""Caption font preparation and *proof of pixels* for burned-in captions.

Why this exists: FFmpeg's ``ass`` filter exits 0 and produces a perfectly valid MP4 even when libass cannot find a
font - the captions are simply not drawn. A success exit code is therefore NOT evidence that captions are visible.
This module (1) hands libass a font directory it can always read, (2) proves libass draws glyphs with that setup, and
(3) proves those glyph pixels are present in the finished MP4.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

from PIL import Image, ImageChops

from .errors import CaptionError

BUNDLED_FONTS = Path(__file__).resolve().parent.parent / "assets" / "fonts"
FALLBACK_FAMILY = "DejaVu Sans"
GRAY = 128                      # luma of the 0x808080 probe canvas
MIN_GLYPH_PIXELS = 150          # fewer than this on the probe canvas => libass drew (almost) nothing
MIN_MATCH_RATIO = 0.85          # share of probe glyph pixels that must reappear in the exported frame (real captions measure ~0.99; "no captions" ~0.4-0.6)
LUMA_TOLERANCE = 48             # allowed luma drift after H.264 re-encoding

# Family -> file names to look for in system font folders (regular/bold). Windows names first.
_KNOWN_FILES = {
    "arial": ["arialbd.ttf", "arial.ttf"], "segoe ui": ["segoeuib.ttf", "segoeui.ttf"], "impact": ["impact.ttf"],
    "verdana": ["verdanab.ttf", "verdana.ttf"], "tahoma": ["tahomabd.ttf", "tahoma.ttf"],
    "trebuchet ms": ["trebucbd.ttf", "trebuc.ttf"], "georgia": ["georgiab.ttf", "georgia.ttf"],
    "calibri": ["calibrib.ttf", "calibri.ttf"], "dejavu sans": ["DejaVuSans-Bold.ttf", "DejaVuSans.ttf"],
}
# Extra fonts so non-Latin captions have glyphs (script regex -> candidate Windows files, fontconfig lang)
_SCRIPT_FALLBACKS = [
    (re.compile(r"[\u0900-\u097F]"), ["Nirmala.ttf", "NirmalaB.ttf", "mangal.ttf"], "hi"),                # Devanagari
    (re.compile(r"[\u0980-\u09FF\u0A00-\u0DFF]"), ["Nirmala.ttf", "NirmalaB.ttf"], "bn"),               # other Indic
    (re.compile(r"[\u4E00-\u9FFF\u3040-\u30FF]"), ["msyh.ttc", "YuGothB.ttc", "YuGothM.ttc", "meiryo.ttc"], "zh"),  # CJK
    (re.compile(r"[\uAC00-\uD7AF]"), ["malgunbd.ttf", "malgun.ttf"], "ko"),                              # Hangul
    (re.compile(r"[\u0E00-\u0E7F]"), ["LeelawUI.ttf", "tahoma.ttf"], "th"),                               # Thai
    (re.compile(r"[\u0600-\u06FF]"), ["segoeui.ttf", "tahoma.ttf", "arial.ttf"], "ar"),                   # Arabic
]


# ----------------------------------------------------------------------------------------------- escaping
def escape_filter_value(value: str) -> str:
    """Escape a path/value for use *inside* an FFmpeg filter option (``ass=file=<value>``).

    Backslashes become forward slashes (FFmpeg accepts them on Windows), then every character that is special in a
    filtergraph is backslash-escaped: ``: ' , [ ] ; =`` and ``%``. Example: ``C:\\Users\\Me\\it's.ass`` ->
    ``C\\:/Users/Me/it\\'s.ass``. Prefer relative names run with ``cwd`` set (what the renderer does); this exists for
    the cases where an absolute path is unavoidable and is covered by tests for Windows-style input.
    """
    v = value.replace("\\", "/")
    return re.sub(r"([:',\[\];=%])", r"\\\1", v)


def ass_filter(ass_name: str, fontsdir: str | None) -> str:
    parts = [f"ass={escape_filter_value(ass_name)}"]
    if fontsdir:
        parts.append(f"fontsdir={escape_filter_value(fontsdir)}")
    return ":".join(parts)


# ----------------------------------------------------------------------------------------------- fonts
def _system_font_dirs() -> list[Path]:
    dirs: list[Path] = []
    if os.getenv("VANTA_FONTS_DIR"):
        dirs.append(Path(os.environ["VANTA_FONTS_DIR"]))
    if sys.platform.startswith("win"):
        dirs.append(Path(os.getenv("WINDIR", r"C:\Windows")) / "Fonts")
        local = os.getenv("LOCALAPPDATA")
        if local:
            dirs.append(Path(local) / "Microsoft" / "Windows" / "Fonts")
    else:
        dirs += [Path("/usr/share/fonts"), Path("/usr/local/share/fonts"), Path.home() / ".fonts", Path("/Library/Fonts"),
                 Path("/System/Library/Fonts")]
    return [d for d in dirs if d.is_dir()]


def _find_named(filenames: list[str]) -> list[Path]:
    wanted = {n.lower() for n in filenames}
    found: list[Path] = []
    for d in _system_font_dirs():
        try:
            for p in d.rglob("*"):
                if p.name.lower() in wanted and p not in found:
                    found.append(p)
        except OSError:
            continue
    return found


def _fc_match(pattern: str) -> Path | None:
    exe = shutil.which("fc-match")
    if not exe:
        return None
    try:
        out = subprocess.run([exe, "-f", "%{file}", pattern], capture_output=True, text=True, timeout=10).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None
    return Path(out) if out and Path(out).is_file() else None


@dataclass
class FontPlan:
    family: str                                   # Fontname to write into the ASS style
    fontsdir: str                                 # directory name RELATIVE to the render working dir
    notes: list[str] = field(default_factory=list)


def prepare_fonts(work_dir: Path, requested_family: str, sample_text: str = "") -> FontPlan:
    """Create ``work_dir/fonts`` with fonts libass can always read and choose the style's font family.

    Bundled DejaVu Sans is always present (libass can never end up with an empty font list). The requested family is
    copied in when it can be found; otherwise captions use DejaVu Sans and the plan says so. Fonts for non-Latin
    scripts present in ``sample_text`` are added when the system has them.
    """
    fonts = Path(work_dir) / "fonts"
    fonts.mkdir(parents=True, exist_ok=True)
    notes: list[str] = []
    for f in BUNDLED_FONTS.glob("*.ttf"):
        shutil.copy2(f, fonts / f.name)
    if not any(fonts.glob("*.ttf")):
        raise CaptionError("The bundled caption fonts are missing from backend/app/assets/fonts. Reinstall VANTA.", "fonts_missing")

    family = (requested_family or "Arial").strip() or "Arial"
    key = family.lower()
    use_family = FALLBACK_FAMILY
    if key == FALLBACK_FAMILY.lower():
        use_family = FALLBACK_FAMILY
    else:
        hits = _find_named(_KNOWN_FILES.get(key, []))
        if not hits:
            m = _fc_match(f"{family}:bold")
            if m and family.lower().split()[0] in m.name.lower().replace("-", " "):
                hits = [m]
        if hits:
            for h in hits[:2]:
                shutil.copy2(h, fonts / h.name)
            use_family = family
        else:
            notes.append(f"Font '{family}' was not found on this computer; captions use {FALLBACK_FAMILY}.")

    for rx, win_files, lang in _SCRIPT_FALLBACKS:
        if sample_text and rx.search(sample_text):
            hits = _find_named(win_files)[:2]
            if not hits:
                m = _fc_match(f":lang={lang}")
                hits = [m] if m else []
            if hits:
                for h in hits:
                    shutil.copy2(h, fonts / h.name)
            else:
                notes.append(f"No installed font covers {lang.upper()} script; some caption characters may appear as boxes.")
    return FontPlan(use_family, "fonts", notes)


# ----------------------------------------------------------------------------------------------- proof of pixels
def _run(cmd: list[str], cwd: Path, timeout: float = 120) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=timeout)


def probe_glyphs(ffmpeg: str, work_dir: Path, ass_name: str, plan: FontPlan, width: int, height: int, t: float, name: str = "caption_probe") -> Path:
    """Render the ASS file alone, at time ``t``, onto a mid-grey canvas and return the PNG path.

    Raises CaptionError when libass draws (almost) nothing - the signature of a font problem.
    """
    out = Path(work_dir) / f"{name}.png"
    out.unlink(missing_ok=True)

    def cmd_for(color: str, name: str) -> list[str]:
        # Input-side seek + -copyts: the canvas frames before ``t`` are never generated or run through libass (15x faster than an
        # output-side -ss on a 1080x1920 canvas), while libass still sees the true timeline (verified frame-identical at several times).
        return [ffmpeg, "-y", "-hide_banner", "-nostdin", "-loglevel", "warning", "-copyts", "-ss", f"{t:.3f}", "-f", "lavfi", "-i",
                f"color=c={color}:s={width}x{height}:r=30:d={t + 1.0:.3f}", "-vf", ass_filter(ass_name, plan.fontsdir),
                "-frames:v", "1", "-update", "1", name]
    cmd = cmd_for("0x808080", out.name)
    try:
        r = _run(cmd, work_dir)
        if r.returncode == 0:      # second canvas: pixels identical on both canvases are OPAQUE (text fill, solid outline); semi-transparent boxes differ
            _run(cmd_for("0x000000", f"{name}_b.png"), work_dir)
    except subprocess.TimeoutExpired as error:
        raise CaptionError("Caption self-test timed out.", "probe_timeout") from error
    (Path(work_dir) / f"{name}_stderr.txt").write_text(r.stderr or "", encoding="utf-8", errors="replace")
    if r.returncode != 0 or not out.is_file():
        msg = (r.stderr or "").strip().splitlines()[-1:] or ["unknown error"]
        raise CaptionError("FFmpeg could not render the caption file (the 'ass' filter is unavailable or the file is invalid): "
                           + msg[0][:300] + " Install an FFmpeg build that includes libass (e.g. the 'full' build from gyan.dev).", "ass_filter_unavailable")
    mask = glyph_mask(out)
    n = mask.histogram()[255]
    if n < MIN_GLYPH_PIXELS:
        raise CaptionError(
            f"FFmpeg's caption renderer (libass) drew only {n} pixels for text that should be visible, so it cannot find a usable font. "
            "Set VANTA_FONTS_DIR to a folder containing a .ttf font (for example C:\\Windows\\Fonts) or install an FFmpeg build with fontconfig/libass.",
            "no_glyphs")
    return out


def glyph_mask(probe_png: Path) -> Image.Image:
    """1-bit-style mask (mode L, 0/255) of pixels that differ from the neutral canvas = caption fill + outline."""
    img = Image.open(probe_png).convert("L")
    sib = Path(probe_png).with_name(Path(probe_png).stem + "_b.png")
    if sib.is_file():
        # Same value on the grey AND black canvas => opaque caption pixel (fill or solid outline, any colour, even grey-ish).
        # Background differs by ~128 between the canvases; semi-transparent boxes land in between and are excluded.
        other = Image.open(sib).convert("L")
        return ImageChops.difference(img, other).point(lambda v: 255 if v <= 6 else 0)
    return img.point(lambda v: 255 if abs(v - GRAY) > 40 else 0)


def extract_frame(ffmpeg: str, video: Path, t: float, out_png: Path) -> Path:
    out_png.unlink(missing_ok=True)
    r = subprocess.run([ffmpeg, "-y", "-hide_banner", "-nostdin", "-loglevel", "error", "-ss", f"{t:.3f}", "-i", str(video),
                        "-frames:v", "1", str(out_png)], capture_output=True, text=True, timeout=120)
    if r.returncode != 0 or not out_png.is_file():
        raise CaptionError("Could not read a frame back from the rendered MP4 to verify captions: " + (r.stderr or "")[-200:], "frame_read_failed")
    return out_png


def compare_frame_to_probe(frame_png: Path, probe_png: Path) -> dict:
    """What share of the caption glyph pixels (from the probe) reappear, in luma, at the same place in the exported frame."""
    mask = glyph_mask(probe_png).convert("1")
    probe = Image.open(probe_png).convert("L")
    frame = Image.open(frame_png).convert("L")
    if frame.size != probe.size:
        raise CaptionError(f"Exported frame is {frame.size} but captions were laid out for {probe.size}.", "size_mismatch")
    close = ImageChops.difference(frame, probe).point(lambda v: 255 if v <= LUMA_TOLERANCE else 0).convert("1")
    both = ImageChops.logical_and(close, mask)
    total = mask.convert("L").histogram()[255]
    ok = both.convert("L").histogram()[255]
    ratio = ok / total if total else 0.0
    return {"glyph_pixels": total, "matched_pixels": ok, "match_ratio": round(ratio, 4), "visible": total >= MIN_GLYPH_PIXELS and ratio >= MIN_MATCH_RATIO}


def pick_probe_time(events: list[tuple[float, float]]) -> float:
    """Middle of the longest caption event, clear of its fade-in/out."""
    a, b = max(events, key=lambda e: e[1] - e[0])
    return a + (b - a) / 2


MAX_PROBE_POINTS = 4
MIN_EVENT_SECONDS = 0.35


def pick_probe_times(events: list[tuple[float, float]], n: int = MAX_PROBE_POINTS) -> list[float]:
    """Up to ``n`` time points (midpoints of caption events) spread over the whole clip: first, last and evenly between.

    Events shorter than MIN_EVENT_SECONDS are skipped when longer ones exist (their midpoint can fall inside a fade).
    A single caption therefore yields one point; verification never claims more coverage than the clip has captions.
    """
    ev = sorted(events)
    long_ev = [e for e in ev if e[1] - e[0] >= MIN_EVENT_SECONDS] or ev
    if not long_ev:
        return []
    if len(long_ev) <= n:
        chosen = long_ev
    else:
        idx = sorted({round(i * (len(long_ev) - 1) / (n - 1)) for i in range(n)})
        chosen = [long_ev[i] for i in idx]
    return [round(a + (b - a) / 2, 3) for a, b in chosen]


def summarize_points(points: list[dict]) -> dict:
    """Combine per-time-point comparisons. ``visible`` only if EVERY sampled point passed; ratio/pixels are the worst case."""
    if not points:
        return {"glyph_pixels": 0, "matched_pixels": 0, "match_ratio": 0.0, "visible": False, "points": [], "checked_at_seconds": None}
    worst = min(points, key=lambda p: p["match_ratio"])
    return {"glyph_pixels": worst["glyph_pixels"], "matched_pixels": worst["matched_pixels"], "match_ratio": worst["match_ratio"],
            "visible": all(p["visible"] for p in points), "points": points, "checked_at_seconds": points[0]["at_seconds"],
            "points_checked": len(points), "points_passed": sum(1 for p in points if p["visible"])}
