"""Paths and limits for VANTA Clipping Studio. Tests call ``configure(tmp)`` to isolate state."""
from __future__ import annotations

import os
from pathlib import Path

from ..config import DATA_DIR

BASE: Path
UPLOAD_DIR: Path
SOURCE_DIR: Path
EXPORT_DIR: Path
TMP_DIR: Path
TRANSCRIPT_DIR: Path
MUSIC_DIR: Path
DIAG_DIR: Path
MODELS_DIR: Path
TRANSCRIPT_CACHE_DIR: Path
DB_PATH: Path

VIDEO_EXTENSIONS = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mpg", ".mpeg", ".ts", ".flv", ".wmv", ".3gp"}
MUSIC_EXTENSIONS = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}
TRANSCRIPT_EXTENSIONS = {".srt", ".vtt", ".json"}

MAX_UPLOAD_BYTES = int(os.getenv("VANTA_MAX_UPLOAD_BYTES", str(4 * 1024 ** 3)))
MAX_DURATION_SECONDS = float(os.getenv("VANTA_MAX_DURATION_SECONDS", str(4 * 3600)))
MAX_TRANSCRIPT_BYTES = 5 * 1024 * 1024
MAX_REMOTE_BYTES = int(os.getenv("VANTA_MAX_REMOTE_BYTES", str(1024 ** 3)))
STALE_TMP_HOURS = 24
# After a restart, continue interrupted render/download jobs instead of failing them (0 = old behaviour: mark Failed).
RESUME_INTERRUPTED_JOBS = os.getenv("VANTA_RESUME_JOBS", "1").strip().lower() not in {"0", "false", "no", "off"}
MAX_JOB_RESUMES = max(0, int(os.getenv("VANTA_MAX_RESUMES", "2") or 2))


def configure(base: Path) -> None:
    global BASE, UPLOAD_DIR, SOURCE_DIR, EXPORT_DIR, TMP_DIR, TRANSCRIPT_DIR, MUSIC_DIR, DIAG_DIR, MODELS_DIR, TRANSCRIPT_CACHE_DIR, DB_PATH
    BASE = Path(base).resolve()
    UPLOAD_DIR, SOURCE_DIR, EXPORT_DIR = BASE / "uploads", BASE / "sources", BASE / "exports"
    TMP_DIR, TRANSCRIPT_DIR, MUSIC_DIR = BASE / "tmp", BASE / "transcripts", BASE / "music"
    DIAG_DIR = BASE / "diagnostics"
    MODELS_DIR = Path(os.getenv("VANTA_WHISPER_CACHE") or (BASE / "models" / "whisper"))
    TRANSCRIPT_CACHE_DIR = TRANSCRIPT_DIR / "cache"
    DB_PATH = BASE / "vanta.db"
    for d in (UPLOAD_DIR, SOURCE_DIR, EXPORT_DIR, TMP_DIR, TRANSCRIPT_DIR, MUSIC_DIR, DIAG_DIR, TRANSCRIPT_CACHE_DIR):
        d.mkdir(parents=True, exist_ok=True)


def is_inside(path: Path, root: Path) -> bool:
    """True when ``path`` resolves to a location inside ``root`` (blocks ../ traversal and symlink escapes)."""
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (ValueError, OSError):
        return False


configure(Path(os.getenv("VANTA_DATA_DIR", DATA_DIR / "vanta")))
