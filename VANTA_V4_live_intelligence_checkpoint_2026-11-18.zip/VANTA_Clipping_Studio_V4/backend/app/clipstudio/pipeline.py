"""Background job runners: analyse (fetch -> probe -> transcribe -> rank) and render. One worker = no concurrent file corruption."""
from __future__ import annotations

import json
import logging
import re
import shutil
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import analysis, db, links, media, settings
from .render import RenderCancelled, RenderError, RenderSettings, render_clip, safe_slug
from .selection import audio as sel_audio
from .selection import engine as sel_engine
from .selection import explain as sel_explain
from .selection import llm_eval
from . import whisper_local
from .transcript import Transcript, TranscriptCancelled, TranscriptError, engine_status, get_engine, load_transcript_file

log = logging.getLogger("vanta")
EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="vanta-job")
_CANCEL: set[str] = set()
_LOCK = threading.Lock()
_SUBMIT_LOCK = threading.Lock()   # makes 'is the project busy?' + 'create the job' atomic, so a double click cannot start two jobs


_AFTER_DOWNLOAD = "The video is saved on disk (it will not be downloaded again), but analysis failed: "


class Cancelled(RuntimeError):
    pass


class Busy(RuntimeError):
    pass


def is_cancelled(job_id: str) -> bool:
    with _LOCK:
        return job_id in _CANCEL


def _check(job_id: str) -> None:
    if is_cancelled(job_id):
        raise Cancelled()


def project_busy(project_id: str) -> bool:
    return any(j["status"] in db.ACTIVE for j in db.list_jobs(50, project_id))


def startup() -> dict:
    """Recover from a restart: continue interrupted render/download jobs (bounded), fail the rest, clean scratch folders."""
    db.init()
    outcome = db.recover_interrupted(resume=settings.RESUME_INTERRUPTED_JOBS, max_resumes=settings.MAX_JOB_RESUMES)
    for old_id in outcome["interrupted_ids"]:   # the dead job's scratch folder is never reused
        shutil.rmtree(settings.TMP_DIR / old_id, ignore_errors=True)
    cleanup_stale_tmp()
    cleanup_download_staging()      # must run before the resumed download job is submitted
    for job in outcome["resumed"]:
        EXECUTOR.submit(_run_render if job["kind"] == "render" else _run_download, job["id"])
    if outcome["resumed"] or outcome["failed"]:
        log.warning("restart recovery: resumed %d, failed %d, already complete %d", len(outcome["resumed"]), len(outcome["failed"]), len(outcome["completed"]))
    return outcome


def cleanup_download_staging() -> int:
    """At startup no download can be running, so any ``.dl-*`` staging folder under sources/ is a leftover partial download."""
    removed = 0
    for d in settings.SOURCE_DIR.glob("*/.dl-*") if settings.SOURCE_DIR.exists() else []:
        if d.is_dir() and settings.is_inside(d, settings.SOURCE_DIR):
            shutil.rmtree(d, ignore_errors=True); removed += 1
    return removed


def cleanup_stale_tmp() -> int:
    """Delete only old scratch directories under tmp/. Uploads, sources and exports are never touched here."""
    removed, cutoff = 0, time.time() - settings.STALE_TMP_HOURS * 3600
    active = {j["id"] for j in db.list_jobs(500) if j["status"] in db.ACTIVE}
    for d in settings.TMP_DIR.iterdir() if settings.TMP_DIR.exists() else []:
        if d.is_dir() and d.name not in active and d.stat().st_mtime < cutoff and settings.is_inside(d, settings.TMP_DIR):
            shutil.rmtree(d, ignore_errors=True); removed += 1
    return removed


# --------------------------------------------------------------------------- transcript/signals persistence
def save_transcript(project_id: str, transcript: Transcript, cache_key: str | None = None) -> Path:
    path = settings.TRANSCRIPT_DIR / f"{project_id}.json"
    path.write_text(json.dumps(transcript.to_dict()), encoding="utf-8")
    meta = {"source": transcript.source, "word_level": transcript.word_level, "language": transcript.language, "segments": len(transcript.segments)}
    if cache_key:
        meta["cache_key"] = cache_key
    db.update_project(project_id, transcript_path=str(path), transcript_meta=meta)
    return path


def _transcript_file(project: dict) -> Path | None:
    """Locate the project's transcript JSON. The stored absolute path can go stale (moved/renamed data folder, upgraded
    install), so fall back to the canonical ``<TRANSCRIPT_DIR>/<project id>.json`` instead of silently losing captions."""
    p = project.get("transcript_path")
    if p and settings.is_inside(Path(p), settings.TRANSCRIPT_DIR) and Path(p).is_file():
        return Path(p)
    canonical = settings.TRANSCRIPT_DIR / f"{project.get('id')}.json"
    if project.get("id") and canonical.is_file():
        return canonical
    if p and Path(p).name and (settings.TRANSCRIPT_DIR / Path(p).name).is_file():
        return settings.TRANSCRIPT_DIR / Path(p).name
    return None


def load_project_transcript(project: dict) -> Transcript | None:
    f = _transcript_file(project)
    if f is None:
        return None
    try:
        t = Transcript.from_dict(json.loads(f.read_text(encoding="utf-8")))
    except (ValueError, KeyError, OSError):
        return None
    return t if t.available else None


def transcript_available(project: dict) -> bool:
    """True only when a transcript can really be loaded (not merely when a path string is stored)."""
    return load_project_transcript(project) is not None


def keep_diagnostics(job_id: str, cid: str, tmp_dir: Path) -> Path | None:
    """Move a failed render's working folder (ass file, probe frame, ffmpeg stderr/command) to <data>/diagnostics."""
    try:
        if not tmp_dir.is_dir():
            return None
        dest = settings.DIAG_DIR / job_id / cid
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.rmtree(dest, ignore_errors=True)
        shutil.copytree(tmp_dir, dest, ignore=shutil.ignore_patterns("fonts"))
        old = sorted((d for d in settings.DIAG_DIR.iterdir() if d.is_dir()), key=lambda d: d.stat().st_mtime)
        for d in old[:-20]:               # keep the 20 most recent failed jobs
            shutil.rmtree(d, ignore_errors=True)
        return dest
    except OSError:
        return None


def load_signals(project: dict) -> dict:
    p = project.get("signals_path")
    if p and Path(p).is_file():
        try:
            return json.loads(Path(p).read_text())
        except ValueError:
            pass
    return {}


def resolve_music(music_id: str | None) -> Path | None:
    if not music_id:
        return None
    if not re.fullmatch(r"[a-f0-9]{12}", music_id):
        raise RenderError("Invalid music id.")
    found = list(settings.MUSIC_DIR.glob(f"{music_id}_*"))
    if not found or not settings.is_inside(found[0], settings.MUSIC_DIR):
        raise RenderError("The selected music file is missing. Upload it again.")
    return found[0]


# --------------------------------------------------------------------------- analysis job
def submit_analyze(project_id: str, options: dict) -> dict:
    with _SUBMIT_LOCK:
        if project_busy(project_id):
            raise Busy("This project already has a job running.")
        job = db.create_job(project_id, "analyze", options)
        db.update_project(project_id, status="queued", error=None)
    EXECUTOR.submit(_run_analyze, job["id"])
    return job


def submit_download(project_id: str) -> dict:
    """Queue a (re)download of a linked project's source. Callers check for an existing valid copy first (see ``valid_source_info``)."""
    with _SUBMIT_LOCK:
        if project_busy(project_id):
            raise Busy("This project already has a job running.")
        job = db.create_job(project_id, "download", {})
        db.update_project(project_id, status="queued", error=None)
    EXECUTOR.submit(_run_download, job["id"])
    return job


def any_download_active() -> bool:
    return any(j["status"] in db.ACTIVE and j["kind"] in {"download", "analyze"} for j in db.list_jobs(50))


# --------------------------------------------------------------------------- source acquisition (shared by download + analyze jobs)
def valid_source_info(project: dict) -> dict | None:
    """ffprobe info when the project's registered source file exists, lives in VANTA's folders and is playable; otherwise None."""
    sp = project.get("source_path")
    if not sp:
        return None
    path = Path(sp)
    if not path.is_file() or not (settings.is_inside(path, settings.SOURCE_DIR) or settings.is_inside(path, settings.UPLOAD_DIR)):
        return None
    try:
        return media.validate_source(path, settings.MAX_DURATION_SECONDS)
    except media.MediaError:
        return None


def _adopt_existing_download(pid: str) -> tuple[Path, dict] | None:
    """A valid source.* left by an interrupted earlier run is reused instead of downloading the video again."""
    folder = settings.SOURCE_DIR / pid
    for cand in sorted(folder.glob("source.*")) if folder.is_dir() else []:
        if cand.suffix.lower() in links.MEDIA_SUFFIXES and cand.is_file() and cand.stat().st_size > 0:
            try:
                return cand, media.validate_source(cand, settings.MAX_DURATION_SECONDS)
            except media.MediaError:
                cand.unlink(missing_ok=True)
    return None


def _download_source(job_id: str, project: dict) -> tuple[dict, dict, str]:
    """Download (or adopt) the linked video, validate it, register it on the project. Returns (project, info, how)."""
    pid = project["id"]
    adopted = _adopt_existing_download(pid)
    if adopted:
        path, info = adopted
        fetched, how = None, "reused"
    else:
        fetched = links.fetch(project["source_ref"] or "", settings.SOURCE_DIR / pid,
                              progress=lambda p, m=None: db.set_progress(job_id, p, m or "Downloading the linked video"), cancelled=lambda: is_cancelled(job_id))
        path, how = fetched.path, "downloaded"
        try:
            info = fetched.probe or media.validate_source(path, settings.MAX_DURATION_SECONDS)
        except media.MediaError as error:
            path.unlink(missing_ok=True)
            raise links.LinkError("invalid_media", f"The download finished but the file is not usable video ({error}). It was discarded.", retryable=True,
                                  hint="Retry, or upload the video file.") from error
    cfg = {k: v for k, v in (project.get("settings") or {}).items() if k != "download_error"}
    new_name = project["name"] if project["name"] != "Linked video" or not fetched else fetched.title
    db.update_project(pid, source_path=str(path), probe=info, name=new_name, settings=cfg, error=None)
    if fetched and fetched.subtitle_path:
        try:
            save_transcript(pid, load_transcript_file(fetched.subtitle_path, "platform-subtitles"))
        except TranscriptError as e:
            log.warning("Ignoring unreadable platform subtitles: %s", e)
    return db.get_project(pid), info, how  # type: ignore[return-value]


def _fail_link(job_id: str, pid: str, error: "links.LinkError") -> None:
    """Record a structured download failure on the job and the project, and drop any partial download."""
    if not (db.get_project(pid) or {}).get("source_path"):
        shutil.rmtree(settings.SOURCE_DIR / pid, ignore_errors=True)
    message = str(error) + (f" {error.hint}" if error.hint else "")
    try:
        db.transition(job_id, "failed", error=message, result={"error": error.to_dict()})
    except db.StateError:
        pass
    proj = db.get_project(pid) or {}
    db.update_project(pid, status="failed", error=message, settings={**(proj.get("settings") or {}), "download_error": error.to_dict()})


def _run_download(job_id: str) -> None:
    job = db.get_job(job_id)
    if not job or job["status"] != "queued":
        return
    pid = job["project_id"]
    try:
        project = db.get_project(pid)
        if project is None:
            raise RuntimeError("Project not found.")
        if project["source_type"] != "link":
            raise RuntimeError("Only linked projects can be downloaded. Uploaded videos are already on disk.")
        existing = valid_source_info(project)
        if existing:
            db.transition(job_id, "downloading", message="A valid local copy already exists")
            db.transition(job_id, "completed", message="Already downloaded - nothing to fetch", result={"how": "existing", "probe": existing}, progress=1.0)
            db.update_project(pid, status="new", error=None)
            return
        db.transition(job_id, "downloading", message="Starting the download"); db.update_project(pid, status="downloading", error=None)
        project, info, how = _download_source(job_id, project)
        _check(job_id)
        db.transition(job_id, "completed", message=("Reused the video already on disk" if how == "reused" else "Download complete") +
                      f" · {info['width']}×{info['height']} · {info['duration']:.0f}s", result={"how": how, "probe": info}, progress=1.0)
        db.update_project(pid, status="new", error=None)
    except Cancelled:
        _settle_cancelled(job_id, pid)
    except links.LinkError as e:
        if e.code == "cancelled":
            _settle_cancelled(job_id, pid)
        else:
            _fail_link(job_id, pid, e)
    except Exception as e:
        log.exception("Download job %s crashed", job_id)
        _fail(job_id, pid, f"Unexpected error: {type(e).__name__}: {str(e)[:200]}")
    finally:
        with _LOCK:
            _CANCEL.discard(job_id)


def _fail(job_id: str, project_id: str, message: str, result: dict | None = None) -> None:
    try:
        db.transition(job_id, "failed", error=message, result=result)
    except db.StateError:
        pass
    db.update_project(project_id, status="failed", error=message)


def _baseline_analysis(c: "analysis.Candidate", has_text: bool) -> dict:
    return {"engine": "baseline-heuristic", "engine_version": "1", "score_meaning": analysis.SCORE_DISCLAIMER,
            "signals_used": (["transcript"] if has_text else []) + ["pauses", "scene-cuts"],
            "features": {k: {"value": v} for k, v in (c.features or {}).items() if isinstance(v, (int, float))}, "summary": "; ".join(c.reasons[:3]),
            "caveats": [], "hook": None, "payoff": None, "alternates": [], "llm": None,
            "confidence": {"level": "low" if not has_text else "medium", "definition": sel_explain.CONFIDENCE_DEFINITION}}


def _rank(duration: float, transcript, signals: dict, target: float, count: int, opts: dict, notes: list[str]):
    """Preferred: multi-signal engine (+ optional local LLM). Fallback: the original heuristic ranker. The choice is always reported."""
    silences, scenes = signals.get("silences", []), signals.get("scenes", [])
    has_text = bool(transcript and transcript.available)
    if opts.get("engine_mode", "auto") != "baseline":
        try:
            env = sel_audio.Envelope.from_dict(signals.get("envelope"))
            cands, _pool = sel_engine.rank(duration, transcript, silences, scenes, target, count, env, bool(signals.get("scenes_ok", True)))
            if cands:
                report = {"requested": False, "available": False, "reason": "Local LLM not used.", "evaluated": 0, "failed": 0}
                if opts.get("local_llm", True):
                    report = llm_eval.apply(cands, settings.BASE / "cache" / "llm")
                    if report["requested"] and report["failed"]:
                        notes.append(f"Local model: {report['failed']} evaluation(s) failed or returned an invalid format; rule-based scores were kept for those.")
                for c in cands:
                    c.features["analysis"]["llm_run"] = report
                return cands, sel_engine.ENGINE_NAME, cands[0].features["analysis"]["signals_used"], report
        except Exception as e:  # noqa: BLE001 - never lose the analysis because the new engine failed
            log.exception("Multi-signal engine failed; falling back to the heuristic ranker")
            notes.append(f"The multi-signal engine failed ({type(e).__name__}: {str(e)[:120]}); the simple heuristic ranker was used instead.")
    cands = analysis.suggest_clips(duration, transcript, silences, scenes, target, count)
    for c in cands:
        c.features = {**c.features, "analysis": _baseline_analysis(c, has_text)}
    return cands, "baseline-heuristic", (["transcript"] if has_text else []) + ["pauses", "scene-cuts"], None


def _auto_transcribe(job_id: str, pid: str, project: dict, source: Path, info: dict, opts: dict, notes: list[str]) -> Transcript | None:
    """Local transcription for a project without a transcript. Never downloads a model; reuses a cached transcript of the
    identical media file; reports real progress and honours cancel. Problems become notes (ranking continues without text)."""
    if not info["has_audio"]:
        notes.append("The video has no audio track, so there is nothing to transcribe.")
        return None
    engine_name = opts.get("engine", "faster-whisper")
    eng = get_engine(engine_name)
    if opts.get("whisper_model") and hasattr(eng, "model_name"):
        try:
            eng.model_name = whisper_local.validate_model(opts["whisper_model"])
        except TranscriptError as e:
            notes.append(str(e))
            return None
    language = opts.get("language") or None
    key = None
    if engine_name == "faster-whisper":
        try:
            key = whisper_local.cache_key(source, eng.model_name, language)
            cached = whisper_local.cache_get(key)
        except OSError:
            key, cached = None, None
        if cached is not None:
            save_transcript(pid, cached, key)
            notes.append(f"Reused the saved transcript of this exact video file (model {eng.model_name}); nothing was transcribed again.")
            return cached
    ok, detail = eng.available()
    if not ok:
        notes.append(f"No local transcription: {detail} Without a transcript, clips are ranked by audio and visual signals only.")
        return None
    db.set_progress(job_id, 0.0, f"Transcribing locally with {engine_name} ({detail}) - this can take a while")
    last = [0.0]

    def progress(p, m=None):
        if p is None or p >= 1.0 or p - last[0] >= 0.01:
            last[0] = p or 0.0
            db.set_progress(job_id, p, m)
    try:
        transcript = eng.transcribe(source, language, progress=progress, cancelled=lambda: is_cancelled(job_id), duration=info.get("duration"))
    except TranscriptCancelled:
        raise Cancelled()
    except TranscriptError as e:
        notes.append(str(e))
        return None
    notes.extend(getattr(eng, "notes", []))
    if key:
        try:
            whisper_local.cache_put(key, transcript, eng.model_name, language)
        except OSError as e:
            notes.append(f"The transcript could not be cached for reuse: {e}")
            key = None
    save_transcript(pid, transcript, key)
    return transcript


def _run_analyze(job_id: str) -> None:
    job = db.get_job(job_id)
    if not job or job["status"] != "queued":
        return
    pid, opts = job["project_id"], job["payload"]
    tmp = settings.TMP_DIR / job_id
    source_ready = False
    try:
        project = db.get_project(pid)
        if project is None:
            raise RuntimeError("Project not found.")
        tmp.mkdir(parents=True, exist_ok=True)
        # ---- source: download (links, only when no valid local copy exists) or re-validate (uploads)
        info = valid_source_info(project)
        if info is None and project["source_type"] == "link":
            db.transition(job_id, "downloading", message="Downloading the linked video"); db.update_project(pid, status="downloading", error=None)
            project, info, _how = _download_source(job_id, project)
            source_ready = True
            _check(job_id)
            db.transition(job_id, "validating", message="Checking the video"); db.update_project(pid, status="validating", error=None)
        else:
            db.transition(job_id, "validating", message="Checking the video"); db.update_project(pid, status="validating", error=None)
            if info is None:
                raise media.MediaError("The source video file is missing or unreadable on disk. Upload the video again.")
            source_ready = project["source_type"] == "link"
        source = Path(project["source_path"])
        _check(job_id)

        # ---- transcript
        db.transition(job_id, "transcribing", message="Preparing transcript"); db.update_project(pid, status="transcribing")
        transcript = load_project_transcript(project)
        notes: list[str] = []
        if transcript is None and opts.get("transcribe", True):
            transcript = _auto_transcribe(job_id, pid, project, source, info, opts, notes)
        if transcript is None and not notes:
            notes.append("No transcript is attached, so clips are ranked by audio and visual signals only. Upload an .srt/.vtt/.json transcript for transcript-based ranking.")
        _check(job_id)

        # ---- signals + ranking
        db.transition(job_id, "analyzing", message="Finding clip candidates"); db.update_project(pid, status="analyzing")
        signals = load_signals(project)
        sp = settings.TRANSCRIPT_DIR / f"{pid}.signals.json"
        dirty = False
        if not signals:
            signals = {"silences": [], "scenes": [], "scenes_ok": True}
            dirty = True
            if info["has_audio"]:
                db.set_progress(job_id, None, "Detecting pauses")
                try:
                    signals["silences"] = media.detect_silences(source)
                except media.MediaError as e:
                    notes.append(f"Pause detection skipped: {e}")
            _check(job_id)
            db.set_progress(job_id, None, "Detecting scene changes")
            try:
                signals["scenes"] = media.detect_scene_changes(source)
            except media.MediaError as e:
                signals["scenes_ok"] = False
                notes.append(f"Scene detection skipped: {e}")
        if info["has_audio"] and "envelope" not in signals and "envelope_error" not in signals and opts.get("engine_mode", "auto") != "baseline":
            _check(job_id)
            db.set_progress(job_id, None, "Measuring audio loudness")
            try:
                signals["envelope"] = sel_audio.compute_envelope(source).to_dict()
            except sel_audio.AudioAnalysisError as e:
                signals["envelope_error"] = str(e)[:200]
                notes.append(f"Loudness analysis skipped: {e}")
            dirty = True
        if dirty:
            sp.write_text(json.dumps(signals)); db.update_project(pid, signals_path=str(sp))
        _check(job_id)
        target = float(opts.get("target_duration", 30)); count = int(opts.get("count", 5))
        cands, engine_used, used_signals, llm_report = _rank(info["duration"], transcript, signals, target, count, opts, notes)
        db.clear_auto_candidates(pid)
        auto_render = bool(opts.get("auto_render", False))
        candidate_ids = []
        for rank, c in enumerate(cands, 1):
            saved = db.add_candidate(pid, c.start, c.end, c.score, c.method, c.reasons, c.excerpt,
                                     rank=rank, status="approved" if auto_render else "suggested", analysis=c.features.get("analysis"))
            candidate_ids.append(saved["id"])
        method = cands[0].method if cands else "none"
        result = {"candidates": len(cands), "method": method, "engine": engine_used, "signals_used": used_signals, "llm": llm_report,
                  "transcript_source": transcript.source if transcript else None,
                  "word_level": bool(transcript and transcript.word_level), "notes": notes,
                  "score_note": sel_explain.SCORE_MEANING if engine_used != "baseline-heuristic" else analysis.SCORE_DISCLAIMER}
        db.update_project(pid, status="awaiting_approval", settings={**(project["settings"] or {}), "last_analysis": opts})
        db.transition(job_id, "awaiting_approval", message=f"{len(cands)} suggestion(s) ready" + ("; starting automatic rendering" if auto_render else " for review"), result=result)
        if auto_render and candidate_ids:
            # Queue a separate render job after the analysis job leaves the active state.
            try:
                submit_render(pid, candidate_ids, opts.get("render_settings") or {})
            except Exception as e:
                log.exception("Could not queue auto-render for project %s", pid)
                db.update_project(pid, status="awaiting_approval", error=f"Clips were found but automatic rendering could not start: {str(e)[:160]}")
        elif auto_render and not candidate_ids:
            db.update_project(pid, status="failed", error="No clip candidates were found. Try a transcript or a longer source video.")
    except Cancelled:
        _settle_cancelled(job_id, pid)
    except links.LinkError as e:
        if e.code == "cancelled":
            _settle_cancelled(job_id, pid)
        else:
            _fail_link(job_id, pid, e)
    except (media.MediaError, TranscriptError) as e:
        _fail(job_id, pid, (_AFTER_DOWNLOAD if source_ready else "") + str(e))
    except Exception as e:  # unexpected: keep details in the server log, show a short message
        log.exception("Analysis job %s crashed", job_id)
        _fail(job_id, pid, (_AFTER_DOWNLOAD if source_ready else "") + f"Unexpected error: {type(e).__name__}: {str(e)[:200]}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        with _LOCK:
            _CANCEL.discard(job_id)


def _resting_status(pid: str) -> str:
    """Where a project goes after a cancelled analyse/download: back to review when it still has suggestions, else 'new'."""
    return "awaiting_approval" if db.list_candidates(pid) else "new"


def _settle_cancelled(job_id: str, pid: str, project_status: str | None = None) -> None:
    try:
        db.transition(job_id, "cancelled", message="Cancelled")
    except db.StateError:
        pass
    db.update_project(pid, status=project_status or _resting_status(pid))


# --------------------------------------------------------------------------- render job
def submit_render(project_id: str, candidate_ids: list[str], render_settings: dict) -> dict:
    with _SUBMIT_LOCK:
        if project_busy(project_id):
            raise Busy("This project already has a job running.")
        job = db.create_job(project_id, "render", {"candidate_ids": candidate_ids, "settings": render_settings})
        for cid in candidate_ids:
            db.update_candidate(cid, status="queued", error=None)
        db.update_project(project_id, status="queued")
    EXECUTOR.submit(_run_render, job["id"])
    return job


def _run_render(job_id: str) -> None:
    job = db.get_job(job_id)
    if not job or job["status"] != "queued":
        return
    pid, payload = job["project_id"], job["payload"]
    cids: list[str] = payload["candidate_ids"]
    tmp_root = settings.TMP_DIR / job_id
    exported, failed = [], []
    try:
        project = db.get_project(pid)
        if project is None or not project["source_path"]:
            raise RuntimeError("Project source is missing.")
        source, info = Path(project["source_path"]), project["probe"]
        if not source.is_file():
            raise RenderError("The source video file is missing from disk.")
        rs = RenderSettings.from_dict(payload["settings"])
        music = resolve_music(payload["settings"].get("music_id"))
        rs.music_path = str(music) if music else None
        transcript = load_project_transcript(project)
        signals = load_signals(project)
        silences = [tuple(x) for x in signals.get("silences", [])]
        db.transition(job_id, "rendering", message=f"Rendering {len(cids)} clip(s)"); db.update_project(pid, status="rendering")
        out_dir = settings.EXPORT_DIR / pid
        for n, cid in enumerate(cids):
            _check(job_id)
            cand = db.get_candidate(cid)
            if not cand:
                continue
            db.update_candidate(cid, status="rendering", error=None)
            name = f"{safe_slug(project['name'], 28)}_{cid}_{rs.aspect.replace(':', 'x')}.mp4"
            db.set_progress(job_id, n / len(cids), f"Rendering clip {n + 1} of {len(cids)}")
            try:
                res = render_clip(source, out_dir / name, tmp_root / cid, cand["start"], cand["end"], info, rs, transcript, silences,
                                  progress=lambda p, n=n: db.set_progress(job_id, (n + p) / len(cids)),
                                  cancelled=lambda: is_cancelled(job_id), srt_path=out_dir / (Path(name).stem + ".srt"))
                exp = db.add_export(pid, cid, job_id, res["path"], name, rs.aspect, res["duration"], res["size_bytes"], res["validation"],
                                    {k: res[k] for k in ("captions_granularity", "captions_note", "caption_verification", "silence_removed", "reframe_used", "subject_tracking")}
                                    | {"settings": rs.to_dict() | {"music_path": None}, "start": cand["start"], "end": cand["end"]}, res["srt_path"])
                db.update_candidate(cid, status="rendered", error=None)
                exported.append(exp["id"])
            except RenderCancelled:
                raise Cancelled()
            except RenderError as e:
                diag = keep_diagnostics(job_id, cid, tmp_root / cid)
                db.update_candidate(cid, status="failed", error=str(e)[:500])
                failed.append({"candidate_id": cid, "error": str(e)[:500], "code": getattr(e, "code", "render_failed"),
                               "diagnostics": str(diag.relative_to(settings.BASE)) if diag else None})
            finally:
                shutil.rmtree(tmp_root / cid, ignore_errors=True)
        result = {"exported": exported, "failed": failed}
        if exported:
            db.transition(job_id, "completed", message=f"{len(exported)} export(s) ready" + (f", {len(failed)} failed" if failed else ""), result=result, progress=1.0)
            db.update_project(pid, status="awaiting_approval", error=None)
        else:
            _fail(job_id, pid, "No clip could be rendered: " + "; ".join(f["error"] for f in failed)[:400], result=result)
            db.update_project(pid, status="awaiting_approval")
    except Cancelled:
        for cid in cids:
            c = db.get_candidate(cid)
            if c and c["status"] in {"queued", "rendering"}:
                db.update_candidate(cid, status="approved")
        _settle_cancelled(job_id, pid, "awaiting_approval")
    except (RenderError, media.MediaError) as e:
        for cid in cids:
            db.update_candidate(cid, status="approved")
        _fail(job_id, pid, str(e)); db.update_project(pid, status="awaiting_approval", error=None)
    except Exception as e:
        log.exception("Render job %s crashed", job_id)
        for cid in cids:
            db.update_candidate(cid, status="approved")
        _fail(job_id, pid, f"Unexpected error: {type(e).__name__}: {str(e)[:200]}"); db.update_project(pid, status="awaiting_approval")
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)
        with _LOCK:
            _CANCEL.discard(job_id)


def cancel_job(job_id: str) -> dict:
    job = db.get_job(job_id)
    if not job:
        raise db.StateError("Job not found")
    if job["status"] == "queued":
        db.transition(job_id, "cancelled", message="Cancelled before it started")
        db.update_project(job["project_id"], status="awaiting_approval" if job["kind"] == "render" else _resting_status(job["project_id"]))
        for cid in (job["payload"] or {}).get("candidate_ids", []):
            c = db.get_candidate(cid)
            if c and c["status"] == "queued":
                db.update_candidate(cid, status="approved")
    elif job["status"] in db.ACTIVE:
        with _LOCK:
            _CANCEL.add(job_id)
    else:
        raise db.StateError(f"A {job['status']} job cannot be cancelled.")
    return db.get_job(job_id)  # type: ignore[return-value]
