"""yt-dlp command builder, process runner and download collector (split from ytdlp.py; re-exported there)."""
from __future__ import annotations

import os
import re
import signal
import subprocess
import threading
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from . import settings
from .linkerrors import LinkError
from .ytdlp_const import DEFAULT_FORMAT, MEDIA_SUFFIXES

# ============================================================================ command + runner
def build_command(base: list[str], url: str, staging: Path, *, max_filesize: int, fmt: str = DEFAULT_FORMAT, ffmpeg_dir: str | None = None,
                  js_runtime_arg: str | None = None, remote_components: str | None = None, auto_subs: bool = False, socket_timeout: int = 20) -> list[str]:
    """Build the yt-dlp argv. ``url`` must already be validated; ``--`` stops option parsing so a URL can never act as a flag."""
    cmd = [*base, "--ignore-config", "--no-playlist", "--no-colors", "--newline", "--progress",
           "--socket-timeout", str(socket_timeout), "--retries", "3", "--fragment-retries", "3", "--extractor-retries", "2",
           "--max-filesize", str(int(max_filesize)), "-f", fmt, "--merge-output-format", "mp4",
           "--write-subs", *(["--write-auto-subs"] if auto_subs else []), "--sub-langs", "en.*,en", "--sub-format", "vtt",
           "--print", "after_move:filepath", "--print", "after_move:VANTA_TITLE=%(title)s"]
    if ffmpeg_dir:
        cmd += ["--ffmpeg-location", ffmpeg_dir]
    if js_runtime_arg:
        cmd += ["--js-runtimes", js_runtime_arg]
    if remote_components:
        cmd += ["--remote-components", remote_components]
    cmd += ["-o", str(staging / "source.%(ext)s"), "--", url]
    return cmd


def _child_env() -> dict[str, str]:
    """Environment for the downloader: UTF-8 output, and no API keys/tokens/secrets from VANTA's own environment."""
    env = {k: v for k, v in os.environ.items() if not re.search(r"(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)", k, re.I)}
    env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", NO_COLOR="1")
    return env


def _popen_kwargs() -> dict:
    if os.name == "nt":
        return {"creationflags": getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)}
    return {"start_new_session": True}


def _kill_tree(proc: subprocess.Popen) -> None:
    """Kill yt-dlp *and* its ffmpeg children."""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, timeout=15, check=False)
        else:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except (OSError, subprocess.SubprocessError, ProcessLookupError):
        pass
    try:
        proc.kill()
    except OSError:
        pass


_PCT = re.compile(r"\[download\]\s+(\d+(?:\.\d+)?)%")
_FORMATS = re.compile(r"Downloading (\d+) format\(s\)")


@dataclass
class RunOutput:
    returncode: int
    stdout: list[str]
    stderr: list[str]


def run_process(cmd: list[str], *, timeout: float, cancelled: Callable[[], bool], on_stdout_line: Callable[[str], None] = lambda l: None) -> RunOutput:
    """Run ``cmd`` streaming both pipes (no deadlock, bounded memory); enforce timeout and cancellation."""
    out: deque[str] = deque(maxlen=3000)
    err: deque[str] = deque(maxlen=3000)
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, text=True, encoding="utf-8",
                            errors="replace", env=_child_env(), **_popen_kwargs())

    def pump(stream, sink: deque, cb: Callable[[str], None]) -> None:
        try:
            for line in stream:
                line = line.rstrip("\r\n")
                sink.append(line)
                try:
                    cb(line)
                except Exception:   # a progress callback must never kill the reader
                    pass
        except (OSError, ValueError):
            pass

    threads = [threading.Thread(target=pump, args=(proc.stdout, out, on_stdout_line), daemon=True),
               threading.Thread(target=pump, args=(proc.stderr, err, lambda l: None), daemon=True)]
    for t in threads:
        t.start()
    deadline = time.monotonic() + timeout
    try:
        while True:
            try:
                proc.wait(timeout=0.25)
                break
            except subprocess.TimeoutExpired:
                if cancelled():
                    _kill_tree(proc)
                    proc.wait()
                    raise LinkError("cancelled", "Download cancelled.")
                if time.monotonic() > deadline:
                    _kill_tree(proc)
                    proc.wait()
                    raise LinkError("timeout", f"The download did not finish within {int(timeout // 60)} minutes and was stopped.", retryable=True,
                                    hint="Retry. For very long videos raise VANTA_YTDLP_TIMEOUT in .env.")
    except BaseException:
        if proc.poll() is None:
            _kill_tree(proc)
            proc.wait()
        raise
    finally:
        for t in threads:
            t.join(timeout=5)
        for s in (proc.stdout, proc.stderr):
            try:
                s.close()
            except OSError:
                pass
    return RunOutput(proc.returncode, list(out), list(err))


@dataclass
class DownloadResult:
    path: Path
    title: str | None
    subtitle: Path | None
    attempts: int


_INTERMEDIATE = re.compile(r"\.f[0-9a-z-]+\.[a-z0-9]+$", re.I)


def _collect(staging: Path, stdout: list[str]) -> DownloadResult | None:
    title = None
    named: list[Path] = []
    for line in stdout:
        if line.startswith("VANTA_TITLE="):
            title = line[len("VANTA_TITLE="):].strip()[:150] or None
            continue
        cand = Path(line.strip()) if line.strip() and not line.startswith("[") else None
        if cand and cand.suffix.lower() in MEDIA_SUFFIXES and cand.is_file() and settings.is_inside(cand, staging):
            named.append(cand)
    pool = [p for p in named if not _INTERMEDIATE.search(p.name)] or \
           [p for p in staging.glob("source.*") if p.suffix.lower() in MEDIA_SUFFIXES and not _INTERMEDIATE.search(p.name)]
    pool = [p for p in pool if p.is_file() and p.stat().st_size > 0]
    if not pool:
        return None
    subs = sorted(staging.glob("source*.vtt"))
    return DownloadResult(max(pool, key=lambda p: p.stat().st_size), title, subs[0] if subs else None, 1)
