"""Transcript model, subtitle parsers and pluggable transcription engines.

Engines are replaceable: anything with ``transcribe(audio_or_video_path, language) -> Transcript`` works.
Word timestamps are only ever taken from an engine/file that actually provides them.
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from .timeutil import TimeError, parse_timestamp


class TranscriptError(RuntimeError):
    pass


class TranscriptCancelled(TranscriptError):
    """The user cancelled while a local transcription was running."""


@dataclass
class Word:
    text: str
    start: float
    end: float


@dataclass
class Segment:
    start: float
    end: float
    text: str
    words: list[Word] | None = None   # None => only sentence-level timing is known

    def to_dict(self) -> dict:
        d = {"start": round(self.start, 3), "end": round(self.end, 3), "text": self.text}
        if self.words:
            d["words"] = [{"text": w.text, "start": round(w.start, 3), "end": round(w.end, 3)} for w in self.words]
        return d


@dataclass
class Transcript:
    segments: list[Segment] = field(default_factory=list)
    source: str = "none"            # "subtitle-file" | "faster-whisper" | "platform-subtitles" | "none"
    language: str | None = None

    @property
    def word_level(self) -> bool:
        return bool(self.segments) and all(s.words for s in self.segments)

    @property
    def available(self) -> bool:
        return bool(self.segments)

    def to_dict(self) -> dict:
        return {"source": self.source, "language": self.language, "word_level": self.word_level,
                "segments": [s.to_dict() for s in self.segments]}

    @classmethod
    def from_dict(cls, data: dict) -> "Transcript":
        segs = []
        for s in data.get("segments", []):
            words = [Word(w["text"], float(w["start"]), float(w["end"])) for w in s.get("words", [])] or None
            segs.append(Segment(float(s["start"]), float(s["end"]), s["text"], words))
        return cls(segs, data.get("source", "none"), data.get("language"))


_TAGS = re.compile(r"<[^>]+>|\{\\[^}]*\}")


def _clean(text: str) -> str:
    text = _TAGS.sub("", text).replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
    return re.sub(r"\s+", " ", text).strip()


_CUE_TIME = re.compile(r"(\d{1,2}:\d{2}(?::\d{2})?[.,]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}(?::\d{2})?[.,]\d{1,3})")


def parse_subtitles(text: str) -> list[Segment]:
    """Parse SRT or WebVTT text into sentence-level segments (no word timings)."""
    text = text.replace("\r\n", "\n").replace("\r", "\n").lstrip("﻿")
    segments: list[Segment] = []
    for block in re.split(r"\n\s*\n", text):
        lines = [l for l in block.split("\n") if l.strip()]
        for i, line in enumerate(lines):
            m = _CUE_TIME.search(line)
            if m:
                try:
                    start, end = parse_timestamp(m.group(1)), parse_timestamp(m.group(2))
                except TimeError:
                    break
                body = _clean(" ".join(lines[i + 1:]))
                if body and end > start:
                    segments.append(Segment(start, end, body))
                break
    # Auto-generated VTT repeats the previous line in each cue; drop exact consecutive duplicates.
    deduped: list[Segment] = []
    for seg in segments:
        if deduped and seg.text == deduped[-1].text:
            deduped[-1].end = max(deduped[-1].end, seg.end)
        else:
            deduped.append(seg)
    return deduped


def parse_json_transcript(text: str) -> list[Segment]:
    """Whisper-style JSON: {"segments":[{"start","end","text","words":[{"word"|"text","start","end"}]}]}."""
    try:
        data = json.loads(text)
    except json.JSONDecodeError as error:
        raise TranscriptError("The transcript JSON could not be parsed.") from error
    items = data.get("segments") if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise TranscriptError("The transcript JSON must contain a 'segments' list.")
    segments = []
    for item in items:
        try:
            start, end = float(item["start"]), float(item["end"])
            words = [Word(str(w.get("word", w.get("text", ""))).strip(), float(w["start"]), float(w["end"]))
                     for w in item.get("words", []) if str(w.get("word", w.get("text", ""))).strip()] or None
            body = _clean(str(item.get("text") or " ".join(w.text for w in (words or []))))
        except (KeyError, TypeError, ValueError) as error:
            raise TranscriptError("A transcript segment is missing start/end/text.") from error
        if body and end > start:
            segments.append(Segment(start, end, body, words))
    return segments


def load_transcript_file(path: Path, source: str = "subtitle-file") -> Transcript:
    path = Path(path)
    if not path.is_file():
        raise TranscriptError("The transcript file does not exist.")
    raw = path.read_text(encoding="utf-8-sig", errors="replace")
    if path.suffix.lower() == ".json":
        segments = parse_json_transcript(raw)
    elif path.suffix.lower() in {".srt", ".vtt"}:
        segments = parse_subtitles(raw)
    else:
        raise TranscriptError("Transcripts must be .srt, .vtt or .json files.")
    if not segments:
        raise TranscriptError("No timed text was found in the transcript file.")
    segments.sort(key=lambda s: s.start)
    return Transcript(segments, source)


# ----------------------------------------------------------------------------- engines
class TranscriptionEngine:
    name = "base"

    def available(self) -> tuple[bool, str]:
        return False, "not implemented"

    def status(self) -> dict:
        ok, detail = self.available()
        return {"id": self.name, "available": ok, "detail": detail, "word_timestamps": True, "cost": "free (runs locally)"}

    def transcribe(self, media_path: Path, language: str | None = None, progress=None, cancelled=None,
                   duration: float | None = None) -> Transcript:  # pragma: no cover - interface
        raise NotImplementedError


class FasterWhisperEngine(TranscriptionEngine):
    """Local, free transcription with word timestamps (needs ``pip install faster-whisper``).

    Models are downloaded only through the explicit, user-confirmed download action (see whisper_local); transcribing
    never touches the network. ``notes`` collects run notes (device fallback, sentence-level warning) after ``transcribe``.
    """
    name = "faster-whisper"

    def __init__(self, model: str | None = None):
        from . import whisper_local
        self.model_name = (model or whisper_local.configured_model()).strip()
        self.notes: list[str] = []

    def available(self) -> tuple[bool, str]:
        from . import whisper_local
        return whisper_local.availability(self.model_name)

    def status(self) -> dict:
        from . import whisper_local
        st = whisper_local.status()
        return {"id": self.name, "word_timestamps": True, "cost": "free (runs locally)", **st, "available": st["ready"]}

    def transcribe(self, media_path: Path, language: str | None = None, progress=None, cancelled=None,
                   duration: float | None = None) -> Transcript:
        from . import whisper_local
        tr, self.notes = whisper_local.transcribe(media_path, language, self.model_name, progress=progress or (lambda p, m: None),
                                                  cancelled=cancelled or (lambda: False), duration_hint=duration)
        return tr


ENGINES: dict[str, type[TranscriptionEngine]] = {"faster-whisper": FasterWhisperEngine}


def get_engine(name: str) -> TranscriptionEngine:
    cls = ENGINES.get(name)
    if not cls:
        raise TranscriptError(f"Unknown transcription engine {name!r}.")
    return cls()


def engine_status() -> list[dict]:
    return [cls().status() for cls in ENGINES.values()]


def extract_audio(media_path: Path, out_path: Path, timeout: int = 900) -> Path:
    """16 kHz mono WAV for engines that want a pure-audio input."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise TranscriptError("FFmpeg not found.")
    r = subprocess.run([ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", str(media_path), "-vn", "-ac", "1", "-ar", "16000", str(out_path)],
                       capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0 or not out_path.is_file():
        raise TranscriptError("Audio extraction failed: " + (r.stderr or "")[-200:])
    return out_path
