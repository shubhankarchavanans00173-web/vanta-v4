"""Video-link handling with SSRF protection.

Two honest adapters:
  * direct media URLs (https://host/file.mp4) - always available, downloaded with httpx.
  * platform pages (YouTube, Vimeo, TikTok, Instagram, X) - only through yt-dlp running in VANTA's own Python environment
    (see ytdlp.py), and only when the operator enables it (VANTA_ENABLE_YTDLP=1). Best effort: private, login-gated, DRM or
    geo-blocked videos are reported, never bypassed. The local-file upload is always the dependable fallback.
Nothing here ever reports success unless a real, probe-able file was written and validated.
"""
from __future__ import annotations

import ipaddress
import os
import re
import shutil
import socket
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import urljoin, urlparse

import httpx

from . import media, settings, ytdlp
from .linkerrors import LinkError

MAX_URL_LENGTH = 2048
MAX_REDIRECTS = 3
PLATFORM_HOSTS = {
    "youtube": set(ytdlp.YOUTUBE_HOSTS),
    "vimeo": {"vimeo.com", "www.vimeo.com", "player.vimeo.com"},
    "tiktok": {"tiktok.com", "www.tiktok.com", "vm.tiktok.com", "m.tiktok.com"},
    "instagram": {"instagram.com", "www.instagram.com"},
    "x": {"x.com", "www.x.com", "twitter.com", "www.twitter.com", "mobile.twitter.com"},
}
OTHER_KNOWN = {"facebook.com", "www.facebook.com", "fb.watch", "netflix.com", "www.netflix.com", "primevideo.com", "www.primevideo.com",
               "disneyplus.com", "www.disneyplus.com", "hulu.com", "www.hulu.com", "twitch.tv", "www.twitch.tv", "spotify.com", "open.spotify.com"}
MEDIA_SUFFIXES = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mpg", ".mpeg", ".ts"}


@dataclass
class Fetched:
    path: Path
    subtitle_path: Path | None
    title: str
    platform: str
    method: str
    probe: dict | None = None
    video_id: str | None = None


def _emit(progress: Callable, fraction: float | None, message: str | None = None) -> None:
    """Call a progress callback that may accept (fraction) or (fraction, message)."""
    try:
        progress(fraction, message)
    except TypeError:
        progress(fraction)


def normalise_url(url: str) -> str:
    url = (url or "").strip()
    if not url or len(url) > MAX_URL_LENGTH:
        raise LinkError("invalid_url", "Enter a video link (up to 2048 characters).")
    if re.search(r"[\s\x00-\x1f]", url):
        raise LinkError("invalid_url", "The link contains spaces or control characters.")
    p = urlparse(url)
    if p.scheme not in {"http", "https"}:
        raise LinkError("invalid_url", "Only http:// and https:// links are supported (no file://, ftp:// or other schemes).")
    if not p.hostname:
        raise LinkError("invalid_url", "The link has no host name.")
    if p.username or p.password:
        raise LinkError("invalid_url", "Links containing a username or password are not accepted.")
    try:
        port = p.port
    except ValueError as error:
        raise LinkError("invalid_url", "The link has an invalid port.") from error
    if port not in {None, 80, 443}:
        raise LinkError("blocked_host", "Links with custom ports are not accepted.")
    return url


def classify(url: str) -> str:
    """'direct_media' | platform id | 'known_unsupported' | 'unknown_page'."""
    p = urlparse(url)
    host = (p.hostname or "").lower().rstrip(".")
    for name, hosts in PLATFORM_HOSTS.items():
        if host in hosts:
            return name
    if host in OTHER_KNOWN or host.endswith((".netflix.com", ".facebook.com")):
        return "known_unsupported"
    if Path(p.path).suffix.lower() in MEDIA_SUFFIXES:
        return "direct_media"
    return "unknown_page"


def canonical_ref(url: str) -> tuple[str, str | None]:
    """(reference stored on the project, video id). YouTube links collapse to one canonical watch URL so duplicates are detectable."""
    if urlparse(url).hostname and ytdlp.is_youtube_host(urlparse(url).hostname):
        ref = ytdlp.parse_youtube_url(url)
        return ref.canonical, ref.video_id
    return url, None


def assert_public_host(host: str, resolver: Callable = socket.getaddrinfo) -> None:
    """Resolve twice and require every address to be globally routable (blocks loopback, private, link-local, metadata IPs)."""
    try:
        first = {i[4][0] for i in resolver(host, None, type=socket.SOCK_STREAM)}
        second = {i[4][0] for i in resolver(host, None, type=socket.SOCK_STREAM)}
        if not first:
            raise LinkError("blocked_host", "The host did not resolve.")
        if first != second:
            raise LinkError("blocked_host", "The host changed its address during validation.")
        if any(not ipaddress.ip_address(a.split("%")[0]).is_global for a in first | second):
            raise LinkError("blocked_host", "That address points to a private or local network, which is not allowed.")
    except LinkError:
        raise
    except (OSError, ValueError) as error:
        raise LinkError("blocked_host", "The host could not be resolved to a public address.") from error


def support_info() -> dict:
    installed, on = ytdlp.installed(), ytdlp.enabled()
    version = ytdlp.version()
    return {
        "direct_media": {"available": True, "detail": "Direct https links to .mp4/.mov/.mkv/.webm files (max "
                                                   f"{settings.MAX_REMOTE_BYTES // 1024 ** 2} MiB, up to {MAX_REDIRECTS} redirects, public hosts only)."},
        "platforms": {"available": bool(installed and on), "enabled_by_operator": on, "yt_dlp_installed": installed,
                      "yt_dlp_version": version, "supported": sorted(PLATFORM_HOSTS),
                      "youtube_forms": ["youtube.com/watch?v=…", "youtu.be/…", "youtube.com/shorts/…", "youtube.com/embed/…"],
                      "detail": "Best effort via yt-dlp for public videos you have the right to use. Private, login-gated, DRM-protected or region-blocked videos cannot be fetched."
                      if installed and on else
                      "Disabled. Run enable_youtube_links.bat, or install yt-dlp and set VANTA_ENABLE_YTDLP=1 in .env to enable best-effort downloads of public platform videos."},
        "never_supported": ["DRM streaming services (Netflix, Prime Video, Disney+, ...)", "private or login-only videos", "playlists, channels, live streams"],
        "fallback": "Upload the video file directly (Create Shorts → Upload video). That always works.",
    }


# ------------------------------------------------------------------------ direct media
def fetch_direct(url: str, dest_dir: Path, progress: Callable = lambda p, m=None: None,
                 cancelled: Callable[[], bool] = lambda: False, resolver: Callable = socket.getaddrinfo,
                 transport: httpx.BaseTransport | None = None) -> Fetched:
    dest_dir.mkdir(parents=True, exist_ok=True)
    current = normalise_url(url)
    limit = settings.MAX_REMOTE_BYTES
    client_args = dict(timeout=httpx.Timeout(connect=15, read=60, write=30, pool=15), follow_redirects=False)
    if transport is not None:
        client_args["transport"] = transport
    target = dest_dir / "download.part"
    try:
        with httpx.Client(**client_args) as client:  # type: ignore[arg-type]
            for _ in range(MAX_REDIRECTS + 1):
                assert_public_host(urlparse(current).hostname or "", resolver)
                with client.stream("GET", current, headers={"User-Agent": "VANTAClippingStudio/1.0", "Accept": "video/*,*/*;q=0.5"}) as r:
                    if r.is_redirect:
                        loc = r.headers.get("location")
                        if not loc:
                            raise LinkError("download_failed", "The server redirected without a target.")
                        current = normalise_url(urljoin(current, loc))
                        continue
                    if r.status_code in (401, 403):
                        raise LinkError("login_required", f"The server refused access (HTTP {r.status_code}). Download the file yourself and upload it here.")
                    if r.status_code in (404, 410):
                        raise LinkError("unavailable", "The video was not found at that link (HTTP %d)." % r.status_code)
                    if r.status_code == 429:
                        raise LinkError("rate_limited", "The server is rate limiting requests. Try again later or upload the file.")
                    if r.status_code >= 400:
                        raise LinkError("download_failed", f"The server answered HTTP {r.status_code}.")
                    ctype = r.headers.get("content-type", "").split(";")[0].strip().lower()
                    if not (ctype.startswith("video/") or ctype in {"application/octet-stream", "binary/octet-stream"}):
                        raise LinkError("not_video", f"That link is a web page or other file type ({ctype or 'unknown'}), not a video file. Paste a direct video file link or upload the file.")
                    total = int(r.headers.get("content-length") or 0)
                    if total > limit:
                        raise LinkError("too_large", f"The remote file is {total / 1024 ** 2:.0f} MiB; the limit is {limit / 1024 ** 2:.0f} MiB.")
                    written = 0
                    with target.open("wb") as fh:
                        for chunk in r.iter_bytes(1024 * 1024):
                            if cancelled():
                                raise LinkError("cancelled", "Download cancelled.")
                            written += len(chunk)
                            if written > limit:
                                raise LinkError("too_large", "The download exceeded the size limit and was stopped.")
                            fh.write(chunk)
                            _emit(progress, written / total if total else None, None)
                    if written == 0:
                        raise LinkError("download_failed", "The server returned an empty file.")
                    suffix = Path(urlparse(current).path).suffix.lower()
                    if suffix not in MEDIA_SUFFIXES:
                        suffix = {"video/mp4": ".mp4", "video/quicktime": ".mov", "video/webm": ".webm", "video/x-matroska": ".mkv"}.get(ctype, ".mp4")
                    final = dest_dir / f"source{suffix}"
                    target.replace(final)
                    return Fetched(final, None, Path(urlparse(current).path).stem or "Linked video", "direct_media", "http")
            raise LinkError("download_failed", f"Too many redirects (limit {MAX_REDIRECTS}).")
    except LinkError:
        target.unlink(missing_ok=True)
        raise
    except httpx.TimeoutException as error:
        target.unlink(missing_ok=True)
        raise LinkError("timeout", "The server took too long to respond.", retryable=True, hint="Retry, or download the file yourself and upload it.") from error
    except httpx.HTTPError as error:
        target.unlink(missing_ok=True)
        raise LinkError("network_error", f"The download failed ({type(error).__name__}).", retryable=True, hint="Check your connection and Retry, or upload the file.") from error


# ------------------------------------------------------------------------ yt-dlp adapter (delegates to ytdlp.py)
def ytdlp_version() -> str | None:
    return ytdlp.version()


def classify_ytdlp_error(stderr: str) -> LinkError:
    """Backwards-compatible alias. Only ``ERROR:`` lines decide; warnings (e.g. the Python 3.10 deprecation notice) never do."""
    return ytdlp.classify_error(stderr)


def fetch_platform(url: str, dest_dir: Path, progress: Callable = lambda p, m=None: None, cancelled: Callable[[], bool] = lambda: False,
                   timeout: float | None = None) -> Fetched:
    """Download a platform video with yt-dlp into a staging folder, validate it with ffprobe, and only then move it into place."""
    platform = classify(url)
    if platform not in PLATFORM_HOSTS:
        raise LinkError("unsupported_platform", "That site is not supported for link downloads. Upload the video file instead.")
    if not ytdlp.enabled():
        raise LinkError("adapter_disabled", "Platform downloads are switched off. Set VANTA_ENABLE_YTDLP=1 in .env (needs yt-dlp) and restart, or upload the file.",
                        hint="Run enable_youtube_links.bat, or upload the video file.")
    video_id = None
    target = url
    if platform == "youtube":
        ref = ytdlp.parse_youtube_url(url)
        target, video_id = ref.canonical, ref.video_id
    dest_dir.mkdir(parents=True, exist_ok=True)
    staging = dest_dir / f".dl-{uuid.uuid4().hex[:8]}"
    try:
        result = ytdlp.download(target, staging, progress=lambda p, m: _emit(progress, p, m), cancelled=cancelled, timeout=timeout)
        try:
            info = media.probe(result.path)
        except media.MediaError as error:
            raise LinkError("invalid_media", f"The download finished but the file is not playable video ({error}). It was discarded.", retryable=True,
                            hint="Retry, or upload the video file.") from error
        if info["duration"] > settings.MAX_DURATION_SECONDS:
            raise LinkError("too_long", f"The video is {info['duration'] / 60:.0f} minutes long; the configured limit is {settings.MAX_DURATION_SECONDS / 60:.0f} minutes. It was discarded.",
                            hint="Raise VANTA_MAX_DURATION_SECONDS in .env or use a shorter video.")
        for old in dest_dir.glob("source.*"):
            old.unlink(missing_ok=True)
        final = dest_dir / f"source{result.path.suffix.lower()}"
        os.replace(result.path, final)
        sub = None
        if result.subtitle:
            sub = dest_dir / "source.en.vtt"
            os.replace(result.subtitle, sub)
        return Fetched(final, sub, result.title or (f"YouTube {video_id}" if video_id else "Linked video"), platform, "yt-dlp", info, video_id)
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def fetch(url: str, dest_dir: Path, progress: Callable = lambda p, m=None: None, cancelled: Callable[[], bool] = lambda: False,
          resolver: Callable = socket.getaddrinfo) -> Fetched:
    url = normalise_url(url)
    kind = classify(url)
    if kind == "known_unsupported":
        raise LinkError("unsupported_platform", "That service uses DRM or login-only video and is not supported. Upload a file you are authorised to use.")
    if kind in PLATFORM_HOSTS:
        return fetch_platform(url, dest_dir, progress, cancelled)
    # unknown pages may still be direct media without an extension; fetch_direct verifies the content type and rejects HTML pages.
    return fetch_direct(url, dest_dir, progress, cancelled, resolver)
