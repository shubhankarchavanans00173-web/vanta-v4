"""Caption template routes."""
from __future__ import annotations


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .. import db
from ..captions import CaptionStyle

router = APIRouter()


# ----------------------------------------------------------------------------- templates
class TemplateRequest(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    style: dict = Field(default_factory=dict)


@router.get("/templates")
def templates():
    return db.list_templates()


@router.post("/templates")
def create_template(req: TemplateRequest):
    style = CaptionStyle.from_dict(req.style).to_dict()
    return db.save_template(req.name.strip(), style)


@router.delete("/templates/{tid}")
def remove_template(tid: str):
    if not db.delete_template(tid):
        raise HTTPException(404, "Template not found or built in.")
    return {"deleted": True}
