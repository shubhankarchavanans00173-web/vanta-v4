"""Optional paid cloud AI routes (off by default, confirmation required)."""
from __future__ import annotations


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import cost, db
from ..transcript import engine_status
from .common import _project

router = APIRouter()


# ----------------------------------------------------------------------------- optional paid cloud AI
class AIConfirm(BaseModel):
    estimate_id: str | None = None
    confirm: bool = False


def _ai_items(pid: str) -> list[dict]:
    return [{"id": c["id"], "start": c["start"], "end": c["end"], "excerpt": c["excerpt"] or ""} for c in db.list_candidates(pid)
            if c["status"] in {"suggested", "approved"} and c["excerpt"]]


@router.get("/ai/providers")
def ai_providers():
    return {"cloud": cost.provider_status(), "local": engine_status(),
            "note": "Local ranking and local transcription are free and always used. Cloud AI is optional, off by default and asks before every request."}


@router.post("/projects/{pid}/ai/estimate")
def ai_estimate(pid: str):
    _project(pid)
    items = _ai_items(pid)
    if not items:
        raise HTTPException(409, "There are no transcript-based suggestions to rate. Add a transcript and analyse first.")
    try:
        return cost.estimate(sum(len(i["excerpt"][:900]) for i in items))
    except cost.PaidAIError as error:
        raise HTTPException(error.status, {"code": error.code, "message": str(error)})


@router.post("/projects/{pid}/ai/rank")
def ai_rank(pid: str, req: AIConfirm):
    p = _project(pid)
    try:
        est = cost.authorize(req.estimate_id, req.confirm)
        items = _ai_items(pid)
        if not items:
            raise HTTPException(409, "There are no transcript-based suggestions to rate.")
        res = cost.rank_with_claude(items, est)
    except cost.PaidAIError as error:
        raise HTTPException(error.status, {"code": error.code, "message": str(error)})
    for cid, r in res["ratings"].items():
        c = db.get_candidate(cid)
        if not c or c["project_id"] != pid:
            continue
        blended = round(0.6 * (c["score"] or r["score"]) + 0.4 * r["score"], 1)
        reasons = [x for x in c["reasons"] if not x.startswith("AI rating")] + [f"AI rating ({res['model']}): {r['score']}/100 - {r['reason']}"]
        db.update_candidate(cid, score=blended, reasons=reasons)
    usage = {"provider": res["provider"], "model": res["model"], **res["usage"], "estimate": {k: est[k] for k in ("est_input_tokens", "est_cost_usd")}}
    log = (p["settings"] or {}).get("ai_usage", []) + [usage]
    db.update_project(pid, settings={**(p["settings"] or {}), "ai_usage": log})
    return {"applied": len(res["ratings"]), "usage": usage, "candidates": db.list_candidates(pid)}
