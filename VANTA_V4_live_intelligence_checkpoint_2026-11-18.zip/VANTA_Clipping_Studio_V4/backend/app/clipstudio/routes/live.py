"""Control surface for local live intelligence sessions.

A session is the operator's own media in, a read-only chat adapter, and review-only clips out. Starting one runs a
local FFmpeg segment ingest on the source the operator named; nothing is downloaded from a platform watch page, no
credential is accepted by an endpoint, and no endpoint publishes.
"""
from __future__ import annotations

import threading
import uuid
from pathlib import Path
from urllib.parse import urlparse

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from .. import links, settings
from ..live import clip_store, stream_source
from ..live.chat_factory import build_chat
from ..live.chat_sources import NullChatSource
from ..live.handoff import HandoffError
from ..live.live_clip_worker import LiveClipWorker
from ..live.review_pipeline import LiveReviewPipeline, clips_dir
from ..live.segment_ingest import IngestError, resolve_source
from ..live.session_runner import LiveRunConfig, LiveSessionRunner
from ..live.stream_manager import manager
from ..transcript import TranscriptError, load_transcript_file
from ..ytdlp import parse_youtube_url
from .common import _save_upload

router = APIRouter()


class LiveSessionRequest(BaseModel):
    platform: str = Field(pattern="^(youtube|twitch|manual)$")
    stream_ref: str = Field("", max_length=300)          # optional when the source link already names the stream
    source: str = Field("", max_length=2048)
    buffer_seconds: int = Field(90, ge=15, le=600)
    post_event_seconds: int = Field(8, ge=0, le=30)
    authorized: bool = False


# ----------------------------------------------------------------------------- running sessions
_LIVE_LOCK = threading.RLock()
_RUNNERS: dict[str, LiveSessionRunner] = {}
_CHAT_PROBLEMS: dict[str, str] = {}
_DISPLAY_SOURCES: dict[str, str] = {}          # what the operator typed; resolved URLs are signed and stay server-side
_pipeline: LiveReviewPipeline | None = None


def _review_pipeline() -> LiveReviewPipeline:
    """One pipeline for the process: events are routed by session id, so sessions can share it."""
    global _pipeline
    with _LIVE_LOCK:
        if _pipeline is None:
            _pipeline = LiveReviewPipeline(manager, LiveClipWorker(clips_dir(settings.BASE)), before_seconds=30.0)
            manager.on_event = _pipeline.on_event
        return _pipeline


def _session_source(req: LiveSessionRequest) -> tuple[str, str, str | None]:
    """Return ``(what the operator typed, video input, optional audio input)`` for the session.

    A local file or direct HLS/RTSP/RTMP URL is used as given. A platform watch page is resolved with the local yt-dlp
    (only when the operator enabled it); the signed URLs it returns never leave the server.
    """
    text = (req.source or "").strip()
    if not text:
        raise HTTPException(400, {"code": "source_required",
                                  "message": "A live session needs the authorised media source it should read.",
                                  "hint": "Paste a YouTube/Twitch live link, the stream's direct HLS/RTSP/RTMP URL, or "
                                          "the path of a local capture file you own."})
    host = (urlparse(text).hostname or "").lower()
    if host and (host in links.OTHER_KNOWN or any(host in hosts for hosts in links.PLATFORM_HOSTS.values())):
        try:
            video, audio = stream_source.resolve(text)
        except stream_source.ResolveError as error:
            raise HTTPException(400, {"code": error.code, "message": str(error), "hint": error.hint})
        return text, video, audio
    try:
        resolve_source(text)
    except IngestError as error:
        raise HTTPException(400, {"code": "bad_source", "message": str(error),
                                  "hint": "The source must be a readable local file or an http(s)/rtsp/rtmp(s) URL."})
    return text, text, None


def _stream_ref(req: LiveSessionRequest) -> str:
    """The chat reference: what the operator gave, else the video id / channel named by the link."""
    ref = (req.stream_ref or "").strip()
    if ref:
        return ref
    text = (req.source or "").strip()
    try:
        return parse_youtube_url(text).video_id
    except Exception:                                # not a YouTube link: fall back to the first path segment
        parts = [part for part in urlparse(text).path.split("/") if part]
        return parts[0] if parts else "live"


def _chat_source(req: LiveSessionRequest, runner: LiveSessionRunner):
    """Build chat, but never let a missing credential or a platform error stop the media ingest."""
    clock = runner.clock.now
    on_message = lambda message: manager.add_chat(runner.session.id, message)
    if req.platform == "manual":
        return NullChatSource(on_message, clock=clock, reason="A manual session has no chat adapter.")
    try:
        if req.platform == "twitch":
            return build_chat("twitch", clock=clock, on_message=on_message, channel=_stream_ref(req))
        # Resolve the identifier from the submitted live URL when the optional
        # explicit ID field is blank. Passing req.stream_ref directly made URL-
        # only YouTube sessions fail to discover activeLiveChatId.
        return build_chat("youtube", clock=clock, on_message=on_message, video_id=_stream_ref(req))
    except Exception as error:                       # a chat failure is reported, not raised
        with _LIVE_LOCK:
            _CHAT_PROBLEMS[runner.session.id] = f"{type(error).__name__}: {error}"[:400]
        return NullChatSource(on_message, clock=clock,
                              reason="Chat is not configured; the stream is still being ingested.")


def _session_payload(session_id: str) -> dict:
    with _LIVE_LOCK:
        runner = _RUNNERS.get(session_id)
        problem = _CHAT_PROBLEMS.get(session_id)
        display = _DISPLAY_SOURCES.get(session_id)
        jobs = runner.pipeline.jobs(session_id) if runner is not None else []
    payload = manager.snapshot(session_id)
    ingest = runner.ingest.status() if runner is not None and runner.ingest else None
    if ingest is not None and display:
        ingest["source"] = display                 # a resolved URL is signed; never return it
    payload.update({"ingest": ingest,
                    "chat_source": runner.chat.status() if runner is not None and runner.chat else None,
                    "clips": jobs, "review_only": True, "published": False})
    if problem:
        payload["chat_problem"] = problem
    return payload


@router.get("/live/sessions")
def list_live_sessions():
    return [_session_payload(session.id) for session in manager.list()]


@router.post("/live/sessions")
def create_live_session(req: LiveSessionRequest):
    if not req.authorized:
        raise HTTPException(400, "Confirm that you are authorised to monitor this stream before creating a live session.")
    typed, video, audio = _session_source(req)
    base = clips_dir(settings.BASE)
    runner = LiveSessionRunner(manager, _review_pipeline(),
                               LiveRunConfig(platform=req.platform, stream_ref=_stream_ref(req), source=video,
                                             audio_source=audio, buffer_seconds=req.buffer_seconds,
                                             post_event_seconds=req.post_event_seconds, base_dir=base),
                               chat_factory=lambda live: _chat_source(req, live), base_dir=base)
    try:
        runner.start()
    except (IngestError, ValueError, RuntimeError) as error:
        if runner.session is not None:               # the session row exists even if the ingest refused the source
            manager.stop(runner.session.id)
        raise HTTPException(400, str(error))
    with _LIVE_LOCK:
        _RUNNERS[runner.session.id] = runner
        _DISPLAY_SOURCES[runner.session.id] = typed
    return {**_session_payload(runner.session.id),
            "note": "FFmpeg is reading your source into a bounded local buffer. Clips stay review-only; nothing is "
                    "published."}


@router.get("/live/sessions/{sid}")
def get_live_session(sid: str):
    if not manager.get(sid):
        raise HTTPException(404, "Live session not found.")
    return _session_payload(sid)


@router.post("/live/sessions/{sid}/stop")
def stop_live_session(sid: str):
    """Stop chat first, then the ingest, so no new event is scheduled while FFmpeg is shutting down."""
    with _LIVE_LOCK:
        runner = _RUNNERS.pop(sid, None)
    if runner is None:
        if not manager.get(sid):
            raise HTTPException(404, "Live session not found.")
        return manager.snapshot(manager.stop(sid).id)
    summary = runner.stop()
    return {**(summary.get("session") or manager.snapshot(sid)), "ingest": summary.get("ingest"),
            "chat_source": summary.get("chat"), "clips": summary.get("jobs") or []}


def stop_all() -> None:
    """Stop every ingest and chat source this process started (called on application shutdown)."""
    with _LIVE_LOCK:
        runners = list(_RUNNERS.values())
        _RUNNERS.clear()
    for runner in runners:
        try:
            runner.stop()
        except Exception:                            # shutdown must never fail because one session did
            pass


# ----------------------------------------------------------------------------- reviewed live clips
# These endpoints never accept a media path: clips are addressed by the id of the sidecar the live pipeline wrote,
# and the file is resolved server-side inside the clips folder. Promotion creates a normal project - it never
# publishes or uploads anything.
_STATUS = {"not_found": 404, "blocked": 409, "not_reviewed": 400, "too_large": 413, "failed": 500}


def _clips() -> Path:
    return clips_dir(settings.BASE)


def _handoff_error(error: HandoffError) -> HTTPException:
    return HTTPException(_STATUS.get(error.code, 400),
                         {"code": error.code, "message": str(error), "hint": error.hint})


@router.get("/live/clips")
def list_live_clips():
    jobs = clip_store.read_all(_clips())
    return {"clips": [clip_store.public(job) for job in jobs], "count": len(jobs), "review_only": True,
            "note": "Clips assembled by the live pipeline. Playback and promotion stay local; nothing is published."}


@router.get("/live/clips/{cid}/file")
def live_clip_file(cid: str):
    try:
        path = clip_store.clip_file(_clips(), cid, settings.VIDEO_EXTENSIONS)
    except HandoffError as error:
        raise _handoff_error(error)
    return FileResponse(path, media_type="video/mp4")


@router.post("/live/clips/{cid}/promote")
async def promote_live_clip_endpoint(cid: str, transcript: UploadFile | None = File(None), title: str = Form("")):
    """The reviewer's explicit action: turn this clip into a project. A transcript is optional when a local speech
    model is ready, and required otherwise (the error says so)."""
    parsed = None
    tmp: Path | None = None
    try:
        await run_in_threadpool(clip_store.read, _clips(), cid)   # gate: no upload is written unless this clip exists
        if transcript is not None and transcript.filename:
            tmp = settings.TMP_DIR / f"live-promote-{uuid.uuid4().hex[:6]}{Path(transcript.filename).suffix.lower()}"
            await _save_upload(transcript, tmp, settings.TRANSCRIPT_EXTENSIONS, settings.MAX_TRANSCRIPT_BYTES, "transcript")
            parsed = await run_in_threadpool(load_transcript_file, tmp)
        payload = await run_in_threadpool(clip_store.promote, _clips(), cid, reviewed=True,
                                          transcript=parsed, title=title)
    except TranscriptError as error:
        raise HTTPException(400, str(error))
    except HandoffError as error:
        raise _handoff_error(error)
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)
    return {**payload, "view": "create",
            "note": "The clip is now a normal project. Open it to review, edit and render; nothing was published."}
