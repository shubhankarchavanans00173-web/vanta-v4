"""Health, diagnostics, yt-dlp update and settings routes."""
from __future__ import annotations

import shutil

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .. import analysis, cost, envsettings, links, pipeline, settings, ytdlp
from ..selection import engine as sel_engine
from ..selection import llm_eval
from ..timeutil import MAX_CLIP_SECONDS, MIN_CLIP_SECONDS, TARGET_DURATIONS
from ..transcript import engine_status
from .common import VERSION, _ffmpeg_version

router = APIRouter()


# ----------------------------------------------------------------------------- health & settings
@router.get("/health")
def health():
    ffmpeg, ffprobe = shutil.which("ffmpeg"), shutil.which("ffprobe")
    link_status = links.support_info()
    return {
        "status": "ok" if ffmpeg and ffprobe else "degraded", "version": VERSION,
        "ffmpeg": _ffmpeg_version(), "ffprobe": bool(ffprobe),
        "yt_dlp": {"installed": link_status["platforms"]["yt_dlp_installed"], "version": link_status["platforms"]["yt_dlp_version"],
                   "enabled": link_status["platforms"]["enabled_by_operator"]},
        "transcription_engines": engine_status(), "links": link_status, "cloud_ai": cost.provider_status(),
        "subject_tracking": {"available": False, "detail": "No subject detector is bundled. Reframing uses a blurred background or centre crop."},
        "limits": {"max_upload_mib": settings.MAX_UPLOAD_BYTES // 1024 ** 2, "max_duration_minutes": settings.MAX_DURATION_SECONDS / 60,
                   "clip_seconds": [MIN_CLIP_SECONDS, MAX_CLIP_SECONDS], "target_durations": list(TARGET_DURATIONS)},
        "score_note": analysis.SCORE_DISCLAIMER,
        "clip_engine": {"name": sel_engine.ENGINE_NAME, "version": sel_engine.ENGINE_VERSION, "local_llm": llm_eval.status()},
        "live_intelligence": {"available": True, "platforms": ["youtube", "twitch"], "buffer_seconds": [15, 600],
                              "detail": "Requires an authorised backend adapter and live validation; it never bypasses platform access controls."},
    }


@router.get("/diagnostics")
def diagnostics(refresh: bool = False):
    """Versions, paths and readiness of everything a platform download depends on (no environment variables or secrets)."""
    if refresh:
        ytdlp.reset_caches()
    return {**ytdlp.diagnostics(), "app": {"version": VERSION}, "transcription_engines": engine_status()}


@router.post("/links/update-ytdlp")
def update_ytdlp():
    """Upgrade yt-dlp[default] in the Python environment that runs this backend (never a different/global Python)."""
    if pipeline.any_download_active():
        raise HTTPException(409, {"code": "busy", "message": "A download or analysis is running. Wait for it to finish (or cancel it), then update yt-dlp."})
    try:
        return ytdlp.update()
    except ytdlp.UpdateError as error:
        raise HTTPException(error.status, {"code": error.code, "message": str(error), "executable": __import__("sys").executable})


@router.get("/settings")
def get_settings():
    """Read-only runtime configuration (change it in .env and restart)."""
    return {"data_dir": str(settings.BASE), "limits": health()["limits"], "cloud_ai": cost.provider_status(),
            "links": links.support_info(), "editable": False, "fields_endpoint": "/api/vanta/settings/fields",
            "note": "This summary is read-only. Edit the whitelisted settings through /settings/fields (they apply after a restart); everything else is in .env, see .env.example."}


class SettingsFieldsRequest(BaseModel):
    values: dict = Field(default_factory=dict, description="KEY -> new value; null removes your override (the default applies again)")
    clear: list[str] = Field(default_factory=list, description="secret KEYs to remove")


@router.get("/settings/fields")
def get_settings_fields():
    """Editable settings with saved vs running values. Secrets are write-only: only 'is one set' is ever returned."""
    return envsettings.describe()


@router.put("/settings/fields")
def put_settings_fields(req: SettingsFieldsRequest):
    """Validate everything first; write nothing if any field is invalid. Changes apply after the backend restarts."""
    apply, errors = envsettings.validate(req.values, req.clear)
    if errors:
        raise HTTPException(422, {"message": "Some settings are not valid; nothing was saved.", "errors": errors})
    if not apply:
        return envsettings.describe() | {"saved": False}
    try:
        info = envsettings.save(apply)
    except OSError as e:
        raise HTTPException(500, f"Could not write the settings file: {type(e).__name__}. Is it open in another program or read-only?") from e
    return envsettings.describe() | {"saved": True, "keys": info["keys"], "backup": info["backup"],
                                     "message": "Saved. Restart the backend (stop_all.bat, then start_all.bat) for the changes to take effect."}
