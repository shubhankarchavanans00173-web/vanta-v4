"""Helpers shared by the VANTA route modules."""
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

from fastapi import HTTPException, UploadFile

from .. import db, pipeline, settings

VERSION = "4.0.0"


def _project(pid: str) -> dict:
    p = db.get_project(pid)
    if not p:
        raise HTTPException(404, "Project not found.")
    return p


def _candidate(cid: str) -> dict:
    c = db.get_candidate(cid)
    if not c:
        raise HTTPException(404, "Clip suggestion not found.")
    return c


def _safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]", "_", Path(name or "").name)[:100] or "file"


def _public_project(p: dict) -> dict:
    out = {k: v for k, v in p.items() if k not in {"source_path", "transcript_path", "signals_path"}}
    out["download_error"] = (p.get("settings") or {}).get("download_error")
    out["has_source"] = bool(p.get("source_path"))
    out["has_transcript"] = pipeline.transcript_available(p)
    return out


def _ffmpeg_version() -> str | None:
    exe = shutil.which("ffmpeg")
    if not exe:
        return None
    try:
        return subprocess.run([exe, "-version"], capture_output=True, text=True, timeout=10).stdout.splitlines()[0]
    except Exception:
        return None


async def _save_upload(file: UploadFile, dest: Path, allowed: set[str], max_bytes: int, label: str) -> int:
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in allowed:
        raise HTTPException(400, f"Unsupported {label} type {suffix or '(none)'}. Allowed: {', '.join(sorted(allowed))}.")
    written = 0
    try:
        with dest.open("wb") as fh:
            while chunk := await file.read(1024 * 1024):
                written += len(chunk)
                if written > max_bytes:
                    raise HTTPException(413, f"The {label} is larger than the {max_bytes // 1024 ** 2} MiB limit.")
                fh.write(chunk)
    except BaseException:
        dest.unlink(missing_ok=True)
        raise
    finally:
        await file.close()
    if written == 0:
        dest.unlink(missing_ok=True)
        raise HTTPException(400, f"The uploaded {label} is empty.")
    return written


def _export(eid: str) -> dict:
    e = db.get_export(eid)
    if not e:
        raise HTTPException(404, "Export not found.")
    return e


def _export_file(e: dict, key: str = "path") -> Path:
    path = Path(e.get(key) or "")
    if not e.get(key) or not path.is_file() or not settings.is_inside(path, settings.EXPORT_DIR):
        raise HTTPException(404, "That file is no longer on disk.")
    return path
