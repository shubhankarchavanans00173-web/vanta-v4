"""Exports, thumbnails and publish-details routes."""
from __future__ import annotations

import re
import shutil
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .. import db, metadata, pipeline, settings
from .common import _export, _export_file

router = APIRouter()


@router.get("/exports")
def exports():
    names = {p["id"]: p["name"] for p in db.list_projects()}
    out = []
    for e in db.list_exports():
        e["project_name"] = names.get(e["project_id"])
        e["file_exists"] = Path(e["path"]).is_file()
        out.append(e)
    return out


@router.get("/exports/{eid}/preview")
def export_preview(eid: str):
    return FileResponse(_export_file(_export(eid)), media_type="video/mp4")


@router.get("/exports/{eid}/download")
def export_download(eid: str):
    e = _export(eid)
    return FileResponse(_export_file(e), media_type="video/mp4", filename=e["filename"])


@router.get("/exports/{eid}/captions")
def export_captions(eid: str):
    e = _export(eid)
    return FileResponse(_export_file(e, "srt_path"), media_type="text/plain", filename=Path(e["srt_path"]).name)


@router.delete("/exports/{eid}")
def delete_export(eid: str):
    e = _export(eid)
    for key in ("path", "srt_path"):
        if e.get(key) and settings.is_inside(Path(e[key]), settings.EXPORT_DIR):
            Path(e[key]).unlink(missing_ok=True)
    if e.get("candidate_id"):
        c = db.get_candidate(e["candidate_id"])
        if c and c["status"] == "rendered":
            db.update_candidate(c["id"], status="approved")
    shutil.rmtree(_thumb_dir(eid), ignore_errors=True)
    db.delete_export(eid)
    return {"deleted": True}


# ----------------------------------------------------------------------------- thumbnails + publish details
THUMB_NAME = re.compile(r"^(t\d{1,2}|custom_\d{1,6})\.jpg$")


def _thumb_dir(eid: str) -> Path:
    return settings.EXPORT_DIR / "_thumbs" / re.sub(r"[^a-z0-9]", "", eid.lower())


def _thumb_urls(eid: str, items: list[dict]) -> list[dict]:
    return [{**i, "url": f"/api/vanta/exports/{eid}/thumbnails/{i['name']}"} for i in items]


@router.post("/exports/{eid}/thumbnails")
def make_thumbnails(eid: str, count: int = 5):
    """Read real frames back from the exported MP4 (the recommended one is the sharpest non-dark frame, not a click prediction)."""
    e = _export(eid)
    video = _export_file(e)
    try:
        items = metadata.make_candidates(video, _thumb_dir(eid), float(e.get("duration") or 0), count)
    except RuntimeError as error:
        raise HTTPException(500, str(error))
    db.merge_export_meta(eid, {"thumbnails": items, "thumbnail": None})   # regenerating replaces the frames, so an earlier choice no longer exists
    return {"candidates": _thumb_urls(eid, items), "selected": None,
            "note": "Frames come from the exported video. 'recommended' = sharpest non-dark frame (a technical measure only)."}


@router.get("/exports/{eid}/thumbnails")
def list_thumbnails(eid: str):
    e = _export(eid)
    meta = e["meta"] or {}
    items = [i for i in meta.get("thumbnails") or [] if (_thumb_dir(eid) / i["name"]).is_file()]
    return {"candidates": _thumb_urls(eid, items), "selected": meta.get("thumbnail")}


@router.get("/exports/{eid}/thumbnails/{name}")
def thumbnail_file(eid: str, name: str):
    _export(eid)
    path = _thumb_dir(eid) / name
    if not THUMB_NAME.match(name) or not path.is_file() or not settings.is_inside(path, settings.EXPORT_DIR):
        raise HTTPException(404, "Thumbnail not found.")
    return FileResponse(path, media_type="image/jpeg")


class ThumbnailChoice(BaseModel):
    name: str | None = None
    time: float | None = Field(None, ge=0)


@router.put("/exports/{eid}/thumbnail")
def choose_thumbnail(eid: str, req: ThumbnailChoice):
    """Select one of the candidate frames by name, or grab a frame at an exact time (seconds into the export)."""
    e = _export(eid)
    if (req.name is None) == (req.time is None):
        raise HTTPException(400, "Send either a candidate name or a time in seconds.")
    if req.name is not None:
        if not THUMB_NAME.match(req.name) or not (_thumb_dir(eid) / req.name).is_file():
            raise HTTPException(404, "That thumbnail does not exist. Generate candidates first.")
        t = next((i["time"] for i in (e["meta"] or {}).get("thumbnails") or [] if i["name"] == req.name), None)
        choice = {"name": req.name, "time": t, "custom": req.name.startswith("custom_"), "chosen_by": "user"}
    else:
        dur = float(e.get("duration") or 0)
        if req.time > max(dur - 0.05, 0):
            raise HTTPException(400, f"The export is {dur:.1f} s long; choose a time inside it.")
        name = f"custom_{int(req.time * 1000)}.jpg"
        try:
            metadata.grab_frame(_export_file(e), req.time, _thumb_dir(eid) / name)
        except RuntimeError as error:
            raise HTTPException(500, str(error))
        choice = {"name": name, "time": round(req.time, 2), "custom": True, "chosen_by": "user"}
    db.merge_export_meta(eid, {"thumbnail": choice})
    return {"selected": choice, "url": f"/api/vanta/exports/{eid}/thumbnails/{choice['name']}"}


@router.get("/exports/{eid}/thumbnail")
def download_thumbnail(eid: str):
    e = _export(eid)
    ch = (e["meta"] or {}).get("thumbnail")
    if not ch:
        raise HTTPException(404, "No thumbnail has been chosen for this export yet.")
    path = _thumb_dir(eid) / ch["name"]
    if not path.is_file():
        raise HTTPException(404, "The chosen thumbnail file is gone; generate candidates again.")
    return FileResponse(path, media_type="image/jpeg", filename=Path(e["filename"]).stem + "_thumbnail.jpg")


def _export_transcript(e: dict):
    p = db.get_project(e["project_id"])
    return pipeline.load_project_transcript(p) if p else None


@router.post("/exports/{eid}/metadata/suggest")
def suggest_metadata(eid: str):
    """Suggestions built from the clip's real transcript text only. Nothing is saved until you PUT /metadata."""
    e = _export(eid)
    m = e["meta"] or {}
    return metadata.suggest(_export_transcript(e), float(m.get("start") or 0), float(m.get("end") or 0))


@router.get("/exports/{eid}/metadata")
def get_metadata(eid: str):
    e = _export(eid)
    return (e["meta"] or {}).get("publish") or {"title": "", "description": "", "hashtags": [], "provenance": {}}


class MetadataRequest(BaseModel):
    title: str = ""
    description: str = ""
    hashtags: list[str] | str = Field(default_factory=list)


@router.put("/exports/{eid}/metadata")
def put_metadata(eid: str, req: MetadataRequest):
    e = _export(eid)
    try:
        clean = metadata.validate(req.title, req.description, req.hashtags)
    except ValueError as error:
        raise HTTPException(400, str(error))
    m = e["meta"] or {}
    sug = metadata.suggest(_export_transcript(e), float(m.get("start") or 0), float(m.get("end") or 0))
    prov = {}
    for k in ("title", "description", "hashtags"):
        prov[k] = "empty" if not clean[k] else "transcript" if sug["available"] and clean[k] == sug[k] else "user"
    saved = {**clean, "provenance": prov, "updated_at": db.now()}
    db.merge_export_meta(eid, {"publish": saved})
    return saved
