"""YouTube connection and explicit-upload routes."""
from __future__ import annotations


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .. import youtube_upload
from .common import _export, _export_file

router = APIRouter()


# ----------------------------------------------------------------------------- YouTube review and explicit upload
class YouTubeUploadRequest(BaseModel):
    title: str = Field(default="", max_length=100)
    description: str | None = Field(default=None, max_length=5000)
    tags: list[str] = Field(default_factory=list, max_length=30)
    privacy: str = Field(default="private", max_length=10)
    made_for_kids: bool = False
    ai_disclosure: bool = True
    set_thumbnail: bool = True
    confirm: bool = False


@router.get("/youtube/status")
def youtube_status():
    return youtube_upload.status()


@router.post("/youtube/connect")
def youtube_connect():
    try:
        return youtube_upload.connect()
    except youtube_upload.UploadError as error:
        raise HTTPException(400, str(error)) from error


@router.post("/youtube/disconnect")
def youtube_disconnect():
    return youtube_upload.disconnect()


@router.get("/exports/{eid}/youtube")
def export_youtube_status(eid: str):
    export = _export(eid)
    return (export.get("meta") or {}).get("youtube_upload") or {
        "state": "not_started", "privacy": "private",
        "note": "Nothing has been uploaded. A separate explicit confirmation is required for every upload.",
    }


@router.post("/exports/{eid}/youtube/upload")
def upload_export_to_youtube(eid: str, req: YouTubeUploadRequest):
    if not req.confirm:
        raise HTTPException(428, "Review the export and tick the explicit confirmation before uploading. Nothing was sent to YouTube.")
    if req.privacy not in {"private", "unlisted", "public"}:
        raise HTTPException(400, "Privacy must be private, unlisted, or public.")
    export = _export(eid)
    _export_file(export)  # do not queue a request for an export no longer on disk
    state = youtube_upload.status()
    if not state.get("connected"):
        raise HTTPException(409, "Connect YouTube with the local OAuth flow before uploading. No video was sent.")
    try:
        return youtube_upload.submit(eid, req.model_dump())
    except youtube_upload.UploadError as error:
        raise HTTPException(409, str(error)) from error
