"""Local transcription (model download, cache) routes."""
from __future__ import annotations


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import settings
from .. import whisper_local

router = APIRouter()


# ----------------------------------------------------------------------------- local transcription
@router.get("/transcription/status")
def transcription_status():
    return whisper_local.status()


class ModelDownloadRequest(BaseModel):
    model: str
    confirm: bool = False


@router.post("/transcription/models/download")
def download_model(req: ModelDownloadRequest):
    """Starts a model download. Refused unless the user explicitly confirmed it (the UI shows the approximate size first)."""
    if req.model not in whisper_local.MODEL_INFO:
        raise HTTPException(400, f"Unknown model {req.model!r}.")
    if not req.confirm:
        raise HTTPException(400, f"Confirmation required: the '{req.model}' model is about {whisper_local.MODEL_INFO[req.model]} MB and is downloaded from Hugging Face. Send confirm=true to approve.")
    try:
        return whisper_local.DOWNLOADER.start(req.model)
    except whisper_local.DownloadError as error:
        raise HTTPException(409 if error.code in {"busy", "already_downloaded"} else 400, str(error))


@router.post("/transcription/models/download/cancel")
def cancel_model_download():
    try:
        return whisper_local.DOWNLOADER.cancel()
    except whisper_local.DownloadError as error:
        raise HTTPException(409, str(error))


@router.delete("/transcription/cache")
def clear_transcript_cache():
    n = 0
    for f in settings.TRANSCRIPT_CACHE_DIR.glob("*.json"):
        f.unlink(missing_ok=True); n += 1
    return {"cleared": n}
