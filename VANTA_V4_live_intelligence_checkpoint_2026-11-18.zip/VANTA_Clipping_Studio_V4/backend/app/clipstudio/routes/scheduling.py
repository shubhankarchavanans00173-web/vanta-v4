"""Local scheduler routes."""
from __future__ import annotations

import sqlite3

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .. import db, pipeline, scheduler
from ..render import RenderError, RenderSettings
from .common import _candidate

router = APIRouter()


# ----------------------------------------------------------------------------- scheduler
class SchedulerConfigRequest(BaseModel):
    enabled: bool | None = None
    paused: bool | None = None
    timezone: str | None = None
    time_of_day: str | None = None
    videos_per_run: int | None = None
    retry_limit: int | None = None


class SchedulerTaskRequest(BaseModel):
    candidate_id: str = Field(min_length=6, max_length=64)
    settings: dict = Field(default_factory=dict)


@router.get("/scheduler")
def get_scheduler():
    return scheduler.status()


@router.put("/scheduler")
def put_scheduler(req: SchedulerConfigRequest):
    try:
        return scheduler.apply_config(req.model_dump(exclude_none=True))
    except scheduler.SchedulerError as error:
        raise HTTPException(409 if "lock" in str(error).lower() else 400, str(error)) from error


@router.get("/scheduler/tasks")
def scheduler_tasks():
    return db.list_scheduler_tasks()


@router.post("/scheduler/tasks")
def add_scheduler_task(req: SchedulerTaskRequest):
    candidate = _candidate(req.candidate_id)
    if candidate["status"] != "approved":
        raise HTTPException(409, "Approve this clip before putting it in the scheduler queue.")
    try:
        clean = RenderSettings.from_dict(req.settings).to_dict()
        pipeline.resolve_music(clean.get("music_id"))
    except RenderError as error:
        raise HTTPException(400, str(error)) from error
    try:
        task = db.create_scheduler_task(candidate["project_id"], candidate["id"], clean, db.get_scheduler_config()["retry_limit"])
    except sqlite3.IntegrityError as error:
        raise HTTPException(409, "This clip is already in the scheduler queue or has already been scheduled.") from error
    return task


@router.delete("/scheduler/tasks/{tid}")
def remove_scheduler_task(tid: str):
    task = db.get_scheduler_task(tid)
    if not task:
        raise HTTPException(404, "Scheduled task not found.")
    if task["status"] in {"ready", "dispatching"}:
        return db.cancel_scheduler_task(tid)
    if task["status"] == "running":
        try:
            pipeline.cancel_job(task["job_id"])
        except (db.StateError, TypeError) as error:
            raise HTTPException(409, str(error)) from error
        return {"cancel_requested": True, "task": db.get_scheduler_task(tid)}
    raise HTTPException(409, f"A {task['status']} scheduled task cannot be removed.")


@router.post("/scheduler/run-now")
def run_scheduler_now():
    try:
        tasks = scheduler.SERVICE.run_now()
    except scheduler.SchedulerError as error:
        raise HTTPException(409, str(error)) from error
    return {"dispatched": len(tasks), "tasks": tasks, "note": "Only explicitly queued, approved local clips are rendered. Nothing is uploaded."}
