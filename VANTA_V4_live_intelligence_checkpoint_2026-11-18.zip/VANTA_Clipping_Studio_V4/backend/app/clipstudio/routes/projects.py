"""Projects: upload, link, download, transcript and analyze routes."""
from __future__ import annotations

import mimetypes
import shutil
import uuid
from pathlib import Path
from urllib.parse import urlparse

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from .. import db, links, media, pipeline, settings
from .. import whisper_local
from ..transcript import TranscriptError, load_transcript_file
from .common import _project, _public_project, _safe_name, _save_upload

router = APIRouter()


# ----------------------------------------------------------------------------- projects
@router.get("/projects")
def list_projects():
    out = []
    for p in db.list_projects():
        item = _public_project(p)
        cands = db.list_candidates(p["id"])
        item["counts"] = {s: sum(1 for c in cands if c["status"] == s) for s in {c["status"] for c in cands}}
        item["exports"] = len(db.list_exports(p["id"]))
        out.append(item)
    return out


@router.post("/projects/upload")
async def upload_project(file: UploadFile = File(...), transcript: UploadFile | None = File(None), name: str = Form("")):
    pid = db.new_id()
    original = Path(file.filename or "video").name
    dest = settings.UPLOAD_DIR / f"{pid}_{_safe_name(original)}"
    await _save_upload(file, dest, settings.VIDEO_EXTENSIONS, settings.MAX_UPLOAD_BYTES, "video")
    try:
        info = await run_in_threadpool(media.validate_source, dest, settings.MAX_DURATION_SECONDS)
    except media.MediaError as error:
        dest.unlink(missing_ok=True)
        raise HTTPException(400, str(error))
    project = db.create_project(name.strip() or Path(original).stem, "upload", original, str(dest), info)
    if transcript is not None and transcript.filename:
        await _attach_transcript(project["id"], transcript)
    return _public_project(db.get_project(project["id"]))  # type: ignore[arg-type]


async def _attach_transcript(pid: str, file: UploadFile):
    tmp = settings.TMP_DIR / f"{pid}_{uuid.uuid4().hex[:6]}{Path(file.filename or '').suffix.lower()}"
    try:
        await _save_upload(file, tmp, settings.TRANSCRIPT_EXTENSIONS, settings.MAX_TRANSCRIPT_BYTES, "transcript")
        try:
            tr = await run_in_threadpool(load_transcript_file, tmp, "subtitle-file")
        except TranscriptError as error:
            raise HTTPException(400, str(error))
        pipeline.save_transcript(pid, tr)
        return tr
    finally:
        tmp.unlink(missing_ok=True)


class LinkRequest(BaseModel):
    url: str
    rights_confirmed: bool = False
    name: str = ""
    start_download: bool = True


@router.post("/projects/link")
def link_project(req: LinkRequest):
    if not req.rights_confirmed:
        raise HTTPException(428, "Confirm that you have the right to use this video before it is downloaded.")
    try:
        url = links.normalise_url(req.url)
        kind = links.classify(url)
        if kind == "known_unsupported":
            raise links.LinkError("unsupported_platform", "That service uses DRM or login-only video and is not supported. Upload a file you are authorised to use.")
        ref, video_id = links.canonical_ref(url)             # YouTube watch / youtu.be / Shorts / embed -> one canonical URL
        if kind in links.PLATFORM_HOSTS:
            info = links.support_info()["platforms"]
            if not info["available"]:
                raise links.LinkError("adapter_disabled", info["detail"] + " You can upload the video file instead.", hint="Open Video Links → Diagnostics to see what is missing.")
        else:
            links.assert_public_host(urlparse(url).hostname or "")
    except links.LinkError as error:
        raise HTTPException(400, error.to_dict())
    existing = db.find_link_project(ref)
    if existing:                                             # same video submitted twice: reuse the project (and its local copy)
        return {**_public_project(existing), "duplicate": True, "job": None}
    project = db.create_project(req.name.strip() or "Linked video", "link", ref, None, None, {"platform": kind, **({"video_id": video_id} if video_id else {})})
    job = None
    if req.start_download:
        try:
            job = pipeline.submit_download(project["id"])
        except pipeline.Busy:
            job = None
    return {**_public_project(db.get_project(project["id"])), "duplicate": False, "job": job}  # type: ignore[arg-type]


@router.post("/projects/{pid}/download")
def download_project(pid: str):
    """(Re)try the download of a linked project. A valid local copy is never downloaded again."""
    p = _project(pid)
    if p["source_type"] != "link":
        raise HTTPException(409, "This project was uploaded, so its video is already on disk. There is nothing to download.")
    if pipeline.project_busy(pid):
        raise HTTPException(409, "This project already has a job running.")
    info = pipeline.valid_source_info(p)
    if info:
        cfg = {k: v for k, v in (p.get("settings") or {}).items() if k != "download_error"}
        db.update_project(pid, status="awaiting_approval" if db.list_candidates(pid) else "new", error=None, settings=cfg)
        return {"already_downloaded": True, "job": None, "probe": info, "message": "A valid local copy of this video is already on disk, so it was not downloaded again."}
    try:
        return {"already_downloaded": False, "job": pipeline.submit_download(pid), "message": "Download started."}
    except pipeline.Busy as error:
        raise HTTPException(409, str(error))


@router.get("/projects/{pid}")
def get_project(pid: str):
    p = _project(pid)
    out = _public_project(p)
    out["candidates"] = db.list_candidates(pid)
    out["jobs"] = db.list_jobs(20, pid)
    out["exports"] = db.list_exports(pid)
    return out


@router.delete("/projects/{pid}")
def delete_project(pid: str, delete_exports: bool = False):
    p = _project(pid)
    if pipeline.project_busy(pid):
        raise HTTPException(409, "Cancel the running job before deleting this project.")
    exports = db.list_exports(pid)
    if exports and not delete_exports:
        raise HTTPException(409, f"This project has {len(exports)} export(s). Delete them first or confirm deleting them with the project.")
    for e in exports:
        for f in (e["path"], e.get("srt_path")):
            if f and settings.is_inside(Path(f), settings.EXPORT_DIR):
                Path(f).unlink(missing_ok=True)
    if delete_exports:
        shutil.rmtree(settings.EXPORT_DIR / pid, ignore_errors=True)
    if p["source_path"] and (settings.is_inside(Path(p["source_path"]), settings.UPLOAD_DIR) or settings.is_inside(Path(p["source_path"]), settings.SOURCE_DIR)):
        Path(p["source_path"]).unlink(missing_ok=True)
    shutil.rmtree(settings.SOURCE_DIR / pid, ignore_errors=True)
    whisper_local.cache_drop((p.get("transcript_meta") or {}).get("cache_key"))
    for extra in (p.get("transcript_path"), p.get("signals_path")):
        if extra and settings.is_inside(Path(extra), settings.TRANSCRIPT_DIR):
            Path(extra).unlink(missing_ok=True)
    db.delete_project(pid)
    return {"deleted": True}


@router.get("/projects/{pid}/source")
def project_source(pid: str):
    p = _project(pid)
    path = Path(p["source_path"] or "")
    if not p["source_path"] or not path.is_file() or not (settings.is_inside(path, settings.UPLOAD_DIR) or settings.is_inside(path, settings.SOURCE_DIR)):
        raise HTTPException(404, "The source video is not available.")
    return FileResponse(path, media_type=mimetypes.guess_type(path.name)[0] or "video/mp4")


@router.get("/projects/{pid}/transcript")
def project_transcript(pid: str):
    p = _project(pid)
    tr = pipeline.load_project_transcript(p)
    if tr is None:
        return {"available": False, "source": None, "word_level": False, "segments": [],
                "message": "No transcript. Upload an .srt/.vtt/.json transcript or install faster-whisper for local transcription."}
    return {"available": True, **tr.to_dict()}


@router.post("/projects/{pid}/transcript")
async def upload_transcript(pid: str, file: UploadFile = File(...)):
    _project(pid)
    if pipeline.project_busy(pid):
        raise HTTPException(409, "Wait for the running job to finish.")
    tr = await _attach_transcript(pid, file)
    return {"attached": True, "source": tr.source, "segments": len(tr.segments), "word_level": tr.word_level,
            "message": "Transcript attached. Run the analysis again to rank clips with it."}


class AnalyzeRequest(BaseModel):
    target_duration: int = Field(30, ge=10, le=180)
    count: int = Field(5, ge=1, le=20)
    transcribe: bool = True
    language: str | None = None
    engine: str = "faster-whisper"
    whisper_model: str | None = None   # one of whisper_local.MODEL_INFO; default comes from VANTA_WHISPER_MODEL
    # Auto mode ranks candidates, approves the top suggestions, and renders them without manual timestamp selection.
    auto_render: bool = False
    render_settings: dict = Field(default_factory=dict)
    # "auto" = multi-signal engine (falls back to the heuristic with a note if it fails); "baseline" = the original simple heuristic ranker.
    engine_mode: str = Field("auto", pattern="^(auto|baseline)$")
    local_llm: bool = True   # only has an effect when a local model is configured and reachable (see /llm-status)


@router.post("/projects/{pid}/analyze")
def analyze(pid: str, req: AnalyzeRequest = AnalyzeRequest()):
    _project(pid)
    try:
        return pipeline.submit_analyze(pid, req.model_dump())
    except pipeline.Busy as error:
        raise HTTPException(409, str(error))
