"""Clip-candidate suggestion.

Two clearly-labelled methods:
  * ``transcript-heuristic`` - sentence-aware windows scored from transcript text, pacing and pauses.
  * ``audio-visual-heuristic`` - fallback used only when no transcript exists (audio activity + scene changes).

Scores are 0-100 *heuristic* ranking scores. They are NOT a prediction of views or virality.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Protocol

from .timeutil import MAX_CLIP_SECONDS, MIN_CLIP_SECONDS
from .transcript import Transcript

SCORE_DISCLAIMER = "Heuristic ranking score (0-100). It orders suggestions; it is not a prediction of views or virality."
MAX_OVERLAP = 0.15  # max fraction of the shorter clip that may overlap an already-chosen clip

HOOK_OPENERS = re.compile(r"^(here'?s|here is|this is|the (?:secret|truth|biggest|best|worst|one|real)|stop|never|always|most people|nobody|everyone|"
                          r"imagine|what if|why|how|did you know|let me|you (?:need|should|won't|can't|have to)|i (?:never|can't|just|wish)|"
                          r"the problem|number one|first of all|listen)\b", re.I)
SURPRISE = re.compile(r"\b(actually|turns out|surpris\w+|unbelievable|shocking|insane|crazy|wrong|mistake|myth|secret|truth|"
                      r"nobody (?:tells|talks)|never (?:told|knew)|except|but here'?s|plot twist|wow)\b|!", re.I)
EXPLAIN = re.compile(r"\b(because|the reason|that'?s why|which means|so that|for example|for instance|step|first|second|third|"
                     r"how to|the key|the trick|rule|lesson|learn\w*|tip|important|basically|in other words)\b", re.I)
STORY = re.compile(r"\b(i remember|one day|when i|years? ago|back then|story|we were|she said|he said|then (?:i|we|he|she|they)|"
                   r"suddenly|that night|the first time)\b", re.I)
EMOTION = re.compile(r"\b(love|hate|afraid|scared|terrified|angry|amazing|incredible|heartbreak\w*|proud|cry|cried|laugh\w*|"
                     r"painful|grateful|hurt|dream|fear|excited|struggl\w*|passion\w*)\b", re.I)
DANGLING_START = re.compile(r"^(and|but|so|or|because|then|which|that|this|these|those|it|its|they|them|he|she|also|however|anyway|yeah|well)\b", re.I)
TERMINAL = re.compile(r"[.!?…][\"')\]]*$")
FILLER_ONLY = re.compile(r"^(um+|uh+|hmm+|okay|ok|yeah|right|so)[.,!? ]*$", re.I)

WEIGHTS = {"hook": 0.22, "contained": 0.14, "explain": 0.12, "surprise": 0.12, "qa": 0.10, "story": 0.08,
           "emotion": 0.08, "pacing": 0.08, "fit": 0.06}   # remaining 0.00 -> bonuses below, total capped at 100


@dataclass
class Unit:
    start: float
    end: float
    text: str

    @property
    def words(self) -> int:
        return len(self.text.split())


@dataclass
class Candidate:
    start: float
    end: float
    score: float
    method: str
    reasons: list[str] = field(default_factory=list)
    excerpt: str = ""
    features: dict = field(default_factory=dict)

    @property
    def duration(self) -> float:
        return round(self.end - self.start, 3)


class Ranker(Protocol):
    """Replaceable ranking strategy (local heuristic today; a cloud/semantic ranker can implement this)."""
    name: str

    def rank(self, duration: float, transcript: Transcript | None, silences: list[tuple[float, float]],
             scenes: list[tuple[float, float]], target: float, count: int, min_len: float, max_len: float) -> list[Candidate]: ...


# ------------------------------------------------------------------ sentence units
def build_units(transcript: Transcript, max_unit: float = 25.0, max_gap: float = 1.5) -> list[Unit]:
    units: list[Unit] = []
    for seg in transcript.segments:
        if seg.words:   # real word timings -> exact sentence boundaries
            cur: list = []
            for w in seg.words:
                if cur and w.start - cur[-1].end > max_gap:
                    units.append(Unit(cur[0].start, cur[-1].end, " ".join(x.text for x in cur))); cur = []
                cur.append(w)
                if TERMINAL.search(w.text):
                    units.append(Unit(cur[0].start, cur[-1].end, " ".join(x.text for x in cur))); cur = []
            if cur:
                units.append(Unit(cur[0].start, cur[-1].end, " ".join(x.text for x in cur)))
        else:
            units.append(Unit(seg.start, seg.end, seg.text))
    # merge unterminated fragments (typical of subtitle files) into whole sentences
    merged: list[Unit] = []
    for u in units:
        if merged and not TERMINAL.search(merged[-1].text) and u.start - merged[-1].end <= max_gap and u.end - merged[-1].start <= max_unit:
            merged[-1] = Unit(merged[-1].start, u.end, merged[-1].text + " " + u.text)
        else:
            merged.append(Unit(u.start, u.end, u.text))
    return [u for u in merged if u.text.strip()]


# ------------------------------------------------------------------ scoring
def _snip(text: str, n: int = 90) -> str:
    text = text.strip()
    return text if len(text) <= n else text[: n - 1].rsplit(" ", 1)[0] + "…"


def score_window(units: list[Unit], i: int, j: int, target: float, prev_end: float | None, scene_times: list[float]) -> tuple[float, list[str], dict]:
    win = units[i:j + 1]
    start, end = win[0].start, win[-1].end
    dur = max(0.1, end - start)
    text = " ".join(u.text for u in win)
    first, first2 = win[0].text, " ".join(u.text for u in win[:2])
    reasons: list[str] = []
    f: dict[str, float] = {}

    f["hook"] = 0.0
    if "?" in first:
        f["hook"] = 1.0; reasons.append(f"Opens with a question: “{_snip(first)}”")
    elif HOOK_OPENERS.search(first):
        f["hook"] = 0.9; reasons.append(f"Strong opening line: “{_snip(first)}”")
    elif re.search(r"\d", first2) and len(first.split()) <= 18:
        f["hook"] = 0.5; reasons.append("Opens with a concrete number or fact")
    elif SURPRISE.search(first):
        f["hook"] = 0.6; reasons.append("Opens with a surprising statement")

    qs = [k for k, u in enumerate(win) if u.text.rstrip().endswith("?")]
    f["qa"] = 1.0 if qs and qs[0] < len(win) - 1 else 0.0
    if f["qa"]:
        reasons.append("Contains a question followed by its answer")
    f["surprise"] = min(1.0, len(SURPRISE.findall(text)) / 2)
    if f["surprise"] >= 0.5:
        reasons.append("Contains a surprising or myth-busting statement")
    f["explain"] = min(1.0, len(EXPLAIN.findall(text)) / 3)
    if f["explain"] >= 0.5:
        reasons.append("Explains something useful (reasons, steps or tips)")
    f["story"] = min(1.0, len(STORY.findall(text)) / 2)
    if f["story"] >= 0.5:
        reasons.append("Tells a short story or anecdote")
    f["emotion"] = min(1.0, len(EMOTION.findall(text)) / 3)
    if f["emotion"] >= 0.5:
        reasons.append("Emotional language")

    contained = 1.0
    if DANGLING_START.search(first) and "?" not in first:
        contained -= 0.5; reasons.append("Penalty: starts mid-thought (refers to earlier context)")
    if not TERMINAL.search(win[-1].text):
        contained -= 0.3
    if FILLER_ONLY.match(first):
        contained -= 0.4
    f["contained"] = max(0.0, contained)
    if f["contained"] >= 0.99:
        reasons.append("Starts and ends on complete sentences, so it makes sense on its own")

    words = sum(u.words for u in win)
    wps = words / dur
    f["pacing"] = 1.0 if 1.8 <= wps <= 3.6 else max(0.0, 1 - min(abs(wps - 2.7) / 2.7, 1))
    f["fit"] = max(0.0, 1 - abs(dur - target) / max(target, 1))

    bonus = 0.0
    if prev_end is not None and start - prev_end >= 0.4:
        bonus += 0.03; reasons.append("Begins after a natural pause")
    if any(abs(t - start) <= 1.0 for t in scene_times):
        bonus += 0.02; reasons.append("Begins at a visual scene change")
    score = 100 * (sum(WEIGHTS[k] * f[k] for k in WEIGHTS) + bonus)
    f["words_per_second"] = round(wps, 2)
    return min(100.0, round(score, 1)), reasons, f


def _overlap(a: Candidate, b: Candidate) -> float:
    inter = max(0.0, min(a.end, b.end) - max(a.start, b.start))
    return inter / max(1e-6, min(a.end - a.start, b.end - b.start))


def select_non_overlapping(cands: list[Candidate], count: int, max_overlap: float = MAX_OVERLAP) -> list[Candidate]:
    chosen: list[Candidate] = []
    for c in sorted(cands, key=lambda c: (-c.score, c.start)):
        if all(_overlap(c, k) <= max_overlap for k in chosen):
            chosen.append(c)
        if len(chosen) >= count:
            break
    return chosen


# ------------------------------------------------------------------ transcript-based method
def _transcript_candidates(duration, transcript, silences, scenes, target, min_len, max_len) -> list[Candidate]:
    units = build_units(transcript)
    scene_times = [t for t, _ in scenes]
    out: list[Candidate] = []
    for i in range(len(units)):
        prev_end = units[i - 1].end if i else None
        for j in range(i, len(units)):
            span = units[j].end - units[i].start
            if span > max_len:
                break
            if span < min_len:
                continue
            score, reasons, feats = score_window(units, i, j, target, prev_end, scene_times)
            # snap padding without crossing neighbouring sentences
            lo = max(0.0, (units[i - 1].end + units[i].start) / 2 if i else units[i].start - 0.2)
            hi = min(duration, (units[j].end + units[j + 1].start) / 2 if j + 1 < len(units) else units[j].end + 0.3)
            start = max(lo, units[i].start - 0.2)
            end = min(hi, units[j].end + 0.3)
            if end - start > MAX_CLIP_SECONDS or end - start < MIN_CLIP_SECONDS:
                continue
            excerpt = " ".join(u.text for u in units[i:j + 1])
            out.append(Candidate(round(start, 3), round(end, 3), score, "transcript-heuristic", reasons, excerpt, feats))
    return out


# ------------------------------------------------------------------ audio/visual fallback
def _fallback_candidates(duration, silences, scenes, target, min_len, max_len) -> list[Candidate]:
    anchors = {0.0}
    anchors.update(e for _, e in silences if e < duration - min_len)
    anchors.update(t for t, _ in scenes if t < duration - min_len)
    step = max(5.0, target / 2)
    anchors.update(k * step for k in range(int(duration // step) + 1) if k * step < duration - min_len)
    silence_starts = sorted(s for s, _ in silences)
    out: list[Candidate] = []
    for a in sorted(anchors):
        end = min(duration, a + target)
        near = [s for s in silence_starts if abs(s - end) <= max(2.0, target * 0.2) and min_len <= s - a <= max_len]
        ends_on_silence = bool(near)
        if near:
            end = min(near, key=lambda s: abs(s - end))
        if end - a < min_len:
            continue
        quiet = sum(max(0.0, min(e, end) - max(s, a)) for s, e in silences)
        activity = 1 - min(1.0, quiet / (end - a))
        n_scenes = sum(1 for t, _ in scenes if a <= t <= end)
        variety = min(1.0, n_scenes / max(1.0, (end - a) / 10))
        at_anchor = any(abs(a - e) < 0.6 for _, e in silences) or any(abs(a - t) < 0.6 for t, _ in scenes)
        score = 100 * (0.5 * activity + 0.25 * variety + 0.12 * (1 if at_anchor else 0) + 0.13 * (1 if ends_on_silence else 0))
        reasons = ["No transcript available: ranked by audio activity and visual changes only (heuristic)",
                   f"{activity * 100:.0f}% of this window has audible sound"]
        if n_scenes:
            reasons.append(f"{n_scenes} visual scene change(s) inside the window")
        if at_anchor:
            reasons.append("Starts where sound resumes or the scene changes")
        if ends_on_silence:
            reasons.append("Ends on a natural pause")
        out.append(Candidate(round(a, 3), round(end, 3), round(min(score, 100), 1), "audio-visual-heuristic", reasons, "",
                             {"audio_activity": round(activity, 2), "scene_changes": n_scenes}))
    return out


class HeuristicRanker:
    name = "local-heuristic"

    def rank(self, duration, transcript, silences, scenes, target, count, min_len, max_len):
        if transcript is not None and transcript.available:
            cands = _transcript_candidates(duration, transcript, silences, scenes, target, min_len, max_len)
            if cands:
                return select_non_overlapping(cands, count)
        return select_non_overlapping(_fallback_candidates(duration, silences, scenes, target, min_len, max_len), count)


def length_bounds(target: float, duration: float) -> tuple[float, float]:
    lo = max(MIN_CLIP_SECONDS, target * 0.6)
    hi = min(MAX_CLIP_SECONDS, target * 1.25)
    return min(lo, duration), min(hi, duration)


def suggest_clips(duration: float, transcript: Transcript | None, silences=None, scenes=None, target: float = 30,
                  count: int = 5, ranker: Ranker | None = None) -> list[Candidate]:
    if duration < MIN_CLIP_SECONDS:
        return []
    lo, hi = length_bounds(float(target), duration)
    result = (ranker or HeuristicRanker()).rank(duration, transcript, list(silences or []), list(scenes or []), float(target), int(count), lo, hi)
    return sorted(result, key=lambda c: -c.score)
