"""yt-dlp output scrubbing and ERROR:-line classification (split from ytdlp.py; re-exported there)."""
from __future__ import annotations

import re
from pathlib import Path

from .linkerrors import LinkError

# ============================================================================ error classification
_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
_SECRET_QS = re.compile(r"(?i)([?&;](?:sig|signature|token|key|auth|cookie|session|pot|n)[a-z_]*=)[^&\s]+")


def scrub(line: str, limit: int = 300) -> str:
    """Make a downloader line safe to show: strip ANSI, signed-URL tokens and the home directory."""
    line = _ANSI.sub("", line).strip()
    line = _SECRET_QS.sub(r"\1…", line)
    try:
        line = line.replace(str(Path.home()), "~")
    except (RuntimeError, OSError):
        pass
    line = re.sub(r"\s+", " ", line)
    return line[:limit]


def split_output(text: str) -> tuple[list[str], list[str], list[str]]:
    """Return (error_lines, warning_lines, other_lines). Only error lines may decide the classification."""
    errors, warnings, other = [], [], []
    for raw in _ANSI.sub("", text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("ERROR:"):
            errors.append(line[6:].strip())
        elif line.startswith(("WARNING:", "Deprecated Feature:", "[debug]")):
            warnings.append(line)
        elif not line.startswith(("[download]", "[info]", "[youtube]", "[Merger]", "[ExtractAudio]", "VANTA_")):
            other.append(line)
    return errors, warnings, other


# (code, regex on lower-cased ERROR text, message, retryable, hint)  - first match wins
_RULES: list[tuple[str, str, str, bool, str | None]] = [
    ("disk_full", r"no space left|disk full|not enough space|errno 28", "The disk is full, so the video could not be written.", False,
     "Free some space on the drive that holds VANTA's data folder, then Retry."),
    ("permission_denied", r"permission denied|access is denied|errno 13|read-only file system", "VANTA is not allowed to write to its download folder.", False,
     "Check folder permissions or antivirus 'controlled folder access' for the data folder."),
    ("ffmpeg_missing", r"ffmpeg is not installed|ffmpeg not found|ffprobe and ffmpeg not found|ffmpeg.{0,30}(not found|not installed)|requires ffmpeg|merging of multiple formats but ffmpeg",
     "FFmpeg was not found, but it is required to merge separate video and audio streams.", False,
     "Install FFmpeg (winget install Gyan.FFmpeg), reopen the terminal, restart VANTA, then Retry."),
    ("bot_check", r"not a bot|captcha|unusual traffic|verify you are human|automated queries", "The platform asked for human verification (bot check) for this request. VANTA does not bypass it.", True,
     "Wait a while and Retry, try another network, or upload the video file you are authorised to use."),
    ("live_unavailable", r"live stream recording is not available|live event will begin|this live event|premieres in|premiere will begin|is a live stream|currently live|live stream.{0,40}(not|no longer)|this live stream",
     "This is a live stream, or a finished live stream whose recording is not available yet, so it cannot be downloaded right now.", True,
     "Retry after the stream has ended and YouTube has finished processing the recording, or upload a recording you have."),
    ("geo_blocked", r"not made this video available in your country|(un)?available in your (country|region)|blocked (it )?in your (country|region)|geo.?restrict|region.?(lock|block)|available only in",
     "This video is blocked in your country or region. VANTA does not bypass regional restrictions.", False, "Upload a copy you are authorised to use."),
    ("login_required", r"private video|sign in|log in|login required|members.only|join this channel|age.?restrict|confirm your age|inappropriate for some users|only available for (music )?premium|authentication required",
     "This video is private, members-only, or age/login-restricted. VANTA does not bypass access controls.", False, "Upload a copy of the video you are authorised to use."),
    ("drm", r"drm protected|has drm|widevine|drm.?protected", "This video is DRM-protected and cannot be downloaded.", False, "Upload a file you are authorised to use."),
    ("unavailable", r"video unavailable|this video is (not available|unavailable)|has been removed|removed by the uploader|no longer available|video.{0,20}(deleted|does not exist)|account associated with this video has been terminated|http error 404|http error 410",
     "The platform reports that this video is unavailable (deleted, removed, or the link is wrong).", False,
     "Open the link in your browser to confirm. If you own the video, upload the file instead."),
    ("unsupported_platform", r"unsupported url|not a valid url|no suitable extractor", "This link is not a supported single-video page.", False,
     "Paste a link to one video, or upload the file."),
    ("rate_limited", r"http error 429|too many requests|rate.?limit", "The platform is rate limiting requests (HTTP 429).", True, "Wait a few minutes and Retry, or upload the file."),
    ("server_error", r"http error 5\d\d|service unavailable|bad gateway|internal server error|gateway time-?out", "The platform returned a temporary server error.", True, "Retry in a minute."),
    ("access_denied", r"http error 403|forbidden", "The platform refused the request (HTTP 403). This can be temporary throttling, an expired link or a restriction; VANTA does not bypass restrictions.", True,
     "Retry. If it keeps happening, open Diagnostics and update yt-dlp, or upload the file."),
    ("timeout", r"timed out|timeout", "The platform did not answer in time.", True, "Check your connection and Retry."),
    ("network_error", r"unable to download (webpage|api page|json|video data)|transporterror|urlopen error|name or service not known|failed to resolve|getaddrinfo|temporary failure in name resolution|connection (refused|reset|aborted)|network is unreachable|no route to host|\bssl\b|certificate verify|proxy|remote end closed|incompleteread",
     "A network, DNS, proxy or TLS problem stopped the download.", True, "Check your internet connection (and any VPN/proxy/antivirus HTTPS scanning), then Retry."),
    ("too_large", r"larger than max-filesize|file is larger", "The video is larger than VANTA's download limit.", False, "Raise VANTA_MAX_REMOTE_BYTES in .env or upload a smaller copy."),
    ("format_unavailable", r"requested format is not available|no video formats found|only images are available|format.{0,30}not available",
     "YouTube returned no downloadable video format that matches VANTA's request.", True,
     "Open Diagnostics: this is often caused by a missing JavaScript runtime or an outdated yt-dlp. Fix that and Retry, or upload the file."),
    ("extraction_failed", r"unable to extract|out of date|outdated|sig function|nsig|n.?challenge|signature (extraction|solving)|player response|unable to (parse|download) (player|js)|please report this issue|confirm you are on the latest version|js(?:c)? runtime|javascript runtime|challenge solving|po.?token|precondition check failed|http error 400|unexpected error|extractor",
     "yt-dlp could not extract this video from the platform (extractor, player or JavaScript-challenge failure). This is a downloader problem; it does not prove the video is unavailable.", True,
     "Open Diagnostics: check that Node.js 20+ is detected and yt-dlp is current, use Update yt-dlp, then Retry. If it still fails, upload the file."),
]
_JS_CONTEXT = re.compile(r"js runtime|javascript runtime|n challenge|challenge solving|nsig|signature solving|no supported javascript|ejs", re.I)


def classify_error(stderr: str, stdout: str = "", returncode: int | None = None) -> LinkError:
    """Turn yt-dlp output into a precise LinkError. Only ``ERROR:`` lines decide; warnings are used as context only."""
    errors, warnings, other = split_output(stderr)
    _, out_warn, out_other = split_output(stdout)
    warnings += out_warn
    candidates = errors or [l for l in other + out_other if not l.startswith("Traceback")][-3:]
    text = " ".join(candidates).lower().replace("\u2019", "'")
    details = [scrub(l) for l in (candidates or [f"yt-dlp exit code {returncode}"])[-3:]]
    if not errors and re.search(r"larger than max-?filesize|file is larger than", _ANSI.sub("", stdout or "") + " " + _ANSI.sub("", stderr or ""), re.I):
        text = "larger than max-filesize"          # yt-dlp skips an oversize video with exit code 0 and says so on a [download] line
    for code, pattern, message, retryable, hint in _RULES:
        if re.search(pattern, text):
            if code == "format_unavailable" and _JS_CONTEXT.search(" ".join(warnings) + " " + text):
                code, message, retryable = "extraction_failed", "YouTube's JavaScript challenge could not be solved, so no formats were returned. This is a downloader/runtime problem, not proof the video is unavailable.", True
                hint = "Install Node.js 20+ (or Deno), restart VANTA, use Update yt-dlp (installs the solver scripts), then Retry. Diagnostics shows what VANTA detected."
            return LinkError(code, message, retryable=retryable, hint=hint, details=details)
    return LinkError("unknown_error", "The download failed for a reason VANTA could not identify.", retryable=True,
                     hint="See the diagnostic details below, run Diagnostics, or upload the video file instead.", details=details)
