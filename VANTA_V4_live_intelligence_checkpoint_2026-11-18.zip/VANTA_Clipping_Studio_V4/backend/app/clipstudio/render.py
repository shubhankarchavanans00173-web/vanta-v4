"""FFmpeg rendering of a single Short, with real progress and ffprobe validation of the result."""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Callable

from . import capfx
from .errors import CaptionError, RenderCancelled, RenderError
from .captions import CaptionStyle, KeepSegments, build_track, kept_duration, write_ass, write_srt
from .media import MediaError, probe
from .transcript import Transcript

ASPECTS = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080)}
MAX_SEGMENTS = 60


@dataclass
class RenderSettings:
    aspect: str = "9:16"
    fps: int = 30
    reframe: str = "blur"               # "blur" (blurred background + fitted video) | "center" (centre crop)
    captions: bool = True
    caption_style: dict = field(default_factory=dict)
    keep_original_audio: bool = True
    volume: float = 1.0
    music_path: str | None = None
    music_volume: float = 0.15
    ducking: bool = True
    remove_silence: bool = False
    silence_min_seconds: float = 0.7
    crf: int = 20
    preset: str = "veryfast"

    @classmethod
    def from_dict(cls, data: dict | None) -> "RenderSettings":
        s = cls()
        for k, v in (data or {}).items():
            if hasattr(s, k) and v is not None:
                setattr(s, k, v)
        if s.aspect not in ASPECTS:
            raise RenderError(f"Unsupported aspect ratio {s.aspect!r}. Use 9:16, 16:9 or 1:1.")
        if s.reframe not in {"blur", "center"}:
            raise RenderError("Reframe mode must be 'blur' or 'center'. (Subject tracking is not available in this build.)")
        s.fps = int(min(60, max(15, s.fps)))
        s.volume = float(min(3.0, max(0.0, s.volume)))
        s.music_volume = float(min(1.0, max(0.0, s.music_volume)))
        s.crf = int(min(35, max(14, s.crf)))
        s.silence_min_seconds = float(min(5.0, max(0.3, s.silence_min_seconds)))
        if s.preset not in {"ultrafast", "superfast", "veryfast", "faster", "fast", "medium"}:
            s.preset = "veryfast"
        return s

    def to_dict(self) -> dict:
        return asdict(self)


def safe_slug(text: str, limit: int = 40) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "-", text or "").strip("-").lower()[:limit].strip("-")
    return slug or "clip"


def compute_keep_segments(clip_start: float, clip_end: float, silences: list[tuple[float, float]],
                          min_silence: float = 0.7, pad: float = 0.15) -> KeepSegments:
    """Clip-relative ranges to keep after trimming silences >= ``min_silence``; each cut leaves ``pad`` s of air."""
    length = clip_end - clip_start
    cuts: list[tuple[float, float]] = []
    for s, e in silences:
        a, b = max(s, clip_start) - clip_start, min(e, clip_end) - clip_start
        if b - a >= min_silence and b - a > 2 * pad + 0.1:
            cuts.append((a + pad, b - pad))
    if not cuts:
        return [(0.0, length)]
    keep, cursor = [], 0.0
    for a, b in sorted(cuts):
        if a - cursor >= 0.1:
            keep.append((round(cursor, 3), round(a, 3)))
        cursor = max(cursor, b)
    if length - cursor >= 0.1:
        keep.append((round(cursor, 3), round(length, 3)))
    return keep or [(0.0, length)]


def build_command(ffmpeg: str, source: Path, out: Path, start: float, end: float, src_info: dict, s: RenderSettings,
                  ass_name: str | None, keep: KeepSegments | None, out_duration: float, fontsdir: str | None = None) -> list[str]:
    """Return the ffmpeg argument list (no shell). Pure function so it can be unit tested."""
    W, H = ASPECTS[s.aspect]
    has_audio = bool(src_info.get("has_audio"))
    use_src_audio = has_audio and s.keep_original_audio
    music = bool(s.music_path)
    cmd = [ffmpeg, "-y", "-hide_banner", "-nostdin", "-loglevel", "warning", "-progress", "pipe:1", "-nostats",
           "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}", "-i", str(source)]
    if music:
        cmd += ["-stream_loop", "-1", "-i", str(s.music_path)]
    f: list[str] = []
    seg = keep if keep and len(keep) > 1 else None
    if seg:
        for k, (a, b) in enumerate(seg):
            f.append(f"[0:v]trim=start={a:.3f}:end={b:.3f},setpts=PTS-STARTPTS[v{k}]")
            if use_src_audio:
                f.append(f"[0:a]atrim=start={a:.3f}:end={b:.3f},asetpts=PTS-STARTPTS[a{k}]")
        joined = "".join(f"[v{k}]" + (f"[a{k}]" if use_src_audio else "") for k in range(len(seg)))
        f.append(f"{joined}concat=n={len(seg)}:v=1:a={1 if use_src_audio else 0}[vsrc]" + ("[asrc]" if use_src_audio else ""))
        vin, ain = "[vsrc]", "[asrc]"
    else:
        vin, ain = "[0:v]", "[0:a]"

    same_ratio = abs((src_info["width"] / src_info["height"]) - (W / H)) < 0.02
    tail = f"fps={s.fps},setsar=1" + (("," + capfx.ass_filter(ass_name, fontsdir)) if ass_name else "") + ",format=yuv420p"
    if same_ratio:
        f.append(f"{vin}scale={W}:{H},{tail}[vout]")
    elif s.reframe == "center":
        f.append(f"{vin}scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},{tail}[vout]")
    else:
        f.append(f"{vin}split=2[bgs][fgs]")
        f.append(f"[bgs]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},scale={W // 8}:{H // 8},gblur=sigma=5,scale={W}:{H},eq=brightness=-0.08[bg]")
        f.append(f"[fgs]scale={W}:{H}:force_original_aspect_ratio=decrease[fg]")
        f.append(f"[bg][fg]overlay=(W-w)/2:(H-h)/2,{tail}[vout]")

    amap = None
    if use_src_audio and music:
        mv = f"{s.music_volume:.3f}"
        f.append(f"{ain}volume={s.volume:.3f}[a0]")
        f.append(f"[1:a]volume={mv}[m]")
        if s.ducking:
            f.append("[a0]asplit=2[a0m][a0s]")
            f.append("[m][a0s]sidechaincompress=threshold=0.03:ratio=10:attack=20:release=400[duck]")
            f.append("[a0m][duck]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]")
        else:
            f.append("[a0][m]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]")
        amap = "[aout]"
    elif use_src_audio:
        f.append(f"{ain}volume={s.volume:.3f}[aout]")
        amap = "[aout]"
    elif music:
        f.append(f"[1:a]volume={s.music_volume:.3f}[aout]")
        amap = "[aout]"

    cmd += ["-filter_complex", ";".join(f), "-map", "[vout]"]
    if amap:
        cmd += ["-map", amap, "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2"]
    else:
        cmd += ["-an"]
    cmd += ["-t", f"{out_duration:.3f}", "-r", str(s.fps), "-c:v", "libx264", "-preset", s.preset, "-crf", str(s.crf),
            "-profile:v", "high", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out)]
    return cmd


def _run_ffmpeg(cmd: list[str], cwd: Path, out_duration: float, progress: Callable[[float], None],
                cancelled: Callable[[], bool], timeout: float) -> None:
    err_path = cwd / "ffmpeg_stderr.txt"
    started = time.monotonic()
    with err_path.open("wb") as err, subprocess.Popen(cmd, cwd=str(cwd), stdout=subprocess.PIPE, stderr=err, text=True, bufsize=1) as proc:
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                if cancelled():
                    proc.kill()
                    raise RenderCancelled("Rendering was cancelled.")
                if time.monotonic() - started > timeout:
                    proc.kill()
                    raise RenderError(f"Rendering exceeded the {int(timeout)}s time limit and was stopped.")
                m = re.match(r"out_time_us=(\d+)", line.strip())
                if m and out_duration > 0:
                    progress(min(0.99, int(m.group(1)) / 1e6 / out_duration))
            proc.wait(timeout=30)
        except BaseException:
            proc.kill()
            raise
    if proc.returncode != 0:
        tail = err_path.read_text(errors="replace").strip().splitlines()[-4:]
        raise RenderError("FFmpeg failed: " + " | ".join(tail)[:600])


def validate_export(path: Path, expected_duration: float, aspect: str, expects_audio: bool, fps: int,
                    duration_tolerance: float = 0.6) -> dict:
    """Independent ffprobe check of the finished file. Returns a report; ``valid`` is False on any mismatch."""
    W, H = ASPECTS[aspect]
    problems: list[str] = []
    try:
        info = probe(path)
    except MediaError as error:
        return {"valid": False, "problems": [str(error)]}
    if info["video_codec"] != "h264":
        problems.append(f"video codec is {info['video_codec']}, expected h264")
    if (info["width"], info["height"]) != (W, H):
        problems.append(f"size is {info['width']}x{info['height']}, expected {W}x{H}")
    if abs(info["fps"] - fps) > 0.6:
        problems.append(f"frame rate is {info['fps']}, expected {fps}")
    if expects_audio and info["audio_codec"] != "aac":
        problems.append(f"audio is {info['audio_codec']}, expected aac")
    if not expects_audio and info["has_audio"]:
        problems.append("unexpected audio stream")
    if abs(info["duration"] - expected_duration) > duration_tolerance:
        problems.append(f"duration is {info['duration']:.2f}s, expected about {expected_duration:.2f}s")
    if info["size_bytes"] < 2048:
        problems.append("file is suspiciously small")
    return {"valid": not problems, "problems": problems, "probe": info}


def render_clip(source: Path, out_path: Path, tmp_dir: Path, start: float, end: float, src_info: dict, settings: RenderSettings,
                transcript: Transcript | None, silences: list[tuple[float, float]] | None = None,
                progress: Callable[[float], None] = lambda p: None, cancelled: Callable[[], bool] = lambda: False,
                srt_path: Path | None = None) -> dict:
    """Render [start, end] of ``source`` to ``out_path`` and validate it. Never modifies the source."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RenderError("FFmpeg was not found on PATH.")
    if end - start < 0.5:
        raise RenderError("The clip is too short to render.")
    source, out_path, tmp_dir = Path(source).resolve(), Path(out_path).resolve(), Path(tmp_dir).resolve()
    if settings.music_path:
        settings.music_path = str(Path(settings.music_path).resolve())
    if srt_path:
        srt_path = Path(srt_path).resolve()
    tmp_dir.mkdir(parents=True, exist_ok=True)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    keep: KeepSegments | None = None
    if settings.remove_silence and src_info.get("has_audio") and silences:
        keep = compute_keep_segments(start, end, silences, settings.silence_min_seconds)
        if len(keep) > MAX_SEGMENTS:
            raise RenderError(f"Silence removal would create {len(keep)} cuts (limit {MAX_SEGMENTS}). Raise the silence threshold or shorten the clip.")
        if len(keep) == 1 and abs(keep[0][1] - keep[0][0] - (end - start)) < 0.01:
            keep = None
    out_dur = kept_duration(end - start, keep)
    W, H = ASPECTS[settings.aspect]

    track = None
    ass_name = None
    fontsdir = None
    caption_note = "Captions disabled."
    probes: list[tuple[float, Path]] = []
    caption_report: dict | None = None
    if settings.captions:
        if transcript is None or not transcript.available:
            raise CaptionError("Captions are turned on but this project has no usable transcript. Attach an .srt/.vtt transcript or run local "
                               "transcription first, or turn 'Burn in captions' off.", "no_transcript")
        style = CaptionStyle.from_dict(settings.caption_style)
        track = build_track(transcript, start, end, keep, style.max_words_per_line)
        caption_note = track.note
        if not track.events:
            raise CaptionError(f"Captions are turned on but the transcript has no speech between {start:.1f}s and {end:.1f}s. "
                               "Choose a clip that contains speech, fix the transcript timing, or turn captions off.", "no_speech_in_range")
        plan = capfx.prepare_fonts(tmp_dir, style.font, " ".join(e.text for e in track.events))
        if plan.notes:
            caption_note += " " + " ".join(plan.notes)
        write_ass(track, tmp_dir / "captions.ass", W, H, style, font_family=plan.family)
        ass_name, fontsdir = "captions.ass", plan.fontsdir
        for i, t in enumerate(capfx.pick_probe_times([(e.start, e.end) for e in track.events])):   # several points across the clip, not one
            probes.append((t, capfx.probe_glyphs(ffmpeg, tmp_dir, ass_name, plan, W, H, t, name=("caption_probe" if i == 0 else f"caption_probe_{i}"))))   # proves libass can draw with these fonts
        if srt_path:
            write_srt(track, srt_path)
    tmp_out = tmp_dir / "render_tmp.mp4"
    cmd = build_command(ffmpeg, source, tmp_out, start, end, src_info, settings, ass_name, keep, out_dur, fontsdir)
    (tmp_dir / "ffmpeg_command.txt").write_text(" ".join(f'"{c}"' if " " in c else c for c in cmd), encoding="utf-8")
    _run_ffmpeg(cmd, tmp_dir, out_dur, progress, cancelled, timeout=max(180.0, out_dur * 40))
    expects_audio = bool(src_info.get("has_audio") and settings.keep_original_audio) or bool(settings.music_path)
    report = validate_export(tmp_out, out_dur, settings.aspect, expects_audio, settings.fps)
    if not report["valid"]:
        shutil.move(str(tmp_out), str(tmp_dir / "FAILED_render.mp4"))     # kept for diagnostics (previously unlinked first, so this raised FileNotFoundError)
        raise RenderError("Output validation failed: " + "; ".join(report["problems"]))
    if track is not None and probes:
        points = []
        for i, (t, png) in enumerate(probes):
            frame = capfx.extract_frame(ffmpeg, tmp_out, min(t, max(0.0, report["probe"]["duration"] - 0.1)), tmp_dir / ("export_frame.png" if i == 0 else f"export_frame_{i}.png"))
            points.append({**capfx.compare_frame_to_probe(frame, png), "at_seconds": round(t, 3)})
        caption_report = capfx.summarize_points(points)
        if not caption_report["visible"]:
            bad = [p for p in points if not p["visible"]]
            shutil.move(str(tmp_out), str(tmp_dir / "FAILED_render.mp4"))
            raise CaptionError(
                "The video was rendered but the captions are NOT visible in the exported frames "
                f"({len(bad)} of {len(points)} checked moments failed; e.g. {bad[0]['match_ratio']:.0%} of caption pixels found at {bad[0]['at_seconds']:.1f}s, need {capfx.MIN_MATCH_RATIO:.0%}). "
                "The file was discarded instead of exporting an uncaptioned clip. See the saved diagnostics for this render.", "captions_not_visible")
    shutil.move(str(tmp_out), str(out_path))   # only now does the export exist
    progress(1.0)
    return {
        "path": str(out_path), "duration": report["probe"]["duration"], "size_bytes": out_path.stat().st_size,
        "validation": report, "captions_granularity": track.granularity if track else "none",
        "captions_note": caption_note, "silence_removed": bool(keep), "reframe_used": settings.reframe,
        "caption_verification": caption_report, "subject_tracking": False, "srt_path": str(srt_path) if srt_path and srt_path.exists() else None,
    }
