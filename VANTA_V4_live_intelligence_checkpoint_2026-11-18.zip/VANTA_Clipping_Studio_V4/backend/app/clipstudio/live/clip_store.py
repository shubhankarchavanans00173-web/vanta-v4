"""On-disk job records for live clips, so the app can see clips the CLI produced in another process.

One JSON sidecar per job next to the clip (``<clips>/<job id>.job.json``), written atomically by the assembly
pipeline and read by the review routes. The sidecar never becomes a way to reach a file: promotion and playback
resolve the stored path server-side and refuse anything outside the clips folder.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

from ..transcript import Transcript
from .handoff import HandoffError, promote_live_clip, promotion_blocked

_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,119}")
PUBLIC_FIELDS = ("id", "session_id", "status", "event", "duration", "coverage", "segments", "error",
                 "requested_at", "finished_at", "before_seconds", "after_seconds", "project_id", "candidate_id")


def _sidecar(directory: Path, job_id: str) -> Path:
    if not _ID.fullmatch(job_id or ""):
        raise HandoffError("not_found", "That is not a valid live clip id.")
    return Path(directory) / f"{job_id}.job.json"


def write(directory: Path, job: dict) -> Path:
    """Atomically replace a job's sidecar (readers never see a half-written file)."""
    path = _sidecar(directory, job["id"])
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(job, ensure_ascii=False, default=str), encoding="utf-8")
    os.replace(tmp, path)
    return path


def _load(path: Path) -> dict | None:
    try:
        job = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return job if isinstance(job, dict) and job.get("id") and job.get("status") else None


def read_all(directory: Path) -> list[dict]:
    directory = Path(directory)
    if not directory.is_dir():
        return []
    jobs = [(f.stat().st_mtime, job) for f in directory.glob("*.job.json") if (job := _load(f))]
    return [job for _, job in sorted(jobs, key=lambda pair: pair[0], reverse=True)]


def read(directory: Path, job_id: str) -> dict:
    job = _load(_sidecar(directory, job_id))
    if job is None:
        raise HandoffError("not_found", "That live clip is not in the output folder any more.")
    return job


def update(directory: Path, job_id: str, **fields) -> dict:
    job = {**read(directory, job_id), **fields}
    write(directory, job)
    return job


def public(job: dict) -> dict:
    """The reviewer-facing view: never the media path, always the honest review-only flags."""
    out = {field: job.get(field) for field in PUBLIC_FIELDS}
    out.update({"review_only": True, "published": False, "file_ready": bool(job.get("path"))})
    return out


def clip_file(directory: Path, job_id: str, video_extensions: set[str]) -> Path:
    """Resolve the assembled file for playback; refuses anything outside the clips folder."""
    from .. import settings

    job = read(directory, job_id)
    path = Path(job["path"]) if job.get("path") else None
    if path is None or not settings.is_inside(path, directory) or path.suffix.lower() not in video_extensions or not path.is_file():
        raise HandoffError("not_found", "This clip has no assembled video yet.")
    return path


def promote(directory: Path, job_id: str, *, reviewed: bool, transcript: Transcript | None = None,
            title: str = "") -> dict:
    """Promote a reviewed clip that this process did not assemble (the CLI did), then record the project on it."""
    if not reviewed:
        raise HandoffError("not_reviewed", "Promotion needs explicit review: watch the clip and confirm it.")
    job = read(directory, job_id)
    blocked = promotion_blocked(job)
    if blocked:
        raise HandoffError("blocked", blocked)
    payload = promote_live_clip(job["path"], session_id=job.get("session_id"), job_id=job_id,
                                evidence=job.get("event"), transcript=transcript, title=title).to_dict()
    update(directory, job_id, project_id=payload["project_id"], candidate_id=payload["candidate_id"],
           published=False, review_only=True)
    return payload
