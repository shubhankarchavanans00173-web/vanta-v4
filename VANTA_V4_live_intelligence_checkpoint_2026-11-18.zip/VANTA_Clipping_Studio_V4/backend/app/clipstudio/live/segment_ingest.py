"""Local FFmpeg segment ingest for one operator-authorised source.

What this module does
    Runs a local FFmpeg process that reads a source the operator named and writes short MPEG-TS segments,
    then publishes each segment to the rolling buffer **only after FFmpeg has closed it** (the segment list
    is the authority, never a file-size guess), and deletes retired segments inside its own session folder.

What it never does
    It does not discover streams, hold credentials, bypass access control or log in to anything: chat and
    platform authentication belong to the adapters. It does not delete the source, and it refuses to
    unlink any path that resolves outside its own ``segments/`` folder. The URL allowlist exists so a
    crafted string cannot smuggle in an FFmpeg protocol handler such as ``concat:`` or ``pipe:``.

Why the segment list matters
    FFmpeg creates the next ``.ts`` file before it finishes the previous one, so "the file exists" is not
    "the file is complete". ``-segment_list_flags +live`` makes FFmpeg flush the list as each segment
    closes; only names that appear there with a positive duration are published.
"""
from __future__ import annotations

import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import urlsplit

from .rolling_buffer import BufferedSegment, RollingBuffer

# Only explicitly named, operator-authorised sources. Anything else (file://, concat:, pipe:, md5:...)
# is rejected rather than passed to FFmpeg's protocol layer.
ALLOWED_URL_SCHEMES = frozenset({"http", "https", "rtsp", "rtmp", "rtmps"})
MEDIA_SUFFIX = ".ts"


class IngestError(RuntimeError):
    """The ingest cannot start or has failed in a way the operator must see."""


@dataclass(frozen=True)
class IngestConfig:
    source: str
    audio_source: str | None = None      # a separate audio stream (a live platform link resolves to video + audio)
    segment_seconds: float = 4.0
    start_at: float = 0.0
    realtime: bool = True          # pace a local file like a live stream (-re); ignored for URLs
    transcode: bool = True         # re-encode for consistent segments; False uses -c copy
    audio: bool = True
    max_bytes: int = 512 * 1024 * 1024

    def __post_init__(self) -> None:
        if not 1.0 <= float(self.segment_seconds) <= 30.0:
            raise ValueError("segment_seconds must be between 1 and 30.")
        if float(self.start_at) < 0:
            raise ValueError("start_at cannot be negative.")
        if int(self.max_bytes) < 8 * 1024 * 1024:
            raise ValueError("max_bytes must be at least 8 MiB.")


def resolve_source(source: str) -> tuple[str, bool]:
    """Return ``(ffmpeg_input, is_local_file)`` for an explicitly named source, or raise ``IngestError``."""
    text = (source or "").strip()
    if not text:
        raise IngestError("An authorised ingest source is required.")
    if "://" in text:
        scheme = urlsplit(text).scheme.lower()
        if scheme not in ALLOWED_URL_SCHEMES:
            raise IngestError(f"Unsupported ingest scheme '{scheme}'. Allowed: {', '.join(sorted(ALLOWED_URL_SCHEMES))}.")
        if len(text) > 2048:
            raise IngestError("The ingest source URL is too long.")
        return text, False
    path = Path(text).expanduser()
    if not path.is_file():
        raise IngestError("The ingest source is not a readable local file.")
    return str(path.resolve()), True


def build_command(ffmpeg: str, source: str, *, local_file: bool, config: IngestConfig,
                  segments_dir: Path, list_path: Path, audio_source: str | None = None) -> list[str]:
    """Build the FFmpeg argument list. Always a list (never a shell string), so a source cannot inject flags."""
    command = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-y"]
    if local_file and config.realtime:
        command += ["-re"]
    if config.start_at:
        command += ["-ss", f"{float(config.start_at):.3f}"]
    command += ["-i", source]
    if audio_source:
        command += ["-i", audio_source]
        command += ["-map", "0:v:0", "-map", "1:a:0"]     # a platform live stream is two separate HLS playlists
    if config.transcode:
        # The segment muxer can only cut on keyframes.  Without forced keyframes a 2s request can produce 8s
        # segments, which makes the post-event window arrive late or never; force one at every boundary.
        command += ["-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
                    "-b:v", "2500k", "-maxrate", "2500k", "-bufsize", "5000k", "-sc_threshold", "0",
                    "-force_key_frames", f"expr:gte(t,n_forced*{float(config.segment_seconds):g})"]
    else:
        command += ["-c", "copy"]
    command += ["-c:a", "aac", "-b:a", "128k", "-ac", "2"] if config.audio else ["-an"]
    command += ["-f", "segment", "-segment_time", f"{float(config.segment_seconds):g}", "-segment_format", "mpegts",
                "-reset_timestamps", "1", "-segment_list", str(list_path), "-segment_list_type", "csv",
                "-segment_list_flags", "+live", str(Path(segments_dir) / "seg_%05d.ts")]
    return command


class SegmentIngest:
    """One ingest process for one session folder; ``poll()`` keeps the rolling buffer fed."""

    def __init__(self, session_dir: Path, buffer: RollingBuffer, config: IngestConfig, *,
                 ffmpeg: str | None = None, popen: Callable[..., object] | None = None,
                 clock: Callable[[], float] = time.monotonic, stop_timeout: float = 15.0,
                 poll_interval: float = 0.2):
        self.session_dir = Path(session_dir)
        self.segments_dir = self.session_dir / "segments"
        self.list_path = self.session_dir / "segments.csv"
        self.log_path = self.session_dir / "ingest.log"
        self.buffer, self.config = buffer, config
        self._ffmpeg, self._popen, self._clock = ffmpeg, popen or subprocess.Popen, clock
        self.stop_timeout = float(stop_timeout)
        self._proc = None
        self._log = None
        self._published: set[str] = set()
        self._retired_deleted = 0
        self._retired_refused: list[str] = []
        self._evicted = 0
        # Deletions blocked because a clip assembly pinned the segment. Retried until the lease is released,
        # so a disk-cap cut can never pull a file out from under a running FFmpeg encode.
        self._deferred: set[Path] = set()
        self._deferred_deleted = 0
        self._stopping = False
        self._error: str | None = None
        self.started_at: float | None = None
        # The buffer only moves if somebody calls poll(); the ingest owns that loop so a session cannot
        # silently stop feeding just because an adapter forgot to tick it.
        self.poll_interval = float(poll_interval)
        self._poll_lock = threading.RLock()
        self._stop_event = threading.Event()
        self._poller: threading.Thread | None = None

    # ------------------------------------------------------------------ lifecycle
    def start(self, *, background: bool = True) -> dict:
        if self.is_running:
            raise IngestError("This ingest is already running.")
        source, local_file = resolve_source(self.config.source)
        audio_source = resolve_source(self.config.audio_source)[0] if self.config.audio_source else None
        ffmpeg = self._ffmpeg or _which_ffmpeg()
        if not ffmpeg:
            raise IngestError("FFmpeg is not installed; the live ingest cannot start.")
        self.segments_dir.mkdir(parents=True, exist_ok=True)
        self.session_dir.mkdir(parents=True, exist_ok=True)
        # A fresh run owns a fresh list; stale rows would describe files this run did not write.
        self.list_path.unlink(missing_ok=True)
        command = build_command(ffmpeg, source, local_file=local_file, config=self.config,
                                segments_dir=self.segments_dir, list_path=self.list_path, audio_source=audio_source)
        self._log = self.log_path.open("wb")
        self._error, self._stopping = None, False
        try:
            self._proc = self._popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                     stderr=self._log, cwd=str(self.session_dir))
        except OSError as exc:
            self._close_log()
            self._proc = None
            raise IngestError(f"FFmpeg could not start: {exc}") from exc
        self.started_at = self._clock()
        if background and self.poll_interval > 0:
            self._stop_event.clear()
            self._poller = threading.Thread(target=self._poll_loop, name=f"live-ingest-{self.session_dir.name}", daemon=True)
            self._poller.start()
        return self.status()

    def _poll_loop(self) -> None:
        while not self._stop_event.wait(self.poll_interval):
            try:
                self.poll()
            except Exception as exc:               # a buffer bug must not kill the ingest silently
                self._error = f"Buffer publication failed: {type(exc).__name__}: {exc}"
                return

    @property
    def is_running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def poll(self) -> list[BufferedSegment]:
        """Publish every segment FFmpeg has closed. Safe to call repeatedly, from any thread; never publishes a partial file."""
        with self._poll_lock:
            return self._poll_once()

    def _poll_once(self) -> list[BufferedSegment]:
        published: list[BufferedSegment] = []
        for name, start, end in self._read_list():
            if name in self._published:
                continue
            path = self.segments_dir / name
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if size <= 0 or end <= start:
                continue                      # listed but empty/zero-length: keep waiting
            segment = BufferedSegment(start, end, path)
            retired = self.buffer.add(segment)
            self._published.add(name)
            published.append(segment)
            self._delete_retired(retired)
            self._enforce_byte_cap()
        # Also retried when nothing new arrived: a lease released between segments must still free the file.
        self._flush_deferred()
        return published

    def stop(self) -> dict:
        """Terminate FFmpeg, publish the segment it flushed on exit, and report honestly."""
        proc = self._proc
        if proc is None:
            return self.status()
        self._stop_event.set()
        if self._poller is not None:
            self._poller.join(timeout=3)
            self._poller = None
        self._stopping = proc.poll() is None
        if self._stopping:
            proc.terminate()
            try:
                proc.wait(timeout=self.stop_timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:   # pragma: no cover - FFmpeg ignores SIGKILL only when wedged
                    self._error = "FFmpeg did not exit after being killed."
        code = proc.returncode
        self.poll()                                    # the final segment is only in the list after exit
        self._close_log()
        self._proc = None
        if code not in (0, None) and not self._stopping and self._error is None:
            self._error = "FFmpeg exited with code " + str(code) + self._log_tail()
        self._stopping = False
        return self.status()

    # ------------------------------------------------------------------ housekeeping
    def cleanup(self, *, delete_segments: bool = True) -> dict:
        """Delete this session's segments (inside its own folder only) and its list; keep the log by default."""
        if self.is_running:
            return {"cleaned": False, "error": "The ingest is still running; stop it before cleaning up."}
        removed = 0
        if delete_segments:
            for path in sorted(self.segments_dir.glob("*" + MEDIA_SUFFIX)):
                if self._safe_unlink(path):
                    removed += 1
                    self._published.discard(path.name)
        self._flush_deferred()
        self._safe_unlink(self.list_path, suffixes=(MEDIA_SUFFIX, ".csv"))
        return {"cleaned": True, "removed_segments": removed, "deferred": len(self._deferred),
                "refused": list(self._retired_refused)}

    def status(self) -> dict:
        return {"running": self.is_running, "pid": getattr(self._proc, "pid", None), "source": self.config.source,
                "separate_audio": bool(self.config.audio_source),
                "poller": bool(self._poller and self._poller.is_alive()),
                "segment_seconds": self.config.segment_seconds, "transcode": self.config.transcode,
                "segments_published": len(self._published), "bytes": self._segment_bytes(),
                "max_bytes": self.config.max_bytes,                 "retired_deleted": self._retired_deleted,
                "evicted_for_size": self._evicted, "refused_deletions": list(self._retired_refused),
                "deferred_deletions": len(self._deferred), "deleted_after_release": self._deferred_deleted,
                "buffered": self.buffer.status(), "error": self._error,
                "review_only": True, "note": "Segments are deleted as they leave the rolling buffer; nothing is published."}

    # ------------------------------------------------------------------ internals
    def _read_list(self) -> list[tuple[str, float, float]]:
        try:
            raw = self.list_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []
        rows: list[tuple[str, float, float]] = []
        for line in raw.splitlines():
            parts = [part.strip() for part in line.split(",")]
            if len(parts) != 3:
                continue
            name = Path(parts[0]).name            # a list can only ever name a file in this folder
            if not name or name in {".", ".."}:
                continue
            try:
                start, end = float(parts[1]), float(parts[2])
            except ValueError:
                continue
            rows.append((name, start, end))
        return rows

    def _delete_retired(self, retired: list[BufferedSegment]) -> None:
        for segment in retired:
            if self._safe_unlink(segment.path):
                self._retired_deleted += 1
                self._published.discard(Path(segment.path).name)

    def _enforce_byte_cap(self) -> None:
        while self._segment_bytes() > int(self.config.max_bytes):
            oldest = self.buffer.evict_oldest()
            if oldest is None:
                break
            if self._safe_unlink(oldest.path):
                self._evicted += 1
                self._published.discard(Path(oldest.path).name)
            # Pinned by an in-flight assembly: it stayed in ``_deferred`` and the loop continues with the next
            # oldest segment, so the cap is met unless every remaining segment is being read right now.

    def _segment_bytes(self) -> int:
        total = 0
        try:
            for path in self.segments_dir.glob("*" + MEDIA_SUFFIX):
                try:
                    total += path.stat().st_size
                except OSError:
                    continue
        except OSError:
            return 0
        return total

    def _safe_unlink(self, path: Path, *, suffixes: tuple[str, ...] = (MEDIA_SUFFIX,)) -> bool:
        """Delete a file inside this session's segments folder unless a reader has it pinned.

        The pin check and the unlink happen under the buffer's lock, the same lock ``lease_window`` takes while
        it pins, so a segment cannot be pinned between the check and the delete.
        """
        try:
            resolved = Path(path).resolve()
        except OSError:
            return False
        if not _is_inside(resolved, self.segments_dir.resolve()):
            self._retired_refused.append(str(path))
            return False
        if resolved.suffix.lower() not in suffixes:
            return False
        with self.buffer.guard():
            if self.buffer.is_pinned(resolved):
                self._deferred.add(resolved)
                return False
            try:
                resolved.unlink()
                return True
            except OSError:
                return False

    def _flush_deferred(self) -> None:
        """Retry deletions that were blocked by a lease; called after every poll and on cleanup."""
        if not self._deferred:
            return
        for path in list(self._deferred):
            with self.buffer.guard():
                if self.buffer.is_pinned(path):
                    continue
                try:
                    path.unlink(missing_ok=True)
                except OSError:
                    continue
            self._deferred.discard(path)
            self._deferred_deleted += 1

    def _log_tail(self) -> str:
        try:
            data = self.log_path.read_bytes()[-400:]
        except OSError:
            return "."
        detail = data.decode("utf-8", "replace").strip()
        return f": {detail}" if detail else "."

    def _close_log(self) -> None:
        if self._log is not None:
            try:
                self._log.close()
            finally:
                self._log = None


def _which_ffmpeg() -> str | None:
    import shutil
    return shutil.which("ffmpeg")


def _is_inside(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False
