"""Align delayed chat reactions with the most likely earlier source event."""
from __future__ import annotations

from dataclasses import dataclass

from .chat_spike_detector import ChatSpike


@dataclass(frozen=True)
class EvidenceEvent:
    start: float
    end: float
    kind: str
    confidence: float
    evidence: str = ""


@dataclass(frozen=True)
class LiveEvent:
    event_time: float
    detected_at: float
    kind: str
    confidence: float
    evidence: tuple[str, ...]

    def to_dict(self) -> dict:
        return {"event_time": round(self.event_time, 3), "detected_at": round(self.detected_at, 3), "kind": self.kind,
                "confidence": round(self.confidence, 1), "evidence": list(self.evidence)}


def correlate(spike: ChatSpike, evidence_events: list[EvidenceEvent], min_delay: float = 1.0, max_delay: float = 25.0) -> LiveEvent:
    """Use the strongest pre-spike evidence, rather than treating chat time as event time."""
    candidates = [e for e in evidence_events if spike.timestamp - max_delay <= e.end <= spike.timestamp - min_delay]
    if candidates:
        # Recent high-confidence evidence wins; the delay bonus deliberately
        # favours ordinary chat latency instead of the oldest possible signal.
        best = max(candidates, key=lambda e: (e.confidence + 0.12 * (1 - abs((spike.timestamp - e.end) - 5) / max_delay), e.end))
        confidence = min(100.0, spike.score * 0.45 + best.confidence * 55)
        return LiveEvent((best.start + best.end) / 2, spike.timestamp, best.kind, confidence,
                         tuple([*spike.reasons, f"correlated with {best.kind} {spike.timestamp - best.end:.1f}s before the chat spike", best.evidence] if best.evidence else [*spike.reasons, f"correlated with {best.kind}"]))
    # Honest fallback: chat alone is an event candidate, not a claim about what
    # occurred in the video.
    return LiveEvent(spike.timestamp, spike.timestamp, "chat activity", min(65.0, spike.score * 0.65), tuple([*spike.reasons, "No corroborating transcript/audio/visual event was available yet."]))
