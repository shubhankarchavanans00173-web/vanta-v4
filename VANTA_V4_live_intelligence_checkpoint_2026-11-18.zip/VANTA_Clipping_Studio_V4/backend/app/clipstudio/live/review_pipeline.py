"""Turn one detected live event into exactly one review-only clip.

The chain is deliberately small and synchronous-looking: an event arrives through the manager's ``on_event``
callback, the pipeline waits (in a worker thread, never the request thread) until the rolling buffer holds
the configured post-event footage, then hands the buffered segments to ``LiveClipWorker.assemble`` and keeps
the result in a job registry.

Review-only is enforced by what this module *cannot* do: it never renders captions, never touches the export
table, never uploads, and never deletes the buffered media. Every job records ``published: False`` so a caller
cannot mistake an assembled file for a published clip. Publishing stays a human decision elsewhere.
"""
from __future__ import annotations

import re
import threading
import time
from pathlib import Path
from typing import Callable

from .event_correlator import LiveEvent
from .live_clip_worker import LiveClipError, LiveClipWorker

_SLUG = re.compile(r"[^a-z0-9]+")
_TERMINAL = {"ready_for_review", "pending_post_event_footage", "failed"}


class LiveReviewPipeline:
    """Queues one assembly per detected event and exposes the outcome for review."""

    def __init__(self, manager, worker: LiveClipWorker, *, before_seconds: float = 30.0,
                 poll_seconds: float = 0.05, max_wait_seconds: float = 120.0,
                 thread_factory: Callable[..., threading.Thread] | None = None,
                 clock: Callable[[], float] = time.monotonic, sleep: Callable[[float], None] = time.sleep):
        self.manager, self.worker = manager, worker
        self.before_seconds, self.poll_seconds, self.max_wait_seconds = float(before_seconds), float(poll_seconds), float(max_wait_seconds)
        self._thread_factory = thread_factory or threading.Thread
        self._clock, self._sleep = clock, sleep
        self._store_dir: Path | None = Path(worker.output_dir)
        self._t0 = clock()
        self._jobs: dict[str, dict] = {}
        self._threads: dict[str, threading.Thread] = {}
        self._lock = threading.RLock()

    # ------------------------------------------------------------------ public API
    def on_event(self, session, event: LiveEvent) -> str:
        """The manager callback: schedule the clip and return its job id immediately."""
        return self.submit(session, event)

    def submit(self, session, event: LiveEvent) -> str | None:
        # Chat-only spikes are leads for investigation, not verified highlights.
        # The current live pipeline has no always-on audiovisual evidence producer;
        # allowing these through would turn ordinary chat activity into arbitrary clips.
        if (event.kind or "").strip().casefold() in {"chat activity", "chat_activity", "chat"}:
            with self._lock:
                self._rejected_chat_only = getattr(self, "_rejected_chat_only", 0) + 1
                self._last_rejection = {
                    "reason": "chat_only_event",
                    "message": "Chat activity detected, but no corroborating media event was available. Monitoring continues without creating a clip.",
                    "event": event.to_dict(),
                }
            return None
        job_id = self._job_id(session, event)
        with self._lock:
            if job_id in self._jobs:
                return job_id
            after = float(session.post_event_seconds)
            self._jobs[job_id] = {
                "id": job_id, "session_id": session.id, "event": event.to_dict(),
                "status": "waiting", "path": None, "duration": None, "coverage": None, "segments": 0,
                "error": None, "review_only": True, "published": False, "publishing": "manual approval only",
                "before_seconds": self.before_seconds, "after_seconds": after,
                "requested_at": round(self._clock() - self._t0, 3), "finished_at": None,
            }
            thread = self._thread_factory(target=self._run, args=(job_id, session, event),
                                          name=f"live-clip-{job_id}", daemon=True)
            self._threads[job_id] = thread
            # Start inside the lock: an observer that can see this job can also join a thread that is already
            # running. Starting it later opened a window where wait()/drain() joined an unstarted thread.
            thread.start()
            self._persist(self._jobs[job_id])
        return job_id

    def get(self, job_id: str) -> dict | None:
        with self._lock:
            job = self._jobs.get(job_id)
            return dict(job) if job else None

    def jobs(self, session_id: str | None = None) -> list[dict]:
        with self._lock:
            return [dict(job) for key, job in sorted(self._jobs.items()) if session_id is None or job["session_id"] == session_id]

    def wait(self, job_id: str, timeout: float | None = None) -> dict | None:
        """Join the assembly thread (bounded) and return the job as it stands."""
        with self._lock:
            thread = self._threads.get(job_id)
        _join_started(thread, timeout)
        return self.get(job_id)

    def drain(self, timeout: float | None = None) -> list[dict]:
        """Join every outstanding assembly; used by tests and shutdown."""
        deadline = None if timeout is None else self._clock() + timeout
        with self._lock:
            threads = [self._threads[job_id] for job_id in sorted(self._threads)]
        for thread in threads:
            remaining = None if deadline is None else max(0.0, deadline - self._clock())
            _join_started(thread, remaining)
        return self.jobs()

    def status(self) -> dict:
        with self._lock:
            counts: dict[str, int] = {}
            for job in self._jobs.values():
                counts[job["status"]] = counts.get(job["status"], 0) + 1
            return {"jobs": len(self._jobs), "by_status": counts, "output_dir": str(self.worker.output_dir),
                    "rejected_chat_only": getattr(self, "_rejected_chat_only", 0),
                    "last_rejection": getattr(self, "_last_rejection", None),
                    "review_only": True, "note": "Chat-only spikes are rejected; assembled corroborated clips remain review-only."}

    # ------------------------------------------------------------------ promotion (reviewed clip -> real project)
    def promote(self, job_id: str, *, reviewed: bool = False, **options) -> dict:
        """Turn a finished, human-reviewed clip into a normal VANTA project (source + transcript + captions + candidate).

        ``reviewed=True`` must be passed explicitly: the assembly thread finishes clips without any human in the loop,
        and a project created here can be rendered and published. Refuses anything that is not ``ready_for_review``
        and refuses to promote the same job twice, so a stray double click cannot duplicate the project.
        """
        from .handoff import promote_live_clip, promotion_blocked

        if not reviewed:
            raise LiveClipError("Pass reviewed=True after watching the clip: promotion creates a renderable project.")
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                raise LiveClipError(f"Unknown live clip job {job_id!r}.")
            blocked = promotion_blocked(job)
            if blocked:
                raise LiveClipError(blocked)
            path, session_id, event = job["path"], job["session_id"], job["event"]
        payload = promote_live_clip(path, session_id=session_id, job_id=job_id, evidence=event, **options).to_dict()
        self._set(job_id, project_id=payload["project_id"], candidate_id=payload["candidate_id"], published=False)
        return payload

    # ------------------------------------------------------------------ assembly
    def _run(self, job_id: str, session, event: LiveEvent) -> None:
        after = float(session.post_event_seconds)
        deadline = event.event_time + after
        started = self._clock()
        while True:
            latest = session.buffer.status()["end"]
            if latest is not None and latest >= deadline:
                break
            if session.state != "monitoring":
                break                      # the stream ended: assemble whatever really exists
            if self._clock() - started >= self.max_wait_seconds:
                break
            self._sleep(self.poll_seconds)
        self._set(job_id, status="assembling",
                  footage_ready=bool(latest is not None and latest >= deadline),
                  waited_seconds=round(self._clock() - started, 3))
        try:
            result = self.worker.assemble(session.buffer, event, job_id, self.before_seconds, after)
            self._set(job_id, status=result.get("status", "failed"), path=result.get("path"),
                      duration=result.get("duration"), coverage=result.get("coverage"),
                      segments=len(result.get("segments") or []), finished_at=round(self._clock() - self._t0, 3))
        except LiveClipError as exc:
            self._set(job_id, status="failed", error=str(exc)[:400], finished_at=round(self._clock() - self._t0, 3))
        except Exception as exc:            # never let a worker kill the monitoring session
            self._set(job_id, status="failed", error=f"{type(exc).__name__}: {str(exc)[:300]}",
                      finished_at=round(self._clock() - self._t0, 3))

    def _set(self, job_id: str, **fields) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return
            job.update(fields)
            self._persist(job)

    def _persist(self, job: dict) -> None:
        """Best-effort sidecar so the app (a different process) can see this clip. Never kills the session."""
        if getattr(self, "_store_dir", None) is None:
            return
        from . import clip_store
        try:
            clip_store.write(self._store_dir, dict(job))
        except (OSError, ValueError):
            pass

    @staticmethod
    def _job_id(session, event: LiveEvent) -> str:
        kind = _SLUG.sub("-", event.kind.lower()).strip("-") or "event"
        return f"{session.id}-{int(round(event.event_time * 1000)):08d}-{kind[:24]}"


def _join_started(thread, timeout: float | None) -> None:
    """Join a thread that is already running; never raise if a caller raced an unstarted thread."""
    if thread is None:
        return
    try:
        thread.join(timeout)
    except RuntimeError:                    # defensive: a thread that was never started cannot be joined
        return


def attach(manager, worker: LiveClipWorker, **kwargs) -> LiveReviewPipeline:
    """Create the pipeline and make the shared manager route its events into it."""
    pipeline = LiveReviewPipeline(manager, worker, **kwargs)
    manager.on_event = pipeline.on_event
    return pipeline


def clips_dir(base: Path) -> Path:
    return Path(base) / "live" / "clips"
