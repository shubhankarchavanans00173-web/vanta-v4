"""Turn one *reviewed* live clip into an ordinary VANTA project.

The live pipeline can only assemble a review-only MP4: it never writes captions, never touches the export table and
never publishes. This module is the one-way bridge into the normal product: the clip is copied into the upload folder,
the transcript is stored with a standalone ``.srt`` beside it, and one candidate covering the whole clip is added.
After that every existing route (analyze, approve, render, export, publish metadata) works unchanged.

There is no network access here and nothing is published. ``published`` is always ``False`` so a caller cannot mistake
a promoted project for a published clip.
"""
from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .. import captions, db, media, pipeline, settings
from ..transcript import Transcript, TranscriptError, get_engine

_HINT = ("Attach a transcript instead (a .srt/.vtt/.json file), or install faster-whisper and download a model in "
         "Settings -> Transcription, then retry. Nothing was created.")


class HandoffError(RuntimeError):
    """A refusal with a stable code, a human message and (usually) an actionable hint."""

    def __init__(self, code: str, message: str, hint: str | None = None):
        super().__init__(message)
        self.code, self.hint = code, hint


def promotion_blocked(job: dict) -> str | None:
    """Why this live clip cannot be promoted (``None`` when it can) - the one rule every promotion entry point uses."""
    if job.get("project_id"):
        return f"This clip was already promoted to project {job['project_id']}."
    if job.get("status") != "ready_for_review" or not job.get("path"):
        return f"Only a ready_for_review clip can be promoted; this one is '{job.get('status')}'."
    return None


@dataclass
class Handoff:
    project: dict
    candidate: dict
    transcript: Transcript
    captions_path: Path

    def to_dict(self) -> dict:
        return {
            "project_id": self.project["id"], "candidate_id": self.candidate["id"], "name": self.project["name"],
            "duration": round(float((self.project.get("probe") or {}).get("duration") or 0), 3),
            "source_type": self.project["source_type"], "source_ref": self.project.get("source_ref"),
            "transcript": {"source": self.transcript.source, "language": self.transcript.language,
                           "segments": len(self.transcript.segments), "word_level": self.transcript.word_level},
            "captions_srt": str(self.captions_path), "candidate_status": self.candidate["status"],
            "review_only": True, "published": False,
            "next": {"render": f"POST /api/vanta/projects/{self.project['id']}/render",
                     "candidate_ids": [self.candidate["id"]]},
        }


def _resolve_clip(clip: str | Path) -> Path:
    """The single place that decides whether a path may become a project source."""
    src = Path(clip).expanduser().resolve()
    if not src.is_file():
        raise HandoffError("not_found", f"The live clip is not on disk anymore: {src.name}")
    if not settings.is_inside(src, settings.BASE):
        raise HandoffError("outside_data", "That file is outside VANTA's own data folder, so it is not a live clip this "
                                           "app produced. Copy it into the data folder first.")
    if src.suffix.lower() not in settings.VIDEO_EXTENSIONS:
        raise HandoffError("unsupported_type", f"{src.suffix or 'That file'} is not a video format VANTA can read.")
    if src.stat().st_size > settings.MAX_UPLOAD_BYTES:
        raise HandoffError("too_large", "The clip is larger than the configured upload limit.")
    return src


def _transcribe_locally(clip: Path, duration: float) -> Transcript:
    engine = get_engine("faster-whisper")
    ok, detail = engine.available()
    if not ok:
        raise HandoffError("no_transcript", f"No local transcription is ready ({detail}).", _HINT)
    try:
        transcript = engine.transcribe(clip, None, duration=duration)
    except TranscriptError as error:
        raise HandoffError("failed", f"Transcription failed: {error}", _HINT) from error
    if not (transcript and transcript.available):
        raise HandoffError("no_transcript", "The local engine found no speech in this clip.", _HINT)
    return transcript


def _reasons(evidence: dict | None, session_id: str | None, job_id: str | None) -> list[str]:
    reasons = ["Promoted from a live clip a human reviewed in VANTA."]
    where = ", ".join(part for part in (f"session {session_id}" if session_id else "",
                                        f"clip job {job_id}" if job_id else "") if part)
    if where:
        reasons.append(f"Live session: {where}.")
    kind = (evidence or {}).get("kind") or (evidence or {}).get("event_kind")
    if kind:
        reasons.append(f"Detected event: {kind}.")
    return reasons


def _excerpt(transcript: Transcript) -> str:
    return " ".join(seg.text.strip() for seg in transcript.segments).strip()[:240]


def promote_live_clip(clip: str | Path, *, session_id: str | None = None, job_id: str | None = None,
                      title: str = "", evidence: dict | None = None, transcript: Transcript | None = None,
                      transcribe: Callable[[Path, dict], Transcript] | None = None,
                      approved: bool = True) -> Handoff:
    """Copy the clip, transcribe it (or take the supplied transcript), write captions, add one candidate.

    ``approved=True`` is the default because promoting *is* the human review step; pass ``approved=False`` to land the
    clip as a suggestion instead. Failures never leave a half-built project behind: the project row, copied media,
    transcript JSON and SRT are all rolled back.
    """
    src = _resolve_clip(clip)
    try:
        info = media.validate_source(src, settings.MAX_DURATION_SECONDS)
    except media.MediaError as error:
        raise HandoffError("unreadable", str(error)) from error
    duration = round(float(info["duration"]), 3)
    if duration <= 0:
        raise HandoffError("unreadable", "The clip has no measurable duration.")

    if transcript is None:
        transcript = transcribe(src, info) if transcribe else _transcribe_locally(src, duration)
    if not (transcript and transcript.available):
        raise HandoffError("no_transcript", "A project needs a transcript before it can be captioned and published.", _HINT)

    name = (title or "").strip() or f"Live clip {src.stem}"
    live_settings = {"promoted_from": "live-review", "session_id": session_id, "job_id": job_id,
                     "clip_name": src.name, "evidence": evidence or {}, "clip_seconds": duration}
    project: dict | None = None
    try:
        # create_project mints the id itself, so the row comes first and every file is named from its real id
        project = db.create_project(name, "live", job_id or session_id, None, info, {"live": live_settings})
        pid = project["id"]
        dest = settings.UPLOAD_DIR / f"{pid}_live{src.suffix.lower()}"
        srt_path = settings.TRANSCRIPT_DIR / f"{pid}.srt"
        shutil.copy2(src, dest)
        pipeline.save_transcript(pid, transcript)
        track = captions.build_track(transcript, 0.0, duration)
        if not track.events:
            raise HandoffError("no_captions", "The transcript produced no caption lines for this clip.")
        captions.write_srt(track, srt_path)
        candidate = db.add_candidate(
            pid, 0.0, duration, None, "live-review", _reasons(evidence, session_id, job_id), _excerpt(transcript),
            rank=1, origin="live", status="approved" if approved else "suggested", title=name[:120],
            analysis={"captions_srt": str(srt_path)},
        )
        db.update_project(pid, source_path=str(dest), status="awaiting_approval",
                          settings={"live": live_settings, "captions_srt": str(srt_path)})
        return Handoff(db.get_project(pid) or project, candidate, transcript, srt_path)
    except HandoffError:
        _rollback(project, src)
        raise
    except Exception as error:                       # noqa: BLE001 - surfaced with a stable code, rollback first
        _rollback(project, src)
        raise HandoffError("failed", f"Could not create the project: {type(error).__name__}: {str(error)[:200]}") from error


def _rollback(project: dict | None, src: Path) -> None:
    """Undo everything promotion may have written, named from the project id exactly as promotion names it."""
    if project is None:
        return
    pid = project["id"]
    for path in (settings.UPLOAD_DIR / f"{pid}_live{src.suffix.lower()}",
                 settings.TRANSCRIPT_DIR / f"{pid}.srt", settings.TRANSCRIPT_DIR / f"{pid}.json"):
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass
    try:
        db.delete_project(pid)
    except Exception:  # pragma: no cover - the DB is the last thing we can do anything about
        pass
