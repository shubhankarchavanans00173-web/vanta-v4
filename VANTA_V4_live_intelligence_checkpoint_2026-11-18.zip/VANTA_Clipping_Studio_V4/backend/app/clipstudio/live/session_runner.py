"""One live session: authorised media in, real chat in, review-only clips out.

The runner is the wiring this project was missing. It creates the session, starts the ingest on the operator's media
source, builds the chat source with a stream clock taken from the buffer, and leaves the existing
``LiveReviewPipeline`` to turn each detected event into one review-only clip.

It owns no credentials and performs no platform login: the caller passes an already authorised chat source.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .chat_sources import StreamClock
from .review_pipeline import LiveReviewPipeline
from .segment_ingest import IngestConfig, SegmentIngest
from .stream_manager import LiveStreamManager
from .media_evidence import MediaEvidenceWorker


@dataclass
class LiveRunConfig:
    platform: str                          # "youtube" | "twitch"
    stream_ref: str                        # video id / channel name, as the operator identifies it
    source: str                            # authorised media source: local file or explicit URL
    audio_source: str | None = None        # separate audio stream when the platform publishes one (live YouTube)
    buffer_seconds: float = 90.0
    post_event_seconds: float = 8.0
    segment_seconds: float = 4.0
    before_seconds: float = 30.0
    base_dir: Path | None = None

    def __post_init__(self) -> None:
        if self.platform not in {"youtube", "twitch", "manual"}:
            raise ValueError("platform must be youtube, twitch, or manual.")
        if not (self.stream_ref or "").strip():
            raise ValueError("A stream reference is required (video id or channel).")
        if not (self.source or "").strip():
            raise ValueError("An authorised media source is required.")


class LiveSessionRunner:
    """Starts and stops the four moving parts of one live session, in the right order."""

    def __init__(self, manager: LiveStreamManager, pipeline: LiveReviewPipeline, config: LiveRunConfig, *,
                 chat_factory: Callable[["LiveSessionRunner"], object], base_dir: Path,
                 ingest_factory: Callable[..., SegmentIngest] = SegmentIngest,
                 clock_factory: Callable = StreamClock):
        self.manager, self.pipeline, self.config = manager, pipeline, config
        self.chat_factory, self.base_dir = chat_factory, Path(base_dir)
        self._ingest_factory, self._clock_factory = ingest_factory, clock_factory
        self.session = None
        self.ingest: SegmentIngest | None = None
        self.chat = None
        self.clock = None
        self.started_at = None
        self.evidence_worker: MediaEvidenceWorker | None = None

    # ------------------------------------------------------------------ lifecycle
    def start(self) -> dict:
        if self.session is not None:
            raise RuntimeError("This live session runner has already been started.")
        config = self.config
        self.session = self.manager.start(config.platform, config.stream_ref,
                                          buffer_seconds=config.buffer_seconds, post_event_seconds=config.post_event_seconds)
        self.manager.on_event = self.pipeline.on_event
        session_dir = self.base_dir / self.session.id
        self.clock = self._clock_factory(self.session.buffer)
        self.ingest = self._ingest_factory(session_dir / "segments", self.session.buffer,
                                           IngestConfig(source=config.source, audio_source=config.audio_source,
                                                        segment_seconds=config.segment_seconds))
        self.ingest.start()
        self.chat = self.chat_factory(self)
        self.chat.start()
        self.evidence_worker = MediaEvidenceWorker(self.manager, self.session)
        self.evidence_worker.start()
        return self.status()

    def stop(self, *, cleanup: bool = False) -> dict:
        """Stop chat first (no new events), then the ingest, then mark the session stopped."""
        chat_status = self.chat.stop() if self.chat is not None else None
        ingest_status = self.ingest.stop() if self.ingest is not None else None
        evidence_status = self.evidence_worker.stop() if self.evidence_worker is not None else None
        cleanup_status = None
        if cleanup and self.ingest is not None:
            cleanup_status = self.ingest.cleanup()
        session_status = None
        if self.session is not None and self.session.state == "monitoring":
            session_status = self.manager.snapshot(self.manager.stop(self.session.id).id)
        return {"chat": chat_status, "ingest": ingest_status, "evidence": evidence_status, "cleanup": cleanup_status,
                "session": session_status, "jobs": self.pipeline.jobs(self.session.id) if self.session else []}

    # ------------------------------------------------------------------ inspection
    def status(self) -> dict:
        if self.session is None:
            return {"started": False}
        return {"started": True, "session_id": self.session.id, "platform": self.session.platform,
                "stream_ref": self.session.stream_ref, "source": self.config.source,
                "buffer": self.session.buffer.status(), "chat": self.chat.status() if self.chat else None,
                "ingest": self.ingest.status() if self.ingest else None,
                "events": len(self.session.events), "jobs": self.pipeline.jobs(self.session.id),
                "media_evidence": self.evidence_worker.status() if self.evidence_worker else {"available": False},
                "review_only": True, "published": False}

    def wait(self, timeout: float | None = None) -> list[dict]:
        """Block until every scheduled clip assembly finishes (or the timeout expires)."""
        self.pipeline.drain(timeout)
        return self.pipeline.jobs(self.session.id) if self.session else []
