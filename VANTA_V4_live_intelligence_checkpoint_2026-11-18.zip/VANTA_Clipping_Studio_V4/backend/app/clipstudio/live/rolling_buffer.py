"""Bounded index of recent, backend-owned live media segments.

The buffer stores references to short ingest segments, not an ever-growing
recording.  Callers own deletion: the class only tells them which retired paths
are no longer needed, avoiding accidental deletion of source media.
"""
from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass
from pathlib import Path
from threading import RLock


def _key(path: Path) -> Path:
    """Compare paths in one form: pins and deletion checks must agree on relative vs absolute spellings."""
    try:
        return Path(path).resolve()
    except OSError:                                  # pragma: no cover - only exotic paths
        return Path(path)


@dataclass(frozen=True)
class BufferedSegment:
    start: float
    end: float
    path: Path

    def __post_init__(self):
        if self.end <= self.start:
            raise ValueError("A buffered media segment must end after it starts.")

    def to_dict(self) -> dict:
        return {"start": round(self.start, 3), "end": round(self.end, 3), "path": str(self.path)}


class RollingBuffer:
    """Keep only the most recent ``retention_seconds`` of timestamped segments."""
    def __init__(self, retention_seconds: float = 90.0, max_segments: int = 180):
        if not 15 <= float(retention_seconds) <= 600:
            raise ValueError("retention_seconds must be between 15 and 600.")
        if not 2 <= int(max_segments) <= 1000:
            raise ValueError("max_segments must be between 2 and 1000.")
        self.retention_seconds = float(retention_seconds)
        self.max_segments = int(max_segments)
        self._segments: deque[BufferedSegment] = deque()
        self._lock = RLock()
        # Segments a reader is currently using. Deletion must consult this: evicting a segment while
        # LiveClipWorker is concatenating it would corrupt or fail the clip.
        self._pins: Counter[Path] = Counter()

    def add(self, segment: BufferedSegment) -> list[BufferedSegment]:
        """Add an ordered segment and return retired segments (without deleting them)."""
        with self._lock:
            if self._segments and segment.end < self._segments[-1].end:
                raise ValueError("Live buffer segments must be added in timestamp order.")
            self._segments.append(segment)
            cutoff = segment.end - self.retention_seconds
            retired: list[BufferedSegment] = []
            while self._segments and (self._segments[0].end <= cutoff or len(self._segments) > self.max_segments):
                retired.append(self._segments.popleft())
            return retired

    def evict_oldest(self) -> BufferedSegment | None:
        """Drop and return the oldest segment (used when a disk cap forces an early retirement)."""
        with self._lock:
            return self._segments.popleft() if self._segments else None

    # ------------------------------------------------------------------ reader pins / leases
    def guard(self):
        """The buffer lock, so a caller can make a pin check and the delete that follows it atomic."""
        return self._lock

    def pin_many(self, paths) -> None:
        with self._lock:
            for path in paths:
                self._pins[_key(path)] += 1

    def unpin_many(self, paths) -> None:
        with self._lock:
            for path in paths:
                key = _key(path)
                if self._pins[key] <= 1:
                    self._pins.pop(key, None)
                else:
                    self._pins[key] -= 1

    def is_pinned(self, path) -> bool:
        with self._lock:
            return self._pins.get(_key(path), 0) > 0

    def lease_window(self, event_time: float, before_seconds: float = 30.0,
                     after_seconds: float = 8.0) -> tuple[list[BufferedSegment], dict, "SegmentLease"]:
        """Select a window and pin it in one step, so it cannot be evicted before the reader opens it."""
        if before_seconds < 0 or after_seconds < 0:
            raise ValueError("before_seconds and after_seconds cannot be negative.")
        requested_start, requested_end = max(0.0, event_time - before_seconds), event_time + after_seconds
        with self._lock:
            chosen, coverage = self._window_locked(requested_start, requested_end)
            paths = [segment.path for segment in chosen]
            for path in paths:
                self._pins[_key(path)] += 1
        return chosen, coverage, SegmentLease(self, paths)

    def snapshot(self) -> list[BufferedSegment]:
        """Return a stable, read-only copy of currently retained segments."""
        with self._lock:
            return list(self._segments)

    @property
    def latest_time(self) -> float | None:
        with self._lock:
            return self._segments[-1].end if self._segments else None

    def status(self) -> dict:
        with self._lock:
            if not self._segments:
                return {"retention_seconds": self.retention_seconds, "segments": 0, "buffered_seconds": 0.0, "start": None, "end": None}
            return {"retention_seconds": self.retention_seconds, "segments": len(self._segments),
                    "buffered_seconds": round(self._segments[-1].end - self._segments[0].start, 3),
                    "start": self._segments[0].start, "end": self._segments[-1].end}

    def window(self, event_time: float, before_seconds: float = 30.0, after_seconds: float = 8.0) -> tuple[list[BufferedSegment], dict]:
        """Return segments covering the requested contextual window and an honest readiness report."""
        if before_seconds < 0 or after_seconds < 0:
            raise ValueError("before_seconds and after_seconds cannot be negative.")
        requested_start, requested_end = max(0.0, event_time - before_seconds), event_time + after_seconds
        with self._lock:
            return self._window_locked(requested_start, requested_end)

    def _window_locked(self, requested_start: float, requested_end: float) -> tuple[list[BufferedSegment], dict]:
        chosen = [s for s in self._segments if s.end > requested_start and s.start < requested_end]
        latest = self._segments[-1].end if self._segments else None
        earliest = self._segments[0].start if self._segments else None
        available_start = chosen[0].start if chosen else None
        available_end = chosen[-1].end if chosen else None
        return chosen, {
            "requested_start": round(requested_start, 3), "requested_end": round(requested_end, 3),
            "ready": bool(chosen and latest is not None and latest >= requested_end),
            "missing_before_seconds": round(max(0.0, (available_start or requested_end) - requested_start), 3),
            "missing_after_seconds": round(max(0.0, requested_end - (latest or requested_start)), 3),
            "available_start": available_start, "available_end": available_end, "buffer_start": earliest, "buffer_end": latest,
        }


class SegmentLease:
    """Pins the segments one reader is using; deleting them is deferred until the lease is released.

    ``LiveClipWorker`` keeps a lease for the whole FFmpeg run. Without it the ingest could honour the disk
    cap (or a retention cut) in the middle of a concat and delete a file the encoder still has open.
    """
    __slots__ = ("_buffer", "_paths", "_released")

    def __init__(self, buffer: RollingBuffer, paths: list[Path]):
        self._buffer, self._paths, self._released = buffer, list(paths), False

    @property
    def paths(self) -> tuple[Path, ...]:
        return tuple(self._paths)

    @property
    def released(self) -> bool:
        return self._released

    def release(self) -> None:
        if not self._released:
            self._released = True
            self._buffer.unpin_many(self._paths)

    def __enter__(self) -> "SegmentLease":
        return self

    def __exit__(self, *_exc) -> bool:
        self.release()
        return False
