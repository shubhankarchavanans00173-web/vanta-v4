"""Run one live session from a terminal: real chat in, review-only clips out.

    cd backend
    PYTHONPATH=. python -m app.clipstudio.live.cli --check --platform youtube --video-id LIVE_VIDEO_ID
    PYTHONPATH=. python -m app.clipstudio.live.cli --platform twitch --channel NAME --source C:/captures/stream.mp4

``--check`` validates credentials and chat without media and without producing clips, which is the right first run:
it spends one YouTube quota call per poll and nothing else. Nothing is uploaded or published, ever.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

from .. import db, settings
from ..transcript import TranscriptError, load_transcript_file
from . import credentials
from .handoff import HandoffError, promote_live_clip
from .chat_factory import build_chat
from .live_clip_worker import LiveClipWorker
from .review_pipeline import LiveReviewPipeline, clips_dir
from .segment_ingest import IngestError
from .session_runner import LiveRunConfig, LiveSessionRunner
from .stream_manager import LiveStreamManager
from .twitch_adapter import TwitchAdapterError
from .youtube_adapter import YouTubeAdapterError


class CliError(RuntimeError):
    pass


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m app.clipstudio.live.cli",
                                     description="Live chat -> detected moment -> one review-only MP4. Read-only, local, never published.")
    parser.add_argument("--platform", choices=["youtube", "twitch"],
                        help="chat platform (required unless --promote is used)")
    parser.add_argument("--source", help="authorised media source: a local file or an explicit http(s)/rtsp/rtmp(s) URL")
    parser.add_argument("--video-id", help="YouTube live video id (VANTA looks up its activeLiveChatId)")
    parser.add_argument("--chat-id", help="YouTube liveChatId, skips the video lookup")
    parser.add_argument("--channel", help="Twitch channel (falls back to TWITCH_CHANNEL)")
    parser.add_argument("--buffer", type=float, default=90.0, help="seconds of media kept (15-600, default 90)")
    parser.add_argument("--before", type=float, default=30.0, help="seconds before the event in the clip (default 30)")
    parser.add_argument("--after", type=float, default=8.0, help="seconds after the event that must exist before assembly (default 8)")
    parser.add_argument("--segment", type=float, default=4.0, help="ingest segment length in seconds (default 4)")
    parser.add_argument("--output", help="folder for review clips (default: <data>/live)")
    parser.add_argument("--seconds", type=float, default=0.0, help="stop after N seconds (0 = run until Ctrl+C)")
    parser.add_argument("--check", action="store_true", help="verify credentials and chat only: no media, no clips")
    parser.add_argument("--promote", metavar="CLIP",
                        help="turn one reviewed live clip into a normal project (transcript + captions + approved candidate), then exit")
    parser.add_argument("--transcript", help="use this .srt/.vtt/.json transcript instead of running local transcription")
    parser.add_argument("--title", default="", help="project name for --promote")
    parser.add_argument("--json", action="store_true", help="print status as JSON lines")
    return parser


# --------------------------------------------------------------------------- output
def _emit(payload: dict, as_json: bool, prefix: str = "") -> None:
    if as_json:
        import json
        print(json.dumps(payload, ensure_ascii=False), flush=True)
        return
    if prefix:
        print(prefix, payload, flush=True)


def _diagnostics(args) -> dict:
    return credentials.youtube_diagnostics() if args.platform == "youtube" else credentials.twitch_diagnostics()


# --------------------------------------------------------------------------- modes
def run_check(args) -> int:
    samples: list = []
    chat = build_chat(args.platform, clock=lambda: 0.0, on_message=samples.append, video_id=args.video_id,
                      chat_id=args.chat_id, channel=args.channel, timeout=5.0)
    chat.start()
    deadline = time.monotonic() + max(3.0, args.seconds or 12.0)
    try:
        while time.monotonic() < deadline and not samples:
            time.sleep(0.2)
    except KeyboardInterrupt:                       # a check that is interrupted is not a failure
        pass
    finally:
        status = chat.stop()
    report = {"check": True, "diagnostics": _diagnostics(args), "chat": status,
              "sample_messages": [{"author": m.author, "text": m.text[:120]} for m in samples[:3]],
              "note": "Read-only credential check. No media was opened and no clip was produced."}
    _emit(report, args.json, "check:")
    if status.get("errors") and not status.get("messages"):
        print(f"error: chat check failed: {status.get('last_error')}", file=sys.stderr)
        return 2
    return 0


def run_session(args) -> int:
    if not args.source:
        raise CliError("--source is required (a local file or an explicit authorised URL). Use --check to test chat only.")
    output_root = Path(args.output).expanduser() if args.output else clips_dir(settings.BASE)
    manager = LiveStreamManager()
    worker = LiveClipWorker(output_root)
    pipeline = LiveReviewPipeline(manager, worker, before_seconds=args.before)
    config = LiveRunConfig(platform=args.platform, stream_ref=(args.video_id or args.chat_id or args.channel or "unknown"),
                           source=args.source, buffer_seconds=args.buffer, post_event_seconds=args.after,
                           segment_seconds=args.segment, before_seconds=args.before, base_dir=output_root)
    runner = LiveSessionRunner(manager, pipeline, config, base_dir=output_root,
                               chat_factory=lambda live: build_chat(
                                   args.platform, clock=live.clock.now, video_id=args.video_id, chat_id=args.chat_id,
                                   channel=args.channel,
                                   on_message=lambda m: manager.add_chat(live.session.id, m)))
    started = runner.start()
    _emit({"started": {"session": started["session_id"], "output": str(output_root), "review_only": True}}, args.json, "live:")
    seen_events = seen_jobs = 0
    deadline = time.monotonic() + args.seconds if args.seconds else None
    try:
        while deadline is None or time.monotonic() < deadline:
            session = runner.session
            events = [event.to_dict() for event in session.events[seen_events:]]
            seen_events += len(events)
            for event in events:
                _emit(event, args.json, "event:")
            jobs = pipeline.jobs(session.id)
            for job in jobs[seen_jobs:]:
                _emit({"job": job["id"], "status": job["status"], "path": job["path"], "error": job["error"]}, args.json, "clip:")
            seen_jobs = len(jobs)
            if runner.chat is not None and getattr(runner.chat, "failed", False):
                print("error: chat source gave up reconnecting; stopping.", file=sys.stderr)
                break
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("stopping (Ctrl+C)...", file=sys.stderr)
    finally:
        summary = runner.stop()
        jobs = runner.wait(timeout=120)
    ready = [job for job in jobs if job.get("status") == "ready_for_review"]
    report = {"stopped": True, "chat": summary["chat"], "ingest": summary["ingest"], "clips": jobs,
              "ready": len(ready), "review_only": True, "published": False,
              "note": "Clips are in the output folder for review. Nothing was uploaded or published."}
    _emit(report, args.json, "done:")
    return 0 if not (jobs and all(job.get("status") == "failed" for job in jobs)) else 1


def run_promote(args) -> int:
    """Reviewed clip -> real project. Local files only; nothing is uploaded or published."""
    db.init()                    # the app does this at startup; the CLI must work on a fresh data folder too
    transcript = None
    if args.transcript:
        transcript = load_transcript_file(Path(args.transcript).expanduser())
        if not transcript.available:
            raise CliError("That transcript file contains no segments.")
    result = promote_live_clip(Path(args.promote), title=args.title, transcript=transcript)
    _emit(result.to_dict(), args.json, "promoted:")
    if not args.json:
        print(f"project {result.project['id']} is ready: open it in VANTA, then render clip {result.candidate['id']}.",
              file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.promote:
            return run_promote(args)
        if not args.platform:
            raise CliError("--platform is required (youtube or twitch) unless you use --promote.")
        if args.platform == "youtube" and not (args.video_id or args.chat_id):
            raise CliError("YouTube needs --video-id (or --chat-id).")
        return run_check(args) if args.check else run_session(args)
    except HandoffError as exc:
        print(f"error: {exc}", file=sys.stderr)
        if exc.hint:
            print(f"hint: {exc.hint}", file=sys.stderr)
        return 2
    except (CliError, credentials.CredentialsError, YouTubeAdapterError, TwitchAdapterError, IngestError,
            TranscriptError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
