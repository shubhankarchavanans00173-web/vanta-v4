"""Chat sources: the bridge between a platform adapter and ``LiveStreamManager.add_chat``.

The adapters turn one transport read into messages; a source owns *when* to read, retries after a failure, and —
most importantly — stamps every message with **stream time**, not wall-clock time. ``StreamClock`` reads the rolling
buffer's latest media timestamp, so a chat spike is placed at the moment that has actually been captured. Without
that, the review pipeline would be asked for footage near second zero of an hour-long stream.

Read-only by design: sources poll or read, never post, never moderate, never need elevated scopes.
"""
from __future__ import annotations

import threading
import time
from dataclasses import replace
from typing import Callable

from .chat_spike_detector import ChatMessage
from .rolling_buffer import RollingBuffer
from .twitch_adapter import TwitchAdapterError, TwitchChatStream
from .youtube_adapter import YouTubeAdapterError, YouTubeLiveChatAdapter


class StreamClock:
    """Stream seconds for an arriving message: the newest buffered media timestamp (0 before any media)."""

    def __init__(self, buffer: RollingBuffer, latency: float = 0.0):
        self.buffer, self.latency = buffer, max(0.0, float(latency))

    def now(self) -> float:
        latest = self.buffer.latest_time
        return 0.0 if latest is None else max(0.0, latest - self.latency)


class _ChatSourceBase:
    name = "chat"

    def __init__(self, on_message: Callable[[ChatMessage], object], *, clock: Callable[[], float] | None = None):
        self.on_message = on_message
        self.clock = clock or (lambda: 0.0)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.messages = self.errors = self.reads = 0
        self.last_error: str | None = None
        self.started_at: float | None = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self, *, thread_factory: Callable[..., threading.Thread] | None = None) -> dict:
        if self.running:
            return self.status()
        self._stop.clear()
        self.started_at = time.monotonic()
        factory = thread_factory or threading.Thread
        self._thread = factory(target=self._run, name=f"live-chat-{self.name}", daemon=True)
        self._thread.start()
        return self.status()

    def stop(self, timeout: float = 5.0) -> dict:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout)
            self._thread = None
        return self.status()

    def _deliver(self, messages: list[ChatMessage]) -> int:
        delivered = 0
        for message in messages:
            self.on_message(message)
            delivered += 1
        self.messages += delivered
        return delivered

    def _run(self) -> None:               # pragma: no cover - covered through poll_once/read_once in tests
        raise NotImplementedError

    def status(self) -> dict:
        return {"source": self.name, "running": self.running, "messages": self.messages, "reads": self.reads,
                "errors": self.errors, "last_error": self.last_error}


class YouTubeChatSource(_ChatSourceBase):
    """Polls an authorised ``YouTubeLiveChatAdapter`` at (at least) the interval the API asks for."""

    name = "youtube"

    def __init__(self, adapter: YouTubeLiveChatAdapter, on_message, *, clock=None,
                 min_interval: float = 0.5, max_interval: float = 10.0, backoff: float = 2.0, sleep: Callable[[float], None] = time.sleep):
        super().__init__(on_message, clock=clock)
        self.adapter, self.min_interval, self.max_interval, self.backoff, self._sleep = adapter, min_interval, max_interval, backoff, sleep

    def poll_once(self) -> int:
        """One API call. Returns delivered messages; records the failure instead of raising."""
        try:
            messages = self.adapter.poll()
        except YouTubeAdapterError as exc:
            self.errors += 1
            self.last_error = str(exc)[:300]
            return 0
        except Exception as exc:                       # a transport bug must not kill the session
            self.errors += 1
            self.last_error = f"{type(exc).__name__}: {str(exc)[:280]}"
            return 0
        self.reads += 1
        self.last_error = None
        stamp = float(self.clock())          # arrival time in stream seconds, not the adapter's default
        return self._deliver([replace(message, timestamp=stamp) for message in messages])

    @property
    def interval(self) -> float:
        return min(self.max_interval, max(self.min_interval, self.adapter.poll_interval_ms / 1000.0))

    def _run(self) -> None:                            # pragma: no cover - loop exercised via poll_once
        while not self._stop.is_set():
            self.poll_once()
            wait = self.interval * (self.backoff if self.last_error else 1.0)
            self._stop.wait(min(self.max_interval * self.backoff, wait))

    def status(self) -> dict:
        return {**super().status(), "poll_interval_seconds": round(self.interval, 3),
                "live_chat_id": getattr(self.adapter, "live_chat_id", None)}


class NullChatSource(_ChatSourceBase):
    """No readable chat adapter (missing credentials, or a manual session): media still ingests.

    The reason is reported with the session so the operator sees *why* there is no chat instead of an idle spinner.
    Messages may still be fed in from another local component; this class simply never produces any itself.
    """

    name = "none"

    def __init__(self, on_message, *, clock=None, reason: str = "No chat adapter is configured for this session."):
        super().__init__(on_message, clock=clock)
        self.reason = reason

    def _run(self) -> None:                            # pragma: no cover - idle wait, stopped by stop()
        self._stop.wait()

    def status(self) -> dict:
        return {**super().status(), "reason": self.reason}


class TwitchChatSource(_ChatSourceBase):
    """Reads one IRC connection, reconnecting with backoff when Twitch drops it."""

    name = "twitch"

    def __init__(self, stream: TwitchChatStream, on_message, *, clock=None, reconnect_attempts: int = 5,
                 backoff: float = 1.0, sleep: Callable[[float], None] = time.sleep):
        super().__init__(on_message, clock=clock)
        self.stream, self.reconnect_attempts, self.backoff, self._sleep = stream, int(reconnect_attempts), float(backoff), sleep
        self.reconnects = 0
        self.connected = False
        self.failed = False

    def connect(self) -> dict:
        try:
            self.stream.connect()
            self.connected = True
            self.last_error = None
        except TwitchAdapterError as exc:
            self.connected = False
            self.errors += 1
            self.last_error = str(exc)[:300]
        return self.status()

    def poll_once(self) -> int:
        """One receive. Reconnects on a dropped connection, gives up after ``reconnect_attempts``."""
        if not self.connected:
            self.connect()
            if not self.connected:
                return 0
        try:
            messages = self.stream.read()
        except TwitchAdapterError as exc:
            self.connected = False
            self.errors += 1
            self.last_error = str(exc)[:300]
            self.stream.close()
            if self.reconnects >= self.reconnect_attempts:
                self.failed = True
                return 0
            self.reconnects += 1
            self._sleep(min(15.0, self.backoff * 2 ** (self.reconnects - 1)))
            self.connect()
            return 0
        self.reads += 1
        self.last_error = None
        return self._deliver(messages)

    def _run(self) -> None:                            # pragma: no cover - loop exercised via poll_once
        while not self._stop.is_set() and not self.failed:
            self.poll_once()

    def stop(self, timeout: float = 5.0) -> dict:
        status = super().stop(timeout)
        self.stream.close()
        self.connected = False
        return status

    def status(self) -> dict:
        return {**super().status(), "connected": self.connected, "reconnects": self.reconnects, "failed": self.failed,
                "channel": getattr(self.stream, "channel", None)}
