"""Local live-stream intelligence primitives.

Platform adapters may feed these classes after authentication.  None of the
objects bypass access controls or attempt to discover private streams.
"""

from .chat_sources import StreamClock, TwitchChatSource, YouTubeChatSource
from .chat_spike_detector import ChatMessage, ChatSpike, ChatSpikeDetector
from .event_correlator import EvidenceEvent, LiveEvent, correlate
from .live_clip_worker import LiveClipError, LiveClipWorker
from .review_pipeline import LiveReviewPipeline, attach, clips_dir
from .rolling_buffer import BufferedSegment, RollingBuffer, SegmentLease
from .segment_ingest import IngestConfig, IngestError, SegmentIngest, build_command, resolve_source
from .session_runner import LiveRunConfig, LiveSessionRunner
from .stream_manager import LiveStreamManager, manager
from .twitch_adapter import TwitchAdapterError, TwitchChatStream, parse_irc_line
from .youtube_adapter import YouTubeAdapterError, YouTubeLiveChatAdapter, find_live_chat_id

__all__ = ["BufferedSegment", "RollingBuffer", "SegmentLease", "ChatMessage", "ChatSpike", "ChatSpikeDetector", "EvidenceEvent",
           "LiveEvent", "correlate", "LiveStreamManager", "manager", "LiveClipWorker", "LiveClipError", "LiveReviewPipeline",
           "attach", "clips_dir", "SegmentIngest", "IngestConfig", "IngestError", "build_command", "resolve_source",
           "StreamClock", "YouTubeChatSource", "TwitchChatSource", "YouTubeLiveChatAdapter", "YouTubeAdapterError",
           "find_live_chat_id", "TwitchChatStream", "TwitchAdapterError", "parse_irc_line", "LiveRunConfig", "LiveSessionRunner"]
