"""Resolve a public platform watch page to the media URLs the ingest can read.

Only the operator's own enable flag (``VANTA_ENABLE_YTDLP``) turns this on, and only yt-dlp decides what is public:
a private, members-only, age-gated or DRM-protected stream fails with the tool's own message rather than being worked
around. The resolved URLs are signed and short-lived, so they are never logged and never returned to the browser - the
session reports the page URL the operator typed.

Why two URLs: a live YouTube stream is published as separate video-only and audio-only HLS playlists, so one input is
not enough for a clip with sound. ``resolve`` returns both when the platform provides two.
"""
from __future__ import annotations

import subprocess
from urllib.parse import urlsplit

from .. import ytdlp
from .segment_ingest import ALLOWED_URL_SCHEMES, IngestError

# One video + one audio HLS playlist when available, otherwise whatever single stream the platform publishes.
_FORMAT = "bv*[protocol^=m3u8]+ba[protocol^=m3u8]/best[protocol^=m3u8]/best"
_MAX_URL = 2048


class ResolveError(IngestError):
    """A link that cannot become a media stream, with a code and a hint the operator can act on."""

    def __init__(self, message: str, *, code: str, hint: str = ""):
        super().__init__(message)
        self.code, self.hint = code, hint


def resolve(source: str, *, timeout: float = 90.0) -> tuple[str, str | None]:
    """Return ``(video_url, audio_url_or_None)`` for a public platform link."""
    if not ytdlp.enabled():
        raise ResolveError("Platform links are switched off, so this watch page cannot be resolved.",
                           code="platform_links_disabled",
                           hint="Set VANTA_ENABLE_YTDLP=1 in .env and restart the backend, or paste the stream's direct "
                                "HLS/RTMP URL.")
    base = ytdlp.base_command()
    if base is None:
        raise ResolveError("yt-dlp is not installed in the backend Python environment.",
                           code="platform_links_disabled", hint=f"Run: {ytdlp.install_command()}")
    try:
        done = subprocess.run([*base, "--no-warnings", "-g", "-f", _FORMAT, source],
                              capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        raise ResolveError("Resolving that link took too long.", code="resolve_failed",
                           hint="Try again, or paste the direct HLS/RTMP URL of the stream.")
    urls = [line.strip() for line in (done.stdout or "").splitlines() if _usable(line.strip())]
    if done.returncode != 0 or not urls:
        message, fields = _failure(done)
        raise ResolveError(message, **fields)
    return urls[0], (urls[1] if len(urls) > 1 else None)


def _usable(url: str) -> bool:
    parts = urlsplit(url or "")
    return parts.scheme.lower() in ALLOWED_URL_SCHEMES and bool(parts.hostname) and len(url) <= _MAX_URL


def _failure(done: subprocess.CompletedProcess) -> tuple[str, dict]:
    """The tool's own reason, scrubbed of signed-URL tokens, as the hint."""
    errors, _, other = ytdlp.split_output((done.stderr or "") + "\n" + (done.stdout or ""))
    detail = ytdlp.scrub((errors or other or ["yt-dlp returned no media URL."])[-1])
    return "That link could not be resolved to a live media stream.", {"code": "resolve_failed", "hint": detail}
