"""In-process coordinator for bounded live intelligence sessions.

Adapters feed timestamped media, chat and lightweight evidence.  Video decoding
and FFmpeg assembly stay in explicit workers; the manager performs only small
in-memory bookkeeping and is safe to inspect through the dashboard.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from threading import RLock
from typing import Callable
from uuid import uuid4

from .chat_spike_detector import ChatMessage, ChatSpikeDetector
from .event_correlator import EvidenceEvent, LiveEvent, correlate
from .rolling_buffer import BufferedSegment, RollingBuffer


@dataclass
class LiveSession:
    id: str
    platform: str
    stream_ref: str
    buffer: RollingBuffer
    detector: ChatSpikeDetector
    post_event_seconds: float
    state: str = "monitoring"
    events: list[LiveEvent] = field(default_factory=list)
    evidence: list[EvidenceEvent] = field(default_factory=list)
    error: str | None = None


class LiveStreamManager:
    def __init__(self, max_sessions: int = 4, on_event: Callable[[LiveSession, LiveEvent], None] | None = None):
        self.max_sessions, self.on_event = max_sessions, on_event
        self._sessions: dict[str, LiveSession] = {}
        self._lock = RLock()

    def start(self, platform: str, stream_ref: str, *, buffer_seconds: float = 90.0, post_event_seconds: float = 8.0) -> LiveSession:
        if platform not in {"youtube", "twitch", "manual"}:
            raise ValueError("platform must be youtube, twitch, or manual.")
        if not stream_ref.strip():
            raise ValueError("An authorized stream reference is required.")
        if not 0 <= post_event_seconds <= 30:
            raise ValueError("post_event_seconds must be between 0 and 30.")
        with self._lock:
            if sum(1 for s in self._sessions.values() if s.state == "monitoring") >= self.max_sessions:
                raise RuntimeError("The local live-session limit has been reached.")
            session = LiveSession(uuid4().hex[:12], platform, stream_ref.strip(), RollingBuffer(buffer_seconds), ChatSpikeDetector(), float(post_event_seconds))
            self._sessions[session.id] = session
            return session

    def get(self, session_id: str) -> LiveSession | None:
        with self._lock:
            return self._sessions.get(session_id)

    def list(self) -> list[LiveSession]:
        with self._lock:
            return list(self._sessions.values())

    def stop(self, session_id: str) -> LiveSession:
        session = self._require(session_id)
        session.state = "stopped"
        return session

    def add_segment(self, session_id: str, start: float, end: float, path: Path) -> list[BufferedSegment]:
        session = self._active(session_id)
        return session.buffer.add(BufferedSegment(float(start), float(end), Path(path)))

    def add_evidence(self, session_id: str, event: EvidenceEvent) -> None:
        session = self._active(session_id)
        session.evidence.append(event)
        cutoff = event.end - session.buffer.retention_seconds
        session.evidence[:] = [item for item in session.evidence if item.end >= cutoff]

    def add_chat(self, session_id: str, message: ChatMessage) -> LiveEvent | None:
        session = self._active(session_id)
        # Chat adapters can connect before FFmpeg has closed its first segment.
        # StreamClock intentionally reports 0 during that interval; accepting a
        # burst then creates a bogus event at t=0 and clips the stream opening.
        # Do not feed the detector until there is an actual media timeline.
        if session.buffer.latest_time is None:
            return None
        spike = session.detector.ingest(message)
        if spike is None:
            return None
        event = correlate(spike, session.evidence)
        # Deduplicate a continuing spike into one event unless its correlated
        # source moved materially in time or kind.
        if session.events and event.event_time - session.events[-1].event_time < 15 and event.kind == session.events[-1].kind:
            return None
        session.events.append(event)
        if self.on_event:
            self.on_event(session, event)
        return event

    def snapshot(self, session_id: str) -> dict:
        session = self._require(session_id)
        return {"id": session.id, "platform": session.platform, "stream_ref": session.stream_ref, "state": session.state, "error": session.error,
                "post_event_seconds": session.post_event_seconds, "buffer": session.buffer.status(), "chat": session.detector.status(),
                "events": [event.to_dict() for event in session.events[-50:]], "evidence_events": len(session.evidence)}

    def _require(self, session_id: str) -> LiveSession:
        session = self.get(session_id)
        if not session:
            raise KeyError(session_id)
        return session

    def _active(self, session_id: str) -> LiveSession:
        session = self._require(session_id)
        if session.state != "monitoring":
            raise RuntimeError("This live session is not monitoring.")
        return session


manager = LiveStreamManager()
