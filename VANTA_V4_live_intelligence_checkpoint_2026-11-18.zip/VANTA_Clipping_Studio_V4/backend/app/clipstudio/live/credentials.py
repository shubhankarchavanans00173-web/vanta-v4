"""Credential resolution for the live chat adapters.

Everything stays on this machine. Nothing here prints, logs or returns a secret value: diagnostics report only whether
a token exists and where it is read from. YouTube reuses the OAuth login the app already has; Twitch reads an optional
``chat:read`` token from the environment and otherwise connects anonymously for public chat.
"""
from __future__ import annotations

import os
from pathlib import Path


class CredentialsError(RuntimeError):
    """Missing or unusable credentials, with an instruction the operator can act on."""


YOUTUBE_SCOPE_NOTE = ("Live chat reading needs the OAuth scope 'youtube.readonly' (or youtube / youtube.force-ssl). "
                      "VANTA requests youtube.readonly when you connect, so an existing connection is normally enough; "
                      "if Google answers 403 insufficientPermissions, disconnect and reconnect YouTube.")


def youtube_token_path(token_path: str | Path | None = None) -> Path:
    if token_path:
        return Path(token_path).expanduser()
    env = os.getenv("YOUTUBE_TOKEN_FILE")
    if env:
        return Path(env).expanduser()
    from ... import youtube as youtube_auth
    return Path(youtube_auth.TOKEN_PATH)


def youtube_diagnostics(token_path: str | Path | None = None) -> dict:
    """Safe facts only: paths and booleans, never token material."""
    from ... import youtube as youtube_auth
    token = youtube_token_path(token_path)
    try:
        secret = Path(youtube_auth.client_secret_path())
    except Exception:                                  # pragma: no cover - only if config is broken
        secret = Path("(unavailable)")
    return {"token_path": str(token), "token_found": token.is_file(),
            "client_secret_path": str(secret), "client_secret_found": secret.is_file(),
            "token_file_env": bool(os.getenv("YOUTUBE_TOKEN_FILE")),
            "client_secret_env": bool(os.getenv("YOUTUBE_CLIENT_SECRET_FILE")),
            "scope_note": YOUTUBE_SCOPE_NOTE}


def youtube_service(token_path: str | Path | None = None):
    """Build an authorised YouTube client from the app's saved OAuth token."""
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
        from googleapiclient.discovery import build
    except ImportError as exc:
        raise CredentialsError("YouTube libraries are missing: pip install google-api-python-client google-auth "
                               "google-auth-oauthlib") from exc
    from ... import youtube as youtube_auth
    token = youtube_token_path(token_path)
    if not token.is_file():
        raise CredentialsError(
            f"No YouTube OAuth token at {token}. Open VANTA once, click 'Connect YouTube' (docs/YOUTUBE_SETUP.md), "
            f"then retry. The OAuth client JSON is read from {youtube_auth.client_secret_path()} "
            "(override with YOUTUBE_CLIENT_SECRET_FILE).")
    try:
        creds = Credentials.from_authorized_user_file(str(token), youtube_auth.SCOPES)
    except Exception as exc:
        raise CredentialsError(f"The saved YouTube token at {token} could not be read. Disconnect and reconnect YouTube.") from exc
    if creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            token.write_text(creds.to_json(), encoding="utf-8")
        except Exception as exc:
            raise CredentialsError("YouTube token refresh failed. Reconnect YouTube in the app, then retry.") from exc
    if not creds.valid:
        raise CredentialsError("The saved YouTube login is no longer valid. Reconnect YouTube in the app, then retry.")
    return build("youtube", "v3", credentials=creds, cache_discovery=False)


def twitch_settings(environ=None) -> dict:
    """``TWITCH_CHANNEL`` (required), ``TWITCH_OAUTH_TOKEN`` (optional), ``TWITCH_NICK`` (optional)."""
    env = os.environ if environ is None else environ
    channel = (env.get("TWITCH_CHANNEL") or "").strip().lstrip("#").lower()
    token = (env.get("TWITCH_OAUTH_TOKEN") or "").strip()
    if token.lower().startswith("oauth:"):
        token = token[6:].strip()
    nick = (env.get("TWITCH_NICK") or "").strip() or None
    return {"channel": channel, "token": token or None, "nick": nick}


def twitch_diagnostics(environ=None) -> dict:
    settings = twitch_settings(environ)
    return {"channel": settings["channel"] or None, "token_present": bool(settings["token"]),
            "nick": settings["nick"], "mode": "authenticated" if settings["token"] else "anonymous (public chat)",
            "token_file_env": False}


def require_twitch_channel(environ=None) -> str:
    channel = twitch_settings(environ)["channel"]
    if not channel:
        raise CredentialsError("No Twitch channel. Pass --channel NAME or set TWITCH_CHANNEL in .env.")
    return channel
