"""Build one chat source, for the terminal runner and for the app.

The caller always supplies the stream clock and the message sink; this module only resolves credentials and wires the
adapter to its polling/reading source. It never starts the source - the session runner owns start/stop order.
"""
from __future__ import annotations

from typing import Callable

from . import credentials
from .chat_sources import TwitchChatSource, YouTubeChatSource
from .twitch_adapter import TwitchChatStream
from .youtube_adapter import YouTubeLiveChatAdapter, find_live_chat_id


def youtube_chat(*, clock: Callable[[], float], on_message, video_id: str | None = None,
                 chat_id: str | None = None) -> YouTubeChatSource:
    service = credentials.youtube_service()
    chat_id = chat_id or find_live_chat_id(service, video_id or "")
    return YouTubeChatSource(YouTubeLiveChatAdapter(service, chat_id, clock=clock), on_message, clock=clock)


def twitch_chat(*, clock: Callable[[], float], on_message, channel: str | None = None,
                timeout: float = 30.0) -> TwitchChatSource:
    name = (channel or credentials.require_twitch_channel()).strip()
    twitch = credentials.twitch_settings()
    stream = TwitchChatStream(name, token=twitch["token"], nick=twitch["nick"], clock=clock, timeout=timeout)
    return TwitchChatSource(stream, on_message, clock=clock)


def build_chat(platform: str, *, clock: Callable[[], float], on_message, video_id: str | None = None,
               chat_id: str | None = None, channel: str | None = None, timeout: float = 30.0):
    if platform == "youtube":
        return youtube_chat(clock=clock, on_message=on_message, video_id=video_id, chat_id=chat_id)
    return twitch_chat(clock=clock, on_message=on_message, channel=channel, timeout=timeout)
