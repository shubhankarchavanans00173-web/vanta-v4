"""Stateful live-chat anomaly detector with bot and copy-spam filtering."""
from __future__ import annotations

import re
from collections import Counter, deque
from dataclasses import dataclass
from statistics import median


_SPACE = re.compile(r"\s+")
_BOT = re.compile(r"(?:^|[_-])(bot|nightbot|streamelements|moobot|wizebot)(?:$|[_-])", re.I)
_REACTION = re.compile(r"\b(what|no way|omg|wow|clutch|insane|wtf|lmao|lol|haha|lets go)\b|[😂🤣💀🔥😭😱]", re.I)


@dataclass(frozen=True)
class ChatMessage:
    timestamp: float
    author: str
    text: str
    platform: str = "unknown"
    is_bot: bool = False

    def normalized(self) -> str:
        return _SPACE.sub(" ", self.text.strip().lower())[:500]


@dataclass(frozen=True)
class ChatSpike:
    timestamp: float
    score: float
    messages_per_second: float
    baseline_messages_per_second: float
    unique_chatters: int
    reaction_ratio: float
    copy_ratio: float
    reasons: tuple[str, ...]

    def to_dict(self) -> dict:
        return {"timestamp": round(self.timestamp, 3), "score": round(self.score, 1),
                "messages_per_second": round(self.messages_per_second, 3), "baseline_messages_per_second": round(self.baseline_messages_per_second, 3),
                "unique_chatters": self.unique_chatters, "reaction_ratio": round(self.reaction_ratio, 3),
                "copy_ratio": round(self.copy_ratio, 3), "reasons": list(self.reasons)}


class ChatSpikeDetector:
    def __init__(self, window_seconds: float = 10.0, history_seconds: float = 120.0, minimum_messages: int = 8, spike_multiplier: float = 3.0):
        if not 3 <= float(window_seconds) <= 60:
            raise ValueError("window_seconds must be between 3 and 60.")
        self.window_seconds, self.history_seconds = float(window_seconds), float(history_seconds)
        self.minimum_messages, self.spike_multiplier = int(minimum_messages), float(spike_multiplier)
        self._messages: deque[ChatMessage] = deque()
        self._velocity_samples: deque[tuple[float, float]] = deque()
        self._recent_author_text: dict[tuple[str, str], float] = {}

    def _prune(self, now: float) -> None:
        while self._messages and self._messages[0].timestamp < now - self.history_seconds:
            self._messages.popleft()
        while self._velocity_samples and self._velocity_samples[0][0] < now - self.history_seconds:
            self._velocity_samples.popleft()
        self._recent_author_text = {k: t for k, t in self._recent_author_text.items() if t >= now - 15.0}

    def ingest(self, message: ChatMessage) -> ChatSpike | None:
        """Add a message and return a spike only when independent activity supports it."""
        if not message.author.strip() or not message.normalized():
            return None
        self._prune(message.timestamp)
        key = (message.author.strip().lower(), message.normalized())
        if message.is_bot or _BOT.search(message.author) or (key in self._recent_author_text and message.timestamp - self._recent_author_text[key] < 8.0):
            return None
        self._recent_author_text[key] = message.timestamp
        self._messages.append(message)
        self._prune(message.timestamp)
        recent = [m for m in self._messages if m.timestamp >= message.timestamp - self.window_seconds]
        velocity = len(recent) / self.window_seconds
        authors = {m.author.strip().lower() for m in recent}
        texts = [m.normalized() for m in recent]
        common = Counter(texts).most_common(1)[0][1] / len(texts) if texts else 1.0
        reactions = sum(1 for m in recent if _REACTION.search(m.text)) / len(recent)
        # Do not let a copy-paste raid redefine normal chat velocity.  It may
        # be legitimate activity, but it is not independent evidence of a
        # moment and would otherwise suppress the next genuine spike.
        if common > 0.72:
            return None
        # Baseline samples must pre-date this exact window so a spike cannot set
        # its own normal level.
        baseline_values = [v for t, v in self._velocity_samples if t < message.timestamp - self.window_seconds]
        baseline = median(baseline_values) if baseline_values else 0.0
        self._velocity_samples.append((message.timestamp, velocity))
        if len(recent) < self.minimum_messages:
            return None
        threshold = max(self.minimum_messages / self.window_seconds, baseline * self.spike_multiplier)
        # A copy-paste raid is not independent audience reaction.  Identical
        # emote-only messages are discounted but not treated as a confirmed event.
        if velocity < threshold or len(authors) < 3:
            return None
        score = min(100.0, 35 + 35 * min(1.0, velocity / max(threshold, 0.01)) + 15 * min(1.0, len(authors) / 12) + 15 * reactions - 25 * common)
        reasons = [f"chat velocity {velocity:.1f}/s vs {baseline:.1f}/s baseline", f"{len(authors)} unique chatters"]
        if reactions >= 0.25:
            reasons.append(f"{reactions * 100:.0f}% reaction-language/emote messages")
        return ChatSpike(message.timestamp, score, velocity, baseline, len(authors), reactions, common, tuple(reasons))

    def status(self, now: float | None = None) -> dict:
        now = now if now is not None else (self._messages[-1].timestamp if self._messages else 0.0)
        recent = [m for m in self._messages if m.timestamp >= now - self.window_seconds]
        return {"messages_per_second": round(len(recent) / self.window_seconds, 3), "active_chatters": len({m.author.lower() for m in recent}),
                "tracked_messages": len(self._messages), "window_seconds": self.window_seconds}
