"""Twitch IRC: line parsing plus a small, dependency-free TLS chat reader.

Twitch chat is IRC. VANTA speaks it with the standard library only (``socket`` + ``ssl``) so the project needs no
extra package. Read-only: the connection joins one channel, never sends PRIVMSG, and needs no credential for
public chat (anonymous ``justinfan`` nick). Supplying ``TWITCH_OAUTH_TOKEN`` (scope ``chat:read``) authenticates
the same connection when anonymous access is refused.
"""
from __future__ import annotations

import random
import re
import socket
import ssl
from typing import Callable

from .chat_spike_detector import ChatMessage

_PRIVMSG = re.compile(r"^(?:@(?P<tags>[^ ]+) )?:(?P<nick>[^!]+)![^ ]+ PRIVMSG #[^ ]+ :(?P<text>.*)$")
_AUTH_FAILED = "Login authentication failed"
_HTTP_BAD = "HTTP/1.1 400"


class TwitchAdapterError(RuntimeError):
    pass


def parse_irc_line(line: str, timestamp: float) -> ChatMessage | None:
    """Parse one Twitch IRC chat line. PING and non-chat events return None."""
    match = _PRIVMSG.match(line.strip())
    if not match:
        return None
    tags = dict(part.split("=", 1) if "=" in part else (part, "") for part in (match.group("tags") or "").split(";") if part)
    return ChatMessage(timestamp, tags.get("user-id") or match.group("nick"), match.group("text"), "twitch", tags.get("user-type") == "bot")


class TwitchChatStream:
    """One read-only IRC connection to a single channel, parsed into ``ChatMessage``s."""

    def __init__(self, channel: str, *, token: str | None = None, nick: str | None = None,
                 clock: Callable[[], float] | None = None, host: str = "irc.chat.twitch.tv", port: int = 6697,
                 tls: bool = True, timeout: float = 30.0, socket_factory: Callable | None = None,
                 wrap_tls: Callable | None = None):
        cleaned = (channel or "").strip().lstrip("#").lower()
        if not cleaned:
            raise TwitchAdapterError("A Twitch channel name is required.")
        self.channel, self.host, self.port, self.tls, self.timeout = cleaned, host, int(port), bool(tls), float(timeout)
        self.token = (token or "").strip() or None
        self.nick = (nick or "").strip() or f"justinfan{random.randint(10000, 99999)}"
        self.clock = clock or (lambda: 0.0)
        self._socket_factory = socket_factory or (lambda host, port: socket.create_connection((host, port), timeout))
        self._wrap_tls = wrap_tls or (lambda sock: ssl.create_default_context().wrap_socket(sock, server_hostname=host))
        self._sock = None
        self._pending = ""
        self.connected = False

    # ------------------------------------------------------------------ connection
    def connect(self) -> "TwitchChatStream":
        try:
            sock = self._socket_factory(self.host, self.port)
            sock.settimeout(self.timeout)
            if self.tls:
                sock = self._wrap_tls(sock)
        except OSError as exc:
            raise TwitchAdapterError(f"Could not reach Twitch IRC at {self.host}:{self.port}: {exc}") from exc
        self._sock, self.connected, self._pending = sock, True, ""
        if self.token:
            self.send(f"PASS oauth:{self.token}")
        self.send(f"NICK {self.nick}")
        self.send(f"JOIN #{self.channel}")
        return self

    def send(self, line: str) -> None:
        if self._sock is None:
            raise TwitchAdapterError("The Twitch IRC connection is not open.")
        try:
            self._sock.sendall((line + "\r\n").encode("utf-8"))
        except OSError as exc:
            raise TwitchAdapterError(f"Twitch IRC write failed: {exc}") from exc

    def read(self) -> list[ChatMessage]:
        """One receive; returns parsed chat messages, answers PING, and fails loudly on auth/reconnect notices."""
        if self._sock is None:
            raise TwitchAdapterError("The Twitch IRC connection is not open.")
        try:
            data = self._sock.recv(8192)
        except socket.timeout as exc:
            raise TwitchAdapterError("Twitch IRC read timed out.") from exc
        except OSError as exc:
            raise TwitchAdapterError(f"Twitch IRC read failed: {exc}") from exc
        if not data:
            raise TwitchAdapterError("Twitch closed the chat connection.")
        self._pending += data.decode("utf-8", "replace")
        lines = self._pending.split("\n")
        self._pending = lines.pop()
        stamp, out = float(self.clock()), []
        for raw in lines:
            line = raw.rstrip("\r")
            if not line:
                continue
            if line.startswith("PING"):
                self.send("PONG :tmi.twitch.tv")
                continue
            if _AUTH_FAILED in line:
                raise TwitchAdapterError("Twitch rejected the credential. Check TWITCH_OAUTH_TOKEN (scope chat:read) or leave it empty for anonymous read.")
            if _HTTP_BAD in line:
                raise TwitchAdapterError("Twitch refused the IRC upgrade. Use TLS port 6697, or turn TLS off only on a trusted network.")
            if line.startswith(":tmi.twitch.tv RECONNECT"):
                raise TwitchAdapterError("Twitch asked the client to reconnect.")
            message = parse_irc_line(line, stamp)
            if message is not None:
                out.append(message)
        return out

    def close(self) -> None:
        self.connected = False
        if self._sock is not None:
            try:
                self._sock.close()
            finally:
                self._sock = None
