"""Authorized YouTube Live Chat polling adapter.

The adapter accepts an already-authorized Google client.  VANTA neither creates
browser login flows here nor uses video downloads to circumvent stream access.

Polling ``liveChatMessages.list`` costs 5 quota units per call (the API's own
number), so this adapter records the server's ``pollingIntervalMillis`` and the
chat source honours it instead of hammering the endpoint.
"""
from __future__ import annotations

from typing import Callable

from .chat_spike_detector import ChatMessage


class YouTubeAdapterError(RuntimeError):
    pass


def find_live_chat_id(service, video_id: str) -> str:
    """Resolve the active chat id for a live video, with an honest reason when there is none."""
    if not (video_id or "").strip():
        raise YouTubeAdapterError("A YouTube video id is required to find its live chat.")
    try:
        data = service.videos().list(part="liveStreamingDetails", id=video_id.strip()).execute()
    except Exception as exc:                       # Google client raises several transport-specific types
        raise YouTubeAdapterError(f"YouTube video lookup failed: {type(exc).__name__}: {str(exc)[:180]}") from exc
    items = data.get("items") or []
    if not items:
        raise YouTubeAdapterError(f"YouTube has no video with id {video_id!r} (check the id and that it is visible to you).")
    details = items[0].get("liveStreamingDetails") or {}
    chat_id = details.get("activeLiveChatId")
    if not chat_id:
        raise YouTubeAdapterError("That video has no active live chat right now. Start the stream (chat enabled) and try again.")
    return chat_id


class YouTubeLiveChatAdapter:
    def __init__(self, service, live_chat_id: str, clock: Callable[[], float] | None = None):
        if not live_chat_id:
            raise YouTubeAdapterError("A YouTube liveChatId is required.")
        self.service, self.live_chat_id, self.page_token = service, live_chat_id, None
        # Stream time for each message. The runner supplies the buffer clock; 0.0 keeps the adapter usable
        # on its own (the timestamp is then replaced by the caller).
        self.clock = clock or (lambda: 0.0)
        self.poll_interval_ms = 2000

    def poll(self) -> list[ChatMessage]:
        try:
            request = self.service.liveChatMessages().list(liveChatId=self.live_chat_id, part="snippet,authorDetails", pageToken=self.page_token)
            data = request.execute()
        except Exception as exc:  # Google client exposes several transport-specific error types.
            raise YouTubeAdapterError(f"YouTube Live Chat poll failed: {type(exc).__name__}: {str(exc)[:180]}") from exc
        self.page_token = data.get("nextPageToken", self.page_token)
        try:
            self.poll_interval_ms = max(250, int(data.get("pollingIntervalMillis") or self.poll_interval_ms))
        except (TypeError, ValueError):
            pass
        stamp = float(self.clock())
        out: list[ChatMessage] = []
        for item in data.get("items", []):
            snippet, author = item.get("snippet") or {}, item.get("authorDetails") or {}
            text = snippet.get("displayMessage") or ""
            out.append(ChatMessage(stamp, author.get("channelId") or author.get("displayName") or "unknown", text, "youtube",
                                   bool(author.get("isChatModerator") and False)))
        return out
