"""Safe, bounded live-buffer clip assembly using the existing local FFmpeg."""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from .event_correlator import LiveEvent
from .rolling_buffer import RollingBuffer


class LiveClipError(RuntimeError):
    pass


class LiveClipWorker:
    def __init__(self, output_dir: Path, ffmpeg_timeout: float = 180.0):
        self.output_dir = Path(output_dir)
        self.ffmpeg_timeout = ffmpeg_timeout

    def plan(self, buffer: RollingBuffer, event: LiveEvent, before_seconds: float = 30.0, after_seconds: float = 8.0) -> dict:
        segments, coverage = buffer.window(event.event_time, before_seconds, after_seconds)
        return {"event": event.to_dict(), "segments": [s.to_dict() for s in segments], "coverage": coverage,
                "start": coverage["requested_start"], "end": coverage["requested_end"]}

    def assemble(self, buffer: RollingBuffer, event: LiveEvent, output_name: str, before_seconds: float = 30.0, after_seconds: float = 8.0) -> dict:
        """Create a review-only MP4 once the configured post-event footage exists.

        The window is leased, not merely read: the ingest may prune the buffer at any moment, so these files are
        pinned for the whole FFmpeg run and only released afterwards. See ``RollingBuffer.lease_window``.
        """
        segments, coverage, lease = buffer.lease_window(event.event_time, before_seconds, after_seconds)
        plan = {"event": event.to_dict(), "segments": [s.to_dict() for s in segments], "coverage": coverage,
                "start": coverage["requested_start"], "end": coverage["requested_end"]}
        try:
            return self._assemble_leased(plan, segments, output_name)
        finally:
            lease.release()          # deletion of these segments resumes after this point

    def _assemble_leased(self, plan: dict, segments: list, output_name: str) -> dict:
        if not plan["coverage"]["ready"]:
            return {**plan, "status": "pending_post_event_footage"}
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            raise LiveClipError("FFmpeg is not installed; the live clip could not be assembled.")
        paths = [Path(s.path) for s in segments]
        if not paths or any(not p.is_file() for p in paths):
            raise LiveClipError("One or more buffered media segments are no longer available.")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        safe_stem = "".join(c if c.isalnum() or c in "-_" else "_" for c in output_name)[:80] or "live_clip"
        output = self.output_dir / f"{safe_stem}.mp4"
        manifest = self.output_dir / f".{safe_stem}.concat.txt"
        # FFmpeg concat manifests use single quotes; quote a literal quote for
        # the demuxer and never place user-provided shell text in a command.
        manifest.write_text("".join("file '" + str(p.resolve()).replace("'", r"'\\''") + "'\n" for p in paths), encoding="utf-8")
        try:
            # Re-encode gives accurate contextual boundaries across segment
            # keyframes.  It runs in a worker, never the FastAPI event loop.
            concat_offset = max(0.0, float(plan["start"]) - float(plan["segments"][0]["start"]))
            command = [ffmpeg, "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(manifest),
                       "-ss", str(concat_offset),
                       "-t", str(max(0.1, plan["end"] - plan["start"])), "-c:v", "libx264", "-preset", "veryfast", "-c:a", "aac", str(output)]
            # Segment timestamps are normalised by the ingest process; trimming
            # against the concat-relative offset avoids trusting file metadata.
            subprocess.run(command, check=True, timeout=self.ffmpeg_timeout, capture_output=True)
        except subprocess.TimeoutExpired as exc:
            output.unlink(missing_ok=True)
            raise LiveClipError("Live clip assembly timed out.") from exc
        except subprocess.CalledProcessError as exc:
            output.unlink(missing_ok=True)
            detail = (exc.stderr or b"").decode("utf-8", "replace")[-300:].strip()
            raise LiveClipError("FFmpeg could not assemble the live clip" + (f": {detail}" if detail else ".")) from exc
        finally:
            manifest.unlink(missing_ok=True)
        return {**plan, "status": "ready_for_review", "path": str(output), "duration": round(plan["end"] - plan["start"], 3)}
