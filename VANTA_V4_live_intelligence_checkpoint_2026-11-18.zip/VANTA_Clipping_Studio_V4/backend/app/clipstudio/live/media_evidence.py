"""Bounded, local-only audio evidence worker for live segments.

It detects sustained, unusually strong audio energy. This is deliberately labelled
`audio intensity`: it does not claim laughter, humour, excitement, or gameplay.
No model is downloaded and FFmpeg runs with bounded timeouts.
"""
from __future__ import annotations

import array
import math
import shutil
import subprocess
import threading
import time
from collections import deque
from pathlib import Path
from typing import Callable

from .event_correlator import EvidenceEvent, LiveEvent


class MediaEvidenceWorker:
    def __init__(self, manager, session, *, ffmpeg: str | None = None,
                 poll_seconds: float = 0.5, min_rms: float = 4200.0,
                 ratio: float = 2.8, refractory_seconds: float = 12.0,
                 max_segments_per_pass: int = 3):
        self.manager, self.session = manager, session
        self.ffmpeg = ffmpeg or shutil.which("ffmpeg")
        self.poll_seconds = max(0.1, float(poll_seconds))
        self.min_rms, self.ratio = float(min_rms), float(ratio)
        self.refractory_seconds = float(refractory_seconds)
        self.max_segments_per_pass = max(1, int(max_segments_per_pass))
        self._seen: set[str] = set()
        self._levels: deque[float] = deque(maxlen=60)
        self._last_event = -1e9
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._error: str | None = None
        self._processed = 0
        self._events = 0

    def start(self) -> dict:
        if self._thread and self._thread.is_alive():
            return self.status()
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name=f"live-audio-evidence-{self.session.id}", daemon=True)
        self._thread.start()
        return self.status()

    def stop(self, timeout: float = 3.0) -> dict:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=max(0.0, timeout))
        return self.status()

    def status(self) -> dict:
        return {"available": bool(self.ffmpeg), "engine": "ffmpeg_pcm_energy", "processed_segments": self._processed,
                "events": self._events, "error": self._error, "running": bool(self._thread and self._thread.is_alive()),
                "capability_note": "Detects audio intensity only; does not identify laughter, jokes, or gameplay."}

    def _run(self):
        while not self._stop.wait(self.poll_seconds):
            try:
                segments = self.session.buffer.snapshot()
                pending = [s for s in segments if str(s.path) not in self._seen][:self.max_segments_per_pass]
                for segment in pending:
                    if self._stop.is_set():
                        break
                    self._seen.add(str(segment.path))
                    self._analyse(segment.path, segment.start, segment.end)
                    self._processed += 1
            except Exception as exc:  # one bad segment must not kill monitoring
                self._error = f"{type(exc).__name__}: {str(exc)[:240]}"

    def _analyse(self, path: Path, start: float, end: float):
        if not self.ffmpeg:
            self._error = "FFmpeg unavailable; audio evidence disabled."
            return
        command = [self.ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-i", str(path),
                   "-vn", "-ac", "1", "-ar", "8000", "-f", "s16le", "pipe:1"]
        try:
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    timeout=max(5.0, (end-start)*3), check=False)
        except (OSError, subprocess.TimeoutExpired) as exc:
            self._error = f"Audio analysis failed: {type(exc).__name__}"
            return
        if result.returncode != 0 or len(result.stdout) < 16000:
            self._error = "Audio stream unavailable in a live segment."
            return
        samples = array.array("h")
        samples.frombytes(result.stdout[:len(result.stdout) - (len(result.stdout) % 2)])
        # 0.5-second windows at 8 kHz; compare each window to recent history.
        width = 4000
        local: list[tuple[float, float]] = []
        for offset in range(0, len(samples)-width+1, width):
            frame = samples[offset:offset+width]
            rms = math.sqrt(sum(int(v)*int(v) for v in frame) / width)
            timestamp = start + offset / 8000.0 + 0.25
            local.append((timestamp, rms))
        for timestamp, rms in local:
            baseline = sorted(self._levels)[len(self._levels)//2] if self._levels else 0.0
            threshold = max(self.min_rms, baseline * self.ratio)
            if rms >= threshold and timestamp - self._last_event >= self.refractory_seconds:
                evidence = EvidenceEvent(max(start, timestamp-0.5), min(end, timestamp+0.5),
                                         "audio intensity", min(65.0, 40.0 + min(25.0, rms / 1000.0)),
                                         f"FFmpeg PCM RMS {rms:.0f}; baseline {baseline:.0f}; audio-intensity signal only")
                self.manager.add_evidence(self.session.id, evidence)
                event = LiveEvent(timestamp, timestamp, "audio intensity", evidence.confidence,
                                  ("unusually high audio energy", evidence.evidence))
                self.session.events.append(event)
                if self.manager.on_event:
                    self.manager.on_event(self.session, event)
                self._last_event = timestamp
                self._events += 1
            self._levels.append(rms)
