"""Local (free, offline after setup) speech-to-text with faster-whisper.

Design rules
* Nothing is ever downloaded implicitly. A model download is a separate, explicit, cancellable action
  (``DOWNLOADER.start``) that the API only allows after the user confirmed it; analysis jobs never touch the network.
* CPU + int8 is the default (works on any PC, including a 4 GB GTX 1650 machine). CUDA is used only when the CUDA
  runtime is really present *and* the model is small, or when the operator forces ``VANTA_WHISPER_DEVICE=cuda``;
  if CUDA fails at run time the job is retried once on CPU and the note says so.
* Word timestamps are kept only when the engine produced them for real, and malformed ones are dropped.
* Progress is real (audio position / audio duration), cancel is checked after every decoded segment.
* A finished transcript is cached by a content fingerprint of the media file + model + language.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from functools import lru_cache
from pathlib import Path
from typing import Callable

from . import settings
from .transcript import Segment, Transcript, TranscriptCancelled, TranscriptError, Word, _clean

CACHE_VERSION = 1
DEFAULT_MODEL = "small"

# Approximate download sizes (MiB) of the CTranslate2 model repositories. Only used to warn the user and to estimate
# download progress; they are labelled "approximate" everywhere they are shown.
MODEL_INFO: dict[str, int] = {
    "tiny": 75, "tiny.en": 75, "base": 145, "base.en": 145, "small": 485, "small.en": 485,
    "medium": 1530, "medium.en": 1530, "large-v3": 3090, "large-v3-turbo": 1620, "distil-large-v3": 1510,
}
# CUDA is chosen automatically only for these (a 4 GB card cannot be assumed to hold anything bigger).
GPU_AUTO_MODELS = {"tiny", "tiny.en", "base", "base.en", "small", "small.en"}
MODEL_NOTES = {
    "tiny": "fastest, lowest accuracy", "base": "fast, modest accuracy", "small": "recommended default: good accuracy on CPU",
    "medium": "more accurate, slow on CPU", "large-v3": "most accurate, very slow on CPU, needs a lot of memory",
    "large-v3-turbo": "near large accuracy, faster; still heavy on CPU", "distil-large-v3": "English-focused, fast for its size",
}


# --------------------------------------------------------------------------- configuration
def installed() -> bool:
    return importlib.util.find_spec("faster_whisper") is not None


def library_version() -> str | None:
    if not installed():
        return None
    try:
        from importlib.metadata import version
        return version("faster-whisper")
    except Exception:
        return None


def configured_model() -> str:
    return (os.getenv("VANTA_WHISPER_MODEL") or DEFAULT_MODEL).strip()


def validate_model(name: str) -> str:
    """Known model names, or an existing local model folder (operator-configured only). Arbitrary hub repos are not accepted."""
    name = (name or "").strip()
    if name in MODEL_INFO:
        return name
    if name and Path(name).is_dir() and (Path(name) / "model.bin").is_file():
        return str(Path(name))
    raise TranscriptError(f"Unknown transcription model {name!r}. Choose one of: {', '.join(MODEL_INFO)}.")


def _complete(folder: Path) -> bool:
    return (folder / "model.bin").is_file() and (folder / "config.json").is_file() and (
        (folder / "tokenizer.json").is_file() or any(folder.glob("vocabulary.*")))


def _repo_dirname(name: str) -> str:
    try:
        from faster_whisper.utils import _MODELS  # type: ignore
        repo = _MODELS.get(name) or f"Systran/faster-whisper-{name}"
    except Exception:
        repo = f"Systran/faster-whisper-{name}"
    return "models--" + repo.replace("/", "--")


def model_path(name: str) -> Path | None:
    """Folder of a fully downloaded model, or None. Never touches the network."""
    p = Path(name)
    if name not in MODEL_INFO:
        return p if p.is_dir() and _complete(p) else None
    snaps = settings.MODELS_DIR / _repo_dirname(name) / "snapshots"
    for rev in sorted(snaps.glob("*")) if snaps.is_dir() else []:
        if rev.is_dir() and _complete(rev):
            return rev
    return None


@lru_cache(maxsize=1)
def cuda_available() -> bool:
    try:
        import ctranslate2  # type: ignore
        return int(ctranslate2.get_cuda_device_count()) > 0
    except Exception:
        return False


def plan_device(model: str) -> tuple[str, str, str]:
    """-> (device, compute_type, reason)."""
    want = (os.getenv("VANTA_WHISPER_DEVICE") or "auto").strip().lower()
    compute_env = (os.getenv("VANTA_WHISPER_COMPUTE") or "").strip()
    device, reason = "cpu", "CPU (default)"
    if want == "cuda":
        if cuda_available():
            device, reason = "cuda", "CUDA (forced by VANTA_WHISPER_DEVICE)"
        else:
            reason = "CPU (CUDA was requested but no CUDA device/runtime was found)"
    elif want == "auto" and cuda_available() and model in GPU_AUTO_MODELS:
        device, reason = "cuda", "CUDA (auto, small model)"
    elif want == "auto" and cuda_available():
        reason = "CPU (the model is too large to assume it fits a small GPU; set VANTA_WHISPER_DEVICE=cuda to force it)"
    compute = compute_env or ("int8_float16" if device == "cuda" else "int8")
    return device, compute, reason


def cpu_threads() -> int:
    try:
        return max(0, int(os.getenv("VANTA_WHISPER_THREADS", "0")))
    except ValueError:
        return 0


def availability(model: str) -> tuple[bool, str]:
    if not installed():
        return False, "faster-whisper is not installed (run enable_local_transcription.bat or: pip install faster-whisper)."
    try:
        model = validate_model(model)
    except TranscriptError as e:
        return False, str(e)
    if model_path(model) is None:
        mb = MODEL_INFO.get(model)
        size = f" (about {mb} MB)" if mb else ""
        return False, (f"The '{model}' model is not downloaded yet{size}. Download it once in AI Models (after you approve it), "
                       "or upload an .srt/.vtt/.json transcript instead.")
    device, compute, _ = plan_device(model)
    return True, f"model {model}, {device} {compute}"


def status() -> dict:
    """Cheap, side-effect free description for the UI (no network, no model load)."""
    model = configured_model()
    models = [{"name": n, "approx_mb": mb, "cached": model_path(n) is not None, "note": MODEL_NOTES.get(n, "")} for n, mb in MODEL_INFO.items()]
    try:
        validate_model(model)
        valid = True
    except TranscriptError:
        valid = False
    device, compute, reason = plan_device(model) if valid else ("cpu", "int8", "CPU")
    ok, detail = availability(model)
    return {"installed": installed(), "library_version": library_version(), "model": model, "model_valid": valid,
            "model_cached": bool(valid and model_path(model)), "ready": ok, "detail": detail,
            "device": device, "compute_type": compute, "device_reason": reason, "cuda_available": cuda_available() if installed() else False,
            "cache_dir": str(settings.MODELS_DIR), "models": models, "download": DOWNLOADER.state(),
            "recommended_model": DEFAULT_MODEL, "uploads_supported": [".srt", ".vtt", ".json"]}


# --------------------------------------------------------------------------- transcription
def _load_model(path: str, device: str, compute: str):  # separate function so tests can replace it
    from faster_whisper import WhisperModel  # type: ignore
    return WhisperModel(path, device=device, compute_type=compute, cpu_threads=cpu_threads(), local_files_only=True)


def _clean_words(words, seg_start: float, seg_end: float) -> list[Word] | None:
    """Keep only well-formed, monotonic word timings that sit inside (a little around) their segment; else None (=sentence-level)."""
    out: list[Word] = []
    last_end = seg_start
    for w in words or []:
        text = str(getattr(w, "word", "")).strip()
        try:
            s, e = float(w.start), float(w.end)
        except (TypeError, ValueError, AttributeError):
            continue
        if not text or e < s or s < seg_start - 0.5 or e > seg_end + 0.5:
            continue
        s = max(s, last_end)
        if e <= s:
            continue
        out.append(Word(text, s, e))
        last_end = e
    return out or None


def _run(path: Path, media: Path, language: str | None, device: str, compute: str, progress, cancelled, duration_hint: float | None):
    model = _load_model(str(path), device, compute)
    raw, info = model.transcribe(str(media), language=language, word_timestamps=True, vad_filter=True,
                                 condition_on_previous_text=False)
    total = float(getattr(info, "duration", 0) or duration_hint or 0)
    segments: list[Segment] = []
    last_report = float("-inf")
    for seg in raw:
        if cancelled():
            raise TranscriptCancelled("Transcription cancelled.")
        text = _clean(seg.text)
        if text:
            s, e = float(seg.start), float(seg.end)
            segments.append(Segment(s, e, text, _clean_words(getattr(seg, "words", None), s, e)))
        if total > 0 and time.monotonic() - last_report >= 0.5:
            last_report = time.monotonic()
            frac = min(0.99, max(0.0, float(seg.end) / total))
            progress(frac, f"Transcribing locally - {int(frac * 100)}% of the audio")
    return segments, info


def transcribe(media: Path, language: str | None, model_name: str, *, progress: Callable[[float | None, str], None] = lambda p, m: None,
               cancelled: Callable[[], bool] = lambda: False, duration_hint: float | None = None) -> tuple[Transcript, list[str]]:
    """-> (transcript, notes). Raises TranscriptError / TranscriptCancelled. Never downloads anything."""
    ok, detail = availability(model_name)
    if not ok:
        raise TranscriptError(detail)
    model_name = validate_model(model_name)
    path = model_path(model_name)
    assert path is not None
    device, compute, _reason = plan_device(model_name)
    notes: list[str] = []
    try:
        try:
            segments, info = _run(path, media, language, device, compute, progress, cancelled, duration_hint)
        except TranscriptCancelled:
            raise
        except Exception as error:
            if device != "cuda":
                raise
            notes.append(f"CUDA transcription failed ({str(error)[:120]}); retried on the CPU.")
            device, compute = "cpu", "int8"
            segments, info = _run(path, media, language, device, compute, progress, cancelled, duration_hint)
    except TranscriptCancelled:
        raise
    except TranscriptError:
        raise
    except Exception as error:  # corrupt audio, out of memory, missing codec ... are environment specific
        raise TranscriptError(f"Local transcription failed: {type(error).__name__}: {str(error)[:300]}") from error
    if not segments:
        raise TranscriptError("The transcription engine found no speech in this video.")
    progress(1.0, "Transcription finished")
    tr = Transcript(segments, "faster-whisper", getattr(info, "language", None) or language)
    if not tr.word_level:
        notes.append("Some segments have no word timings, so captions for this transcript are sentence-level.")
    notes.append(f"Transcribed locally with faster-whisper ({model_name}, {device} {compute}).")
    return tr, notes


# --------------------------------------------------------------------------- transcript cache
def media_fingerprint(path: Path) -> str:
    """Size + hash of the first, middle and last MiB: cheap, content based (a renamed copy still hits), changes when the file changes."""
    path = Path(path)
    size = path.stat().st_size
    h = hashlib.sha256(str(size).encode())
    chunk = 1024 * 1024
    with open(path, "rb") as f:
        for off in (0, max(0, size // 2 - chunk // 2), max(0, size - chunk)):
            f.seek(off)
            h.update(f.read(chunk))
    return h.hexdigest()


def cache_key(media: Path, model: str, language: str | None) -> str:
    return hashlib.sha256(f"{media_fingerprint(media)}|{model}|{language or 'auto'}|v{CACHE_VERSION}".encode()).hexdigest()[:40]


def cache_get(key: str) -> Transcript | None:
    f = settings.TRANSCRIPT_CACHE_DIR / f"{key}.json"
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
        tr = Transcript.from_dict(data["transcript"])
        return tr if tr.available else None
    except (OSError, ValueError, KeyError, TypeError):
        return None


def cache_put(key: str, tr: Transcript, model: str, language: str | None, keep: int = 200) -> None:
    d = settings.TRANSCRIPT_CACHE_DIR
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / f".{key}.tmp"
    tmp.write_text(json.dumps({"key": key, "model": model, "language_request": language, "created": time.time(), "transcript": tr.to_dict()}), encoding="utf-8")
    os.replace(tmp, d / f"{key}.json")
    files = sorted(d.glob("*.json"), key=lambda p: p.stat().st_mtime)
    for old in files[:-keep]:
        old.unlink(missing_ok=True)


def cache_drop(key: str | None) -> None:
    if key and all(c in "0123456789abcdef" for c in key):
        (settings.TRANSCRIPT_CACHE_DIR / f"{key}.json").unlink(missing_ok=True)


# --------------------------------------------------------------------------- explicit model download
class DownloadError(RuntimeError):
    def __init__(self, message: str, code: str = "download_failed"):
        super().__init__(message)
        self.code = code


_DOWNLOAD_SCRIPT = ("import sys\nfrom faster_whisper.utils import download_model\n"
                    "download_model(sys.argv[1], cache_dir=sys.argv[2])\n")


def _download_command(model: str, models_dir: Path) -> list[str]:
    return [sys.executable, "-I", "-c", _DOWNLOAD_SCRIPT, model, str(models_dir)]


def _classify(stderr: str) -> tuple[str, str]:
    low = stderr.lower()
    if any(k in low for k in ("no space left", "errno 28", "not enough space", "disk full")):
        return "disk_full", "The disk is full. Free some space and try again."
    if any(k in low for k in ("connection", "name or service", "max retries", "timed out", "proxyerror", "offline", "ssl", "getaddrinfo", "unreachable")):
        return "network", "Could not reach the model host (Hugging Face). Check your internet connection or proxy and try again, or upload an .srt/.vtt transcript."
    return "download_failed", "The model download failed: " + (stderr.strip().splitlines() or ["unknown error"])[-1][:200]


def _dir_bytes(folder: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(folder):
        for n in files:
            try:
                total += (Path(root) / n).stat().st_size
            except OSError:
                pass
    return total


class ModelDownloader:
    """One model download at a time, in a child process so it can really be cancelled. Progress = bytes on disk / approximate size."""

    def __init__(self, command_factory: Callable[[str, Path], list[str]] | None = None, poll: float = 0.5):
        self._factory = command_factory
        self._poll = poll
        self._lock = threading.Lock()
        self._proc: subprocess.Popen | None = None
        self._cancel = False
        self._thread: threading.Thread | None = None
        self._state: dict = {"status": "idle", "model": None, "progress": None, "message": None, "error": None, "error_code": None}

    def state(self) -> dict:
        with self._lock:
            return dict(self._state)

    def _set(self, **kw) -> None:
        with self._lock:
            self._state.update(kw)

    def active(self) -> bool:
        with self._lock:
            return self._state["status"] == "downloading"

    def start(self, model: str) -> dict:
        model = (model or "").strip()
        if model not in MODEL_INFO:
            raise DownloadError(f"Unknown model {model!r}. Choose one of: {', '.join(MODEL_INFO)}.", "unknown_model")
        if not installed():
            raise DownloadError("faster-whisper is not installed, so a model cannot be used yet.", "not_installed")
        if model_path(model) is not None:
            raise DownloadError(f"The '{model}' model is already downloaded.", "already_downloaded")
        models_dir = settings.MODELS_DIR
        models_dir.mkdir(parents=True, exist_ok=True)
        need = MODEL_INFO[model] * 1024 * 1024
        free = shutil.disk_usage(models_dir).free
        if free < need * 1.2:
            raise DownloadError(f"Not enough free disk space: the '{model}' model needs about {MODEL_INFO[model]} MB and {free // 1024 // 1024} MB is free.", "disk_full")
        with self._lock:
            if self._state["status"] == "downloading":
                raise DownloadError("A model download is already running.", "busy")
            self._cancel = False
            self._state.update(status="downloading", model=model, progress=0.0, message=f"Downloading the '{model}' model (about {MODEL_INFO[model]} MB)", error=None, error_code=None)
        existed = (models_dir / _repo_dirname(model)).exists()
        self._thread = threading.Thread(target=self._run, args=(model, models_dir, existed), daemon=True, name="vanta-model-download")
        self._thread.start()
        return self.state()

    def cancel(self) -> dict:
        with self._lock:
            if self._state["status"] != "downloading":
                raise DownloadError("No model download is running.", "idle")
            self._cancel = True
            proc = self._proc
        if proc is not None and proc.poll() is None:
            proc.terminate()
        return self.state()

    def _run(self, model: str, models_dir: Path, existed: bool) -> None:
        repo_dir = models_dir / _repo_dirname(model)
        err = tempfile.TemporaryFile("w+", encoding="utf-8", errors="replace")
        try:
            cmd = (self._factory or _download_command)(model, models_dir)
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=err)
            with self._lock:
                self._proc = proc
            expected = MODEL_INFO[model] * 1024 * 1024
            while proc.poll() is None:
                if self._cancel:
                    proc.terminate()
                    try:
                        proc.wait(10)
                    except subprocess.TimeoutExpired:
                        proc.kill(); proc.wait()
                    break
                frac = min(0.99, _dir_bytes(repo_dir) / expected) if repo_dir.exists() else 0.0
                self._set(progress=round(frac, 3), message=f"Downloading the '{model}' model - {int(frac * 100)}% (approximate)")
                time.sleep(self._poll)
            if self._cancel:
                if not existed:
                    shutil.rmtree(repo_dir, ignore_errors=True)
                self._set(status="cancelled", progress=None, message="Model download cancelled; partial files were removed.")
                return
            if proc.returncode == 0:
                if model_path(model) is None:
                    self._set(status="failed", progress=None, error="The download finished but the model files are incomplete.", error_code="incomplete", message="Download failed")
                else:
                    self._set(status="done", progress=1.0, message=f"The '{model}' model is ready.")
                return
            err.seek(0)
            code, msg = _classify(err.read()[-2000:])
            if not existed:
                shutil.rmtree(repo_dir, ignore_errors=True)
            self._set(status="failed", progress=None, error=msg, error_code=code, message="Download failed")
        except Exception as e:  # e.g. cannot start the child process
            self._set(status="failed", progress=None, error=f"Could not start the download: {str(e)[:160]}", error_code="download_failed", message="Download failed")
        finally:
            err.close()
            with self._lock:
                self._proc = None


DOWNLOADER = ModelDownloader()
