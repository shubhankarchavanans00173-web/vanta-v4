"""Cached environment probes: JS runtime, FFmpeg, yt-dlp-ejs, folder writability (split from ytdlp.py; re-exported there).

The patched-in-tests functions installed/version/base_command/diagnostics deliberately stay in ytdlp.py."""
from __future__ import annotations

import importlib.metadata
import os
import re
import shutil
import subprocess
import time
from datetime import date
from pathlib import Path
from typing import Callable

from .ytdlp_const import JS_RUNTIMES, _JS_MIN_MAJOR

_CACHE: dict[str, tuple[float, object]] = {}
_CACHE_TTL = 30.0


def reset_caches() -> None:
    _CACHE.clear()


def _cached(key: str, fn: Callable[[], object]):
    now = time.monotonic()
    hit = _CACHE.get(key)
    if hit and now - hit[0] < _CACHE_TTL:
        return hit[1]
    value = fn()
    _CACHE[key] = (now, value)
    return value

def ejs_version() -> str | None:
    try:
        return importlib.metadata.version("yt-dlp-ejs")
    except importlib.metadata.PackageNotFoundError:
        return None


def version_age_days(ver: str | None) -> int | None:
    m = re.match(r"^(\d{4})\.(\d{1,2})\.(\d{1,2})", ver or "")
    if not m:
        return None
    try:
        return (date.today() - date(int(m[1]), int(m[2]), int(m[3]))).days
    except ValueError:
        return None

def _tool_version(exe: str) -> str | None:
    try:
        r = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=6, check=False, encoding="utf-8", errors="replace")
        line = ((r.stdout or r.stderr or "").strip().splitlines() or [""])[0]
        return line[:80] or None
    except (OSError, subprocess.SubprocessError):
        return None


def _major(ver: str | None) -> int | None:
    m = re.search(r"(\d+)\.", ver or "")
    return int(m[1]) if m else None


def js_runtime_info() -> dict:
    """Find a JavaScript runtime that yt-dlp can use for YouTube's player challenge (Deno 2+, Node 20+, Bun 1+, QuickJS)."""
    def build() -> dict:
        override = os.getenv("VANTA_YTDLP_JS_RUNTIME", "").strip()
        if override.lower() in {"none", "off", "0", "disabled"}:
            return {"available": False, "disabled_by_setting": True, "name": None, "path": None, "version": None, "arg": None, "found": [],
                    "note": "Disabled with VANTA_YTDLP_JS_RUNTIME=none."}
        found: list[dict] = []
        if override:
            m = re.fullmatch(r"(deno|node|quickjs|bun)(?::(.+))?", override)
            if not m:
                return {"available": False, "name": None, "path": None, "version": None, "arg": None, "found": [],
                        "note": "VANTA_YTDLP_JS_RUNTIME must look like node, node:C:\\Program Files\\nodejs\\node.exe, deno, bun, quickjs or none."}
            name, path = m[1], (m[2] or shutil.which(m[1]))
            if path and Path(path).is_dir():
                path = shutil.which(name, path=path)
            names = [(name, path)]
        else:
            names = [(n, shutil.which(n)) for n in JS_RUNTIMES]
        chosen: dict | None = None
        for name, exe in names:
            if not exe or not Path(exe).exists():
                continue
            ver = _tool_version(exe)
            major = _major(ver)
            ok = major is None or major >= _JS_MIN_MAJOR[name]
            entry = {"name": name, "path": exe, "version": ver, "supported": ok}
            found.append(entry)
            if ok and chosen is None:
                chosen = entry
        if chosen:
            return {"available": True, **chosen, "arg": f"{chosen['name']}:{chosen['path']}", "found": found,
                    "note": "VANTA passes this runtime to yt-dlp (--js-runtimes) for YouTube's JavaScript challenge."}
        old = [f"{f['name']} {f['version']}" for f in found if not f["supported"]]
        note = ("Found " + ", ".join(old) + " but it is too old (need Node 20+, Deno 2+, Bun 1+).") if old else \
               "No JavaScript runtime found. Install Node.js 20+ (https://nodejs.org) and restart VANTA; some YouTube videos fail without it."
        return {"available": False, "name": None, "path": None, "version": None, "arg": None, "found": found, "note": note}
    return _cached("js", build)  # type: ignore[return-value]


def ffmpeg_info() -> dict:
    def build() -> dict:
        ff, fp = shutil.which("ffmpeg"), shutil.which("ffprobe")
        ver = None
        if ff:
            try:
                ver = (subprocess.run([ff, "-version"], capture_output=True, text=True, timeout=10, encoding="utf-8", errors="replace").stdout.splitlines() or [None])[0]
            except (OSError, subprocess.SubprocessError):
                ver = None
        return {"ffmpeg": ff, "ffprobe": fp, "version": ver, "available": bool(ff and fp), "dir": str(Path(ff).parent) if ff else None}
    return _cached("ffmpeg", build)  # type: ignore[return-value]


def _writable(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / f".w{os.getpid()}"
        probe.write_bytes(b"x")
        probe.unlink()
        return True
    except OSError:
        return False
