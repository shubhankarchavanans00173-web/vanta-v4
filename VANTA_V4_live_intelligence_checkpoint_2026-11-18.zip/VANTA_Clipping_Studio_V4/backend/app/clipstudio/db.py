"""SQLite persistence (stdlib only) for projects, jobs, candidates, exports and caption templates."""
from __future__ import annotations

import json
import shutil
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from . import settings

_LOCK = threading.RLock()

# ---- job state machine -------------------------------------------------------
JOB_STATES = ("queued", "downloading", "validating", "transcribing", "analyzing", "awaiting_approval", "rendering", "completed", "failed", "cancelled")
ALLOWED = {
    "queued": {"downloading", "validating", "rendering", "cancelled", "failed"},
    "downloading": {"validating", "completed", "failed", "cancelled"},
    "validating": {"transcribing", "analyzing", "failed", "cancelled"},
    "transcribing": {"analyzing", "failed", "cancelled"},
    "analyzing": {"awaiting_approval", "failed", "cancelled"},
    "awaiting_approval": {"cancelled"},
    "rendering": {"completed", "failed", "cancelled"},
    "completed": set(), "failed": set(), "cancelled": set(),
}
ACTIVE = {"queued", "downloading", "validating", "transcribing", "analyzing", "rendering"}
SETTLED = {"awaiting_approval", "completed", "failed", "cancelled"}


class StateError(RuntimeError):
    pass


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id() -> str:
    return uuid.uuid4().hex[:12]


@contextmanager
def connect():
    """Commit on success, roll back on error, and always close (sqlite3's own context manager never closes)."""
    conn = sqlite3.connect(settings.DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, name TEXT NOT NULL, source_type TEXT NOT NULL, source_ref TEXT,
  source_path TEXT, probe TEXT, transcript_path TEXT, transcript_meta TEXT, settings TEXT NOT NULL DEFAULT '{}',
  signals_path TEXT, status TEXT NOT NULL DEFAULT 'new', error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL,
  progress REAL, message TEXT, error TEXT, payload TEXT NOT NULL DEFAULT '{}', result TEXT, created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL, finished_at TEXT);
CREATE TABLE IF NOT EXISTS candidates(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, rank INTEGER, start REAL NOT NULL, end REAL NOT NULL,
  score REAL, method TEXT, reasons TEXT, excerpt TEXT, status TEXT NOT NULL DEFAULT 'suggested', origin TEXT NOT NULL DEFAULT 'auto',
  edited INTEGER NOT NULL DEFAULT 0, error TEXT, title TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS exports(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, candidate_id TEXT, job_id TEXT, path TEXT NOT NULL,
  filename TEXT NOT NULL, aspect TEXT, duration REAL, size_bytes INTEGER, validation TEXT, meta TEXT, srt_path TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS clip_feedback(candidate_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, label TEXT NOT NULL, note TEXT,
  engine TEXT, score REAL, start REAL, end REAL, features TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS templates(id TEXT PRIMARY KEY, name TEXT NOT NULL, builtin INTEGER NOT NULL DEFAULT 0, style TEXT NOT NULL,
  render TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS scheduler_config(id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0,
  paused INTEGER NOT NULL DEFAULT 0, timezone TEXT NOT NULL DEFAULT 'UTC', time_of_day TEXT NOT NULL DEFAULT '09:00',
  videos_per_run INTEGER NOT NULL DEFAULT 1, retry_limit INTEGER NOT NULL DEFAULT 1, last_run_key TEXT, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS scheduler_tasks(id TEXT PRIMARY KEY, project_id TEXT NOT NULL, candidate_id TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'ready', attempts INTEGER NOT NULL DEFAULT 0, retry_limit INTEGER NOT NULL DEFAULT 1,
  run_key TEXT, job_id TEXT, render_settings TEXT NOT NULL DEFAULT '{}', next_attempt_at TEXT, error TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, finished_at TEXT);
CREATE INDEX IF NOT EXISTS scheduler_tasks_due ON scheduler_tasks(status, next_attempt_at, created_at);
"""

BUILTIN_TEMPLATES = [
    ("builtin-highlight", "Karaoke highlight", {"mode": "word_highlight", "font_size_pct": 4.6, "position": "bottom", "margin_pct": 16, "color": "#FFFFFF", "highlight_color": "#FFC83C", "max_words_per_line": 3, "uppercase": True}),
    ("builtin-clean", "Clean subtitles", {"mode": "clean", "font_size_pct": 3.6, "position": "bottom", "margin_pct": 12, "color": "#FFFFFF", "max_words_per_line": 6, "background": True, "background_opacity": 0.5}),
    ("builtin-center", "Centre punch", {"mode": "word_highlight", "font_size_pct": 5.4, "position": "middle", "color": "#FFFFFF", "highlight_color": "#8B83FF", "max_words_per_line": 2, "uppercase": True}),
]


def init() -> None:
    with _LOCK, connect() as c:
        c.executescript(SCHEMA)
        cols = {r[1] for r in c.execute("PRAGMA table_info(candidates)")}
        if "analysis" not in cols:   # added in V4: structured explanation from the multi-signal engine (older rows keep NULL)
            c.execute("ALTER TABLE candidates ADD COLUMN analysis TEXT")
        fcols = {r[1] for r in c.execute("PRAGMA table_info(clip_feedback)")}
        for col in ("engine_version", "ranker_kind"):   # added in the final repair: which ranker VERSION/kind produced the rated clip (old rows keep NULL)
            if col not in fcols:
                c.execute(f"ALTER TABLE clip_feedback ADD COLUMN {col} TEXT")
        for tid, name, style in BUILTIN_TEMPLATES:
            c.execute("INSERT OR REPLACE INTO templates(id,name,builtin,style,render,created_at) VALUES(?,?,?,?,?,?)",
                      (tid, name, 1, json.dumps(style), "{}", now()))
        c.execute("INSERT OR IGNORE INTO scheduler_config(id,updated_at) VALUES(1,?)", (now(),))


def _j(value) -> str | None:
    return None if value is None else json.dumps(value)


def _row(r: sqlite3.Row | None, json_cols: tuple[str, ...] = ()) -> dict | None:
    if r is None:
        return None
    d = dict(r)
    for col in json_cols:
        if d.get(col) is not None:
            try:
                d[col] = json.loads(d[col])
            except (TypeError, json.JSONDecodeError):
                d[col] = None
    return d


# ---- projects ----------------------------------------------------------------
P_JSON = ("probe", "transcript_meta", "settings")


def create_project(name: str, source_type: str, source_ref: str | None = None, source_path: str | None = None,
                   probe: dict | None = None, proj_settings: dict | None = None) -> dict:
    pid, t = new_id(), now()
    with _LOCK, connect() as c:
        c.execute("INSERT INTO projects(id,name,source_type,source_ref,source_path,probe,settings,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (pid, name[:200], source_type, source_ref, source_path, _j(probe), json.dumps(proj_settings or {}), "new", t, t))
    return get_project(pid)  # type: ignore[return-value]


def get_project(pid: str) -> dict | None:
    with connect() as c:
        return _row(c.execute("SELECT * FROM projects WHERE id=?", (pid,)).fetchone(), P_JSON)


def find_link_project(source_ref: str) -> dict | None:
    """Newest link project with exactly this (canonical) reference - used to stop duplicate submissions."""
    with connect() as c:
        return _row(c.execute("SELECT * FROM projects WHERE source_type='link' AND source_ref=? ORDER BY created_at DESC LIMIT 1", (source_ref,)).fetchone(), P_JSON)


def list_projects() -> list[dict]:
    with connect() as c:
        return [_row(r, P_JSON) for r in c.execute("SELECT * FROM projects ORDER BY created_at DESC LIMIT 200")]  # type: ignore[misc]


def update_project(pid: str, **fields) -> None:
    allowed = {"name", "source_path", "probe", "transcript_path", "transcript_meta", "settings", "signals_path", "status", "error", "source_ref"}
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return
    for k in P_JSON:
        if k in fields:
            fields[k] = _j(fields[k])
    fields["updated_at"] = now()
    with _LOCK, connect() as c:
        c.execute("UPDATE projects SET " + ",".join(f"{k}=?" for k in fields) + " WHERE id=?", (*fields.values(), pid))


def delete_project(pid: str) -> None:
    """Remove DB rows. File deletion is the caller's job (it knows which files are safe to remove)."""
    with _LOCK, connect() as c:
        for table in ("candidates", "exports", "jobs", "clip_feedback"):
            c.execute(f"DELETE FROM {table} WHERE project_id=?", (pid,))
        c.execute("DELETE FROM projects WHERE id=?", (pid,))


# ---- candidates --------------------------------------------------------------
C_JSON = ("reasons", "analysis")


def add_candidate(project_id: str, start: float, end: float, score: float | None, method: str, reasons: list[str],
                  excerpt: str = "", rank: int | None = None, origin: str = "auto", status: str = "suggested", title: str | None = None,
                  analysis: dict | None = None) -> dict:
    cid, t = new_id(), now()
    with _LOCK, connect() as c:
        c.execute("INSERT INTO candidates(id,project_id,rank,start,end,score,method,reasons,excerpt,status,origin,title,analysis,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (cid, project_id, rank, start, end, score, method, json.dumps(reasons), excerpt, status, origin, title, _j(analysis), t, t))
    return get_candidate(cid)  # type: ignore[return-value]


def get_candidate(cid: str) -> dict | None:
    with connect() as c:
        d = _row(c.execute("SELECT * FROM candidates WHERE id=?", (cid,)).fetchone(), C_JSON)
        if d is not None:
            r = c.execute("SELECT label FROM clip_feedback WHERE candidate_id=?", (cid,)).fetchone()
            d["feedback"] = r["label"] if r else None
        return d


def list_candidates(project_id: str) -> list[dict]:
    with connect() as c:
        rows = c.execute("SELECT * FROM candidates WHERE project_id=? ORDER BY CASE WHEN rank IS NULL THEN 1 ELSE 0 END, rank, start", (project_id,))
        out = [_row(r, C_JSON) for r in rows]
        fb = {r["candidate_id"]: r["label"] for r in c.execute("SELECT candidate_id,label FROM clip_feedback WHERE project_id=?", (project_id,))}
    for d in out:
        d["feedback"] = fb.get(d["id"])  # type: ignore[index]
    return out  # type: ignore[return-value]


def update_candidate(cid: str, **fields) -> None:
    allowed = {"start", "end", "status", "edited", "error", "title", "score", "reasons", "excerpt", "rank", "analysis"}
    fields = {k: v for k, v in fields.items() if k in allowed}
    if "reasons" in fields:
        fields["reasons"] = json.dumps(fields["reasons"])
    if "analysis" in fields:
        fields["analysis"] = _j(fields["analysis"])
    if not fields:
        return
    fields["updated_at"] = now()
    with _LOCK, connect() as c:
        c.execute("UPDATE candidates SET " + ",".join(f"{k}=?" for k in fields) + " WHERE id=?", (*fields.values(), cid))


def delete_candidate(cid: str) -> None:
    with _LOCK, connect() as c:
        c.execute("DELETE FROM candidates WHERE id=?", (cid,))   # feedback rows are kept on purpose: ratings are evaluation data


# The UI uses the editor-oriented labels below.  Older local databases may
# contain the V4 labels, so the API continues to accept them for history and
# evaluation compatibility rather than invalidating stored feedback.
FEEDBACK_LABELS = ("excellent", "good", "average", "bad", "missed_context", "not_funny", "duplicate", "wrong_boundaries")
LEGACY_FEEDBACK_LABELS = ("weak", "incomplete", "repetitive", "missing_context")


def set_feedback(cid: str, label: str, note: str | None = None) -> dict:
    """Upsert the human rating for a candidate. A snapshot of the engine, score, boundaries and features is stored with it."""
    if label not in (*FEEDBACK_LABELS, *LEGACY_FEEDBACK_LABELS):
        raise ValueError("Label must be one of: " + ", ".join(FEEDBACK_LABELS))
    cand = get_candidate(cid)
    if cand is None:
        raise KeyError(cid)
    a = cand.get("analysis") or {}
    feats = {k: v.get("value") for k, v in (a.get("features") or {}).items()}
    engine = a.get("engine") or cand.get("method")
    engine_version = a.get("engine_version")
    llm_status = (a.get("llm") or {}).get("status")
    ranker_kind = "rules+local-llm" if llm_status == "evaluated" else ("rules" if a else (cand.get("method") or "manual"))
    t = now()
    with _LOCK, connect() as c:
        c.execute("INSERT INTO clip_feedback(candidate_id,project_id,label,note,engine,engine_version,ranker_kind,score,start,end,features,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) "
                  "ON CONFLICT(candidate_id) DO UPDATE SET label=excluded.label, note=excluded.note, engine=excluded.engine, engine_version=excluded.engine_version, "
                  "ranker_kind=excluded.ranker_kind, score=excluded.score, start=excluded.start, end=excluded.end, features=excluded.features, updated_at=excluded.updated_at",
                  (cid, cand["project_id"], label, (note or "")[:300] or None, engine, engine_version, ranker_kind, cand.get("score"), cand["start"], cand["end"], json.dumps(feats), t, t))
        return dict(c.execute("SELECT * FROM clip_feedback WHERE candidate_id=?", (cid,)).fetchone())


def clear_feedback(cid: str) -> None:
    with _LOCK, connect() as c:
        c.execute("DELETE FROM clip_feedback WHERE candidate_id=?", (cid,))


def list_feedback(project_id: str | None = None) -> list[dict]:
    with connect() as c:
        q, args = "SELECT * FROM clip_feedback", ()
        if project_id:
            q, args = q + " WHERE project_id=?", (project_id,)
        return [_row(r, ("features",)) for r in c.execute(q + " ORDER BY updated_at", args)]  # type: ignore[misc]


def clear_auto_candidates(project_id: str) -> None:
    """Before re-analysis: drop auto suggestions the user has not approved/rendered. Custom/approved clips survive."""
    with _LOCK, connect() as c:
        c.execute("DELETE FROM candidates WHERE project_id=? AND origin='auto' AND status IN ('suggested','rejected')", (project_id,))


# ---- jobs --------------------------------------------------------------------
J_JSON = ("payload", "result")


def create_job(project_id: str, kind: str, payload: dict | None = None) -> dict:
    jid, t = new_id(), now()
    with _LOCK, connect() as c:
        c.execute("INSERT INTO jobs(id,project_id,kind,status,payload,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                  (jid, project_id, kind, "queued", json.dumps(payload or {}), t, t))
    return get_job(jid)  # type: ignore[return-value]


def get_job(jid: str) -> dict | None:
    with connect() as c:
        return _row(c.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone(), J_JSON)


def list_jobs(limit: int = 100, project_id: str | None = None) -> list[dict]:
    with connect() as c:
        if project_id:
            rows = c.execute("SELECT * FROM jobs WHERE project_id=? ORDER BY created_at DESC LIMIT ?", (project_id, limit))
        else:
            rows = c.execute("SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,))
        return [_row(r, J_JSON) for r in rows]  # type: ignore[misc]


def transition(jid: str, new_status: str, message: str | None = None, error: str | None = None, result: dict | None = None,
               progress: float | None = None) -> dict:
    """Move a job to ``new_status`` enforcing the state machine. ``progress`` is None unless the operation reports real progress."""
    if new_status not in JOB_STATES:
        raise StateError(f"Unknown job state {new_status!r}")
    with _LOCK, connect() as c:
        row = c.execute("SELECT status FROM jobs WHERE id=?", (jid,)).fetchone()
        if row is None:
            raise StateError("Job not found")
        if new_status not in ALLOWED[row["status"]]:
            raise StateError(f"Illegal job transition {row['status']} -> {new_status}")
        finished = now() if new_status in {"completed", "failed", "cancelled", "awaiting_approval"} else None
        c.execute("UPDATE jobs SET status=?, message=COALESCE(?,message), error=?, result=COALESCE(?,result), progress=?, updated_at=?, finished_at=COALESCE(?,finished_at) WHERE id=?",
                  (new_status, message, error, _j(result), progress, now(), finished, jid))
    return get_job(jid)  # type: ignore[return-value]


def set_progress(jid: str, progress: float | None, message: str | None = None) -> None:
    """Update a RUNNING job's progress. A late callback (e.g. a render thread that is still unwinding after the job was
    cancelled/failed/completed) must never overwrite a settled job, so the update is skipped unless the job is still active."""
    q = ",".join("?" for _ in ACTIVE)
    with _LOCK, connect() as c:
        c.execute(f"UPDATE jobs SET progress=?, message=COALESCE(?,message), updated_at=? WHERE id=? AND status IN ({q})",
                  (progress, message, now(), jid, *ACTIVE))


def fail_interrupted() -> int:
    """After a backend restart no worker is running: mark active jobs failed (never pretend they will resume)."""
    with _LOCK, connect() as c:
        q = ",".join("?" for _ in ACTIVE)
        rows = c.execute(f"SELECT id, project_id FROM jobs WHERE status IN ({q})", tuple(ACTIVE)).fetchall()
        for r in rows:
            c.execute("UPDATE jobs SET status='failed', error=?, updated_at=?, finished_at=? WHERE id=?",
                      ("The backend restarted before this job finished. Start it again.", now(), now(), r["id"]))
            c.execute("UPDATE projects SET status='failed', error=?, updated_at=? WHERE id=?", ("A job was interrupted by a backend restart.", now(), r["project_id"]))
            c.execute("UPDATE candidates SET status='approved', updated_at=? WHERE project_id=? AND status='rendering'", (now(), r["project_id"]))
    return len(rows)


RESUMABLE_KINDS = ("render", "download")
INTERRUPTED_MSG = "The backend restarted before this job finished. Start it again."


def _export_is_intact(row) -> bool:
    """A recorded export counts as done only when its file is still on disk with the size that was validated and stored."""
    try:
        p = Path(row["path"])
        return p.is_file() and p.stat().st_size > 0 and (not row["size_bytes"] or p.stat().st_size == int(row["size_bytes"]))
    except (OSError, ValueError, TypeError):
        return False


def recover_interrupted(resume: bool = True, max_resumes: int = 2) -> dict:
    """After a backend restart no worker is running. Active jobs are never silently dropped:

    * render / download jobs are continued as a NEW queued job (the old one is marked failed and says so). A render only
      redoes clips that have no intact export, so finished clips are kept. A job that was already resumed ``max_resumes``
      times is failed instead (a crash loop must not retry forever).
    * analyze / transcribe jobs, and any job a scheduler task owns (the scheduler has its own retry path), are failed
      exactly like :func:`fail_interrupted`.
    * nothing here can upload or publish: there is no upload job kind.

    Returns ``{"failed": [ids], "resumed": [new job dicts], "completed": [ids], "interrupted_ids": [old ids]}``.
    The caller submits the resumed jobs to the executor.
    """
    out: dict = {"failed": [], "resumed": [], "completed": [], "interrupted_ids": []}
    with _LOCK, connect() as c:
        q = ",".join("?" for _ in ACTIVE)
        rows = c.execute(f"SELECT * FROM jobs WHERE status IN ({q}) ORDER BY created_at", tuple(ACTIVE)).fetchall()
        owned = {r["job_id"] for r in c.execute("SELECT job_id FROM scheduler_tasks WHERE job_id IS NOT NULL AND status IN ('dispatching','running')")}
        for r in rows:
            jid, pid, kind = r["id"], r["project_id"], r["kind"]
            out["interrupted_ids"].append(jid)
            try:
                payload = json.loads(r["payload"] or "{}")
            except ValueError:
                payload = {}
            n = int(payload.get("resume_count") or 0)
            t = now()

            def fail(msg: str) -> None:
                c.execute("UPDATE jobs SET status='failed', error=?, updated_at=?, finished_at=? WHERE id=?", (msg, t, t, jid))
                c.execute("UPDATE projects SET status='failed', error=?, updated_at=? WHERE id=?", ("A job was interrupted by a backend restart.", t, pid))
                c.execute("UPDATE candidates SET status='approved', updated_at=? WHERE project_id=? AND status IN ('rendering','queued')", (t, pid))
                out["failed"].append(jid)

            if not resume or kind not in RESUMABLE_KINDS or jid in owned:
                fail(INTERRUPTED_MSG)
                continue
            if n >= max_resumes:
                fail(f"This job was interrupted by a backend restart {n + 1} times and is not resumed again automatically. Start it again.")
                continue
            new_payload = dict(payload, resume_of=jid, resume_count=n + 1)
            if kind == "render":
                cids = list(payload.get("candidate_ids") or [])
                done: dict[str, str] = {}
                for cid in cids:
                    e = c.execute("SELECT * FROM exports WHERE job_id=? AND candidate_id=? ORDER BY created_at DESC", (jid, cid)).fetchall()
                    ok = next((x for x in e if _export_is_intact(x)), None)
                    if ok is not None:
                        done[cid] = ok["id"]
                todo = [cid for cid in cids if cid not in done]
                for cid in done:
                    c.execute("UPDATE candidates SET status='rendered', error=NULL, updated_at=? WHERE id=?", (t, cid))
                if not todo:
                    c.execute("UPDATE jobs SET status='completed', message=?, result=?, progress=1.0, updated_at=?, finished_at=? WHERE id=?",
                              ("All clips had finished before the restart", json.dumps({"exported": list(done.values()), "failed": [], "recovered": True}), t, t, jid))
                    c.execute("UPDATE projects SET status='awaiting_approval', error=NULL, updated_at=? WHERE id=?", (t, pid))
                    out["completed"].append(jid)
                    continue
                new_payload["candidate_ids"] = todo
                for cid in todo:
                    c.execute("UPDATE candidates SET status='queued', error=NULL, updated_at=? WHERE id=?", (t, cid))
                note = f"{len(done)} clip(s) were already exported; {len(todo)} continue" if done else f"{len(todo)} clip(s) restart"
            else:
                note = "the download starts again (a complete copy on disk is reused)"
            nid = new_id()
            c.execute("INSERT INTO jobs(id,project_id,kind,status,message,payload,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                      (nid, pid, kind, "queued", f"Continuing after a restart: {note}", json.dumps(new_payload), t, t))
            c.execute("UPDATE jobs SET status='failed', error=?, result=?, updated_at=?, finished_at=? WHERE id=?",
                      (f"Interrupted by a backend restart; continued automatically as job {nid}.", json.dumps({"resumed_as": nid}), t, t, jid))
            c.execute("UPDATE projects SET status='queued', error=NULL, updated_at=? WHERE id=?", (t, pid))
            out["resumed"].append(dict(c.execute("SELECT * FROM jobs WHERE id=?", (nid,)).fetchone()))
    out["resumed"] = [get_job(j["id"]) for j in out["resumed"]]
    return out


# ---- optional scheduler ------------------------------------------------------
# Scheduler work is deliberately separate from normal pipeline jobs. A task
# always refers to one already-approved candidate; there is no URL ingestion or
# publishing path here.
SCHEDULER_TASK_STATES = ("ready", "dispatching", "running", "completed", "failed", "cancelled")
SCHED_T_JSON = ("render_settings",)


def get_scheduler_config() -> dict:
    with connect() as c:
        row = dict(c.execute("SELECT * FROM scheduler_config WHERE id=1").fetchone())
    row["enabled"] = bool(row["enabled"])
    row["paused"] = bool(row["paused"])
    return row


def update_scheduler_config(**fields) -> dict:
    allowed = {"enabled", "paused", "timezone", "time_of_day", "videos_per_run", "retry_limit", "last_run_key"}
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return get_scheduler_config()
    for key in ("enabled", "paused"):
        if key in fields:
            fields[key] = int(bool(fields[key]))
    fields["updated_at"] = now()
    with _LOCK, connect() as c:
        c.execute("UPDATE scheduler_config SET " + ",".join(f"{key}=?" for key in fields) + " WHERE id=1",
                  (*fields.values(),))
    return get_scheduler_config()


def _scheduler_task(row: sqlite3.Row | None) -> dict | None:
    return _row(row, SCHED_T_JSON)


def get_scheduler_task(tid: str) -> dict | None:
    with connect() as c:
        return _scheduler_task(c.execute("SELECT * FROM scheduler_tasks WHERE id=?", (tid,)).fetchone())


def list_scheduler_tasks(limit: int = 200) -> list[dict]:
    with connect() as c:
        return [_scheduler_task(row) for row in c.execute(
            "SELECT * FROM scheduler_tasks ORDER BY CASE status WHEN 'ready' THEN 0 WHEN 'dispatching' THEN 1 WHEN 'running' THEN 2 ELSE 3 END, created_at LIMIT ?",
            (limit,))]  # type: ignore[misc]


def create_scheduler_task(project_id: str, candidate_id: str, render_settings: dict, retry_limit: int) -> dict:
    tid, t = new_id(), now()
    with _LOCK, connect() as c:
        c.execute(
            "INSERT INTO scheduler_tasks(id,project_id,candidate_id,retry_limit,render_settings,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
            (tid, project_id, candidate_id, retry_limit, json.dumps(render_settings), t, t),
        )
    return get_scheduler_task(tid)  # type: ignore[return-value]


def cancel_scheduler_task(tid: str) -> dict | None:
    with _LOCK, connect() as c:
        c.execute(
            "UPDATE scheduler_tasks SET status='cancelled',updated_at=?,finished_at=? WHERE id=? AND status IN ('ready','dispatching')",
            (now(), now(), tid),
        )
    return get_scheduler_task(tid)


def scheduler_task_running(tid: str, job_id: str) -> dict | None:
    with _LOCK, connect() as c:
        c.execute(
            "UPDATE scheduler_tasks SET status='running',job_id=?,error=NULL,next_attempt_at=NULL,updated_at=? WHERE id=? AND status='dispatching'",
            (job_id, now(), tid),
        )
    return get_scheduler_task(tid)


def scheduler_task_complete(tid: str) -> dict | None:
    with _LOCK, connect() as c:
        c.execute(
            "UPDATE scheduler_tasks SET status='completed',error=NULL,next_attempt_at=NULL,updated_at=?,finished_at=? WHERE id=? AND status='running'",
            (now(), now(), tid),
        )
    return get_scheduler_task(tid)


def scheduler_task_retry(tid: str, error: str, next_attempt_at: str | None) -> dict | None:
    """Record a failed render. retry_limit is the number of retries after the first failure."""
    with _LOCK, connect() as c:
        row = c.execute("SELECT attempts,retry_limit,status FROM scheduler_tasks WHERE id=?", (tid,)).fetchone()
        if row is None:
            return None
        attempts = int(row["attempts"]) + 1
        retry = attempts <= int(row["retry_limit"])
        c.execute(
            "UPDATE scheduler_tasks SET status=?,attempts=?,error=?,next_attempt_at=?,updated_at=?,finished_at=? WHERE id=?",
            ("ready" if retry else "failed", attempts, error[:1000], next_attempt_at if retry else None, now(),
             None if retry else now(), tid),
        )
    return get_scheduler_task(tid)


def defer_scheduler_task(tid: str, message: str, next_attempt_at: str) -> dict | None:
    """Return a task to the queue without consuming a render retry."""
    with _LOCK, connect() as c:
        c.execute(
            "UPDATE scheduler_tasks SET status='ready',error=?,next_attempt_at=?,updated_at=? WHERE id=? AND status IN ('dispatching','running')",
            (message[:1000], next_attempt_at, now(), tid),
        )
    return get_scheduler_task(tid)


def finish_scheduler_task(tid: str, status: str, error: str | None = None) -> dict | None:
    if status not in {"completed", "failed", "cancelled"}:
        raise ValueError("Scheduler tasks may only be finished as completed, failed, or cancelled.")
    with _LOCK, connect() as c:
        c.execute(
            "UPDATE scheduler_tasks SET status=?,error=?,next_attempt_at=NULL,updated_at=?,finished_at=? WHERE id=?",
            (status, error[:1000] if error else None, now(), now(), tid),
        )
    return get_scheduler_task(tid)


def recover_scheduler_dispatches() -> list[dict]:
    """Return non-settled scheduler tasks after a backend restart."""
    with connect() as c:
        return [_scheduler_task(row) for row in c.execute(
            "SELECT * FROM scheduler_tasks WHERE status IN ('dispatching','running') ORDER BY created_at")]  # type: ignore[misc]


def reset_stale_scheduler_run(current_run_key: str) -> int:
    """Make a retry from an earlier run eligible for the current run."""
    with _LOCK, connect() as c:
        return c.execute(
            "UPDATE scheduler_tasks SET run_key=NULL,updated_at=? WHERE status='ready' AND run_key IS NOT NULL AND run_key<>?",
            (now(), current_run_key),
        ).rowcount


def claim_scheduler_tasks(run_key: str, videos_per_run: int, at: str) -> list[dict]:
    """Atomically reserve at most the configured number of distinct videos for one run."""
    with _LOCK, connect() as c:
        # A retry retains its run key, so it does not consume another
        # videos-per-run slot. Prefer it before selecting any new clip.
        rows = c.execute(
            "SELECT * FROM scheduler_tasks WHERE status='ready' AND run_key=? AND (next_attempt_at IS NULL OR next_attempt_at<=?) "
            "ORDER BY created_at LIMIT ?",
            (run_key, at, int(videos_per_run)),
        ).fetchall()
        if not rows:
            rows = None
        occupied = c.execute(
            "SELECT COUNT(*) FROM scheduler_tasks WHERE run_key=? AND status<>'cancelled'", (run_key,)
        ).fetchone()[0]
        if rows is None:
            slots = max(0, int(videos_per_run) - int(occupied))
            if slots == 0:
                return []
            rows = c.execute(
                "SELECT * FROM scheduler_tasks WHERE status='ready' AND run_key IS NULL AND (next_attempt_at IS NULL OR next_attempt_at<=?) "
                "ORDER BY created_at LIMIT ?",
                (at, slots),
            ).fetchall()
        claimed = []
        for row in rows:
            updated = c.execute(
                "UPDATE scheduler_tasks SET status='dispatching',run_key=?,updated_at=? WHERE id=? AND status='ready'",
                (run_key, now(), row["id"]),
            ).rowcount
            if updated:
                claimed.append(row["id"])
    return [get_scheduler_task(tid) for tid in claimed if get_scheduler_task(tid) is not None]  # type: ignore[misc]


# ---- exports -----------------------------------------------------------------
E_JSON = ("validation", "meta")


def add_export(project_id: str, candidate_id: str | None, job_id: str | None, path: str, filename: str, aspect: str,
               duration: float, size_bytes: int, validation: dict, meta: dict, srt_path: str | None) -> dict:
    eid = new_id()
    with _LOCK, connect() as c:
        c.execute("INSERT INTO exports(id,project_id,candidate_id,job_id,path,filename,aspect,duration,size_bytes,validation,meta,srt_path,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (eid, project_id, candidate_id, job_id, path, filename, aspect, duration, size_bytes, json.dumps(validation), json.dumps(meta), srt_path, now()))
    return get_export(eid)  # type: ignore[return-value]


def get_export(eid: str) -> dict | None:
    with connect() as c:
        return _row(c.execute("SELECT * FROM exports WHERE id=?", (eid,)).fetchone(), E_JSON)


def list_exports(project_id: str | None = None) -> list[dict]:
    with connect() as c:
        rows = c.execute("SELECT * FROM exports WHERE project_id=? ORDER BY created_at DESC", (project_id,)) if project_id else c.execute("SELECT * FROM exports ORDER BY created_at DESC LIMIT 500")
        return [_row(r, E_JSON) for r in rows]  # type: ignore[misc]


def merge_export_meta(eid: str, patch: dict) -> dict | None:
    """Shallow-merge ``patch`` into an export's meta JSON (thumbnail choice, publish details ...). None when the export is gone."""
    with _LOCK, connect() as c:
        row = c.execute("SELECT meta FROM exports WHERE id=?", (eid,)).fetchone()
        if row is None:
            return None
        try:
            meta = json.loads(row["meta"]) if row["meta"] else {}
        except (TypeError, json.JSONDecodeError):
            meta = {}
        meta.update(patch)
        c.execute("UPDATE exports SET meta=? WHERE id=?", (json.dumps(meta), eid))
    return get_export(eid)


def delete_export(eid: str) -> None:
    with _LOCK, connect() as c:
        c.execute("DELETE FROM exports WHERE id=?", (eid,))


# ---- templates ---------------------------------------------------------------
def list_templates() -> list[dict]:
    with connect() as c:
        return [_row(r, ("style", "render")) for r in c.execute("SELECT * FROM templates ORDER BY builtin DESC, created_at")]  # type: ignore[misc]


def save_template(name: str, style: dict, render: dict | None = None) -> dict:
    tid = new_id()
    with _LOCK, connect() as c:
        c.execute("INSERT INTO templates(id,name,builtin,style,render,created_at) VALUES(?,?,?,?,?,?)", (tid, name[:80], 0, json.dumps(style), json.dumps(render or {}), now()))
        return _row(c.execute("SELECT * FROM templates WHERE id=?", (tid,)).fetchone(), ("style", "render"))  # type: ignore[return-value]


def delete_template(tid: str) -> bool:
    with _LOCK, connect() as c:
        return c.execute("DELETE FROM templates WHERE id=? AND builtin=0", (tid,)).rowcount > 0
