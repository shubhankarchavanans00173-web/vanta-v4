"""Video generation, source-clip editing, and output validation.

Module layout (split from one 1000-line file, behaviour unchanged): renderer_common, renderer_scenes, renderer_audio, renderer_validate,
renderer_download and renderer_clips hold the leaf pieces. This module keeps the orchestrators (``render_video``, ``_render_ai_video``)
and the motion-score helpers that tests patch (``_temporal_motion_score``), plus ``subprocess``/``httpx``/``socket`` etc., and
re-exports every old name (including private ones) so ``from app.renderer import _x`` and ``patch(\"app.renderer.X\")`` keep working.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import math
import os
from io import BytesIO
from pathlib import Path
import re
import shutil
import socket
import subprocess
import textwrap
from typing import Callable
from urllib.parse import urlparse

import httpx
from PIL import Image, ImageDraw, ImageFont, ImageStat

from .config import OUTPUT_DIR, UPLOAD_DIR
from .video_providers import get_video_provider

from .renderer_common import AUDIO_EXTENSIONS, DEFAULT_FPS, MAX_DIRECT_VIDEO_BYTES, _fraction, _run, _safe_upload, _sample_image, _timestamp, dims, getfont, wrap  # noqa: F401
from .renderer_scenes import _normalise_scenes, _palette, _scene_image, _style_prompt, _video_shot_prompt, _write_srt  # noqa: F401
from .renderer_audio import _add_audio_tracks, _audio_upload, _normalise_audio_track, _optional_media, _voice  # noqa: F401
from .renderer_validate import _render_source_video, validate_output  # noqa: F401
from .renderer_download import _download_authorized_video  # noqa: F401
from .renderer_clips import _parse_srt_time, _render_video_clips, _scene_changes, _select_clip_windows, _slice_srt, _title_overlay  # noqa: F401



def _temporal_motion_score(ffmpeg: str, video: Path, duration: float) -> float | None:
    start=max(0.0,min(duration*0.2,duration-0.3))
    before=_sample_image(ffmpeg,video,start)
    after=_sample_image(ffmpeg,video,min(duration-0.02,start+0.25))
    if before is None or after is None:
        return None
    return round(sum(abs(a-b) for a,b in zip(before.tobytes(),after.tobytes()))/len(before.tobytes()),3)


def _existing_ai_clip_motion_score(ffmpeg: str, ffprobe: str, video: Path, expected_duration: float) -> float | None:
    if not video.is_file() or video.stat().st_size < 5000:
        return None
    result=subprocess.run(
        [ffprobe,"-v","error","-show_streams","-show_format","-of","json",str(video)],
        capture_output=True,text=True,timeout=30,
    )
    if result.returncode:
        return None
    data=json.loads(result.stdout)
    if not any(stream.get("codec_type")=="video" for stream in data.get("streams",[])):
        return None
    duration=float(data.get("format",{}).get("duration") or 0)
    if duration < max(0.5,expected_duration*0.75):
        return None
    return _temporal_motion_score(ffmpeg,video,duration)


def _render_ai_video(
    job_id: str,
    job: dict,
    progress: Callable[[int,str],None],
    cancelled: Callable[[],bool],
    output: Path,
    final: Path,
    width: int,
    height: int,
    duration: int,
    fps: int,
) -> dict:
    settings=job["settings"]
    mode=settings.get("generation_mode","local_ai")
    provider_mode="online_ai" if mode=="hybrid" and settings.get("hybrid_online_enabled") else "local_ai" if mode=="hybrid" else mode
    provider=get_video_provider(provider_mode)
    ffmpeg=shutil.which("ffmpeg")
    ffprobe=shutil.which("ffprobe")
    if not ffmpeg or not ffprobe:
        raise RuntimeError("FFmpeg and ffprobe must both be available before generating AI video.")
    scenes=_normalise_scenes(settings.get("scenes",[]),duration)
    reference_ids=settings.get("reference_upload_ids") or []
    reference=_safe_upload(reference_ids[0],{".png",".jpg",".jpeg",".webp"}) if reference_ids else None
    if reference_ids and not reference:
        raise RuntimeError("The selected reference image is missing or unavailable. Upload it again and create a new job.")
    optional_warnings=[]
    captions_path=output/"captions.srt" if settings.get("captions") else None
    if captions_path:
        try:
            _write_srt(scenes,captions_path)
        except (OSError,UnicodeError) as error:
            optional_warnings.append(f"Caption export was skipped: {error}")
            captions_path=None

    subject=str(job.get("topic") or "the subject")
    character=str(settings.get("character_description") or "").strip()
    environment=str(settings.get("environment_description") or "").strip()
    style=settings.get("visual_style","cinematic")
    continuity=" ".join(value for value in (f"Consistent subject and story: {subject}.",_style_prompt(style),character,environment) if value)
    shot_angles=("wide establishing shot","medium action shot","close detail shot")
    clips=[]
    clip_motion_scores=[]
    generated_clips=[]
    segments=[]
    for scene_index,scene in enumerate(scenes,1):
        scene_duration=scene["end_seconds"]-scene["start_seconds"]
        provider_clip_seconds=1.0 if provider.name=="animatediff_local" else 6.0
        part_count=max(1,int((scene_duration+provider_clip_seconds-0.001)//provider_clip_seconds))
        for part_index in range(part_count):
            part_duration=min(provider_clip_seconds,scene_duration-part_index*provider_clip_seconds)
            segments.append((scene_index,scene,part_index,part_duration))
    regenerate_scene_id=settings.get("regenerate_scene_id")
    try:
        regenerate_scene_id=int(regenerate_scene_id) if regenerate_scene_id is not None else None
    except (TypeError,ValueError) as error:
        raise RuntimeError("The requested scene ID is invalid.") from error
    if regenerate_scene_id is not None and regenerate_scene_id not in {scene["id"] for scene in scenes}:
        raise RuntimeError("The requested scene no longer exists. Save the storyboard and try again.")
    previous_clips={
        (int(clip.get("scene_index",0)),int(clip.get("segment_index",0))):clip
        for clip in settings.get("generated_clips",[])
        if isinstance(clip,dict)
    }
    for clip_index,(scene_index,scene,part_index,part_duration) in enumerate(segments,1):
        if cancelled():
            raise RuntimeError("Video generation was cancelled.")
        clip_path=output/f"generated_clip_{clip_index:03d}.mp4"
        total_clips=max(1,len(segments))
        previous=previous_clips.get((scene_index,part_index+1))
        reuse_existing=False
        if regenerate_scene_id is not None and scene_index!=regenerate_scene_id:
            if not previous:
                raise RuntimeError("Existing generated shots are missing; regenerate the full video instead.")
            previous_path=Path(str(previous.get("path",""))).resolve()
            if OUTPUT_DIR.resolve() not in previous_path.parents or not previous_path.is_file():
                raise RuntimeError("An existing generated shot is unavailable; regenerate the full video instead.")
            clip_path=previous_path
            motion_score=float(previous.get("motion_score") or 0)
        elif regenerate_scene_id is None and clip_path.is_file():
            motion_score=_existing_ai_clip_motion_score(ffmpeg,ffprobe,clip_path,part_duration)
            reuse_existing=motion_score is not None and motion_score>=0.15
            if reuse_existing:
                clip_base=18+round(48*((clip_index-1)/total_clips),1)
                progress(clip_base,f"Reusing validated AI clip {clip_index}/{total_clips}")
        if not reuse_existing and not (regenerate_scene_id is not None and scene_index!=regenerate_scene_id):
            shot=" ".join(
                str(value).strip()
                for value in (
                    scene.get("visual_prompt",""),
                    scene.get("title","Scene "+str(scene_index)),
                    scene["narration"],
                )
                if str(value).strip()
            )
            prompt=_video_shot_prompt(continuity,shot,shot_angles[(scene_index+part_index-1)%len(shot_angles)])
            clip_base=18+round(48*((clip_index-1)/total_clips),1)
            progress(clip_base,f"{provider.name}: generating scene {scene_index}, shot {part_index+1}")

            def clip_progress(percent: int, message: str, *, index: int=clip_index) -> None:
                base=18+round(48*((index-1)/total_clips),1)
                progress(min(76,base+round(max(0,min(100,percent))*0.48/total_clips,1)),message)

            provider.generate_clip(
                prompt=prompt,
                duration_seconds=part_duration,
                output_path=clip_path,
                progress=clip_progress,
                cancelled=cancelled,
                reference_image=reference if part_index==0 else None,
            )
            motion_score=_temporal_motion_score(ffmpeg,clip_path,part_duration)
        if motion_score is None or motion_score<0.15:
            raise RuntimeError(
                f"Scene {scene_index} shot {part_index+1} failed temporal-motion validation "
                f"(sampled frame difference: {motion_score if motion_score is not None else 'unavailable'})."
            )
        clip_motion_scores.append(motion_score)
        clips.append({"path":clip_path,"duration":part_duration})
        generated_clips.append({
            "index":clip_index,
            "scene_index":scene_index,
            "segment_index":part_index+1,
            "duration_seconds":round(part_duration,3),
            "path":str(clip_path),
            "motion_score":motion_score,
        })
        if cancelled():
            raise RuntimeError("Video generation was cancelled.")

    narration_path=_optional_media(
        "Narration",
        lambda:_normalise_audio_track(
            _voice(job.get("script") or " ".join(scene["narration"] for scene in scenes),output,float(settings.get("narration_speed",1))),
            output,"narration",duration,
        ),
        optional_warnings,
    ) if settings.get("narration") else None
    music_source=_optional_media("Music",lambda:_audio_upload(settings,"music_upload_id","music"),optional_warnings)
    effects_source=_optional_media("Sound effects",lambda:_audio_upload(settings,"sound_effects_upload_id","sound effects"),optional_warnings)
    music_path=_optional_media("Music",lambda:_normalise_audio_track(music_source,output,"music",duration),optional_warnings) if music_source else None
    sound_effects_path=_optional_media("Sound effects",lambda:_normalise_audio_track(effects_source,output,"effects",duration),optional_warnings) if effects_source else None

    def assembly_command(include_audio: bool,include_captions: bool) -> tuple[list[str],bool]:
        command=[ffmpeg,"-y","-hide_banner"]
        for clip in clips:
            command.extend(["-i",str(clip["path"])])
        filters=[]
        for index,clip in enumerate(clips):
            clip_seconds=clip["duration"]
            filters.append(
                f"[{index}:v]trim=duration={clip_seconds:.3f},setpts=PTS-STARTPTS,"
                f"scale={width}:{height}:force_original_aspect_ratio=increase,"
                f"crop={width}:{height},fps={fps},setsar=1,format=yuv420p[v{index}]"
            )
        filters.append("".join(f"[v{index}]" for index in range(len(clips)))+f"concat=n={len(clips)}:v=1:a=0[vout]")
        has_audio=_add_audio_tracks(
            command,filters,len(clips),duration,
            narration_path if include_audio else None,
            music_path if include_audio else None,
            sound_effects_path if include_audio else None,
        )
        video_map="[vout]"
        if include_captions and captions_path:
            filters.append("[vout]subtitles=filename='captions.srt'[captioned]")
            video_map="[captioned]"
        command.extend(["-filter_complex",";".join(filters),"-map",video_map])
        if has_audio:
            command.extend(["-map","[aout]","-c:a","aac","-b:a","128k"])
        command.extend([
            "-t",str(duration),"-r",str(fps),"-c:v","libx264","-preset","veryfast","-crf","23",
            "-movflags","+faststart",str(final),
        ])
        return command,has_audio

    command,audio_inputs=assembly_command(True,True)
    progress(78,"Assembling generated video shots")
    captions_embedded=bool(captions_path)
    try:
        _run(command,max(240,duration*30),cwd=output)
    except RuntimeError as error:
        if not (audio_inputs or captions_path):
            raise
        optional_warnings.append(f"Optional audio/caption muxing was skipped after FFmpeg reported: {error}")
        final.unlink(missing_ok=True)
        command,audio_inputs=assembly_command(False,False)
        captions_embedded=False
        _run(command,max(240,duration*30),cwd=output)
    if not final.exists() or final.stat().st_size<5000:
        raise RuntimeError("AI video assembly failed: the output MP4 is missing or too small.")
    progress(88,"Validating generated MP4 and temporal motion")
    validation=validate_output(final,width,height,duration,bool(audio_inputs),fps)
    if not validation["valid"]:
        raise RuntimeError("Validation failed: generated video output appears black.")
    if validation["frozen_scene_suspected"]:
        raise RuntimeError("Validation failed: generated video samples appear frozen; no still-image fallback was used.")
    validation["generated_clip_motion_scores"]=clip_motion_scores
    validation["actual_temporal_motion"]=True
    thumbnail=output/"thumbnail.png"
    _run([ffmpeg,"-y","-hide_banner","-ss","0.2","-i",str(final),"-frames:v","1",str(thumbnail)],30)
    return {
        "output_path":str(final),
        "captions_path":str(captions_path) if captions_path and captions_path.exists() else None,
        "thumbnail_path":str(thumbnail) if thumbnail.exists() else None,
        "validation":validation,
        "captions_embedded":captions_embedded,
        "render_mode":provider.name,
        "selected_video_provider":getattr(provider,"identifier",provider.name),
        "generation_mode":mode,
        "generated_clips":generated_clips,
        "regenerate_scene_id":None,
        "render_notice":f"Generated {len(clips)} actual AI-video clip(s) with {provider.name}, then assembled them using hard cuts. {'Captions were embedded and exported as SRT.' if captions_embedded else 'Captions were exported as SRT but could not be embedded.' if captions_path else 'Caption export was disabled or unavailable.'} No motion-graphics fallback was used. {' '.join(optional_warnings)}".strip(),
    }


def render_video(
    job_id: str,
    job: dict,
    progress: Callable[[int,str],None],
    cancelled: Callable[[],bool]=lambda:False,
) -> dict:
    settings=job["settings"]
    output=OUTPUT_DIR/job_id; output.mkdir(parents=True,exist_ok=True)
    width,height=dims(settings["aspect_ratio"],settings.get("resolution_preset","balanced")); duration=int(settings["duration_seconds"]); fps=int(settings.get("frame_rate",DEFAULT_FPS))
    final=output/"final.mp4"
    if settings.get("input_type")=="video_clips":
        if settings.get("source_upload_id"):
            source=_safe_upload(settings.get("source_upload_id"),{".mp4",".mov",".mkv",".webm"})
            if not source:
                raise RuntimeError("Authorized source video is missing. Upload it again and create a new job.")
        else:
            source=_download_authorized_video(str(settings.get("source_video_url") or ""),output/"authorized_source")
        return _render_video_clips(job_id,settings,source,output,width,height,fps,progress,cancelled)
    source=_safe_upload(settings.get("source_upload_id"),{".mp4",".mov",".mkv",".webm"}) if settings.get("input_type")=="source_video" else None
    if settings.get("input_type")=="source_video" and not source:
        raise RuntimeError("Authorized source video is missing. Upload it again and create a new job.")
    if source:
        captions_path=None
        has_requested_audio,notice=_render_source_video(source,final,width,height,duration,fps,progress)
        render_mode="authorized_source_reframe"
    else:
        if settings.get("generation_mode","motion_graphics")!="motion_graphics":
            return _render_ai_video(job_id,job,progress,cancelled,output,final,width,height,duration,fps)
        if os.getenv("STUDIO_LEGACY_RENDERER")!="1":
            from .pro_render import render_pro   # Studio Pro pipeline (default)
            return render_pro(job_id,job,progress,cancelled,output,final,width,height,fps)
        scenes=_normalise_scenes(settings.get("scenes",[]),duration)
        captions_path=output/"captions.srt" if settings.get("captions") else None
        if captions_path: _write_srt(scenes,captions_path)
        progress(18,"Creating scene artwork")
        for index,scene in enumerate(scenes,1):
            _scene_image(scene,output/f"scene_{index:02d}.png",width,height,settings.get("visual_style","motion_graphics"),bool(settings.get("captions")),index,len(scenes))
        narration_path=_voice(job.get("script") or " ".join(scene["narration"] for scene in scenes),output,float(settings.get("narration_speed",1))) if settings.get("narration") else None
        music_path=_audio_upload(settings,"music_upload_id","music")
        sound_effects_path=_audio_upload(settings,"sound_effects_upload_id","sound effects")
        ffmpeg=shutil.which("ffmpeg")
        if not ffmpeg: raise RuntimeError("FFmpeg not found on PATH. Install FFmpeg, reopen the terminal and retry.")
        command=[ffmpeg,"-y","-hide_banner"]
        for scene in scenes:
            seconds=max(.2,scene["end_seconds"]-scene["start_seconds"])
            command.extend(["-loop","1","-framerate",str(fps),"-t",f"{seconds:.3f}","-i",str(output/f"scene_{scene['id']:02d}.png")])
        filters=[]
        for index in range(len(scenes)):
            filters.append(f"[{index}:v]zoompan=z='min(zoom+0.0009,1.08)':d=1:fps={fps}:s={width}x{height},setsar=1[v{index}]")
        filters.append("".join(f"[v{index}]" for index in range(len(scenes)))+f"concat=n={len(scenes)}:v=1:a=0,format=yuv420p[vout]")
        audio_inputs=_add_audio_tracks(command,filters,len(scenes),duration,narration_path,music_path,sound_effects_path)
        command.extend(["-filter_complex",";".join(filters),"-map","[vout]"])
        if audio_inputs: command.extend(["-map","[aout]","-c:a","aac","-b:a","128k"])
        command.extend(["-t",str(duration),"-r",str(fps),"-c:v","libx264","-preset","veryfast","-crf","23","-movflags","+faststart",str(final)])
        progress(48,"Rendering motion-graphics video")
        _run(command,max(180,duration*25))
        has_requested_audio=bool(audio_inputs)
        notice="Sentence-timed captions were embedded in each scene and exported as SRT." if captions_path else "Caption export was disabled."
        render_mode="motion_graphics"
    if not final.exists() or final.stat().st_size<5000: raise RuntimeError("Validation failed: output file is missing or too small.")
    progress(88,"Validating playable MP4")
    validation=validate_output(final,width,height,duration,has_requested_audio,fps)
    if not validation["valid"]: raise RuntimeError("Validation failed: sampled output frames appear black.")
    thumbnail=output/"thumbnail.png"
    ffmpeg=shutil.which("ffmpeg")
    _run([ffmpeg,"-y","-hide_banner","-ss","0.2","-i",str(final),"-frames:v","1",str(thumbnail)],30)
    return {"output_path":str(final),"captions_path":str(captions_path) if captions_path and captions_path.exists() else None,"thumbnail_path":str(thumbnail) if thumbnail.exists() else None,"validation":validation,"render_mode":render_mode,"render_notice":notice}
