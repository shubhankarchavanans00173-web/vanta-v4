"""Per-scene narration with word timings.

engines:  edge   - free Microsoft neural voices through the `edge-tts` package (needs internet, no key)
          system - offline pyttsx3 / OS voice (no word timings; they are estimated)
          test   - silent placeholder used only by automated tests
"""
from __future__ import annotations

import asyncio
import re
import shutil
import subprocess
from pathlib import Path

FALLBACK_VOICES=[
    {"id":"en-US-AndrewNeural","label":"Andrew - US male (warm)"},
    {"id":"en-US-AriaNeural","label":"Aria - US female"},
    {"id":"en-US-GuyNeural","label":"Guy - US male"},
    {"id":"en-US-JennyNeural","label":"Jenny - US female"},
    {"id":"en-GB-RyanNeural","label":"Ryan - UK male"},
    {"id":"en-IN-PrabhatNeural","label":"Prabhat - Indian English male"},
    {"id":"en-IN-NeerjaNeural","label":"Neerja - Indian English female"},
    {"id":"hi-IN-MadhurNeural","label":"Madhur - Hindi male"},
    {"id":"hi-IN-SwaraNeural","label":"Swara - Hindi female"},
    {"id":"mr-IN-AarohiNeural","label":"Aarohi - Marathi female"},
    {"id":"es-ES-AlvaroNeural","label":"Alvaro - Spanish male"},
    {"id":"fr-FR-DeniseNeural","label":"Denise - French female"},
]


def list_voices() -> list[dict]:
    try:
        import edge_tts
        voices=asyncio.run(edge_tts.list_voices())
        return [{"id":v["ShortName"],"label":f"{v['ShortName'].split('-',2)[-1].replace('Neural','')} - {v['Locale']} {v['Gender']}"} for v in voices]
    except Exception:
        return FALLBACK_VOICES


def probe_duration(path: Path) -> float:
    ffprobe=shutil.which("ffprobe")
    out=subprocess.run([ffprobe,"-v","error","-show_entries","format=duration","-of","csv=p=0",str(path)],capture_output=True,text=True,timeout=30)
    try: return float(out.stdout.strip())
    except ValueError: return 0.0


def estimate_words(text: str, duration: float) -> list[tuple[str,float,float]]:
    words=text.split()
    if not words: return []
    weights=[len(re.sub(r"\W","",w))+2 for w in words]
    total=sum(weights); cursor=0.0; out=[]
    for word,weight in zip(words,weights):
        span=duration*weight/total
        out.append((word,round(cursor,3),round(cursor+span,3))); cursor+=span
    return out


async def _edge(text: str, voice: str, rate: str, target: Path) -> list[tuple[str,float,float]]:
    import edge_tts
    try: communicate=edge_tts.Communicate(text,voice,rate=rate,boundary="WordBoundary")
    except TypeError: communicate=edge_tts.Communicate(text,voice,rate=rate)
    words=[]
    with target.open("wb") as handle:
        async for chunk in communicate.stream():
            if chunk["type"]=="audio": handle.write(chunk["data"])
            elif chunk["type"]=="WordBoundary":
                start=chunk["offset"]/1e7; words.append((chunk["text"],round(start,3),round(start+chunk["duration"]/1e7,3)))
    return words


def _system(text: str, target: Path, speed: float) -> None:
    import pyttsx3
    engine=pyttsx3.init()
    if not (engine.getProperty("voices") or []):
        engine.stop(); raise RuntimeError("No system voice is installed.")
    engine.setProperty("rate",max(100,min(260,round(165*speed))))
    engine.save_to_file(text[:8000],str(target)); engine.runAndWait(); engine.stop()


def _silent(text: str, target: Path) -> None:
    seconds=max(1.0,len(text.split())/2.6)
    subprocess.run([shutil.which("ffmpeg"),"-y","-loglevel","error","-f","lavfi","-i",f"sine=frequency=180:sample_rate=44100:duration={seconds:.2f}",
                    "-af","volume=0.05","-c:a","libmp3lame",str(target)],check=True,timeout=60)


def synthesize(text: str, out_dir: Path, name: str, engine: str, voice: str, speed: float) -> dict:
    """Return {path,duration,words,engine}. Raises RuntimeError with a readable message."""
    text=re.sub(r"\s+"," ",text).strip()
    if engine=="test":
        target=out_dir/f"{name}.mp3"; _silent(text,target); dur=probe_duration(target)
        return {"path":target,"duration":dur,"words":estimate_words(text,dur),"engine":"test"}
    if engine=="edge":
        target=out_dir/f"{name}.mp3"; rate=f"{round((speed-1)*100):+d}%"
        try:
            words=asyncio.run(_edge(text,voice,rate,target))
            dur=probe_duration(target)
            if dur<=0.2: raise RuntimeError("empty audio")
            return {"path":target,"duration":dur,"words":words or estimate_words(text,dur),"engine":"edge"}
        except Exception as error:
            raise RuntimeError(f"Neural voice failed ({str(error)[:160] or error.__class__.__name__}); check internet or choose the offline system voice.") from error
    target=out_dir/f"{name}.wav"
    try: _system(text,target,speed)
    except Exception as error: raise RuntimeError(f"System voice unavailable: {error}") from error
    if not target.exists() or target.stat().st_size<1000: raise RuntimeError("System voice produced no audio.")
    dur=probe_duration(target)
    return {"path":target,"duration":dur,"words":estimate_words(text,dur),"engine":"system"}
