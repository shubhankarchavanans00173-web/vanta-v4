"""Visual assets drawn with Pillow: YouTube thumbnail, scene title chips, shade overlay, watermark."""
from __future__ import annotations

import os
import re
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

BOLD_CANDIDATES=[
    r"C:\Windows\Fonts\impact.ttf",r"C:\Windows\Fonts\arialbd.ttf",r"C:\Windows\Fonts\segoeuib.ttf",
    "/System/Library/Fonts/Supplemental/Impact.ttf","/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf","/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
]


def bold_font(size: int):
    for candidate in BOLD_CANDIDATES:
        if os.path.exists(candidate):
            try: return ImageFont.truetype(candidate,size)
            except OSError: pass
    return ImageFont.load_default()


def hex_rgb(value: str, default=(255,200,60)) -> tuple[int,int,int]:
    h=(value or "").lstrip("#")
    return tuple(int(h[i:i+2],16) for i in (0,2,4)) if re.fullmatch(r"[0-9a-fA-F]{6}",h) else default


def _wrap_pixels(draw, text, font, max_width) -> list[str]:
    lines=[]; line=""
    for word in text.split():
        trial=(line+" "+word).strip()
        if draw.textlength(trial,font=font)<=max_width or not line: line=trial
        else: lines.append(line); line=word
    if line: lines.append(line)
    return lines


def shade_overlay(path: Path, width: int, height: int) -> None:
    """Dark gradients top and bottom so captions/titles stay readable on any footage."""
    column=Image.new("L",(1,height))
    px=column.load()
    for y in range(height):
        t=y/height; a=0.0
        if t>0.42: a=max(a,min(1,(t-0.42)/0.58)**1.6*0.68)
        if t<0.20: a=max(a,(1-t/0.20)**1.5*0.42)
        px[0,y]=int(255*a)
    alpha=column.resize((width,height))
    img=Image.new("RGBA",(width,height),(0,0,0,0)); img.putalpha(alpha); img.save(path)


def title_chip(text: str, path: Path, width: int, accent: tuple[int,int,int]) -> tuple[int,int]:
    label=re.sub(r"\s+"," ",text).upper()
    if len(label)>30: label=label[:29].rsplit(" ",1)[0]+"..."
    probe=ImageDraw.Draw(Image.new("RGBA",(10,10)))
    size=max(20,round(width*0.042))
    while True:                                   # shrink until the pill fits the frame
        font=bold_font(size); tw=int(probe.textlength(label,font=font)); pad=round(size*0.7); bar=round(size*0.28)
        if tw+pad*2+bar<=width*0.86 or size<=16: break
        size-=2
    w,h=tw+pad*2+bar,round(size*2.0)
    scale=2; img=Image.new("RGBA",(w*scale,h*scale),(0,0,0,0)); d=ImageDraw.Draw(img)
    d.rounded_rectangle((0,0,w*scale-1,h*scale-1),radius=h*scale//2,fill=(10,12,20,205))
    d.rounded_rectangle((pad*scale//2,h*scale*0.22,pad*scale//2+bar*scale,h*scale*0.78),radius=bar*scale//2,fill=accent+(255,))
    f2=bold_font(size*scale)
    d.text((pad*scale//2+bar*scale+pad*scale//2,h*scale//2),label,font=f2,fill=(255,255,255,255),anchor="lm")
    img.resize((w,h),Image.LANCZOS).save(path)
    return w,h


def watermark(text: str, path: Path, width: int) -> tuple[int,int]:
    size=max(18,round(width*0.03)); font=bold_font(size)
    probe=ImageDraw.Draw(Image.new("RGBA",(10,10))); tw=int(probe.textlength(text,font=font))
    w,h=tw+size,round(size*1.7)
    img=Image.new("RGBA",(w,h),(0,0,0,0)); d=ImageDraw.Draw(img)
    d.text((w//2,h//2),text,font=font,fill=(255,255,255,190),anchor="mm",stroke_width=2,stroke_fill=(0,0,0,150))
    img.save(path); return w,h


def make_thumbnail(frame: Path, title: str, out: Path, accent: str="#FFC83C", channel: str="") -> Path:
    W,H=1280,720; accent_rgb=hex_rgb(accent)
    src=Image.open(frame).convert("RGB")
    scale=max(W/src.width,H/src.height)
    src=src.resize((round(src.width*scale),round(src.height*scale)),Image.LANCZOS)
    left=(src.width-W)//2; top=(src.height-H)//2
    img=src.crop((left,top,left+W,top+H))
    # punchier look: slight contrast/saturation boost + dark gradient from the left for text
    from PIL import ImageEnhance
    img=ImageEnhance.Contrast(img).enhance(1.12); img=ImageEnhance.Color(img).enhance(1.2)
    grad=Image.linear_gradient("L").rotate(-90).resize((W,H))   # white (opaque shade) on the left, fading to the right
    shade=Image.new("RGBA",(W,H),(0,0,0,255)); shade.putalpha(grad.point(lambda v:int(v*0.78)))
    img=Image.alpha_composite(img.convert("RGBA"),shade)
    d=ImageDraw.Draw(img)
    text=re.sub(r"\s+"," ",title).strip().upper()
    for size in range(150,60,-6):
        font=bold_font(size); lines=_wrap_pixels(d,text,font,W*0.58)
        if len(lines)<=3 and size*1.08*len(lines)<H*0.7: break
    y=(H-size*1.08*len(lines))/2
    for i,line in enumerate(lines):
        color=accent_rgb if i==len(lines)-1 else (255,255,255)
        d.text((60,y),line,font=font,fill=color,stroke_width=max(4,size//14),stroke_fill=(0,0,0)); y+=size*1.08
    if channel:
        cf=bold_font(34); d.text((60,H-70),channel.upper(),font=cf,fill=(255,255,255),stroke_width=3,stroke_fill=(0,0,0))
    img=img.convert("RGB"); img.save(out,quality=92,optimize=True)
    if out.stat().st_size>1_900_000: img.save(out,quality=80,optimize=True)
    return out
