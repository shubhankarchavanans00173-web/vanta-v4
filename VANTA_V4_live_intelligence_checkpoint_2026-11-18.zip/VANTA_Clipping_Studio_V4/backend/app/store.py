import sqlite3,json
from contextlib import contextmanager
from datetime import datetime,timezone
from .config import DB_PATH
def now(): return datetime.now(timezone.utc).isoformat()
@contextmanager
def connect():
    """Commit on success, roll back on error, always close (sqlite3's own context manager never closes the connection)."""
    c=sqlite3.connect(DB_PATH,timeout=30); c.row_factory=sqlite3.Row
    try:
        yield c; c.commit()
    except BaseException:
        c.rollback(); raise
    finally:
        c.close()
def init_db():
    with connect() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,topic TEXT NOT NULL,script TEXT,status TEXT NOT NULL,progress INTEGER NOT NULL DEFAULT 0,settings TEXT NOT NULL,output_path TEXT,error TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)""")
def create_job(i,topic,script,settings):
    t=now()
    with connect() as c: c.execute("INSERT INTO jobs(id,topic,script,status,progress,settings,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",(i,topic,script,"draft",0,json.dumps(settings),t,t))
def update_job(i,**fields):
    fields["updated_at"]=now()
    fields={k:v for k,v in fields.items() if k in {"status","progress","output_path","error","script","settings","updated_at"}}
    if isinstance(fields.get("settings"),dict): fields["settings"]=json.dumps(fields["settings"])
    if fields:
        with connect() as c: c.execute("UPDATE jobs SET "+", ".join(k+"=?" for k in fields)+" WHERE id=?",(*fields.values(),i))
def conv(r):
    d=dict(r); d["settings"]=json.loads(d["settings"]); return d
def get_job(i):
    with connect() as c: r=c.execute("SELECT * FROM jobs WHERE id=?",(i,)).fetchone()
    return conv(r) if r else None
def list_jobs():
    with connect() as c: rows=c.execute("SELECT * FROM jobs ORDER BY created_at DESC LIMIT 100").fetchall()
    return [conv(r) for r in rows]

def update_settings(i,**changes):
    job=get_job(i)
    if not job: return None
    settings=job["settings"]
    settings.update(changes)
    update_job(i,settings=settings)
    return get_job(i)

def recover_interrupted_jobs():
    """A local process cannot safely resume a dead ffmpeg process after restart."""
    with connect() as c:
        c.execute("UPDATE jobs SET status=?, progress=0, error=?, updated_at=? WHERE status IN ('planning','producing','validating','queued')",(
            "draft","Backend restarted before this job finished. Use Retry to render again.",now()))


def delete_job(i):
    with connect() as c: c.execute("DELETE FROM jobs WHERE id=?",(i,))
