"""Caption writers: karaoke-style ASS (burned into the video) and word-timed SRT."""
from __future__ import annotations

import re

Word=tuple[str,float,float]


def _ass_time(t: float) -> str:
    cs=round(max(0,t)*100); h,cs=divmod(cs,360000); m,cs=divmod(cs,6000); s,cs=divmod(cs,100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _srt_time(t: float) -> str:
    ms=round(max(0,t)*1000); h,ms=divmod(ms,3600000); m,ms=divmod(ms,60000); s,ms=divmod(ms,1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _bgr(hex_color: str, default: str="FFC83C") -> str:
    h=(hex_color or "").lstrip("#")
    if not re.fullmatch(r"[0-9a-fA-F]{6}",h): h=default
    return f"&H00{h[4:6]}{h[2:4]}{h[0:2]}&".upper()


def paginate(words: list[Word], max_words: int, max_chars: int) -> list[list[Word]]:
    pages=[]; cur=[]
    for w in words:
        cur.append(w)
        text=" ".join(x[0] for x in cur)
        ends=bool(re.search(r"[.!?;:]$",w[0]))
        if len(cur)>=max_words or len(text)>=max_chars or ends:
            pages.append(cur); cur=[]
    if cur: pages.append(cur)
    return pages


def _esc(text: str) -> str:
    return text.replace("\\","").replace("{","(").replace("}",")").replace("\n"," ")


def write_ass(words: list[Word], path, width: int, height: int, style: str="karaoke", accent: str="#FFC83C", aspect: str="9:16") -> None:
    vertical=aspect=="9:16"
    size=round(height*(0.041 if vertical else 0.066 if aspect=="16:9" else 0.05))
    margin_v=round(height*(0.24 if vertical else 0.09 if aspect=="16:9" else 0.14))
    margin_x=round(width*0.07)
    outline=max(3,round(size*0.11))
    max_words,max_chars=(3,18) if vertical else (6,44) if aspect=="16:9" else (4,24)
    karaoke=style=="karaoke"
    if not karaoke: max_words,max_chars=(5,30) if vertical else (9,64) if aspect=="16:9" else (6,36)
    hi=_bgr(accent)
    lines=[
        "[Script Info]","ScriptType: v4.00+",f"PlayResX: {width}",f"PlayResY: {height}","WrapStyle: 0","ScaledBorderAndShadow: yes","",
        "[V4+ Styles]",
        "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
        f"Style: Main,Arial,{size},&H00FFFFFF&,&H00FFFFFF&,&H00000000&,&H96000000&,-1,0,0,0,100,100,0,0,1,{outline},{max(2,outline//2)},2,{margin_x},{margin_x},{margin_v},1",
        "","[Events]","Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
    ]
    for page in paginate(words,max_words,max_chars):
        texts=[_esc(w[0]).upper() if (karaoke and vertical) else _esc(w[0]) for w in page]
        if not karaoke:
            lines.append(f"Dialogue: 0,{_ass_time(page[0][1])},{_ass_time(page[-1][2])},Main,,0,0,0,,{{\\fad(80,80)}}{' '.join(texts)}")
            continue
        for i,w in enumerate(page):
            start=w[1]; end=page[i+1][1] if i+1<len(page) else w[2]
            if end<=start: end=start+0.08
            parts=[]
            for j,t in enumerate(texts):
                parts.append(f"{{\\c{hi}\\fscx110\\fscy110}}{t}{{\\r}}" if j==i else t)
            pop="{\\fad(40,0)}" if i==0 else ""
            lines.append(f"Dialogue: 0,{_ass_time(start)},{_ass_time(end)},Main,,0,0,0,,{pop}{' '.join(parts)}")
    path.write_text("\n".join(lines)+"\n",encoding="utf-8")


def write_srt(words: list[Word], path, aspect: str="9:16") -> None:
    blocks=[]
    for n,page in enumerate(paginate(words,5 if aspect=="9:16" else 9,36 if aspect=="9:16" else 70),1):
        blocks.append(f"{n}\n{_srt_time(page[0][1])} --> {_srt_time(page[-1][2])}\n{' '.join(w[0] for w in page)}\n")
    path.write_text("\n".join(blocks),encoding="utf-8")
