from pydantic import BaseModel, Field, model_validator
from typing import Any, Literal, Optional


class CreateJobRequest(BaseModel):
    topic: str = Field(default="",max_length=4000)
    script: Optional[str] = Field(default=None,max_length=30000)
    source_text: Optional[str] = Field(default=None,max_length=30000)
    input_type: Literal["topic","script","story","transcript","youtube_remake","source_video","video_clips"]="topic"
    source_upload_id: Optional[str] = Field(default=None,max_length=64)
    source_video_url: Optional[str] = Field(default=None,max_length=2000)
    source_authorized: bool=False
    clip_count: int=Field(default=5,ge=1,le=10)
    clip_duration_seconds: int=Field(default=15,ge=3,le=90)
    clip_title_overlay: bool=True
    clip_title: str=Field(default="",max_length=120)
    subtitle_upload_id: Optional[str]=Field(default=None,max_length=64)
    reference_upload_ids: list[str] = Field(default_factory=list,max_length=5)
    music_upload_id: Optional[str] = Field(default=None,max_length=64)
    sound_effects_upload_id: Optional[str] = Field(default=None,max_length=64)
    duration_seconds: int = Field(default=45,ge=15,le=600)
    aspect_ratio: Literal["9:16","16:9","1:1"]="9:16"
    resolution_preset: Literal["draft","balanced","quality"]="quality"
    frame_rate: Literal[24,30,60]=30
    language: str=Field(default="English",max_length=40)
    visual_style: Literal[
        "motion_graphics","realistic","illustrated","anime","cartoon","cinematic",
        "educational","storytelling","anime_inspired","documentary","minimal",
    ]="cinematic"
    generation_mode: Literal["motion_graphics","local_ai","online_ai","hybrid"]="motion_graphics"
    hybrid_online_enabled: bool=False
    character_description: str=Field(default="",max_length=1000)
    environment_description: str=Field(default="",max_length=1000)
    workflow_mode: Literal["manual","approval","auto"]="manual"
    narration: bool=True
    narration_speed: float=Field(default=1.0,ge=0.7,le=1.4)
    captions: bool=True
    # ---- Studio Pro options (all optional, safe defaults) ----
    visual_source: Literal["auto","stock","animated"]="auto"      # auto = Pexels stock if key is set, else animated
    narration_engine: Literal["edge","system"]="edge"            # edge = free neural voices (internet), system = offline
    voice: str=Field(default="en-US-AndrewNeural",max_length=80)
    caption_style: Literal["karaoke","classic"]="karaoke"
    music_volume: float=Field(default=0.12,ge=0.02,le=0.5)
    transitions: bool=True
    progress_bar: bool=True
    watermark: str=Field(default="",max_length=40)
    accent_color: str=Field(default="",max_length=7)
    channel_name: str=Field(default="",max_length=60)

    @model_validator(mode="after")
    def validate_input(self):
        supplied=" ".join(v for v in [self.topic,self.script or "",self.source_text or ""] if v).strip()
        if self.input_type=="video_clips":
            if bool(self.source_upload_id)==bool(self.source_video_url):
                raise ValueError("Provide exactly one authorized source-video upload or direct video URL.")
            if not self.source_authorized:
                raise ValueError("Confirm that you are authorized to create clips from this source video.")
            if self.generation_mode!="motion_graphics":
                raise ValueError("Video-to-Clips preserves source footage; choose the separate AI remake workflow to generate new footage.")
        elif self.input_type=="source_video":
            if not self.source_upload_id:
                raise ValueError("Upload an authorized source video before creating this job.")
            if self.generation_mode!="motion_graphics":
                raise ValueError("Authorized source-video reframing is a separate mode; choose Motion Graphics for source-video jobs.")
        elif self.input_type!="video_clips" and len(supplied)<3:
            raise ValueError("Enter a topic, script, story, or transcript with at least 3 characters.")
        if self.hybrid_online_enabled and self.generation_mode!="hybrid":
            raise ValueError("Enable paid online video only in Hybrid workflow mode.")
        return self


class ProduceJobRequest(BaseModel):
    approve_online: bool=False


class YouTubeAnalyzeRequest(BaseModel):
    url: str=Field(min_length=8,max_length=2000)
    mode: Literal["clip","remake"]="remake"


class YouTubeUploadRequest(BaseModel):
    title: str=Field(default="",max_length=100)
    description: Optional[str]=Field(default=None,max_length=5000)
    tags: list[str]=Field(default_factory=list,max_length=30)
    privacy: Literal["private","unlisted","public"]="private"
    made_for_kids: bool=False
    ai_disclosure: bool=True
    category_id: str=Field(default="22",max_length=4)
    publish_at: Optional[str]=Field(default=None,max_length=40)   # RFC3339 UTC, requires private
    set_thumbnail: bool=True


class UpdateScriptRequest(BaseModel):
    script: str=Field(min_length=3,max_length=30000)


class UpdateStoryboardRequest(BaseModel):
    scenes: list[dict[str,Any]]=Field(min_length=1,max_length=60)


class UpdateMetadataRequest(BaseModel):
    titles: list[str]=Field(min_length=1,max_length=3)
    description: str=Field(default="",max_length=5000)
    hashtags: list[str]=Field(default_factory=list,max_length=20)

    @model_validator(mode="after")
    def validate_metadata(self):
        self.titles=[title.strip()[:120] for title in self.titles if title.strip()]
        self.hashtags=[tag.strip()[:80] for tag in self.hashtags if tag.strip()]
        if not self.titles:
            raise ValueError("Add at least one non-empty title suggestion.")
        return self
