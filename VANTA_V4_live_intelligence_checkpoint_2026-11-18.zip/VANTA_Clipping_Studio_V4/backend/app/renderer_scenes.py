"""Scene normalisation, prompts, SRT writing and scene-image drawing for the legacy renderer.

Split from renderer.py (Phase 2c); re-exported there, behaviour unchanged.
"""
from __future__ import annotations

import re
from PIL import Image, ImageDraw
from pathlib import Path
from .renderer_common import _timestamp, getfont, wrap


def _video_shot_prompt(continuity: str, shot: str, angle: str) -> str:
    prompt=f"{continuity} {shot}. {angle}. Show clear continuous physical action and natural subject movement."
    if re.search(r"\bcats?\b",prompt,re.IGNORECASE):
        prompt+=" Keep the chef unmistakably feline, with an orange-and-white furry face, pointed ears, whiskers, a cat muzzle, and paws; show any human customer separately in the background."
    return prompt


def _style_prompt(style: str) -> str:
    styles={
        "realistic":"photorealistic live-action visual style, natural textures and physically plausible lighting",
        "illustrated":"hand-painted illustrated visual style with expressive brushwork and layered color",
        "anime":"anime visual style with expressive hand-drawn character motion and detailed backgrounds",
        "anime_inspired":"anime-inspired visual style with expressive character motion and detailed backgrounds",
        "cartoon":"stylized cartoon animation with clear silhouettes and expressive movement",
        "cinematic":"cinematic live-action visual style, composed lighting and filmic camera language",
        "educational":"clear educational documentary visuals that make the described action easy to understand",
        "storytelling":"cinematic visual storytelling with expressive action and coherent scene composition",
        "documentary":"natural documentary visual style with believable environments and movement",
        "minimal":"clean minimal visual style with a focused subject and uncluttered scene",
    }
    return styles.get(style,styles["cinematic"])


def _normalise_scenes(raw: list[dict], duration: int) -> list[dict]:
    scenes=[scene for scene in raw if isinstance(scene,dict) and str(scene.get("narration","")).strip()]
    if not scenes: scenes=[{"title":"Your short","narration":"Add narration to this scene.","caption":"Add narration to this scene."}]
    # Preserve edited timings when they form a valid contiguous timeline. Older
    # jobs and hand-edited payloads fall back to an even split.
    proposed=[]
    valid_timing=True
    cursor=0.0
    for index,scene in enumerate(scenes):
        try:
            start=float(scene.get("start_seconds",cursor))
            end=float(scene.get("end_seconds",duration if index==len(scenes)-1 else 0))
        except (TypeError,ValueError):
            valid_timing=False
            break
        if index==0 and abs(start)>0.01:
            valid_timing=False
        if index and abs(start-cursor)>0.05:
            valid_timing=False
        if end<=start or end>duration+0.05:
            valid_timing=False
        proposed.append((max(0.0,start),min(float(duration),end)))
        cursor=end
    if not proposed or abs(cursor-duration)>0.05:
        valid_timing=False
    if not valid_timing:
        each=duration/len(scenes)
        proposed=[]
        cursor=0.0
        for index in range(len(scenes)):
            end=duration if index==len(scenes)-1 else round(cursor+each,3)
            proposed.append((cursor,end)); cursor=end
    start=0.0
    normalized=[]
    for index,scene in enumerate(scenes,1):
        start,end=proposed[index-1]
        narration=str(scene.get("narration","")).strip()
        normalized.append({
            **scene,
            "id":index,
            "title":str(scene.get("title") or f"Scene {index}")[:80],
            "narration":narration,
            "caption":str(scene.get("caption") or narration)[:500],
            "start_seconds":round(start,3),
            "end_seconds":round(end,3),
        })
        start=end
    return normalized


def _write_srt(scenes: list[dict], path: Path) -> None:
    blocks=[]
    for index,scene in enumerate(scenes,1):
        caption=scene["caption"].strip()
        if caption:
            blocks.append(f"{index}\n{_timestamp(scene['start_seconds'])} --> {_timestamp(scene['end_seconds'])}\n{caption}\n")
    path.write_text("\n".join(blocks),encoding="utf-8")


def _palette(style: str) -> tuple[tuple[int,int,int],tuple[int,int,int],tuple[int,int,int]]:
    options={
        "anime_inspired":((42,25,76),(221,109,185),(104,222,235)),
        "documentary":((22,37,47),(74,154,150),(244,190,82)),
        "cinematic":((23,22,34),(123,80,178),(245,157,86)),
        "minimal":((22,26,34),(81,116,155),(210,221,232)),
        "motion_graphics":((15,18,43),(105,88,225),(88,222,200)),
    }
    return options.get(style,options["motion_graphics"])


def _scene_image(scene: dict, output: Path, width: int, height: int, style: str, captions: bool, index: int, total: int) -> None:
    background,accent,secondary=_palette(style)
    image=Image.new("RGB",(width,height),background)
    draw=ImageDraw.Draw(image)
    # The later zoom/pan turns this artwork into a declared motion-graphics clip.
    for y in range(0,height,6):
        amount=int(15+40*y/height)
        draw.line((0,y,width,y),fill=tuple(min(255,value+amount//6) for value in background),width=2)
    for offset,size in ((.16,.27),(.83,.18),(.65,.12)):
        x=int(width*offset); y=int(height*(.11+offset/5)); radius=int(width*size)
        draw.ellipse((x-radius,y-radius,x+radius,y+radius),outline=accent,width=max(2,width//230))
    card=(int(width*.07),int(height*.11),int(width*.93),int(height*(.79 if captions else .88)))
    draw.rounded_rectangle(card,radius=max(18,width//25),outline=accent,width=max(3,width//190),fill=tuple(max(0,v-4) for v in background))
    label_font=getfont(max(16,int(width*.024)))
    title_font=getfont(max(25,int(width*.049)))
    body_font=getfont(max(20,int(width*.034)))
    draw.text((int(width*.12),int(height*.17)),f"SCENE {index}/{total}  •  LOCAL MOTION GRAPHICS",font=label_font,fill=secondary)
    title_y=int(height*.27)
    for line in wrap(scene["title"],max(16,int(width/24)))[:2]:
        draw.text((int(width*.12),title_y),line,font=title_font,fill=(248,248,252),stroke_width=1,stroke_fill=background)
        title_y+=int(width*.067)
    text_y=max(int(height*.42),title_y+int(height*.025))
    for line in wrap(scene["narration"],max(20,int(width/20)))[:7]:
        draw.text((int(width*.12),text_y),line,font=body_font,fill=(223,226,238))
        text_y+=int(width*.052)
        if text_y>card[3]-int(height*.08): break
    if captions:
        caption_y=int(height*.825)
        draw.rounded_rectangle((int(width*.07),caption_y-int(height*.025),int(width*.93),int(height*.96)),radius=14,fill=(3,5,12),outline=secondary,width=2)
        caption_font=getfont(max(17,int(width*.029)))
        for line_number,line in enumerate(wrap(scene["caption"],max(18,int(width/21)))[:3]):
            draw.text((int(width*.11),caption_y+line_number*int(width*.04)),line,font=caption_font,fill=(255,255,255),stroke_width=1,stroke_fill=(0,0,0))
    image.save(output)
