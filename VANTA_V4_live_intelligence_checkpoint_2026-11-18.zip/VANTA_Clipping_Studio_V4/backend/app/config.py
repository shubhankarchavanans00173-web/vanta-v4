from pathlib import Path
import os

from .envload import load_env

ROOT=Path(__file__).resolve().parents[2]
# Keys live in <project>/.env (copy .env.example). Never commit that file.
load_env(ROOT/".env")

DATA_DIR=Path(os.getenv("STUDIO_DATA_DIR",ROOT/"data")).resolve()
OUTPUT_DIR=DATA_DIR/"outputs"
UPLOAD_DIR=DATA_DIR/"uploads"
CACHE_DIR=DATA_DIR/"cache"
SECRETS_DIR=DATA_DIR/"secrets"
DB_PATH=DATA_DIR/"jobs.db"
MAX_UPLOAD_BYTES=int(os.getenv("STUDIO_MAX_UPLOAD_BYTES",str(2*1024*1024*1024)))
for _d in (DATA_DIR,OUTPUT_DIR,UPLOAD_DIR,CACHE_DIR,SECRETS_DIR):
    _d.mkdir(parents=True,exist_ok=True)
