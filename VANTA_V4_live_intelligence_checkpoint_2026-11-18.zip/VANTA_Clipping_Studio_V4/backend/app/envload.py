"""Tiny .env loader (no extra dependency). Real environment variables always win.

Robust against what Windows editors and shells actually produce: UTF-8 with or without BOM, UTF-16 (PowerShell ``>>``),
legacy ANSI, ``export KEY=value``, quotes, and trailing ``# comments`` after unquoted values.
"""
from __future__ import annotations

import os
import re
from pathlib import Path


def read_env_text(path: Path) -> str:
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16")
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def parse_env(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.lower().startswith("export "):
            line = line[7:].lstrip()
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip()
        if value[:1] in {'"', "'"} and value.count(value[0]) >= 2:
            value = value[1:value.index(value[0], 1)]
        else:
            value = re.split(r"\s+#", value, maxsplit=1)[0].strip()
        if key and value:
            out[key] = value
    return out


def load_env(path: Path) -> None:
    if not path.is_file():
        return
    try:
        values = parse_env(read_env_text(path))
    except OSError:
        return
    for key, value in values.items():
        if key not in os.environ:
            os.environ[key] = value
