"""Command-line diagnostics for platform link downloads.

  python diagnose.py                       print the dependency report (Python, yt-dlp, FFmpeg, JS runtime, folders)
  python diagnose.py --test-url <url>      ALSO download that public video for real into a temp folder, validate it with ffprobe, then delete it

Exit code 0 = report printed (and test download, if requested, succeeded); 1 = problems found or test failed.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.clipstudio import links, media, settings, ytdlp  # noqa: E402  (importing app.config also loads .env)
from app.clipstudio.linkerrors import LinkError  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--test-url", help="a public video you may use, e.g. https://www.youtube.com/watch?v=jNQXAC9IVRw")
    ap.add_argument("--json", action="store_true", help="print the report as JSON")
    args = ap.parse_args()
    d = ytdlp.diagnostics()
    if args.json:
        print(json.dumps(d, indent=2))
    else:
        js = d["js_runtime"]
        print("VANTA link-download diagnostics")
        print(f"  Python        : {d['python']['version']}  {d['python']['executable']}  ({'virtualenv' if d['python']['in_virtualenv'] else 'NOT a virtualenv'})")
        print(f"  yt-dlp        : {d['yt_dlp']['version'] or 'NOT INSTALLED'}" + (f"  ({d['yt_dlp']['age_days']} days old)" if d['yt_dlp']['age_days'] is not None else ""))
        print(f"  solver scripts: {d['yt_dlp']['ejs_version'] or 'not installed (yt-dlp-ejs)'}")
        print(f"  links enabled : {'yes' if d['yt_dlp']['enabled'] else 'NO (set VANTA_ENABLE_YTDLP=1 in .env)'}")
        print(f"  FFmpeg        : {d['ffmpeg']['version'] or 'NOT FOUND'}")
        print(f"  JS runtime    : {(js['name'] + ' ' + str(js['version']) + ' ' + js['path']) if js['available'] else 'none - ' + js['note']}")
        print(f"  .env          : {d['env_file']['path']}  ({'found' if d['env_file']['exists'] else 'missing'})")
        print(f"  download dir  : {d['folders']['sources']}  writable={d['folders']['writable']}")
        for p in d["problems"]:
            print(f"  PROBLEM : {p}")
        for w in d["warnings"]:
            print(f"  WARNING : {w}")
        print("  READY" if d["ready"] else "  NOT READY - fix the PROBLEM lines above")
    if not args.test_url:
        return 0 if d["ready"] else 1
    print(f"\nTest download of {args.test_url} (real network; the file is deleted afterwards)")
    dest = Path(tempfile.mkdtemp(prefix="vanta-difftest-", dir=settings.TMP_DIR if settings.TMP_DIR.exists() else None))
    try:
        url = links.normalise_url(args.test_url)
        fetched = links.fetch_platform(url, dest, progress=lambda p, m=None: print(f"\r  {m or ''}".ljust(60), end="", flush=True))
        info = fetched.probe or media.probe(fetched.path)
        print(f"\n  OK: {fetched.title!r} - {info['duration']:.0f}s, {info['width']}x{info['height']}, audio={info['has_audio']}, {fetched.path.stat().st_size / 1e6:.1f} MB")
        return 0
    except LinkError as e:
        print(f"\n  FAILED [{e.code}]: {e}")
        if e.hint:
            print(f"  What to do: {e.hint}")
        for line in e.details:
            print(f"    | {line}")
        return 1
    finally:
        shutil.rmtree(dest, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
