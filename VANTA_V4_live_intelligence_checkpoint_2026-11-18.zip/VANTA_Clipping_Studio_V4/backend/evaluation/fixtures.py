"""Synthetic evaluation transcripts, written by the developer (not real videos, not human ratings).

Each block is tagged: ``good`` = a self-contained moment an editor would plausibly publish; everything else is a stretch a good
ranker should avoid (greeting/outro, rambling filler, context-dependent fragments, repetition). Timing is sentence-level at ~2.7 words/s
with short gaps inside a block and a 1.0 s pause between blocks. Gold/bad spans below are derived from these tags.
"""
from __future__ import annotations

from app.clipstudio.transcript import Segment, Transcript

VIDEOS = {
    "focus_talk": [
        ("meta", "Hey everyone, welcome back to the channel. Today we're going to talk about focus. Before we start, don't forget to like and subscribe. Okay, so, let's get into it."),
        ("good", "Why do you feel exhausted after a day of doing nothing important? Because your brain spends energy on every decision, even tiny ones. Researchers call this decision fatigue. A judge deciding parole cases was more lenient in the morning than late in the day. So the fix is simple: decide the small things once. Wear similar clothes, eat the same breakfast, and save your energy for choices that matter."),
        ("ramble", "Um, so yeah, I was thinking about that the other day, and, you know, it's kind of like, whatever, stuff just happens. And I mean, we could go on about this for a while. Honestly I don't even remember where I was going with that. Anyway, it's one of those things."),
        ("dangling", "And that's why it didn't work the second time. But they said it was fine, so we just kept going with it. It was the same thing as before, basically, only slower. So yeah, that part was frustrating, and it kept going like that for a while."),
        ("good", "Three years ago I missed a deadline that cost my team a major client. I remember sitting in my car for an hour, unable to go inside. Then my manager walked out, sat next to me, and said one sentence I still repeat. He said a mistake you learn from is cheaper than a lesson you never get. That afternoon we wrote a checklist, and we haven't missed a deadline since."),
        ("repeat", "Focus is important. Focus is really important. You have to focus on focus. If you do not focus then you cannot focus. Focus matters because focus is what helps you focus. So remember that focus is important and you should focus."),
        ("good", "Here's the thing nobody tells you about multitasking. People who think they are great at it are usually the worst. A study at Stanford found heavy multitaskers were worse at filtering out irrelevant information. They actually switched tasks more slowly. So the busiest looking person in the room is often the least productive. Pick one task, set a timer for twenty five minutes, and protect it."),
        ("meta", "That's it for today. Thanks for watching, and I'll see you next time. Don't forget to subscribe and hit the bell."),
    ],
    "kitchen_science": [
        ("meta", "Hi everyone, welcome to the kitchen. In this video we're going to cook a few things. Don't forget to subscribe. Alright, let's start."),
        ("good", "What happens when you put salt on a steak an hour before cooking? Most people think salt dries meat out. But it works the opposite way. The salt pulls moisture out, then the meat reabsorbs that salty liquid. The result is seasoned meat all the way through, not just on the surface. So salt your steak early, or right before the pan, but never in the middle."),
        ("ramble", "So, um, yeah, we had a lot of stuff in the fridge, and, you know, I kind of just threw things together. Whatever, it was fine. I mean, it was sort of okay, I guess. Anyway, that's a thing that happens sometimes."),
        ("good", "The first time I made bread I forgot the yeast. I waited three hours and nothing happened. My grandmother looked at the pan and laughed until she cried. Then she handed me a rolling pin and said we're making flatbread tonight. It turned out to be the best thing I ate all year. I still make that recipe every Sunday."),
        ("dangling", "So then she took the other one and put it back in the oven. Which, honestly, is why it came out darker than the first batch. And they didn't really notice, but it was different from what we talked about. That one was her favorite though."),
        ("repeat", "Butter is good. Butter is really good. You should use butter because butter makes everything better. If you do not use butter then you are missing the butter. Butter matters because butter is the best, so use butter."),
        ("good", "Here's the secret to crispy roast potatoes. Boil them first for ten minutes, then drain and shake them hard in the pot. Those rough edges turn into crunchy bits in the oven. Skip the shaking and you lose half the crunch. Roast them in very hot oil at two hundred degrees for about forty minutes."),
        ("meta", "That's all for today. Thanks for watching, see you next time. Like and subscribe if you enjoyed it."),
    ],
    "founder_interview": [
        ("meta", "Welcome to the show. We have a great guest today. Thanks for joining us, and before we start, subscribe to the channel. Let's jump right in."),
        ("good", "Did you ever think the company would fail? Honestly, every single month for the first two years. We were three weeks from running out of money when a customer paid an invoice early. That one email kept the whole company alive. I still have it printed on my wall. It taught me that survival is mostly about cash, not ideas."),
        ("dangling", "And that's the reason it took so long. But like I said, they weren't really on board with it at the time. So we just did the other thing, which was basically what we talked about before. Yeah, and that was kind of the end of that."),
        ("ramble", "Um, well, you know, it's hard to say, it's kind of a lot of things, I mean, stuff goes on. Honestly whatever, we just sort of went with it. And yeah, I guess that's a thing, you know, anyway."),
        ("good", "The biggest mistake founders make is hiring too fast. We hired twelve people in one quarter. Culture fell apart in ninety days. We had to let half of them go, and that was the hardest week of my life. Now we hire slowly, and every new person has to solve a real problem before their first day."),
        ("repeat", "Growth is key. Growth is really key. You need growth to grow. If there is no growth then you cannot grow. Growth matters because growth is how you grow, so always remember growth and keep growing."),
        ("good", "Here's what surprised me most about our first big customer. They didn't want more features, they wanted fewer. We removed a third of the product and their usage doubled. People don't pay for options, they pay for the one thing that works. Since then, every feature has to earn its place against that."),
        ("meta", "That's all the time we have. Thanks so much for watching, and see you in the next episode. Don't forget to subscribe."),
    ],
}


def build(name: str) -> dict:
    segs, t = [], 0.0
    gold, bad = [], []
    for tag, text in VIDEOS[name]:
        sentences = [s.strip() + "." if not s.strip()[-1] in ".?!" else s.strip() for s in _split(text)]
        block_start = t
        for s in sentences:
            d = max(1.2, len(s.split()) / 2.7)
            segs.append(Segment(round(t, 3), round(t + d, 3), s))
            t += d + 0.25
        block_end = t - 0.25
        (gold if tag == "good" else bad).append((round(block_start, 2), round(block_end, 2), tag))
        t += 1.0
    return {"name": name, "duration": round(t + 2, 2), "transcript": Transcript(segs, "synthetic-fixture"), "gold": gold, "bad": bad}


def _split(text: str) -> list[str]:
    import re
    return [p for p in re.split(r"(?<=[.!?])\s+", text.strip()) if p]


def all_fixtures() -> list[dict]:
    return [build(n) for n in VIDEOS]
