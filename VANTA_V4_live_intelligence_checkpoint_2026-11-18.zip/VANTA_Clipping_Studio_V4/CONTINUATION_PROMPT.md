# VANTA continuation — live intelligence repair

Continue from the updated source tree, not from the original archive.

## Already changed
1. `backend/app/clipstudio/live/stream_manager.py`: ignores chat messages until the rolling buffer has a first published media segment, preventing startup chat bursts from creating timestamp-zero candidates.
2. `backend/app/clipstudio/routes/live.py`: resolves the platform reference through `_stream_ref(req)` before creating the YouTube/Twitch chat adapter, so URL-only inputs can provide their own video/channel reference.
3. `backend/tests/test_live_intelligence.py`: regression test for chat arriving before the first media segment.
4. `docs/FINAL_REPAIR_PLAN.md`: records changes, test results, and remaining verification.

## Test status
- `python -m pytest backend/tests/test_live_intelligence.py backend/tests/test_live_session_api.py -q`: 9 passed.
- `backend/tests/test_live_chat_wiring.py`: 16 passed, then one failed because Google OAuth Python dependencies are absent in this environment (`google-api-python-client`, `google-auth`, `google-auth-oauthlib`).
- A broader live test run timed out and is incomplete.

## Next required work
1. Install/verify optional Google OAuth dependencies in the target environment; rerun credential tests.
2. Add a focused route test proving a YouTube live URL with blank `stream_ref` passes the parsed video ID into `build_chat`.
3. Investigate why only one clip is produced in real sessions. Instrument event counts, chat spike detector status, deduplication decisions, event timestamps, rolling-buffer start/end, job status, and ingest errors. Do not weaken thresholds blindly.
4. Implement a real, lightweight media-evidence producer (audio activity/transcription or another locally available signal) that timestamps evidence on the same media clock. Never fabricate evidence or label chat activity as a visual/audio event.
5. Improve correlation so weak/unrelated evidence cannot be attached to a chat spike merely because it falls within a broad time window. Preserve honest chat-only labelling when no corroboration exists.
6. Add tests for multiple independent spikes, deduplication boundaries, media/chat clock alignment, unrelated evidence rejection, and chat-unavailable sessions.
7. Run all backend tests and frontend typecheck/build; record exact outcomes. Then test with a real authorised stream and manually inspect multiple clips.

## Constraints
- Preserve existing workflows and user changes; no rebuild.
- No paid API calls without explicit user permission.
- Keep all clips review-only; never auto-publish.
- Do not package `.env`, OAuth tokens, `data/secrets`, credentials, `.venv`, `node_modules`, caches, build output, or `.git`.
- Do not claim live correctness or clip quality without an actual authorised stream test.
- Before stopping, update this file and `docs/FINAL_REPAIR_PLAN.md`, create and verify a complete source ZIP, and provide the actual artifact.
