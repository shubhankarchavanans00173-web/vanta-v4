@echo off
setlocal
cd /d "%~dp0"
rem Stops whatever is LISTENING on VANTA's two ports (backend 8000, frontend 3000). Close the two console windows instead if you prefer.
set "FOUND=0"
for %%P in (8000 3000) do (
  for /f "tokens=5" %%A in ('netstat -ano ^| findstr /R /C:":%%P .*LISTENING"') do (
    echo Stopping process %%A on port %%P
    taskkill /PID %%A /T /F >nul 2>nul
    if errorlevel 1 ( echo Could not stop process %%A & set "RC=1" ) else set "FOUND=1"
  )
)
if "%FOUND%"=="0" echo No VANTA listener was found on ports 8000 or 3000.
if not defined RC set "RC=0"
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%
