@echo off
setlocal
cd /d "%~dp0"
call "%~dp0_find_python.bat"
if not defined STUDIO_PYTHON ( echo Backend is not set up. Run setup_all.bat first. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
where ffmpeg >nul 2>nul || ( echo FFmpeg was not found. Run check_system.bat. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
where ffprobe >nul 2>nul || ( echo FFprobe was not found. Run check_system.bat. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
where node >nul 2>nul || ( echo Node.js 20+ was not found. Run check_system.bat. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
if not exist "frontend\node_modules\next\package.json" ( echo Frontend dependencies are missing. Run setup_frontend.bat first. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
if not exist ".env" if exist ".env.example" copy ".env.example" ".env" >nul
if not exist ".env" ( echo .env.example is missing; backend not started. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
start "VANTA backend" cmd /k ""%~dp0start_backend.bat""
start "VANTA frontend" cmd /k ""%~dp0start_frontend.bat""
echo Waiting for the servers, then opening the dashboard...
timeout /t 12 >nul
start http://localhost:3000
endlocal & exit /b 0
