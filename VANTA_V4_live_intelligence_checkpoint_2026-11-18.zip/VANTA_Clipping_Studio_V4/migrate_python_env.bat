@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo VANTA - create a NEW Python 3.12 environment (optional)
echo ============================================================
echo Your current environment (e.g. C:\ai-video-env) is NOT touched or deleted.
echo The new one is created at C:\ai-video-env-py312, the backend requirements and
echo yt-dlp are installed, and the VANTA tests are run against it. Nothing switches
echo over until YOU choose to (see the end of this script).
echo.
where py >nul 2>nul || ( echo The Windows "py" launcher was not found. Install Python 3.12 from python.org first. & pause & exit /b 1 )
py -3.12 --version >nul 2>nul || ( echo Python 3.12 is not installed. Install it from python.org ^(keep "py launcher" ticked^) and run this again. & pause & exit /b 1 )
if exist "C:\ai-video-env-py312\Scripts\python.exe" (
  echo C:\ai-video-env-py312 already exists - it will be reused, not recreated.
) else (
  py -3.12 -m venv C:\ai-video-env-py312 || ( echo Could not create the environment. & pause & exit /b 1 )
)
set "NEWPY=C:\ai-video-env-py312\Scripts\python.exe"
"%NEWPY%" -m pip install --upgrade pip
"%NEWPY%" -m pip install -r backend\requirements.txt -r backend\requirements-links.txt || ( echo Installing requirements failed. Your old environment is unchanged. & pause & exit /b 1 )
echo.
echo Optional local transcription (large download) is NOT installed here. To add it later:
echo   %NEWPY% -m pip install faster-whisper
echo.
echo Running the VANTA tests with the new environment...
cd backend
"%NEWPY%" -m unittest discover -s tests -t .
if errorlevel 1 ( echo. & echo Some tests FAILED on Python 3.12. Do not switch; keep using your current environment. & pause & exit /b 1 )
cd ..
echo.
echo ALL TESTS PASSED on the new environment.
echo To switch VANTA to it, create a file named python_env.txt in this folder whose only line is:
echo   %NEWPY%
echo To switch back, delete python_env.txt. Your old environment stays untouched either way.
pause
endlocal
