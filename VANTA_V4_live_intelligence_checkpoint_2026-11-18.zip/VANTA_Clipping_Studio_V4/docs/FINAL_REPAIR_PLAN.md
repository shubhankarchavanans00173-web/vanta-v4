# VANTA Final Repair Plan

Baseline (before any edit, 2026-10-28, Linux sandbox, Python 3.12, FFmpeg 6.1.1 with libass/x264):
`pytest backend/tests` -> **227 passed, 72 subtests, 154 s**. Backup of the V4 tree taken before editing.

Every defect lists: root cause (reproduced, not assumed) -> fix -> proving test.

## D1. Captions missing from exported MP4 (highest priority)

The captions pipeline itself is correct *when it has a transcript and libass has fonts*: a reproduction render
(`clip 4.2-12.0 s of a 12 s speech video, sentence SRT`) produced 41,841 changed pixels in the caption band versus a
captions-off render. The bug is that **four other paths ship an uncaptioned MP4 and still report success**:

| Path | Reproduced result | Root cause |
|---|---|---|
| A. captions on, no transcript | job SUCCESS, no captions | `build_track` returns an empty track; `render_clip` just records a note. |
| B. libass cannot load any font (empty fontconfig, as on many Windows FFmpeg builds) | FFmpeg exit 0, valid MP4, **0 caption pixels** | Success was defined as "exit 0 + ffprobe OK". Nothing ever looked at pixels. `-loglevel error` also hides libass font warnings. |
| C. long Whisper-style segment partly inside the clip | job SUCCESS, no `.ass` written | Sentence-level lines were dropped unless >=50% inside the clip. |
| G. transcript file moved / data dir changed | UI says "has transcript", render skips captions | `has_transcript = bool(transcript_path)` but loading silently returns `None` if the stored absolute path is outside the current data dir. |

Fix: captions requested => the render must *prove* them or fail. Fonts are prepared per job (bundled DejaVu +
requested font when found) and passed with a relative `fontsdir`; the ASS is probed on a neutral canvas (proves libass
draws glyphs) and then the finished MP4's frame is compared with that probe (proves glyph pixels are in the file).
Failures raise `CaptionError` with an actionable message and diagnostics are kept.

Tests: `tests/test_captions_render.py` (real FFmpeg; frame-pixel assertions), see docs/CAPTION_RENDERING.md.

(Remaining defects are appended below as they are fixed and verified.)

## 2026-11-18 repair pass — startup timestamp and URL-only chat reference

### Confirmed defects addressed
- `LiveStreamManager.add_chat()` now ignores incoming chat until the rolling media buffer has published its first segment. Previously, the stream clock returned `0.0` before the first segment; an early chat burst could therefore be accepted as an event at timestamp zero and cause VANTA to clip the unrelated opening of the stream.
- The live route now passes `_stream_ref(req)` to YouTube/Twitch chat adapters instead of the raw optional `req.stream_ref`. This allows a YouTube live URL to supply its video ID when the separate ID field is blank, and uses the resolved channel/video reference consistently.

### Verification performed in this repair pass
- `python -m pytest backend/tests/test_live_intelligence.py backend/tests/test_live_session_api.py -q` — **9 passed**.
- `python -m pytest backend/tests/test_live_chat_wiring.py -q -x` — **16 passed, 1 failed** because this execution environment does not have `google-api-python-client`, `google-auth`, and `google-auth-oauthlib` installed. The failing test expects the missing-token guidance but the code reports missing Google libraries first. This is an environment/dependency diagnostic, not proof that OAuth works.
- A broader live test command was started but exceeded the execution time limit after showing a failure; it was not fully verified.

### Still unverified / remaining work
- No live YouTube or Twitch stream was available for an end-to-end test in this environment.
- The media-only fallback/evidence producer is not implemented by this repair pass. Chat-only events remain explicitly labelled `chat activity`; this is not semantic understanding of video/audio.
- Multiple distinct candidate production over a long real stream has not been validated. Existing chat spike thresholds and deduplication may still limit event frequency; do not claim this is fixed.
- Actual clip relevance/quality must be reviewed against real stream footage. No model or deterministic heuristic can guarantee humour/context recognition without evidence and evaluation.
- Install the Google OAuth dependencies in the user's normal backend environment, then repeat credential and authorised live tests.

## 2026-11-18 live false-positive correction

- Reproduced the design path behind the unrelated GTA driving clip: chat spikes without corroborating `EvidenceEvent` data become `LiveEvent(kind="chat activity")`, and the review pipeline previously assembled them like any other event.
- Changed the review pipeline to reject chat-only event kinds before creating a clip job. The rejection is observable through pipeline status (`rejected_chat_only`, `last_rejection`); monitoring remains active.
- Added a regression test proving a chat-only spike creates no clip job.
- Important limitation: this archive still has no always-on live audiovisual semantic evidence producer. This correction prevents unsupported chat-only clips; it does not yet make VANTA understand jokes/gameplay. Implement and validate that producer as the next engineering phase.

### Verification

- `python -m pytest backend/tests/test_live_intelligence.py -q`: **6 passed**.
- `python -m pytest backend/tests/test_live_intelligence.py backend/tests/test_live_chat_wiring.py backend/tests/test_live_clip_api.py backend/tests/test_live_clip_handoff.py -q -k 'not missing_youtube_token_explains_what_to_do'`: **45 passed, 1 deselected**.
- The deselected credential diagnostic test cannot pass in this execution environment because optional Google OAuth client libraries are not installed; it reports the dependency-install instruction before reaching the missing-token message. This is an environment dependency issue, not a test of the chat-only gate.
- An earlier broader live test invocation exceeded the execution time limit; no full-suite pass is claimed.
