# VANTA V4 — Final completion status (2026-11-18)

## What this checkpoint guarantees

- Live clips remain review-only; no automatic publishing or upload is performed.
- Chat-only events (`chat activity`, `chat_activity`, `chat`) are rejected by the review pipeline. A chat burst without corroborating media evidence must not become an arbitrary clip.
- The live UI/API can show rejected-chat-only diagnostics through pipeline status.
- Existing media ingest, rolling buffer, chat adapters, review clip assembly, and manual promotion paths are retained.
- YouTube OAuth client configuration and token files are intentionally excluded from the archive. Preserve the local `data/secrets` directory when replacing the application folder.

## What is NOT complete or proven

The current implementation does **not** yet have a continuously running semantic audiovisual evidence producer. `event_correlator.py` can correlate chat with `EvidenceEvent` records, but the live session runner does not yet generate reliable transcript/audio/visual evidence from each ingested segment. Therefore:

- It cannot reliably understand jokes, punchlines, sarcasm, conversations, gameplay context, clutch plays, laughter, or visual reactions.
- Chat activity alone is deliberately insufficient to create a clip.
- A session may correctly produce zero clips if no corroborating media evidence is generated.
- The existing audio loudness envelope is a signal feature, not a laughter/emotion/humour classifier.
- No claim is made that a clip from the user's real YouTube stream has been evaluated as valuable.

## Remaining engineering work (ordered)

1. Implement a bounded media-evidence worker that consumes each closed segment exactly once, with a bounded queue and clear health/capability status.
2. Add local transcription integration only when a compatible model is already installed/configured. Do not download model weights automatically and do not call paid APIs.
3. Produce timestamped transcript events and audio evidence with source offsets; keep audio loudness separate from semantic labels.
4. Optionally add sampled-frame evidence only if a real local vision model is configured. Otherwise report visual analysis unavailable.
5. Correlate chat spikes with earlier evidence using configurable delay windows; do not create clips from chat-only events.
6. Add event-level deduplication so separate moments are retained while repeated evidence for the same moment is merged.
7. Add configurable multi-clip queue limits, cooldowns, clip quality gates, and session-level metrics.
8. Test on authorised real streams from YouTube and Twitch; rate candidate quality manually before tuning thresholds.
9. Verify the full frontend/backend suite, then build and inspect the release ZIP on Windows.

## Credential and safety handling

- Keep `data/secrets/client_secret.json`, `data/secrets/youtube_token.json`, `.env`, and Twitch credentials local and private.
- Do not paste OAuth client secrets, refresh tokens, API keys, or `.env` values into chat.
- OAuth consent screen in Testing mode only permits listed test users. Keep the Google account used for the channel on the test-user list.
- Preserve the user's local OAuth token across code updates. Re-authorisation is only needed if the token is missing, revoked, expired and cannot refresh, or scopes changed.
- Human review remains mandatory before promotion/export/publishing.

## Next-session instruction

Read this file, `docs/CONTINUE_LIVE_INTELLIGENCE.md`, and `docs/FINAL_REPAIR_PLAN.md`. Implement the media evidence producer as a separate bounded worker and write tests before wiring it into `LiveSessionRunner`. Do not claim VANTA is complete until actual segment-derived evidence is produced, multiple distinct moments are queued, clips are manually rated, and real YouTube/Twitch tests pass.
