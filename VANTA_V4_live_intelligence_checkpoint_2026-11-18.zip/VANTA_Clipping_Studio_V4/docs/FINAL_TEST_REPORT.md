# Final2 test report (2026-10-30)

# Session 13 (2026-11-17) — local review panel for live clips

Environment: **real Windows 11, Chrome/Chromium, FFmpeg 9.0.1**, app and API running locally. Files: new
`backend/app/clipstudio/live/clip_store.py`, `routes/live.py` (+3 endpoints), `live/review_pipeline.py` (sidecar writes,
shared promotion rule), `live/handoff.py` (`promotion_blocked`), `frontend/app/vanta/LiveView.tsx` (panel),
`backend/tests/test_live_clip_api.py` (8), `work/mutation_live_panel.py`.

| Item | Status | Evidence / limit |
|---|---|---|
| Clips from another process are visible | VERIFIED | sidecar written by the pipeline, listed by the API |
| No path over HTTP | VERIFIED | list payload has ids/metadata only; test asserts the media path is absent |
| Playback | VERIFIED | `GET .../file` 200 `video/mp4` (1,016,277 bytes) and `<video>` rendered in the panel |
| Promotion creates the project | VERIFIED | project `ddae6819fd11`, `source_type=live`, transcript attached, candidate `live-review` approved |
| One promotion per clip | VERIFIED | second POST -> 409 `blocked`; sidecar carries `project_id` |
| Review gate in the HTTP path | VERIFIED | `clip_store.promote(reviewed=False)` -> 400 `not_reviewed` |
| Refuses traversal / foreign paths | VERIFIED | id regex + `is_inside(clips)` test, sidecar one level up unreachable |
| Panel promotes and links into the workflow | VERIFIED (browser) | card showed `Project ddae6819fd11`; **Open in Create Shorts** selected the project, transcript and candidate visible |
| No publish / upload control | VERIFIED by inspection | panel has no such control; response has `published: false` |
| Bad id + transcript upload | VERIFIED | `..\..\evil` -> 404, `_save_upload` never called, no stray file |
| App live session takes a stream | VERIFIED | API session -> real FFmpeg ingest -> 12.1 s buffered, 3 segments (UI: pid 7724, 20 s, 5 segments) |
| Source refusals | VERIFIED | no source -> `source_required`; YouTube/Twitch watch page -> `not_a_media_stream` |
| Network live HLS ingest | VERIFIED (public HLS) | live playlist -> 3 segments / 12.1 s, `error: null`, clean stop; test streams HLS -> 8 segments / 32 s |
| YouTube live link ingest | VERIFIED (public, owner's link) | `youtube.com/live/63p6dc99He8` -> 15 segments / 60 s, segment `h264`+`aac`, signed URL never returned |
| Twitch live link ingest | NOT VERIFIED | resolver is shared, but no Twitch live link was run; Twitch chat is the credential-free path |
| YouTube live chat | NOT VERIFIED (no token) | `No YouTube OAuth token` reported on the session; connect YouTube first |
| Mutation checks | VERIFIED | 6/6 caught |
| Frontend build | VERIFIED | `npx tsc --noEmit` and `next build` clean |
| Real live session -> panel -> promote | NOT VERIFIED | needs real chat credentials (still none here); panel was exercised with a stored demo sidecar |

# Session 12 (2026-11-17) — reviewed live clip -> project with transcript and captions

Environment: **real Windows 11, Python 3.14.5, FFmpeg 9.0.1**. Files: new `backend/app/clipstudio/live/handoff.py`,
`live/review_pipeline.py` (+`promote`, review gate), `live/cli.py` (`--promote`/`--transcript`/`--title`, platform now
optional for promotion), `backend/tests/test_live_clip_handoff.py` (9), `work/mutation_handoff.py`.

| Item | Status | Evidence / limit |
|---|---|---|
| Promote creates a normal project | VERIFIED | `source_type=live`, copy inside `UPLOAD_DIR`, probe duration, `source_ref=job id` |
| Transcript stored where the app reads it | VERIFIED | `pipeline.transcript_available()` true; JSON reloaded; word-level preserved |
| Captions written and reusable | VERIFIED | standalone `.srt` next to the transcript, re-parsed by `load_transcript_file` |
| Candidate for the existing flow | VERIFIED | one `origin=live`, whole-clip candidate, approved (or suggestion on request) |
| Refuses unsafe input | VERIFIED | outside data folder, non-video, missing file, unavailable engine, no-caption transcript |
| Rollback on failure | VERIFIED | project row + source copy + JSON + SRT all removed |
| Review gate | VERIFIED | `reviewed=True` required; only `ready_for_review`; double promotion refused |
| Flows through analyze + render API | VERIFIED | promote -> `POST /analyze` -> `POST /render` -> export ffprobe 1080x1920 h264 |
| Mutation checks | VERIFIED | 6/6 caught (guard, engine refusal, review gate, id bug, SRT write, rollback) |
| Real speech transcription of a live clip | NOT VERIFIED | no local model on this machine; tests stub the engine, `--transcript` is the documented alternative |
| HTTP promotion endpoint | NOT DONE (deliberate) | would need the persisted clip registry first; no media paths over HTTP |

# Session 11 (2026-11-17) — Phase 5 step 2: real chat adapters wired to review-only clips

Environment: **real Windows 11, Python 3.14.5, FFmpeg 9.0.1**. Files: `live/youtube_adapter.py` (+`find_live_chat_id`, clock,
quota-aware interval), `live/twitch_adapter.py` (+`TwitchChatStream`), new `live/chat_sources.py`, `live/session_runner.py`,
`live/credentials.py`, `live/cli.py`, `live/review_pipeline.py` (submit race fix), `live/__init__.py`, new
`tests/test_live_chat_wiring.py`, two pipeline tests in `tests/test_live_ingest.py`, `.env.example`, docs.

| Item | Status | Evidence / limit |
|---|---|---|
| `activeLiveChatId` discovery | VERIFIED (fake transport) | Found from `videos().list(part=liveStreamingDetails)`; missing video, blank id and no-active-chat each raise an actionable `YouTubeAdapterError`; transport errors keep type + detail |
| YouTube adapter stamping + quota | VERIFIED (fake transport) | Messages carry the supplied stream clock; `pollingIntervalMillis` 9000 is honoured, 1 is clamped to 250; page token threaded |
| YouTube chat source | VERIFIED (fake transport) | `poll_once` delivers stamped messages and counts them; failures are recorded (`errors`, `last_error`) instead of raised; the polling thread starts and stops |
| Twitch IRC reader | VERIFIED (fake socket) | Anonymous `justinfan` nick; `PASS oauth:…` only when a token is given; `JOIN #channel`; PING answered with PONG; a split line is reassembled on the next read; RECONNECT, auth failure and a closed socket each raise with the right text; **never sends PRIVMSG** |
| Twitch chat source | VERIFIED (fake stream) | Reconnects once after a drop and then delivers; gives up after the reconnect budget (`failed: true`) |
| Stream clock | VERIFIED | `StreamClock` reads the buffer (0 before media, 12.0 for a 0–12 s segment, latency subtracted) |
| Credentials | VERIFIED | `TWITCH_CHANNEL`/`TWITCH_OAUTH_TOKEN`/`TWITCH_NICK` parsing (with `#` and `oauth:` prefixes); missing channel is actionable; YouTube diagnostics and Twitch diagnostics **never contain the secret** (asserted against the dumped JSON); missing token names the path and says to Connect YouTube |
| End to end | VERIFIED (Windows, real FFmpeg) | Scripted chat source + real paced stream + manager + pipeline → exactly one `ready_for_review` clip, `review_only: true`, `published: false`, ffprobe duration ≈5 s; the manager is wired to the pipeline |
| CLI | VERIFIED | Missing `--video-id`, missing `TWITCH_CHANNEL` and a missing media source each return exit code 2 with a one-line message and no traceback |
| Submit/drain race | VERIFIED | Fixed: thread started under the pipeline lock; `_join_started` cannot raise; new tests assert a submitted job's thread is already started and that concurrent submit+drain does not raise |
| Mutation checks | VERIFIED | 4/4 caught: stamping removed, runner not routing events, Twitch token never sent, discovery returning the video id |
| Full backend suite | VERIFIED (Windows) | **Ran 571 tests in 271.851s — OK (skipped=3)** |
| Real YouTube / Twitch credentials | **PARTIAL** | Fake transports only; no quota, moderation, ban, slow-mode or reconnect event tried |
| Real live video / Twitch channel | NOT VERIFIED | Media was a paced local file; platform HLS behaviour and throttling untested |
| Live clip UI | NOT VERIFIED | CLI + API objects only; nothing renders live clips in the frontend |

# Session 10 (2026-11-17) — Phase 5 step 1: local segment ingest + review-only live clips

Environment: **real Windows 11, Python 3.14.5, FFmpeg 9.0.1**. Files: new `live/segment_ingest.py`, `live/review_pipeline.py`,
`tests/test_live_ingest.py`; `live/rolling_buffer.py` (+`evict_oldest`), `live/__init__.py` (exports), `docs/LIVE_INGEST.md` (new).
No dependency added; no credential used or stored.

| Item | Status | Evidence / limit |
|---|---|---|
| Authorised-source validation | VERIFIED (Windows) | Existing local file and `http(s)`/`rtsp`/`rtmp(s)` URLs accepted; `""`, missing file, `concat:a\|b`, `pipe:0`, `file:///etc/passwd`, `ftp://`, `md5:abc` all raise `IngestError` |
| FFmpeg command construction | VERIFIED (Windows) | Argument list only (no shell); source is one argument after `-i`; `-re` only for local files; `-segment_list_flags +live`, `-segment_list_type csv`, `-reset_timestamps 1`, `seg_%05d.ts`; `-an` / `-c copy` modes |
| Atomic publication (no partial segments) | VERIFIED (Windows) | A partial (zero-byte) **unlisted** file, a listed zero-duration row, and a **listed zero-byte** row are all withheld; a listed complete segment publishes once and only once |
| Bounded disk + eviction | VERIFIED (Windows) | `max_bytes` evicts the oldest segment through `RollingBuffer.evict_oldest()` and deletes it; bytes stay under the cap |
| Safe cleanup | VERIFIED (Windows) | Retired media deleted inside the session folder; a buffer reference pointing outside is **refused** and recorded; list rows with `../../evil.ts` publish nothing and delete nothing; the ingest source survives; cleanup refuses while running and keeps the log |
| Ingest lifecycle | VERIFIED (Windows) | `stop()` terminates, publishes the final segment, and does not report a self-inflicted kill as an error; an FFmpeg that dies on its own reports the log tail |
| Real paced local stream | VERIFIED (Windows) | `ffmpeg -re` on a generated file → real segment muxer → real `RollingBuffer`: ≥3 segments, none empty, none overlapping, monotonic; source unchanged |
| Clip assembly from real segments | VERIFIED (Windows) | `LiveClipWorker.assemble` produced a real MP4 for a 6 s window; ffprobe duration within ±1.5 s; > 5 KB. Incomplete coverage returns `pending_post_event_footage`; a vanished segment raises `LiveClipError` |
| Detected event → review-only clip | VERIFIED (Windows) | Fake YouTube transport (fake Google client, paged) + real stream + manager + `LiveReviewPipeline`: one chat spike → exactly one job, `ready_for_review`, `review_only: true`, `published: false`, clip duration ≈5 s |
| Fake chat transports | VERIFIED (Windows) | YouTube paging (`pageToken` threaded), adapter errors surfaced as `YouTubeAdapterError` with the transport type/message; Twitch IRC parse with `user-id`/`user-type=bot`, `PING` ignored |
| Real YouTube / Twitch credentials | NOT VERIFIED / **PARTIAL** | Deliberately fake transports only; no quota, reconnect, moderation or ban event tested |
| Real live URL ingest | NOT VERIFIED | Only a paced local file was ingested; network connect, platform throttling and reconnects are untested |
| Live clip UI | NOT VERIFIED | Backend jobs only; nothing renders them in the frontend |
| Full backend suite | VERIFIED (Windows) | `cd backend && PYTHONPATH=. python -m unittest discover -s tests -t .` → **Ran 539 tests in 268.203s — OK (skipped=3)** |
| Mutation checks | VERIFIED (Windows) | 6/6 caught: empty partial segment published, deletion outside the session folder allowed, disk cap disabled, forced keyframes removed, background poller disabled, review clip reported as published. One mutation was initially **missed** (no test covered a listed-but-empty segment) → a test was added instead of accepting the gap. All restored; 20 tests green afterwards |

Two behaviours were found by tests rather than by reading code: (1) FFmpeg only cuts on keyframes, so a 2 s
`-segment_time` produced ~8 s segments until `-force_key_frames` was added; (2) nothing pumped the buffer while the
review pipeline waited, so the ingest now owns a publication poller thread.

### Review follow-up (same session): a clip could lose its segments mid-encode

Review found the real race: retention cuts and disk-cap eviction delete segment files, while `LiveClipWorker` reads
them, so a prune during an encode could fail or truncate the clip. Fixed with leases, and the verified behaviour from
above is unchanged (same 28-test module, same assertions; the PARTIAL chat labels are untouched).

| Item | Status | Evidence / limit |
|---|---|---|
| Window selection and pinning are atomic | VERIFIED (Windows) | `lease_window()` pins under the buffer lock; `SegmentLeaseTests` prove pin/release, context-manager release on exception, and reference counts. `window()` still pins nothing |
| Disk cap defers instead of deleting a pinned file | VERIFIED (Windows) | 3 × 3 MiB under an 8 MiB cap with the oldest pinned: file survives, `deferred_deletions` ≥ 1, then deletion happens on the next poll after release and `deleted_after_release` increments |
| Retention retirement defers the same way | VERIFIED (Windows) | Pinned 0–2 s segment survives the 15 s cutoff and is deleted one poll after unpinning |
| Assembly pins for the whole FFmpeg run | VERIFIED (Windows) | Real FFmpeg: a spy reads the concat manifest inside the encoder call and asserts every file is pinned at that moment, and that none is pinned after `assemble()` returns |
| Failed assembly releases its lease | VERIFIED (Windows) | `LiveClipError` path leaves no pin behind |
| Mutation checks for the fix | VERIFIED (Windows) | 3/3 caught: pinned segments deletable again, deferred deletions never retried, lease released before encoding |
| Full backend suite | VERIFIED (Windows) | **Ran 547 tests in 265.689s — OK (skipped=3)** — the 28 live tests plus the unchanged rest |

# Session 9 (2026-11-17) — Phase 3 steps 1-2: Unicode tokenisation + Hindi/Hinglish cues

Environment: **real Windows 11, Python 3.14.5**. Files changed: `backend/app/clipstudio/selection/lexicon.py` (tokeniser +
`TERMINAL`), `backend/app/clipstudio/selection/engine.py` (imports the language layer, adds `analysis.language_cues`, no scoring
change), new `backend/app/clipstudio/selection/languages/__init__.py` and `languages/hindi.py`, new `backend/tests/test_multilingual.py`
(16 tests) and `backend/tests/test_language_cues.py` (15 tests), docs.

| Item | Status | Evidence / limit |
|---|---|---|
| Unicode tokenisation, test-first | VERIFIED (Windows) | Before the change the new tests gave **7 failures + 1 import error**; `words("हिन्दी में लिखा है।")`, `words("मैं तो बहुत अच्छा खिलाड़ी हूँ")` and `content_words` were all `[]`, and `ends_terminal("...है।")` was `False`. After: 31 new tests OK. `हिन्दी` and `अच्छा` stay single tokens (matra + virama + nukta kept), `क्षत्रिय` is one token, decomposed and composed forms agree, `“bakwaas”`, `…`, emoji ZWJ sequences and U+200B separate words |
| English behaviour unchanged | VERIFIED (Windows) | Pure-ASCII input still runs `WORD.findall` (the original `[A-Za-z0-9']+`), so identity is structural; a test asserts `words`/`content_words`/`trigrams` equal the old pattern's output over 7 adversarial English strings (`don't`, `rock'n'roll`, `U.S.A.`, `C++`, `__init__`, `%`, `LOL`), and again over every text in `tests.vanta_fixtures.SCRIPT`. `ends_terminal` unchanged for `.` `?` `!` `…` |
| Cues reach the engine | VERIFIED (Windows) | A Hindi transcript through `engine.rank` yields candidate windows with transcript signals, measurable text features and a non-zero text value; the top candidate carries `language_cues` with matched words. English candidates report `language=None` |
| Cue evidence cannot change a score | VERIFIED (Windows) | Test patches `engine.languages.analyze_cues` with a deliberately absurd payload and asserts identical candidate scores; `weights_used` contains no language key |
| Hindi/Hinglish cue matching | PARTIAL | Unit-tested literal matching for eight categories (laughter, humour, banter, sarcasm, surprise, frustration, agreement, disagreement) in Devanagari and romanised forms, de-duplicated and deterministic; a single hit scores low confidence (0.40) and stays under 0.5. It is a small hand-written list, so recall on real Hinglish speech is **unmeasured** |
| Full backend suite | VERIFIED (Windows) | `cd backend && PYTHONPATH=. python -m unittest discover -s tests -t .` → **Ran 519 tests in 253.996s — OK (skipped=3)** |
| Mutation checks | VERIFIED (Windows) | 5/5 caught: tokeniser reverted to ASCII-only (8 failures), combining marks removed from the word categories (7), danda removed from `TERMINAL` (1), Hindi adapter claiming all text (1), banter cues emptied (1). All restored; 28 targeted tests green afterwards |
| Cue layer in the UI | NOT VERIFIED | The result is in the API payload and persisted with the candidate, but no component displays it and no browser check was run against it |
| Real Hindi YouTube transcript / ASR | NOT VERIFIED | Everything here used synthetic transcripts; no Whisper/yt-dlp Hindi run, so real Hinglish ASR spelling variance (`bakwas`/`bakwaas`, `yaar`/`yar`) is untested beyond the listed variants |
| Other scripts (Tamil, Bengali, Arabic, Cyrillic) | NOT VERIFIED | They now tokenise (Unicode categories are script-agnostic) but no cue list, fixture or test exists for them |

# Session 8 (2026-11-17) — Phase 2c steps 4-5, Phase 2d, real Windows verification

Environment: **real Windows 11 (win32), Python 3.14.5, Node 24.16.0, FFmpeg/FFprobe 9.0.1 (gyan full build), yt-dlp 2026.10.26**. Unlike every earlier session this was **not** a Linux sandbox, so the Windows items that were previously "NOT VERIFIED" were executed here.

Files changed: `frontend/app/vanta/CreateView.tsx` (now a 17 KB orchestrator + `CandidateCard.tsx`, `SourcePanel.tsx`, `ClipSettingsPanel.tsx`, `JobStrip.tsx`, `clipSettings.ts`, `useClipSettings.ts`), `frontend/app/legacy/page.tsx` (53 KB → 1.2 KB + `Sidebar`, `StudioHeader`, `CreatePanel`, `PreviewPanel`, `MetadataPanel`, `YouTubePanel`, `StoryboardPanel`, `HistoryPanel`, `ProviderPanel`, `useStudioState.ts`, `api.ts`, `types.ts`), `frontend/app/vanta/QueueView.tsx` (+`v-linkbtn` in `vanta.css`), `frontend/app/vanta/api.ts` (`Job.payload`), `backend/app/clipstudio/scheduler.py` (log handler), `backend/tests/test_frontend_split.py` (new), `backend/tests/test_resume.py` (+1 test), and six test files whose assertions were platform-specific (see below). Originals of every edited file are in `work/backups/2026-11-17-phase2c-step4/`.

| Item | Status | Evidence / limit |
|---|---|---|
| `CreateView.tsx` split, same behaviour | VERIFIED (Windows) | `npx tsc --noEmit` exit 0; `npm run build` exit 0; new `tests.test_frontend_split` 7 tests OK; real browser against the built app + real backend: project select, source `<video>`, candidate card with trim inputs, **Why selected** panel opens, clip-settings panel and render button render |
| `legacy/page.tsx` split, same behaviour | VERIFIED (Windows) | `tsc --noEmit` exit 0; `npm run build` lists `/legacy` (17 kB); browser: 4 `section.panel`s, 6 nav items, workflow switch changes `input_type` to `video_clips` and shows the clips panel, prompt editor accepts text, `#studio-settings` `<details>` toggles, `#studio-history`/`#studio-providers` anchors exist, **0 console errors** |
| Queue: continued-job indicator + link to the resumed job | VERIFIED (Windows) | Isolated data dir, real render job interrupted, backend restarted (`restart recovery: resumed 1, failed 0`). Queue shows `Interrupted by a backend restart; continued automatically as job 6da2c22d05cc.` + button `as job 6da2c22d ↓`, and on the resumed job `Continued from job 0deb5628 ↑ · resume 1`. Clicking the link applies the highlight: `outline: 2px solid var(--purple)` computed as **solid / 2px / rgb(139,108,255)** (first attempt used a non-existent `--pur` variable, so the flash was invisible — found by this browser check and fixed) |
| Queue: correct states, error and retry visibility | VERIFIED (Windows) | The pair above came from the real `db.recover_interrupted()` + `pipeline.startup()` path; the resumed render completed with a validated export. A failed job with no continuation now says why it was not resumed. `tests.test_resume` 15 OK (incl. new `QueueVisibility` API test) |
| Full backend suite on Windows | VERIFIED (Windows) | `cd backend && PYTHONPATH=. python -m unittest discover -s tests -t .` → **Ran 488 tests in 248.208s — OK (skipped=3)** |
| Captions rendering (never run in earlier sessions) | VERIFIED (Windows) | `python -m unittest tests.test_captions_render` inside the run above: 21 tests OK (real FFmpeg, frame-pixel assertions) |
| Browser click-through of the new UI paths | VERIFIED (Windows, local Chromium via the editor browser) | Queue pair + both splits, as described above; 0 console errors |
| Mutation checks | VERIFIED (Windows) | (1) `CreateView` no longer imports `SourcePanel` → 1 failure; (2) legacy hook stops providing a used binding → 1 failure; (3) `/jobs` stops returning `result` → `QueueVisibility` errors; (4) scheduler log handler reverted to a long-lived `FileHandler` → `tests.test_selection` teardown error returns. All four restored and re-verified green |
| Windows temp-folder lock bug | VERIFIED (Windows) | Root cause of a real failure here: the scheduler held `diagnostics/scheduler.log` open, so `TemporaryDirectory.cleanup()` failed with `WinError 32`. Replaced with a handler that opens the file per record (and detaches handlers bound to a previous data folder). This also lets a user move/delete the data folder while VANTA runs |
| Test-suite portability fixes | VERIFIED (Windows) | Six assertions were POSIX-only and failed here for real reasons (not suppressed): `/models` vs `\models`, `/x/a b; rm -rf.mp4` vs `\x\...`, `PosixPath` vs `WindowsPath` in the split snapshots, uppercase lambda addresses in signatures, a retired rating label (`weak`), a symlink that Windows refuses without a privilege. Each now compares platform-independently; the symlink and empty-fontconfig tests **skip with an explicit reason** instead of failing |
| `yt-dlp` for the link tests | VERIFIED (Windows) | Installed `yt-dlp 2026.10.26` (the package `enable_youtube_links.bat` installs); `tests.test_links_api` 18 OK against stub downloader processes |
| Real YouTube download / OAuth upload / Whisper model / scheduler task | NOT VERIFIED | Needs an authorised public video, Google credentials and a downloaded model; unchanged from earlier sessions |
| `verify_all.bat` and the other `.bat` launchers | NOT VERIFIED | Not executed in this session (they were not touched). Python entry points they wrap were |
| Real restart of a *running* render inside the same process tree | VERIFIED (Windows) | The interrupted job was created by a killed process state and resumed by a genuinely new backend process (`run.py`), which rendered a real MP4 |

Known limits of this session's verification: the browser checks used the desktop Chromium only (no other browsers or mobile widths), and the Queue pair came from a seeded throw-away data folder (`work/browser-check/`), never the user's `data/vanta`.

## Fixing the fresh baseline (what was already broken before this session)

The first full run here was **481 tests, 6 failures, 13 errors**. Every one was caused by the environment (Windows/Python 3.14/FFmpeg 9) or by stale assertions, not by this session's changes; each was fixed at its cause, and none by deleting or weakening a product assertion:

* `tests.test_links_api` (12 errors, 1 failure): the optional `yt-dlp` package was not installed in this interpreter, so the API answered `adapter_disabled` and the tests' `["job"]` lookup failed. Package installed; no test logic weakened.
* `tests.test_remaining_repair`: the dataset template test filled in `"weak"`, a label retired when the eight editor labels were introduced. Test now uses `"average"`.
* `tests.test_vanta_unit.PathSafetyTests`: `symlink_to` needs `SeCreateSymbolicLinkPrivilege` on Windows → the test skips with the OS error text instead of erroring.
* `tests.test_vanta_unit.RenderUnitTests`: a POSIX hostile path was asserted literally → now built with `Path`/`str()`.
* `tests.test_transcription`: asserted `"/models"` → now `str(Path("/models"))`.
* `tests.test_renderer_split` / `tests.test_ytdlp_split`: snapshots compared `PosixPath`/`WindowsPath` and lowercase-only memory addresses → normalised on both sides.
* `tests.test_check_captions` Hindi-box test: Windows does not use fontconfig, so its simulation cannot remove Devanagari and the check correctly reports real glyphs → skipped on Windows with that reason; still verified in the earlier Linux runs.


# Session 6 update (2026-11-03) - Phase 1: verification tooling

| Item | Status | Evidence / limit |
|---|---|---|
| `verify_all.py` classification (PASS/FAIL/SKIPPED, timeouts, exit codes) | VERIFIED (Linux) | `python -m unittest tests.test_verify_all` -> 26 tests OK |
| Secret/home-folder scrubbing in the report | VERIFIED (Linux, unit-level) | redaction tests; mutation "redaction disabled" made 3 tests fail |
| Skips never counted as passes | VERIFIED (Linux) | mutation "skip code -> PASS" made 2 tests fail |
| Scheduled task never touched | VERIFIED (unit-level) | test scans every built command in both modes |
| End-to-end run in Python mode | PARTIAL | subset only (--skip-network, 3 test modules); report written and readable |
| `verify_all.bat` and Windows command-line quoting | NOT VERIFIED | not executable in the Linux sandbox; run it on your PC |
| Live YouTube download, real Whisper, browser playback, live upload | NOT VERIFIED | unchanged; `verify_all.bat` is how you check the first two |
| Full backend suite in one run | NOT VERIFIED | `verify_all.bat` runs it module by module on your PC |

Manual step for you: run `verify_all.bat` (or `verify_all.bat --skip-tests` for a quick pass) and send back `verify_report.txt`.

## Phase 2c step 1 - router.py split (2026-11-03, session 7)

Files: `backend/app/clipstudio/router.py` (now an assembler), `backend/app/clipstudio/routes/*.py` (new), `backend/tests/test_router_split.py` and `backend/tests/data/vanta_routes_snapshot.json` (new). No behaviour change intended or made.

| Item | Status | Evidence / limit |
|---|---|---|
| Same API surface | VERIFIED (Linux) | whole-app OpenAPI captured before/after: 94 operations equal (method, path, operationId, tags); only a cosmetic schema component name differs (`YouTubeUploadRequest` now module-qualified) |
| Guard test | VERIFIED (Linux) | `cd backend && PYTHONPATH=. python -m unittest tests.test_router_split` -> 6 tests OK; snapshot taken from the original single file |
| Mutation checks | VERIFIED (Linux) | module dropped from mount loop -> 2 tests fail; route path renamed -> 1 fails; re-export removed -> 1 fails; files restored, 6/6 OK |
| Old import and patch paths | VERIFIED (Linux) | `tests.test_scheduler_upload` (7) patches `app.clipstudio.router.youtube_upload.*` and calls `router.upload_export_to_youtube` unchanged, OK |
| Regression modules (each run separately) | VERIFIED (Linux) | vanta_unit 57, envsettings 24, resume 14, job_states 12, core 17, metadata 11, selection 45, links_api 18, vanta_e2e 12, pro 18, video_providers 9, transcription 43, verify_all 26, remaining_repair 40, ingestion_audit 5, ytdlp 51 - all OK |
| `compileall -q backend`, pyflakes on new modules | VERIFIED (Linux) | clean |
| Pre-existing failing test fixed | VERIFIED (Linux) | `tests.test_final2_e2e_light` failed on the ORIGINAL code too (stale: `target_duration` 9 < API minimum 10; project detail `exports` is a list, not a count). Test corrected, now passes; `test_check_captions` 16 OK. `test_captions_render` not run this session |
| Frontend | NOT RE-RUN | no frontend file changed |
| Full suite in one run, Windows | NOT VERIFIED | unchanged limits |

## Phase 2b-UI - settings form (2026-11-03)

Files: `frontend/app/vanta/SettingsFields.tsx` (new), `SettingsView.tsx` (mounts it), `api.ts` (`ApiError.errors` keeps per-field 422 messages), `docs/ui_checks/settings_clickthrough.py` + `reseed_test_env.sh` (the click-through).

| Item | Status | Evidence / limit |
|---|---|---|
| Type check and production build | VERIFIED (Linux) | `cd frontend && npx tsc --noEmit` -> exit 0; `npm run build` -> exit 0 (routes `/`, `/_not-found`, `/legacy`) |
| Scripted browser click-through against the real backend and a temp `.env` (CRLF, comment, one secret) | VERIFIED (Linux, headless Chromium) | 32 checks, 0 failed: grouped fields; saved vs running; restart banner and per-field badge; password inputs; secret shows only "is set" and never appears in the page; invalid value -> per-field 422 error, nothing written (all-or-nothing, typed edits kept); valid save keeps CRLF and comments and writes `.env.bak`; bool/choice save; "Remove my override" deletes the line; secret replace and Clear; malformed secret rejected without echoing it; Discard edits; scheduler panel still renders; no console errors other than the 2 deliberate 422 responses |
| UI mutation checks | VERIFIED (Linux) | banner removed -> 1 check fails; "remove override" sends "" instead of null -> 4 fail; `errors` dropped from `ApiError` -> run fails at the per-field error assertion (caught by a 8 s timeout, not a clean assertion failure). Restored build -> 32/32. An earlier mutation run was INVALID (a stale `next-server` kept serving the old build) and was discarded and redone. |
| Backend regression | VERIFIED (Linux) | `compileall -q backend`; `tests.test_envsettings` 24, `tests.test_resume` 14, `tests.test_job_states` 12, `tests.test_vanta_unit` 57 - all OK |
| Real restart: saved value becomes the running value | NOT VERIFIED | the click-through never restarts the backend; do the Windows check below |
| Windows browser, other browsers, narrow/mobile layout | NOT VERIFIED | only desktop-width headless Chromium was used |
| The form is not covered by a unit-test runner (no Jest/Vitest in the project) | PARTIAL | coverage is the Playwright script, run by hand |

Windows check for you: open Settings, change "Download attempts" to 3 and Save; confirm the yellow "Restart required" banner appears and `.env` (and `.env.bak`) changed; run `stop_all.bat`, `start_all.bat`; reopen Settings and confirm the banner is gone and Running shows 3. Then set a test API key, Save, confirm the field only says "is set", click Clear, and confirm the line is gone from `.env`. Close Notepad on `.env` first (an open editor can block the write; the app then shows a clear error).

## Phase 2a - resumable renders and downloads (2026-11-03)

| Item | Status | Evidence / limit |
|---|---|---|
| Interrupted render/download continued as a new job; intact exports kept | VERIFIED (Linux) | `python -m unittest tests.test_resume` -> 14 tests OK (includes a real 160x90 FFmpeg render resumed via `pipeline.startup()` and ffprobe-valid export) |
| Truncated/missing export files are redone, not trusted | VERIFIED (Linux) | dedicated tests; mutation "ignore intact exports" -> 2 failures |
| Crash-loop cap | VERIFIED (Linux) | mutation "cap removed" -> 1 failure |
| Scheduler-owned jobs left to the scheduler retry path | VERIFIED (Linux) | mutation -> 1 failure; test_scheduler_upload 7 OK |
| Existing behaviour unchanged (`fail_interrupted`, job-state audit, links API) | VERIFIED (Linux) | test_job_states 12, test_vanta_unit 57, test_links_api 18 OK |
| Restarting the real backend process on Windows | NOT VERIFIED | start a render, close `start_backend.bat` window, start it again, open Queue |
| Queue wording for the failed-old / queued-new pair in a browser | NOT VERIFIED | no browser click-through |

## Phase 2b - editable settings API (2026-11-03)

| Item | Status | Evidence / limit |
|---|---|---|
| Validation, whitelist, local-only Ollama URL, all-or-nothing save | VERIFIED (Linux) | `python -m unittest tests.test_envsettings` -> 24 tests OK; 4 mutations caught |
| `.env` keeps comments, line endings, UTF-8 BOM / UTF-16, backup, atomic replace | VERIFIED (Linux, temp files) | dedicated tests incl. a simulated failed `os.replace` |
| Secrets never returned or echoed | VERIFIED (Linux, API + describe) | secret-leak mutation fails 2 tests |
| Settings form in the UI | VERIFIED (Linux, headless Chromium) - see Phase 2b-UI below | |
| Changes taking effect after a real restart; a `.env` open in Notepad | NOT VERIFIED | needs your PC |


This Final2 section is the current release record. Older session notes remain
below for traceability and are not the final feature/status statement.

## Verified in this release

* Frontend production build completed with Next.js 14.2.35.
* The dedicated Final2 scheduler/upload suite passed: 7 tests in 1.638 seconds.
  It covered disabled-by-default configuration, timezone
  validation, persistent queue uniqueness, retry/backoff, restart
  reconciliation, single-instance lock, pause/no-upload boundary, explicit
  upload confirmation, mocked quota failure and save-ID-only-after-success.
* check_system.bat ran through cmd.exe with VANTA_NO_PAUSE=1 and a selected
  Python 3.14 interpreter; it found FFmpeg, FFprobe and Node.js. Optional
  yt-dlp was honestly reported unavailable/disabled.
* The archive process verifies the ZIP manifest and extracts it into a new
  folder before release.

## Partially verified

* The complete backend command was attempted with workspace-local temporary
  state, but this execution environment terminates each command after 30
  seconds during the real-FFmpeg caption tests. It must be rerun on the target
  machine before it can be called a Final2 full-suite pass.
* VANTA import, attached-transcript analysis, explanation, approval, vertical
  captioned MP4 render, FFprobe validation, download and persistence have
  existing automated end-to-end coverage from prior sessions. A Final2 light
  real-media end-to-end check is included but was not completed here because
  of that same command limit.
* Windows launcher syntax and prerequisite detection were audited on Windows,
  but Task Scheduler creation was not executed because it changes a user's
  scheduled-task state.

## Unverified/manual requirements

* Live Google OAuth consent, refresh, quota handling against a real channel,
  resumable network upload and all public/unlisted/public visibility outcomes.
  No credentials or uploads were used. Test a private upload first.
* A real human-labelled clip-quality comparison. No labels are bundled and no
  ranker-quality improvement is claimed.
* A real faster-whisper model download/transcription, live authorised
  platform download, and physical browser click-through/video playback.
* The end-to-end workflow with a user-owned spoken-dialogue source video on
  the target Windows machine, including manual failure/retry observation.

# Historical repair reports

Environment: Linux sandbox, Python 3.12, FFmpeg 6.1.1 (libass, x264), yt-dlp 2026.10.26, faster-whisper installed. NOT Windows.

| Suite | Result |
|---|---|
| Baseline before edits (`pytest backend/tests`) | 227 passed |
| Final code, full backend suite | **248 passed**, 75 subtests, 518 s |
| New `tests/test_captions_render.py` (real FFmpeg, frame-pixel assertions) | 21 passed (included above) |
| Frontend `tsc --noEmit` | passed |
| Frontend `next build` | NOT RUN |

Existing tests changed: `test_vanta_e2e::test_03` (it asserted the buggy "captions on + no transcript = silent success" behaviour; now asserts failure, then success with captions off).

## Verified
Captions visible in exported MP4 (independent pixel diff vs captions-off render), absent when disabled; fail loudly with no transcript / no speech / unusable libass; works with an empty fontconfig; spaces/apostrophes/Unicode paths; 9:16, 1:1, 16:9; boxed, coloured and top-positioned styles; quote guard on 12 fixture clips; ratings migration preserves old rows.

## Not verified / not done
Real Windows run; `next build`; tests for `dataset_eval.py`, `quotes.py`, retry-includes-failed; YouTube ingestion changes; Whisper model run; thumbnails/metadata; scheduler; upload; job-state/UI audit; launcher audit; real human-labelled ranking evaluation (no claim of ranking improvement is made).

## Known limits
Frame check samples one time point per clip. Long sentence-level lines partly inside a clip are estimated splits. Synthetic (flite) speech used for test video.

# Update (session 2, 2026-10-29) - PARTIAL

| Item | Result |
|---|---|
| New `tests/test_remaining_repair.py` (dataset_eval, quotes, ratings migration, retry-includes-failed, transcript rebase) | 40 tests; 5 mutation checks each caught |
| `tsc --noEmit`, `next build` | passed |
| `tests/test_captions_render.py` after multi-point + fast-probe change | 21 passed, but took 447 s (partly contention; runtime not isolated) |
| `tests/test_check_captions.py` | see result line appended below |
| Windows `scripts\check_captions.bat` | NOT RUN on Windows |
| Full backend suite after this session | NOT RE-RUN |

Fixed: failed output validation raised FileNotFoundError (temp file unlinked before move). Changed: caption verification samples up to 4 moments.
Still not done: TODO 3-13 of docs/REMAINING_WORK_PROMPT.md.

Result line: `tests/test_check_captions.py` + `tests/test_remaining_repair.py` -> **56 passed** (388 s, Linux, FFmpeg 6.1.1).

## Phase 2c step 2 - ytdlp.py split (2026-11-04, session 7)

Files: `backend/app/clipstudio/ytdlp.py` (facade, 281 lines), `ytdlp_const.py`, `ytdlp_urls.py`, `ytdlp_errors.py`, `ytdlp_probe.py`, `ytdlp_proc.py` (new), `backend/tests/test_ytdlp_split.py`, `backend/tests/data/ytdlp_surface_snapshot.json` (new).

| Item | Status | Evidence / limit |
|---|---|---|
| Same module surface | VERIFIED (Linux) | 75 names (kind + normalised signature) compared with a snapshot taken from the original file: identical |
| Guard test | VERIFIED (Linux) | `cd backend && PYTHONPATH=. python -m unittest tests.test_ytdlp_split` -> 9 tests OK |
| Mutation checks | VERIFIED (Linux) | 5 mutations each failed >=1 test: re-export dropped, diagnostics bypassing facade `ffmpeg_info`, `base_command` bypassing `installed`, `--cookies` added, function copied not re-exported; code restored and re-verified |
| Existing patch targets still work | VERIFIED (Linux) | `test_ytdlp` 51 OK (same count as before the split), `test_links_api` 18 OK, `test_ingestion_audit` 5 OK |
| Whole backend, module by module | VERIFIED (Linux) | 21 modules OK (list in UPGRADE_STATUS.md); `test_captions_render` NOT run |
| `compileall -q backend`, pyflakes | VERIFIED (Linux) | compileall clean; pyflakes found 2 missing imports during the work, both fixed; the remaining "imported but unused" lines are intentional re-exports |
| Live YouTube download | NOT VERIFIED | sandbox cannot reach youtube.com; the split moved no network code but this was not run |
| Windows | NOT VERIFIED | not executed |

## Phase 2c step 3 - legacy renderer.py split (2026-11-04, session 7)

Files: `backend/app/renderer.py` (facade, 347 lines), `renderer_common/scenes/audio/validate/download/clips.py` (new), `backend/tests/test_renderer_split.py`, `backend/tests/data/renderer_surface_snapshot.json` (new). `pro_render.py` unchanged.

| Item | Status | Evidence / limit |
|---|---|---|
| Same module surface | VERIFIED (Linux) | 58 names (kind + normalised signature) identical to a snapshot of the original file |
| Guard test | VERIFIED (Linux) | `cd backend && PYTHONPATH=. python -m unittest tests.test_renderer_split` -> 8 tests OK |
| Mutation checks | VERIFIED (Linux) | 5 mutations each failed >=1 test; code restored and re-verified |
| Existing tests and patch targets | VERIFIED (Linux) | `test_core` 17 (patches `app.renderer.subprocess.run`, `_temporal_motion_score`), `test_pro` 18, `test_vanta_e2e` 12 OK |
| Whole backend, module by module | VERIFIED (Linux) | 22 modules OK; `test_captions_render` NOT run |
| Real AI-video-provider render | NOT VERIFIED | needs a provider and network |
| Windows | NOT VERIFIED | not executed |
