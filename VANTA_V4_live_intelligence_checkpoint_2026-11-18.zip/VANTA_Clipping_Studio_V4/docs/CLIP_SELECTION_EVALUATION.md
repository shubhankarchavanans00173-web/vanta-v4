# Clip-selection evaluation

Status: **tooling verified on synthetic/unit fixtures; human-quality result
unverified because no human-labelled real-video dataset was supplied.**

VANTA retains the original simple transcript heuristic (baseline) and compares
it with the multi-signal ranker. Neither score predicts views or virality.
Human judgement is required to make a quality claim.

## Create a blinded human label pool

Prepare a JSON list of authorised local videos:

    [
      {"id":"talk-001","duration":420,"transcript":"talk-001.srt","split":"dev"},
      {"id":"talk-002","duration":380,"transcript":"talk-002.srt","split":"test"}
    ]

Generate the union of top suggestions from both rankers:

    cd backend
    python evaluate_ranking.py --videos videos.json --export-pool labels-template.json --target 30 --k 5

Watch every pooled clip without being told which ranker proposed it. Fill each
label with one of excellent, good, weak, incomplete, repetitive, or
missing_context. Do not turn missing labels into failures or successes.

The generated JSON has dataset.kind set to human and may then be evaluated:

    cd backend
    python evaluate_ranking.py --dataset labels-template.json
    python evaluate_ranking.py --dataset labels-template.json --json

## Measures reported

For both baseline and multi-signal rankers, VANTA reports per dev and held-out
test split:

* rated share and human acceptance (excellent/good);
* precision at K and NDCG at K on rated overlap;
* recall at K only when good moments were exhaustively labelled;
* self-contained, repetitive, duplicate, duration/boundary, mid-thought and
  unfinished-ending rates.

The evaluator warns when there are fewer than 30 clips per split, labels are
incomplete, a test split is missing, or rules/weights were tuned on the same
split. Pooling candidates from both rankers reduces but does not remove pool
bias. Tune only on dev; quote test results for a comparison.

## Current honest result

docs/EVALUATION.md is a controlled synthetic-fixture comparison, written by
the developer. It is useful regression coverage for known bad stretches and
structural constraints, but is not evidence that editors prefer VANTA's
multi-signal clips. No real dataset or human labels are bundled in this
release, and no improvement claim is made.
