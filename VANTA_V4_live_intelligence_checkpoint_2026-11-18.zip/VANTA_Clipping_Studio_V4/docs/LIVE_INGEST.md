# Live ingest and review-only clips (Phase 5 step 1)

Live clipping in VANTA is **local, review-only and bounded**. It records nothing continuously that you did not
start, it never publishes anything, and it does not authenticate to any platform. This page describes exactly what
runs, what it refuses to do, and what has been verified versus what has not.

## What is implemented

| Piece | Module | What it really does |
|---|---|---|
| Segment ingest | `backend/app/clipstudio/live/segment_ingest.py` | Runs one local FFmpeg process that reads an operator-named source and writes short MPEG-TS segments into the session folder. A background poller publishes each segment to the rolling buffer **only after FFmpeg has closed it** (the `-segment_list` CSV is the authority, never a file-size guess). |
| Rolling buffer | `backend/app/clipstudio/live/rolling_buffer.py` | Keeps the most recent N seconds / segments. Retired segments are returned to the ingest, which deletes them inside its own folder. `evict_oldest()` exists for the disk cap. |
| Event detection | `chat_spike_detector.py`, `event_correlator.py` | Stateful chat-velocity spike detection with bot/copy-spam filtering, correlated to earlier transcript/audio/visual evidence when present. Chat alone is labelled `chat activity`, not a claim about the video. |
| Clip assembly | `live_clip_worker.py` | Concatenates the buffered segments and re-encodes the requested window to an MP4 with a real contextual boundary. Never runs on the request thread. |
| Review pipeline | `review_pipeline.py` | Subscribes to the session manager's events, waits (in a worker thread) until the configured post-event footage exists, then asks the worker for one clip per event and stores the job. |
| Chat adapters | `youtube_adapter.py`, `twitch_adapter.py` | YouTube Live Chat polling (5 quota units/call, honours the API's `pollingIntervalMillis`) and `activeLiveChatId` discovery; Twitch read-only IRC over TLS using only the standard library. **PARTIAL**: tested against fake transports only. |
| Chat sources | `chat_sources.py` | Own the polling/read loop, retries with backoff, reconnects, and stamp every message with **stream time** taken from the rolling buffer (`StreamClock`) so a spike lands where the media actually is. |
| Session runner | `session_runner.py` | Wires session → ingest → chat source → `LiveReviewPipeline` → one review-only clip per event. It creates no credentials and performs no platform login. |
| Terminal entry point | `cli.py` | `--check` validates credentials and chat without media; the normal run ingests the source, watches chat, prints events and clip paths, and stops on Ctrl+C. |

The intended chain is:

```
authorised source ──FFmpeg segment muxer──► buffer (bounded, atomic publication)
                                             │
      chat (authorised adapter) ─► spike ─► correlate with evidence ─► LiveEvent
                                             │
                            LiveReviewPipeline waits for post-event footage
                                             │
                                  LiveClipWorker.assemble ─► review-only MP4
```

## Safety and bounds

* **Authorised sources only.** `resolve_source` accepts an existing local file, or an explicitly named
  `http(s)`/`rtsp`/`rtmp(s)` URL. It rejects `file://`, `concat:`, `pipe:`, `md5:` and any other FFmpeg protocol
  string, so a crafted value cannot reach FFmpeg's protocol layer. No discovery, no credential handling, no
  attempts to bypass login/region/DRM.
* **Argument lists, never shell strings.** `build_command` returns a list; the source is a single argument after
  `-i`, so it cannot inject flags.
* **Atomic publication.** A segment enters the buffer only when it appears in the segment list with a positive
  duration *and* its file is non-empty. A partially written file is never assembled.
* **Bounded writes.** The buffer keeps `buffer_seconds` (15–600) and `max_segments`; the ingest additionally
  enforces `max_bytes` (default 512 MiB) by evicting and deleting the oldest segment — see *A clip can never lose its
  segments* below.
* **Safe cleanup.** Deletion is refused unless the path resolves inside that session's `segments/` folder; names
  in the segment list are reduced to their basename, so a list row cannot point elsewhere. Refusals are recorded
  in `status()["refused_deletions"]`. The source file is never touched. A file a clip is currently reading is never
  deleted: see below.

## A clip can never lose its segments

Retention cuts and the disk cap both delete files, and `LiveClipWorker` reads files — the two could previously collide:
pruning during an encode could delete a segment FFmpeg still had open, failing the clip or truncating it.

That is closed by leases:

1. `RollingBuffer.lease_window(...)` selects the window **and** pins its segments under the buffer lock, so a segment
   cannot be pinned a moment after the check that would have let it be deleted.
2. `LiveClipWorker.assemble()` holds that lease for the whole FFmpeg run (including a failed run) and releases it in
   a `finally` block.
3. `SegmentIngest` takes the same lock before deleting. If the segment is pinned, the deletion is **deferred** —
   recorded in `status()["deferred_deletions"]` and retried after every poll, and on `cleanup()` — and the byte-cap
   loop moves on to the next oldest segment instead.

Consequences worth knowing: while a clip is assembling, the disk cap can be exceeded temporarily by that clip's window
(at most `before_seconds + after_seconds` of media); `status()["deleted_after_release"]` counts files freed later.
Pin counts are reference-counted, so two concurrent assemblies of the same segment are safe.

Tested by: `SegmentLeaseTests` (pin/release, context manager, refcounts), two ingest tests (cap and retention both
defer while pinned, then delete after release), a real-FFmpeg test that inspects the concat manifest inside the encoder
call and asserts every file is pinned during the run and unpinned afterwards, and a failed-assembly test that proves
the lease is released even when FFmpeg raises.
* **Review-only.** The pipeline never renders captions, never writes to the export table and never uploads. Every
  job reports `review_only: true`, `published: false`, `publishing: "manual approval only"`.
* **Forced keyframes.** The ingest asks FFmpeg for a keyframe on every segment boundary (`-force_key_frames`).
  Without it a 2 s request produced ~8 s segments and post-event footage arrived late or never — found by a real
  test, not by reading the code.

## Using it

```python
from pathlib import Path
from app.clipstudio.live import (IngestConfig, LiveClipWorker, LiveReviewPipeline, LiveStreamManager, SegmentIngest)

manager = LiveStreamManager()
session = manager.start("manual", "operator-authorised-source", buffer_seconds=90, post_event_seconds=8)
ingest = SegmentIngest(Path("data/vanta/live/session-1"), session.buffer,
                       IngestConfig(source="C:/captures/stream.mp4", segment_seconds=2))
pipeline = LiveReviewPipeline(manager, LiveClipWorker(Path("data/vanta/live/clips")), before_seconds=30)
manager.on_event = pipeline.on_event

ingest.start()                       # starts FFmpeg and the publication poller
# ... an authorised adapter feeds manager.add_chat(session.id, ChatMessage(...)) ...
print(pipeline.jobs(session.id))     # one job per detected event
ingest.stop()                        # terminate FFmpeg, publish the final segment
ingest.cleanup()                     # delete this session's segments only
```

## Start a session in the app

**Live Intelligence → Start authorised monitoring** starts the same runner the CLI uses:

| Field | What it takes |
|---|---|
| Platform | `YouTube` (chat needs the OAuth token), `Twitch` (chat is read anonymously), or `Manual` (no chat adapter) |
| Reference | optional: the YouTube **live video id** or Twitch **channel name**. Leave it empty and it is taken from the link |
| Source | a **YouTube/Twitch live link**, the stream's direct **HLS/RTSP/RTMP URL**, or the path of a **local capture file** you own |

The source is validated before anything starts. With no source the request is refused (`source_required`).

### A platform link is resolved locally, not bypassed

A watch page is not a media file, so it is resolved with the **local yt-dlp** (`studio/ytdlp.py`, the same tool the
Video Links feature uses) and only when platform links are enabled (`VANTA_ENABLE_YTDLP=1`). Otherwise the request is
refused with `platform_links_disabled` and a hint. yt-dlp decides what is public: a private, members-only, age-gated or
DRM-protected stream fails with the tool's own reason (`resolve_failed`), never a workaround. Nothing signs in.

A live YouTube stream is published as **two HLS playlists** (video-only and audio-only), so `live/stream_source.py`
returns both and one FFmpeg ingest maps `0:v:0` + `1:a:0` into the same MPEG-TS segments - clips keep their sound. The
resolved URLs are signed and short-lived: they are **never logged and never returned to the browser**; the session
shows the page link the operator typed.

Starting a session spawns one FFmpeg segment ingest; the card then shows `Ingest: running (pid N) · n segment(s)`,
the buffer in seconds and the chat adapter state. **A chat failure never stops the ingest**: the reason (for example a
missing YouTube token) is shown on the session and clips simply wait for chat events. `Stop` ends chat first, then
FFmpeg; the application shutdown hook also stops every ingest this process started, so no FFmpeg outlives the backend.

Verified on this machine: the API session took a paced local file through real FFmpeg, published segments, filled the
buffer, and stopped cleanly (`backend/tests/test_live_session_api.py`, 4 tests). A live network HLS playlist filled 3
segments / 12.1 s with `error: null` before a clean stop. A **real YouTube live link**
(`https://www.youtube.com/live/63p6dc99He8`) started from both the API and the form: ingest `running`, 15 segments /
60 s buffered, every sampled segment `h264` + `aac`, and the payload's `ingest.source` was the page link - no signed URL.
YouTube chat stayed off in that run (`No YouTube OAuth token`), so no candidates were produced: connect YouTube first.

## Run it with your own credentials

Chat integrations stay **PARTIAL** until you have actually run them against your own account. Here is exactly what to
provide and what to run. Nothing below sends, moderates, uploads or publishes; the adapters only read.

### YouTube Live Chat

| What | Value / file |
|---|---|
| OAuth client JSON | `data/secrets/client_secret.json` (or point `YOUTUBE_CLIENT_SECRET_FILE` at it) — the same file the uploader uses |
| OAuth token | `data/secrets/youtube_token.json`, created when you click **Connect YouTube** in the app (override with `YOUTUBE_TOKEN_FILE`) |
| Scope | live chat reading needs `youtube.readonly`; VANTA already requests that on connect. If Google answers `403 insufficientPermissions`, disconnect and reconnect YouTube |
| Video | the live video id (`--video-id`) or its `activeLiveChatId` (`--chat-id`) |

```bat
cd backend
set PYTHONPATH=.
rem 1) credential + chat check only: no media, no clip, one quota call per poll
python -m app.clipstudio.live.cli --check --platform youtube --video-id YOUR_LIVE_VIDEO_ID

rem 2) real run: your own authorised media source (local capture file, or an authorised HLS/RTMP URL you control)
python -m app.clipstudio.live.cli --platform youtube --video-id YOUR_LIVE_VIDEO_ID --source "C:\captures\my-stream.mp4" --buffer 90 --before 30 --after 8
```

Quota: `liveChatMessages.list` costs **5 units per call**. VANTA honours the server's `pollingIntervalMillis`
(clamped to 0.5–10 s), so a 1 s interval would burn the 10,000/day quota in under an hour — leave it at the default.

### Twitch IRC

| What | Value |
|---|---|
| Channel | `--channel NAME` or `TWITCH_CHANNEL=name` (**required**) |
| Token | `TWITCH_OAUTH_TOKEN` — optional, scope `chat:read`. Without it VANTA connects anonymously (`justinfan…`) for public chat |
| Nick | `TWITCH_NICK` — optional display name for the authenticated connection |

```bat
cd backend
set PYTHONPATH=.
python -m app.clipstudio.live.cli --check --platform twitch --channel YOUR_CHANNEL
python -m app.clipstudio.live.cli --platform twitch --channel YOUR_CHANNEL --source "C:\captures\my-stream.mp4"
```

Twitch is spoken over TLS on `irc.chat.twitch.tv:6697` using `socket` + `ssl` only (no extra package). The
connection joins one channel and never sends `PRIVMSG`; a test asserts that.

### What a run prints

`live: {...}` when the session starts, `event: {...}` for each detected moment, `clip: {status, path}` when an assembly
finishes, and `done: {clips: [...], ready: N, review_only: true, published: false}` at the end. Clips go to
`--output` (default `<data>/live/clips`). Useful flags: `--seconds N` to stop automatically, `--json` for machine-readable
lines, `--buffer/--before/--after/--segment` for timing.

### What is still PARTIAL, and what would change that

* Both adapters have only been exercised with **fake transports** (a fake Google client, a fake IRC socket) and a scripted
  chat source. No real credential, quota error, moderation event, ban, slow-mode or reconnect has been tried here.
* No real live video or Twitch channel was ingested: the media path was a paced local file. Network HLS reconnect and
  platform throttling are untested.
* The first successful `--check` against your own account, followed by one real spike producing one clip, is what moves
  the label from PARTIAL to verified. If either fails, the printed error is the thing to send me.

## Verified on this machine (Windows 11, FFmpeg 9.0.1)

* A **real, paced local stream** (`ffmpeg -re` on a generated file, so the segment muxer runs in real time) feeds
  a real rolling buffer: segments arrive progressively, do not overlap, and are non-empty.
* The assembled clip is a real MP4: ffprobe reports the requested window within ±1.5 s, file > 5 KB.
* A detected chat spike from a **fake YouTube transport** produces exactly **one** review-only clip; its job says
  `ready_for_review`, `published: false`.
* 28 tests in `backend/tests/test_live_ingest.py`; 9/9 mutation checks caught across both rounds (see
  `docs/FINAL_TEST_REPORT.md`).

## Not verified / PARTIAL

* **Chat integrations are PARTIAL.** YouTube Live Chat and Twitch IRC are exercised only through fake transports
  (a fake Google client and hand-written IRC lines). No real credential, quota, reconnect or moderation event has
  been tried here. Your own authorised test is what makes them verified.
* A public **network HLS** source was ingested through the app: `https://demo.unified-streaming.com/k8s/live/stable/scte35.isml/.m3u8`
  produced 3 segments / 12.1 s buffered, and `https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8` produced 8 segments /
  32 s buffered, both `ingest.error: null`, both stopped cleanly.
* A **public YouTube live link** was ingested through the app (`youtube.com/live/63p6dc99He8`): 15 segments / 60 s,
  sampled segment `h264` + `aac`. Twitch live links use the same resolver but were **not** run; a token-protected HLS
  URL given directly (without a page link) is still the operator's problem to supply.
* Deleted/expired segments, mid-stream resolution changes, and streams longer than the buffer are untested.
* Windows path/permission edge cases beyond the tested ones (for example a segment file locked by an antivirus
  scanner for longer than a poll) are unhandled: a failed delete is silently retried on the next retirement.

## Promote a reviewed clip into a normal project

The live pipeline only assembles review-only files. `live/handoff.py` is the one-way bridge into the normal product:

```
cd backend
set PYTHONPATH=.
python -m app.clipstudio.live.cli --promote "data\vanta\live\clips\<job>.mp4" --title "Big laugh"
# or, without a local speech model, attach a transcript you already have:
python -m app.clipstudio.live.cli --promote "data\vanta\live\clips\<job>.mp4" --transcript "clip.srt"
```

It copies the clip into the upload folder, stores the transcript and a standalone `.srt` (`<data>/transcripts/<project>.srt`),
and adds one candidate covering the whole clip. From then on the project behaves like any other: analyze with the
existing engine, approve/edit, render, export, add publish metadata. Nothing is uploaded and `published` stays `false`.

Rules that are enforced (not just documented):

* the clip must be a playable video **inside VANTA's data folder** - an HTTP caller cannot import an arbitrary path;
* a transcript is mandatory - from the local engine or an attached file - so the project can actually be captioned;
* in code, `LiveReviewPipeline.promote(job_id, reviewed=True)` refuses anything that is not `ready_for_review`, refuses
the same job twice, and requires the explicit human-review flag;
* every failure rolls back the project row, the copied media, the transcript JSON and the SRT.

Verified on this machine: promote -> `POST /projects/{id}/analyze` -> `POST /projects/{id}/render` produced a real
1080x1920 h264 export (9 tests, 6/6 mutations).

### Reviewing clips in the app

**Live Intelligence → Review live clips** lists every clip the pipeline assembled - including clips produced by the CLI
in another process, because each job writes a JSON sidecar next to the clip (`<data>/live/clips/<job id>.job.json`).
The panel plays the clip and offers **Promote reviewed clip**; the optional transcript box is only needed when no local
speech model is installed. After promotion the card shows the new project id and an **Open in Create Shorts** button
that selects the project in the normal clip workflow (transcript, candidate, render, export).

Backend endpoints (local only, no credentials, no publish/upload):

* `GET /api/vanta/live/clips` - id, event, status, duration, `file_ready`, `project_id`; never a media path;
* `GET /api/vanta/live/clips/{id}/file` - the assembled MP4, resolved server-side and refused outside the clips folder;
* `POST /api/vanta/live/clips/{id}/promote` - optional `transcript` upload and `title`; refuses a clip that is not
  `ready_for_review`, refuses a second promotion, and records `project_id`/`candidate_id` on the sidecar.

Verified on this machine (real Windows, real FFmpeg): the panel rendered a stored clip with working playback, promotion
through the API produced a project + approved candidate, the card refreshed to `Project <id>`, and **Open in Create
Shorts** loaded that project with its transcript and candidate. 8 API tests + 5/5 mutation checks. **Real speech transcription of a live clip is NOT verified here**: no
local model is installed, so tests stub the engine; use `--transcript` or install a model first. There is no HTTP
promotion endpoint yet on purpose - that needs the persisted clip registry, otherwise it would accept media paths.
