# VANTA continuation — semantic live highlight engine

## Current checkpoint
Read `docs/FINAL_DELIVERY_STATE.md` first. The live runner now has a bounded FFmpeg PCM audio-intensity worker. It deliberately does not call loudness laughter, humour, excitement, or gameplay. Chat-only events remain rejected.

## Next required engineering work
1. Wire the existing local Whisper transcription provider into a bounded, cached segment-analysis queue. Only use an already installed library and locally cached model; never download automatically. Keep CPU/int8 as default and expose progress/capability.
2. Build timestamped transcript windows with surrounding context; add deterministic event signals for punchline structure, reactions, conversational payoff, repeated laughter words, and gaming vocabulary, with language-aware handling. These are candidate signals, not ground truth.
3. Correlate chat spikes to prior transcript/audio events over configurable latency windows. Chat may boost confidence but may never create a clip without media evidence.
4. Deduplicate by event time + evidence fingerprint, not event kind alone. Permit multiple distinct events in one stream.
5. Add an opt-in local vision adapter only when a supported model is already installed and configured. Sample frames sparsely; otherwise report unavailable.
6. Rank clips by evidence quality, context completeness, duration, overlap, repetition, and transcript quality. Return several independent candidates subject to a configurable cap, not one clip per session.
7. Keep every result review-only. Promotion requires explicit human review. Publishing remains separate and manual.
8. Add synthetic end-to-end fixtures with known event times, run full backend tests, frontend typecheck/build, and real authorised stream testing on Windows.

## Known compatibility issue
An older test in `tests/test_live_ingest.py` expects a chat-only burst to create a clip. This is now intentionally incompatible with the safety rule. Update that test to assert rejection and continue monitoring; do not weaken the guard to satisfy the old assertion.

## Hardware constraints
Target the user's GTX 1650 4GB / 16GB RAM machine. CPU/int8 is the safe transcription fallback. No paid API calls, no implicit model downloads, no auto-publishing, no credentials in release archives.
