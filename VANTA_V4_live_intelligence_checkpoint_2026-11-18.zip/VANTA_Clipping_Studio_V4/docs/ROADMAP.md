# Status and what is left

## VANTA reliability (2026-11-17, real Windows)
Phase 2 is complete: router/ytdlp/renderer/`CreateView`/legacy-page splits, resumable render+download jobs surfaced in the
Queue (with a link between the interrupted job and its continuation), editable settings, and a green backend suite
(488 tests, 3 documented skips) plus a clean TypeScript build and a real browser click-through.

Phase 3 steps 1-2 are done (session 9): `selection/lexicon.py` tokenises Unicode text (Devanagari matras/virama, danda as a
sentence end) with ASCII/English output proven identical, and `selection/languages/` reports Hindi/Hinglish surface cues per
candidate **without** feeding the score. Still open in Phase 3: wiring cues into scoring with weights you can inspect, richer
joke setup/payoff and reaction intelligence, the rank-weights editor, Ollama reranking as a scored stage, and the human-feedback
summary (needs >= 30 labelled clips).

Phase 5 steps 1-2 are done (sessions 10-11): a local FFmpeg segment ingest feeds the rolling buffer with atomic, bounded
publication and safe in-folder cleanup; real YouTube Live Chat (polling + `activeLiveChatId` discovery) and Twitch IRC
(TLS, read-only, stdlib) sources stamp messages with stream time and drive the review pipeline, which turns one detected
event into one review-only MP4. A terminal entry point (`python -m app.clipstudio.live.cli`, `--check` first) runs it
(`docs/LIVE_INGEST.md`). Chat adapters remain **PARTIAL** until they are exercised with the operator's own credentials;
no real live URL has been ingested and there is no live UI yet.

Still not started (each needs the user's approval): smarter boundaries and explainable weighted scoring, multimodal event
correlation, real authorised YouTube/Twitch chat wiring, NVENC and reframing adapters, local-LLM
metadata. See `CONTINUATION_PROMPT.md` for the ordered plan.

## Done in V3
Studio Pro renderer (stock/animated visuals, neural voice, word-synced captions, transitions, ducking, loudness, thumbnails),
LLM script writer (Ollama/Claude, optional), long-form up to 10 min, YouTube OAuth + resumable upload, chapters, credits, `.env` config, tests.

## Not done / ideas (in priority order)
1. **Live verification of network features** (Pexels, edge-tts, YouTube upload, Ollama/Claude) with real credentials - written to the official contracts and mock-tested only.
2. Per-scene visual editing UI: pick a different stock clip, paste your own clip/image per scene, edit the search phrase in the form (the field exists in the data).
3. Speech-to-text for Video-to-Clips (auto captions on uploaded footage), e.g. `faster-whisper`.
4. Hook-first "cold open" template and branded intro/outro slots.
5. Batch queue / daily scheduler (create N videos from a topic list).
6. Pixabay/own-library footage sources, AI image generation per scene (Replicate/Flux) as an optional paid visual source.
7. Analytics pull-back from YouTube (views, retention) to tune titles.
