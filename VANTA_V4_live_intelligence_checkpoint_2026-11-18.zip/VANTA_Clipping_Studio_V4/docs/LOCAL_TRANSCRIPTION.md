# Local transcription (faster-whisper)

## Final2 status

Local transcription remains optional and local-first. The Final2 scheduler
does not trigger model download, transcription, ingestion or paid services;
it renders only clips that a user previously approved.

Free, offline after a one-time model download, no cloud service. Implemented in `backend/app/clipstudio/whisper_local.py`
(engine wrapper in `transcript.py`, job integration in `pipeline._auto_transcribe`).

## Status: what is verified and what is not
| Item | Status |
|---|---|
| Model discovery, consent gate, device planning, word-timing hygiene, progress, cancel, CUDA->CPU retry, transcript cache, child-process downloader, full analysis job through the HTTP API | **Verified on Linux with a stub model** (`tests/test_transcription.py`, 43 tests, 7 mutations caught) |
| Downloader failure path against the real Hugging Face host | **Verified once** in the test sandbox: host unreachable -> classified as "network", partial folder removed |
| faster-whisper 1.2.1 installs; `WhisperModel.transcribe` accepts the keyword arguments used; `TranscriptionInfo` has `duration`/`language` | **Verified** (signature inspection) |
| A real model downloading and transcribing real speech (accuracy, speed, memory, word timings) | **NOT verified** - the sandbox cannot reach Hugging Face. Run `scripts\check_transcription.bat` on your PC. |
| CUDA on a GTX 1650 | **NOT verified**; CPU int8 is the default and recommended path. |
| Windows launchers (`enable_local_transcription.bat`, `scripts\check_transcription.bat`) | **NOT run on Windows** |

## Rules the code follows
* **No implicit download.** Analysis jobs never touch the network. A model is downloaded only after the user confirms it
  (`POST /api/vanta/transcription/models/download` with `confirm: true`; the UI shows the approximate size first). Only the known model
  names in `MODEL_INFO` are accepted, never arbitrary hub repositories.
* **Default: `small`, CPU, int8** (suits 16 GB RAM, with or without a GTX 1650). CUDA is used only when a CUDA runtime is found *and* the model is
  tiny/base/small, or when you force `VANTA_WHISPER_DEVICE=cuda`. If CUDA fails while running, the job is retried once on the CPU and a note says so.
* **Word timestamps only when real.** They come from the engine; malformed ones (end before start, far outside the segment, overlapping) are dropped.
  If any segment has no words the transcript is sentence-level and captions say so.
* **Real progress and cancel.** Progress = decoded audio position / audio duration; cancel is checked after every segment. A cancelled job saves no transcript.
* **Cache.** A finished transcript is stored under `<data>/transcripts/cache/` keyed by a content fingerprint (size + first/middle/last MiB) + model + language,
  so the same video in another project is not transcribed again (even if the model was removed since). Deleting a project removes its cache entry;
  "Clear saved transcripts" in AI Models (or `DELETE /api/vanta/transcription/cache`) removes all.
* **Fallbacks.** No library / no model / no audio / engine error -> a note on the job, ranking continues with audio and scene signals (labelled), and you can upload `.srt`, `.vtt` or `.json`.
  An uploaded transcript always wins over automatic transcription.
* **Model download** runs in a child process (so Cancel really stops it), checks free disk space first, classifies network / disk-full / incomplete errors, and removes partial files on cancel or failure.

## Setup
1. `enable_local_transcription.bat` installs the library into the backend's Python (no model is downloaded).
2. Restart VANTA, open **AI Models -> Transcription**, choose a model, click **Download**, confirm.
3. Make it the default with `VANTA_WHISPER_MODEL=<name>` in `.env` (see `.env.example`). Models live in `<data>/vanta/models/whisper` (`VANTA_WHISPER_CACHE` to move).

Approximate download sizes (MB, from the model repositories, rounded): tiny 75, base 145, small 485, medium 1530, large-v3 3090, large-v3-turbo 1620.
Speed and memory numbers are intentionally not listed: they have not been measured here. `check_transcription.py` prints a measured real-time factor for your PC.
For non-English audio use a multilingual model (not `*.en`); tiny/base are weak for most non-English speech (general knowledge, not measured here).

## Check it on your machine
```
scripts\check_transcription.bat                         status only, no network
scripts\check_transcription.bat --download tiny         asks first, ~75 MB
scripts\check_transcription.bat --file "D:\talk.mp4"    transcribes the first 60 s; prints segments, word-timing flag, real-time factor
```
Please send back the output: it settles the "NOT verified" rows above.

## API
`GET /api/vanta/transcription/status`, `POST /transcription/models/download {model, confirm}`, `POST /transcription/models/download/cancel`, `DELETE /transcription/cache`.
`POST /projects/{id}/analyze` accepts `whisper_model` (a known name) and `language`.

## Known limits
Whole files are decoded by faster-whisper in one pass (very long videos take long on CPU; there is no chunk-level resume). Language is auto-detected unless given.
The download progress bar is an estimate (bytes on disk vs approximate size). Speaker separation is not provided.
