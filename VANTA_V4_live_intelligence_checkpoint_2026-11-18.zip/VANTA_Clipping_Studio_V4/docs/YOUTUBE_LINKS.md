# Video links (YouTube and other public videos) — setup, diagnosis, fallback

> `docs/YOUTUBE_SETUP.md` is about *uploading* finished shorts to YouTube. This page is about *downloading a source video from a link*.

VANTA only fetches videos you **own or are authorised to use**. It never bypasses private, login, age-gated, DRM, paywalled or region-blocked
videos, and it never reads browser cookies. Everything runs locally and free; no paid API is involved.

## 1. Enable it (once, Windows)

1. Run `setup_backend.bat` (if you have not already), then `enable_youtube_links.bat`.
   It installs `yt-dlp[default]` into **the same Python the backend uses** (`C:\ai-video-env` if present), sets `VANTA_ENABLE_YTDLP=1` in `.env`, and prints a diagnostic report.
2. Install **FFmpeg** (`winget install Gyan.FFmpeg`, then reopen the terminal) — needed to merge video+audio and to validate downloads.
3. Install **Node.js 20+** (https://nodejs.org). YouTube hides its stream URLs behind a JavaScript challenge; yt-dlp needs a JS runtime (Node 20+, Deno 2+ or Bun 1+) to solve it. VANTA detects the runtime itself and passes it to yt-dlp. The solver scripts (`yt-dlp-ejs`) come with `yt-dlp[default]`, so nothing is fetched from the internet at download time.
4. `stop_all.bat`, then `start_all.bat` (the backend reads `.env` only at start).
5. Open **Video Links → Diagnostics**. Every line should be `ok`.

Accepted YouTube forms (all collapse to one canonical URL, so the same video is never added or downloaded twice):
`youtube.com/watch?v=ID`, `youtu.be/ID`, `youtube.com/shorts/ID`, `youtube.com/embed/ID`, `youtube-nocookie.com/embed/ID`, `m.`/`music.` hosts.
Playlist, channel, search and `@handle` pages are rejected with a clear message — paste one video.

## 2. How a link becomes clips

`Add link` → URL validated and normalised → project created → **download job** (shown in Create Shorts and the Processing Queue, with real % from yt-dlp) →
file written to a *staging* folder → checked with `ffprobe` (playable, has video, duration within limit) → moved to `data/vanta/sources/<project>/source.mp4` → registered.
Only then can you Analyze. Failures remove the staging folder; a half-written or unplayable file is never registered. **Retry download** never re-downloads when a valid local copy already exists.
Analyze on a linked project that has no file yet downloads it first; if analysis later fails, the error says the video is saved and re-analysis will not download it again.

## 3. Updating yt-dlp (correctly)

Use **Video Links → Update yt-dlp**, or run by hand with the exact interpreter VANTA uses (shown in Diagnostics):

```bat
C:\ai-video-env\Scripts\python.exe -m pip install --upgrade --upgrade-strategy only-if-needed "yt-dlp[default]"
```

The button runs a `pip --dry-run` first (a resolver conflict changes nothing), then the real upgrade, then asks the new yt-dlp for its version, and shows
`previous → new version` plus the executable it updated and any *other* package pip changed. No restart is needed: every download starts a fresh `python -m yt_dlp`.
It is refused while a download is running. VANTA never upgrades your whole environment and never touches a global Python.

## 4. Reading the error you get

| Code shown | Meaning | What to do |
|---|---|---|
| `unavailable` | Deleted/removed/wrong link | Open it in a browser; upload the file if you own it |
| `login_required` | Private, members-only, age/login-gated | Not bypassed. Upload a copy you may use |
| `bot_check` | YouTube asked for human verification | Wait, try another network, or upload |
| `live_unavailable` | Live stream, or recording not ready | Retry after YouTube finishes processing, or upload a recording |
| `geo_blocked`, `drm` | Region block / DRM | Not bypassed. Upload |
| `rate_limited`, `server_error`, `access_denied` | Temporary refusal (HTTP 429/5xx/403) | Wait and Retry |
| `network_error`, `timeout` | DNS / proxy / TLS / slow connection | Check connection, VPN, antivirus HTTPS scanning; Retry |
| `extraction_failed`, `format_unavailable` | yt-dlp could not read YouTube's player (often missing/old JS runtime, or old yt-dlp) | Diagnostics → install Node 20+, Update yt-dlp, Retry |
| `ffmpeg_missing` | FFmpeg/ffprobe not on PATH | `winget install Gyan.FFmpeg`, reopen terminal, restart VANTA |
| `disk_full`, `permission_denied` | Cannot write the download folder | Free space / fix permissions |
| `too_large`, `too_long` | Over `VANTA_MAX_REMOTE_BYTES` / `VANTA_MAX_DURATION_SECONDS` | Raise the limit in `.env` or use a shorter video |
| `invalid_media` | Download finished but is not playable video (discarded) | Retry, or upload |
| `unknown_error` | VANTA could not identify the cause | Read the *Diagnostic details*, run diagnostics |

The "Python 3.10 … Please update to Python 3.11" line that yt-dlp prints is a **warning about the Python version**. It is cosmetic for downloads and is
ignored by the classifier. (Before V3 it was mistaken for "yt-dlp is outdated" and shown for *every* failure.)

## 5. Test a public video for real

```bat
diagnose_youtube.bat https://www.youtube.com/watch?v=jNQXAC9IVRw
```
(“Me at the zoo”, the first YouTube video, 19 s.) It downloads the file for real into a temp folder, validates it with `ffprobe`, prints title/duration/size, then deletes it.
Exit code 0 = success. Or in the app: Video Links → paste the URL → tick the rights box → *Check link & download*.
**Do not use `--simulate` as proof**; it never downloads media.

## 6. Local-file fallback (always works)

Create Shorts → **Upload video**. Everything after upload (transcript attach/transcription, analysis, ranking, editing, rendering, captions, export) is identical.
You can also attach an existing `.srt`, `.vtt` or JSON transcript.

## 7. Optional `.env` settings

| Setting | Default | Purpose |
|---|---|---|
| `VANTA_ENABLE_YTDLP` | `1` in `.env.example` | `1/true/yes/on` enables platform links |
| `VANTA_YTDLP_TIMEOUT` | `1800` | Seconds before a download is stopped (60–86400) |
| `VANTA_YTDLP_ATTEMPTS` | `2` | Max automatic tries for *transient* errors only (network/timeout/5xx), 1–4 |
| `VANTA_YTDLP_JS_RUNTIME` | auto | `node`, `node:C:\Program Files\nodejs\node.exe`, `deno`, `bun`, `quickjs`, or `none` |
| `VANTA_YTDLP_REMOTE_COMPONENTS` | off | Advanced: `ejs:github` or `ejs:npm` lets yt-dlp fetch solver scripts instead of the bundled `yt-dlp-ejs` |
| `VANTA_YTDLP_AUTO_SUBS` | off | `1` also fetches YouTube auto-captions (lower quality; more rate-limit risk). Manual subtitles are always fetched |
| `VANTA_MAX_REMOTE_BYTES` | 1 GiB | Download size cap |

## 8. Python 3.10 → 3.11/3.12 (optional)

Not required to fix download failures. Every backend dependency (`fastapi`, `uvicorn`, `pydantic`, `Pillow`, `pyttsx3`, `python-multipart`, `httpx`, `edge-tts`, Google client libs, `yt-dlp`) supports 3.11 and 3.12, and the whole VANTA test suite was run on **3.12**.
`faster-whisper` (optional) also publishes 3.12 wheels but was **not** tested here. To try it safely: run `migrate_python_env.bat`. It creates `C:\ai-video-env-py312` next to your current environment, installs requirements, runs the tests, and switches nothing.
To switch: create `python_env.txt` containing `C:\ai-video-env-py312\Scripts\python.exe`. To switch back: delete that file. Your old environment is never deleted.

## 9. Known limits

* Platform downloads are best effort; YouTube changes often and any given video may still fail (use the diagnostics + Update, then the upload fallback).
* Jobs run one at a time (a long download delays rendering); cancel from the Processing Queue.
* Live streams and not-yet-processed recordings cannot be downloaded.
* Windows `.bat` scripts and the Windows-specific process-tree kill (`taskkill`) could not be executed in the Linux test sandbox.
