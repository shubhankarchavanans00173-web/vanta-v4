# Connect your YouTube channel (one-time, ~5 minutes)

1. Open https://console.cloud.google.com and create a project (any name).
2. **APIs & Services -> Library** -> search **YouTube Data API v3** -> **Enable**.
3. **APIs & Services -> OAuth consent screen**: choose *External*, fill the app name and your email, then under **Test users** add the Google account that owns your channel. (Leave the app in *Testing* - that is fine for personal use. Tokens issued in Testing mode expire after 7 days, so you may need to click *Connect YouTube* again weekly. Publishing the consent screen removes that limit.)
4. **APIs & Services -> Credentials -> Create credentials -> OAuth client ID** -> Application type **Desktop app** -> Create -> **Download JSON**.
5. Save the file as `data/secrets/client_secret.json` inside this project (or point `YOUTUBE_CLIENT_SECRET_FILE` in `.env` to it).
6. Restart the backend, create/open a finished video, scroll to **Publish to YouTube** -> **Connect YouTube**, sign in and allow access.

## Good to know
* Default visibility is **Private**. Google restricts uploads from API projects that have not passed their compliance audit to private; publish from YouTube Studio, or apply for the audit via the YouTube API Services form if you want fully automatic public posting.
* Quota: default 10,000 units/day; one upload = 1,600.
* Custom thumbnails require a phone-verified channel.
* Tick *Disclose altered / synthetic content* when voice or visuals are AI-generated and realistic.
* Never commit `data/secrets/` or `.env`; both are in `.gitignore`.
